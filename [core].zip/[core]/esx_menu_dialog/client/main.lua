-- SPDX-License-Identifier: GPL-3.0-only
-- Copyright (C) 2022-2026 ESX Framework

local OpenedMenus, MenuType = {}, "dialog"

local function openMenu(namespace, name, data)
    OpenedMenus[namespace .. "_" .. name] = true

    xLib.nui.send({
        action = "openMenu",
        namespace = namespace,
        name = name,
        data = data,
    })

    xLib.timeout.setTimeout(200, function()
        if next(OpenedMenus) then
            xLib.nui.focus(true, true)
        end
    end)
end

local function closeMenu(namespace, name)
    OpenedMenus[namespace .. "_" .. name] = nil

    xLib.nui.send({
        action = "closeMenu",
        namespace = namespace,
        name = name,
    })

    if not next(OpenedMenus) then
        xLib.nui.focus(false, false)
    end
end

ESX.UI.Menu.RegisterType(MenuType, openMenu, closeMenu)

AddEventHandler("esx_menu_dialog:message:menu_submit", function(data)
    local menu = ESX.UI.Menu.GetOpened(MenuType, data._namespace, data._name)
    local cancel = false

    if not menu then
        return
    end

    if menu.submit then
        -- is the submitted data a number?
        local value = tonumber(data.value)
        if value then
            data.value = ESX.Math.Round(value)

            -- check for negative value
            if tonumber(data.value) <= 0 then
                cancel = true
            end
        end

        data.value = ESX.Math.Trim(data.value)

        -- don't submit if the value is negative or if it's 0
        if cancel then
            ESX.ShowNotification("That input is not allowed!")
        else
            menu.submit(data, menu)
        end
    end
end)

AddEventHandler("esx_menu_dialog:message:menu_cancel", function(data)
    local menu = ESX.UI.Menu.GetOpened(MenuType, data._namespace, data._name)

    if not menu then
        return
    end

    if menu.cancel ~= nil then
        menu.cancel(data, menu)
    end
end)

AddEventHandler("esx_menu_dialog:message:menu_change", function(data)
    local menu = ESX.UI.Menu.GetOpened(MenuType, data._namespace, data._name)

    if not menu then
        return
    end

    if menu.change ~= nil then
        menu.change(data, menu)
    end
end)
