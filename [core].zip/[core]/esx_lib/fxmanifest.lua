-- SPDX-License-Identifier: GPL-3.0-only
-- Copyright (C) 2022-2026 ESX Framework

fx_version 'cerulean'
game 'gta5'

use_experimental_fxv2_oal 'yes'
lua54 'yes'

author 'ESX-Framework'
description 'Official ESX library'
version '1.0.0'
legacyversion '1.16.3'

ui_page 'html/medal.html'

files {
    'imports.lua',
    'imports/**/client.lua',
    'imports/**/shared.lua',
    'html/medal.html',
    'html/medal.js',
}

shared_scripts {
    'config.lua',
    'resource/init.lua',
    'resource/**/shared.lua',
}

client_scripts {
    'resource/**/client.lua',
}

server_scripts {
    'resource/**/server.lua',
}



