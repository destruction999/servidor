-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts


local QBCore = nil
local ESX = nil
local CoreName = GetResourceState("qb-core") == "started" and "qb-core" or 
                 GetResourceState("qbx_core") == "started" and "qbx_core" or 
                 GetResourceState("es_extended") == "started" and "es_extended" or nil

if CoreName == "qb-core" or CoreName == "qbx_core" then
    local success, core = pcall(function()
        return exports[CoreName]:GetCoreObject()
    end)
    if success then QBCore = core end
elseif CoreName == "es_extended" then
    ESX = exports["es_extended"]:getSharedObject()
end

if not QBCore then
    QBCore = {
        Functions = {
            CreateCallback = function(name, cb)
                if lib and lib.callback then
                    lib.callback.register(name, cb)
                end
            end,
            GetPlayer = function(source)
                if ESX then
                    return ESX.GetPlayerFromId(source)
                end
                return nil
            end,
            GetPlayers = function()
                if ESX then
                    return ESX.GetPlayers()
                end
                return {}
            end,
            GetPlayerByCitizenId = function(identifier)
                if ESX then
                    return ESX.GetPlayerFromIdentifier(identifier)
                end
                return nil
            end,
            CreateUseableItem = function(name, cb)
                if ESX then
                    ESX.RegisterUsableItem(name, cb)
                end
            end,
            Notify = function(source, text, type, length)
                if ESX then
                    local player = ESX.GetPlayerFromId(source)
                    if player then
                        player.showNotification(text)
                    end
                end
            end
        }
    }
end

local cacheData = {
    report = {},
    clothing = {},
    job_grades = {},
    job_perms = {},
    job_vaults = {},
    job_logs = {},
    evidence_scans = {}
}

local playerData = {
    cuffed = {},
    gsr = {},
    status = {},
    communityService = {},
    duty = {},
    dutyHistory = {}
}

local evidenceData = {}
local evidenceIdCounter = 1

local function SafeGetPlayerName(source)
    return GetPlayerName(source) or "Unknown"
end

local function ValidateSource(source)
    return source and GetPlayerName(source) ~= nil
end

local function GetStableIdentifier(source)
    if QBCore and QBCore.Functions and QBCore.Functions.GetPlayer then
        local player = QBCore.Functions.GetPlayer(source)
        if player and player.PlayerData and player.PlayerData.citizenid then
            return "qb:" .. player.PlayerData.citizenid
        end
    elseif ESX then
        local player = ESX.GetPlayerFromId(source)
        if player and player.identifier then
            return "esx:" .. player.identifier
        end
    end
    
    local identifiers = GetPlayerIdentifiers(source)
    for _, id in ipairs(identifiers) do
        if string.find(id, "license:") == 1 then return id end
    end
    for _, id in ipairs(identifiers) do
        if string.find(id, "license2:") == 1 then return id end
    end
    for _, id in ipairs(identifiers) do
        if string.find(id, "fivem:") == 1 then return id end
    end
    
    return "src:" .. tostring(source)
end

local function GetPlayerCid(source)
    if CoreName == "es_extended" and ESX then
        local player = ESX.GetPlayerFromId(source)
        return player and player.identifier or nil
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = exports[CoreName]:GetCoreObject().Functions.GetPlayer(source)
        return player and player.PlayerData and player.PlayerData.citizenid or nil
    end
    return GetStableIdentifier(source)
end

local function GetPlayerJob(source)
    if CoreName == "es_extended" and ESX then
        local player = ESX.GetPlayerFromId(source)
        if player and player.job then
            return player.job.name, player.job.grade or 0
        end
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = exports[CoreName]:GetCoreObject().Functions.GetPlayer(source)
        if player and player.PlayerData and player.PlayerData.job then
            return player.PlayerData.job.name, player.PlayerData.job.grade.level or 0
        end
    end
    return nil, nil
end

local function GetDiscordId(source)
    for _, id in ipairs(GetPlayerIdentifiers(source)) do
        if string.sub(id, 1, 8) == "discord:" then
            return string.sub(id, 9)
        end
    end
    return nil
end

local function LoadAllData()
    cacheData.report = {}
    
    MySQL.Async.fetchAll('SELECT * FROM frkn_pd_reports', {}, function(reports)
        for _, report in ipairs(reports or {}) do
            table.insert(cacheData.report, {
                id = report.id,
                job = report.job,
                phone = report.phone,
                report = report.report,
                anonymous = report.anonymous,
                created_at = report.created_at
            })
        end
        
        MySQL.Async.fetchAll('SELECT * FROM frkn_pd_cloth', {}, function(clothing)
            for _, cloth in ipairs(clothing or {}) do
                table.insert(cacheData.clothing, {
                    id = cloth.id,
                    name = cloth.name,
                    data = json.decode(cloth.data or "{}"),
                    created_at = cloth.created_at
                })
            end
            
            MySQL.Async.fetchAll('SELECT * FROM frkn_pd_job_grade_perms', {}, function(perms)
                for _, perm in ipairs(perms or {}) do
                    table.insert(cacheData.job_perms, {
                        id = perm.id,
                        job_grade_id = perm.job_grade_id,
                        can_hire = perm.can_hire,
                        can_promote = perm.can_promote,
                        can_view_balance = perm.can_view_balance,
                        can_withdraw = perm.can_withdraw,
                        can_manage_evidence = perm.can_manage_evidence,
                        can_read_report = perm.can_read_report
                    })
                end
                
                MySQL.Async.fetchAll('SELECT * FROM frkn_pd_job_grades', {}, function(grades)
                    for _, grade in ipairs(grades or {}) do
                        table.insert(cacheData.job_grades, {
                            id = grade.id,
                            job_name = grade.job_name,
                            grade = grade.grade,
                            label = grade.label,
                            payment = grade.payment,
                            is_boss = grade.is_boss
                        })
                    end
                    
                    MySQL.Async.fetchAll('SELECT * FROM frkn_pd_vaults', {}, function(vaults)
                        for _, vault in ipairs(vaults or {}) do
                            table.insert(cacheData.job_vaults, {
                                id = vault.id,
                                station = vault.station,
                                vault = vault.vault
                            })
                        end
                        
                        MySQL.Async.fetchAll('SELECT * FROM frkn_pd_vaults_log', {}, function(logs)
                            for _, log in ipairs(logs or {}) do
                                table.insert(cacheData.job_logs, {
                                    id = log.id,
                                    station = log.station,
                                    action = log.action,
                                    name = log.name,
                                    amount = log.amount,
                                    update_date = log.update_date
                                })
                            end
                            
                            MySQL.Async.fetchAll('SELECT * FROM frkn_evidence_scans ORDER BY id DESC LIMIT 200', {}, function(scans)
                                for _, scan in ipairs(scans or {}) do
                                    table.insert(cacheData.evidence_scans, {
                                        id = scan.id,
                                        evidence_id = scan.evidence_id,
                                        type = scan.type,
                                        container = scan.container,
                                        street = scan.street,
                                        created = scan.created,
                                        citizenid = scan.citizenid,
                                        victim = scan.victim,
                                        shooter = scan.shooter,
                                        shot = scan.shot,
                                        memo = scan.memo,
                                        source_identifier = scan.source_identifier,
                                        inserted_at = scan.inserted_at
                                    })
                                end
                                
                                TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
                            end)
                        end)
                    end)
                end)
            end)
        end)
    end)
end

RegisterNetEvent('frkn-policejob:getData')
AddEventHandler('frkn-policejob:getData', LoadAllData)

RegisterNetEvent('frkn-policejob:dataPostClient')
AddEventHandler('frkn-policejob:dataPostClient', function()
    TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
end)

AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        Wait(1000)
        TriggerEvent('frkn-policejob:getData')
    end
end)

RegisterNetEvent('frkn-policejob:deleteReport')
AddEventHandler('frkn-policejob:deleteReport', function(reportId)
    if not reportId then return end
    
    MySQL.query('DELETE FROM frkn_pd_reports WHERE id = ?', {reportId}, function()
        for i, report in ipairs(cacheData.report) do
            if tonumber(report.id) == tonumber(reportId) then
                table.remove(cacheData.report, i)
                break
            end
        end
        TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
    end)
end)

RegisterNetEvent('frkn-policejob:reportSubmit')
AddEventHandler('frkn-policejob:reportSubmit', function(data)
    local source = source
    if type(data) ~= "table" then return end
    
    local job = data.job or "Unknown"
    local phone = data.phone or "Unknown"
    local report = data.report or ""
    local anonymous = data.anonymous == false and SafeGetPlayerName(source) or 1
    local created = os.date("%Y-%m-%d %H:%M:%S")
    
    MySQL.insert('INSERT INTO frkn_pd_reports (job, phone, report, anonymous, created_at) VALUES (?, ?, ?, ?, ?)',
        {job, phone, report, anonymous, created},
        function(insertId)
            if insertId then
                table.insert(cacheData.report, {
                    id = insertId,
                    job = job,
                    phone = phone,
                    report = report,
                    anonymous = anonymous,
                    created_at = created
                })
                TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
            end
        end
    )
end)

RegisterNetEvent('frkn-policejob:deleteClothing')
AddEventHandler('frkn-policejob:deleteClothing', function(clothId)
    if not clothId or clothId == "" then return end
    
    MySQL.update.await('DELETE FROM frkn_pd_cloth WHERE id = ?', {clothId})
    
    for i, cloth in ipairs(cacheData.clothing) do
        if tonumber(cloth.id) == tonumber(clothId) then
            table.remove(cacheData.clothing, i)
            break
        end
    end
    
    TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
end)

RegisterNetEvent('frkn-policejob:saveClothing')
AddEventHandler('frkn-policejob:saveClothing', function(name, data)
    if not name or name == "" or type(data) ~= "table" then return end
    
    local created = os.date("%Y-%m-%d %H:%M:%S")
    local encoded = json.encode(data)
    
    MySQL.insert('INSERT INTO frkn_pd_cloth (name, data, created_at) VALUES (?, ?, ?)',
        {name, encoded, created},
        function(insertId)
            if insertId then
                table.insert(cacheData.clothing, {
                    id = insertId,
                    name = name,
                    data = data,
                    created_at = created
                })
                TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
            end
        end
    )
end)

local validPermissions = {
    can_hire = true,
    can_promote = true,
    can_view_balance = true,
    can_withdraw = true,
    can_manage_evidence = true,
    can_read_report = true
}

RegisterNetEvent('frkn-policejob:updateGradePerm')
AddEventHandler('frkn-policejob:updateGradePerm', function(data)
    local source = source
    local key = tostring(data.key or "")
    local value = tonumber(data.value) == 1 and 1 or 0
    local gradeId = tonumber(data.job_grade_id)
    
    if not validPermissions[key] then return end
    
    local job, grade = GetPlayerJob(source)
    if not job then return end
    
    local permIndex = nil
    for i, perm in ipairs(cacheData.job_perms) do
        if tonumber(perm.job_grade_id) == gradeId then
            permIndex = i
            break
        end
    end
    
    if permIndex then
        cacheData.job_perms[permIndex][key] = value
        MySQL.update.await(string.format('UPDATE frkn_pd_job_grade_perms SET %s=? WHERE job_grade_id=?', key), {value, gradeId})
    else
        local newPerm = {
            can_hire = 0,
            can_promote = 0,
            can_view_balance = 0,
            can_withdraw = 0,
            can_manage_evidence = 0,
            can_read_report = 0
        }
        newPerm[key] = value
        
        local insertId = MySQL.insert.await(
            'INSERT INTO frkn_pd_job_grade_perms (job_grade_id, can_hire, can_promote, can_view_balance, can_withdraw, can_manage_evidence, can_read_report) VALUES (?,?,?,?,?,?,?)',
            {gradeId, newPerm.can_hire, newPerm.can_promote, newPerm.can_view_balance, newPerm.can_withdraw, newPerm.can_manage_evidence, newPerm.can_read_report}
        )
        
        newPerm.id = insertId
        newPerm.job_grade_id = gradeId
        table.insert(cacheData.job_perms, newPerm)
    end
    
    TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
end)

RegisterNetEvent('frkn-policejob:server:CuffPlayer')
AddEventHandler('frkn-policejob:server:CuffPlayer', function(targetId, isSoftcuff, cuffType, isHandcuffed)
    local source = source
    
    if isHandcuffed then
        
    else
        
    end
    
    TriggerClientEvent('frkn-policejob:client:GetCuffed', targetId, source, isSoftcuff, cuffType, isHandcuffed)
end)

RegisterNetEvent('frkn-policejob:server:SetHandcuffStatus')
AddEventHandler('frkn-policejob:server:SetHandcuffStatus', function(isCuffed, item, pos)
    local source = source
    local cid = GetPlayerCid(source)
    
    if isCuffed then
        playerData.cuffed[cid] = {
            cuffed = true,
            item = item,
            pos = pos
        }
    else
        playerData.cuffed[cid] = nil
    end
end)

RegisterNetEvent('frkn-policejob:server:EscortPlayer')
AddEventHandler('frkn-policejob:server:EscortPlayer', function(targetId)
    local source = source
    TriggerClientEvent('frkn-policejob:client:GetEscorted', targetId, source)
end)

RegisterNetEvent('frkn-policejob:server:isEscortingPlayer')
AddEventHandler('frkn-policejob:server:isEscortingPlayer', function(escorterId, targetId)
    TriggerClientEvent('frkn-policejob:client:setEscortStatus', targetId, escorterId)
end)

RegisterNetEvent('frkn-policejob:server:PutPlayerInVehicle')
AddEventHandler('frkn-policejob:server:PutPlayerInVehicle', function(targetId)
    TriggerClientEvent('frkn-policejob:client:PutInVehicle', targetId)
end)

RegisterNetEvent('frkn-policejob:server:SetPlayerOutVehicle')
AddEventHandler('frkn-policejob:server:SetPlayerOutVehicle', function(targetId)
    TriggerClientEvent('frkn-policejob:client:SetOutVehicle', targetId)
end)

RegisterNetEvent('frkn-gsr:server:shot')
AddEventHandler('frkn-gsr:server:shot', function()
    local source = source
    playerData.gsr[source] = {
        has = true,
        ts = os.time()
    }
end)

RegisterNetEvent('frkn-gsr:server:clear')
AddEventHandler('frkn-gsr:server:clear', function()
    playerData.gsr[source] = nil
end)

RegisterNetEvent('frkn-gsr:server:has')
AddEventHandler('frkn-gsr:server:has', function(targetId)
    local source = source
    local hasGSR = false
    
    if targetId and playerData.gsr[targetId] then
        if playerData.gsr[targetId].has then
            local elapsed = os.time() - (playerData.gsr[targetId].ts or 0)
            if elapsed <= 600 then 
                hasGSR = true
            end
        end
    else
        playerData.gsr[targetId] = nil
    end
    
    TriggerClientEvent('frkn-gsr:client:hasResult', source, targetId or 0, hasGSR)
end)

CreateThread(function()
    while not FRKN do Wait(1000) end 
    while true do
        Wait((FRKN and FRKN.GSRCleanInterval) or 60000)
        local now = os.time()
        for source, data in pairs(playerData.gsr) do
            if data.ts and (now - data.ts) > 600 then
                playerData.gsr[source] = nil
            end
        end
    end
end)

local function GetCommunityServiceCount(source)
    return tonumber(playerData.communityService[source] or 0)
end

local function SetCommunityServiceCount(source, count)
    playerData.communityService[source] = math.max(0, tonumber(count) or 0)
    return playerData.communityService[source]
end

local function DecrementCommunityService(source)
    local current = GetCommunityServiceCount(source)
    if current <= 0 then return 0 end
    playerData.communityService[source] = current - 1
    return playerData.communityService[source]
end

RegisterNetEvent('frkn-policejob:completeService')
AddEventHandler('frkn-policejob:completeService', function()
    local source = source
    local remaining = DecrementCommunityService(source)
    
    if remaining <= 0 then
        SetCommunityServiceCount(source, 0)
        TriggerClientEvent('frkn-policejob:finishCommunityService', source)
    end
end)

RegisterNetEvent('frkn-policejob:server:sendcommunityservice')
AddEventHandler('frkn-policejob:server:sendcommunityservice', function(data)
    local targetId = tonumber(data and data.id)
    local count = tonumber(data and data.kamu) or 0
    
    if not targetId or count <= 0 then return end
    
    SetCommunityServiceCount(targetId, count)
    TriggerClientEvent('frkn-policejob:inCommunityService', targetId, count)
end)

local function GenerateEvidenceId()
    if not evidenceIdCounter or evidenceIdCounter < 1 then
        evidenceIdCounter = 1
        for id in pairs(evidenceData) do
            local num = tonumber(id) or 0
            if num >= evidenceIdCounter then
                evidenceIdCounter = num + 1
            end
        end
    end
    
    while evidenceData[tostring(evidenceIdCounter)] do
        evidenceIdCounter = evidenceIdCounter + 1
    end
    
    local id = tostring(evidenceIdCounter)
    evidenceIdCounter = evidenceIdCounter + 1
    return id
end

RegisterNetEvent('frkn-evidence:create')
AddEventHandler('frkn-evidence:create', function(data)
    local source = source
    if not data or not data.t or not data.x or not data.y or not data.z then return end
    
    local id = GenerateEvidenceId()
    
    evidenceData[id] = {
        id = id,
        t = data.t,
        x = data.x,
        y = data.y,
        z = data.z,
        time = os.time(),
        by = tostring(source),
        street = data.street or "",
        citizenid = data.citizenid or "",
        shooter = data.shooter or "",
        victim = data.victim or "",
        shot = data.shot or ""
    }
    
    TriggerClientEvent('frkn-evidence:add', -1, id, evidenceData[id])
end)

RegisterNetEvent('frkn-evidence:pickup')
AddEventHandler('frkn-evidence:pickup', function(evidenceId)
    local source = source
    local evidence = evidenceData[evidenceId]
    if not evidence then return end
    
    local evidenceInfo = {
        evidence_id = evidence.id,
        type = evidence.t or "",
        street = evidence.street or "",
        citizenid = evidence.citizenid or "",
        shooter = evidence.shooter or "",
        victim = evidence.victim or "",
        shot = evidence.shot or "",
        by = evidence.by or "",
        x = evidence.x,
        y = evidence.y,
        z = evidence.z,
        created = evidence.time or os.time()
    }
    
    evidenceData[evidenceId] = nil
    TriggerClientEvent('frkn-evidence:remove', -1, evidenceId)
end)

CreateThread(function()
    while true do
        Wait(60000) 
        local now = os.time()
        local decayTime = ((FRKN and FRKN.Evidence and FRKN.Evidence.DecayMinutes) or 30) * 60
        
        for id, evidence in pairs(evidenceData) do
            local elapsed = now - (evidence.time or now)
            if elapsed >= decayTime then
                evidenceData[id] = nil
                TriggerClientEvent('frkn-evidence:remove', -1, id)
            end
        end
    end
end)

AddEventHandler('playerDropped', function()
    local source = source
    local sid = GetStableIdentifier(source)
    
    playerData.gsr[source] = nil
    playerData.status[source] = nil
    playerData.communityService[source] = nil
    
    local cid = GetPlayerCid(source)
    if cid then
        playerData.cuffed[cid] = nil
    end
end)

exports('HasGSR', function(source)
    local data = playerData.gsr[source]
    if not data or not data.ts then return false end
    
    local elapsed = os.time() - data.ts
    if elapsed > 600 then
        playerData.gsr[source] = nil
        return false
    end
    
    return data.has == true
end)

exports('IsPlayerOnDuty', function(source)
    local sid = GetStableIdentifier(source)
    if not sid then return false end
    
    for job, players in pairs(playerData.duty or {}) do
        if players[sid] and players[sid].onDuty == 1 then
            return true
        end
    end
    
    return false
end)

print("^2[FRKN Police Job]^7 Server script loaded successfully!")

local function HasWithdrawPermission(source)
    local job, grade = GetPlayerJob(source)
    if not job or not grade then return false end
    
    for _, perm in ipairs(cacheData.job_perms or {}) do
        if tonumber(perm.job_grade_id) == tonumber(grade) then
            return perm.can_withdraw == 1
        end
    end
    
    return false
end

CreateCallback('frkn-policejob:vaultTransfer', function(source, cb, data)
    local action = string.lower(tostring(data.type or ""))
    local amount = tonumber(data.amount) or 0
    local stationIndex = tonumber(data.stationIndex or data.station) or 1
    
    if (action ~= "deposit" and action ~= "withdraw") or amount <= 0 then
        return cb({ok = false, error = "bad_input"})
    end
    
    local job, grade = GetPlayerJob(source)
    if not job then
        return cb({ok = false, error = "nojob"})
    end
    
    local vaultIndex = nil
    local vaultData = nil
    
    for i, vault in ipairs(cacheData.job_vaults) do
        if tonumber(vault.station) == stationIndex then
            vaultIndex = i
            vaultData = vault
            break
        end
    end
    
    if not vaultData then
        local insertId = MySQL.insert.await('INSERT INTO frkn_pd_vaults (station, vault) VALUES (?, ?)', {stationIndex, 0})
        vaultData = {id = insertId, station = stationIndex, vault = 0}
        table.insert(cacheData.job_vaults, vaultData)
        vaultIndex = #cacheData.job_vaults
    end
    
    local currentBalance = tonumber(vaultData.vault) or 0
    
    if action == "deposit" then
        local playerMoney = GetPlayerMoney(source, "bank")
        if amount > playerMoney then
            return cb({ok = false, error = "not_enough_money", message = Lang.t("error.not_enough_bank")})
        end
    elseif action == "withdraw" then
        if not HasWithdrawPermission(source) then
            return cb({ok = false, error = "forbidden", message = Lang.t("error.not_permission")})
        end
        if amount > currentBalance then
            return cb({ok = false, error = "not_enough_cash", message = Lang.t("error.not_enough_cash"), balance = currentBalance})
        end
    end
    
    local newBalance = action == "deposit" and (currentBalance + amount) or (currentBalance - amount)
    
    if action == "deposit" then
        RemoveMoney(source, "bank", amount)
    else
        AddMoney(source, "bank", amount)
    end
    
    MySQL.update.await('UPDATE frkn_pd_vaults SET vault=? WHERE station=?', {newBalance, stationIndex})
    cacheData.job_vaults[vaultIndex].vault = newBalance
    
    local playerName = SafeGetPlayerName(source)
    MySQL.insert.await('INSERT INTO frkn_pd_vaults_log (station, action, name, amount, update_date) VALUES (?,?,?,?,?)',
        {stationIndex, action, playerName, amount, os.date("%Y-%m-%d")})
    
    table.insert(cacheData.job_logs, {
        id = MySQL.insert.await('SELECT LAST_INSERT_ID() as id', {}),
        station = stationIndex,
        action = action,
        name = playerName,
        amount = amount,
        update_date = os.date("%Y-%m-%d")
    })
    
    TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
    
    cb({
        ok = true,
        station = stationIndex,
        amount = amount,
        type = action,
        balance = newBalance,
        message = Lang.t("success.vault")
    })
    
    DiscordLog(WEBHOOK_MONEY, {
        username = "FRKN Police Job Log System",
        title = action == "deposit" and "💰 Vault Deposit" or "🏦 Vault Withdraw",
        description = string.format("%s %s $%s in station vault #%d", playerName, action == "deposit" and "deposited" or "withdrew", amount, stationIndex),
        color = action == "deposit" and 5793266 or 15158332,
        footer = string.format("Police Job • %s", os.date("%d.%m.%Y %H:%M")),
        kv_inline = true,
        kv = {
            Player = string.format("%s (%d)", playerName, source),
            Action = action,
            Amount = tostring(amount),
            ["Balance Before"] = tostring(currentBalance),
            ["Balance After"] = tostring(newBalance),
            Station = tostring(stationIndex)
        }
    })
end)

CreateCallback('frkn-policejob:hirePlayer', function(source, cb, data)
    local targetId = data.playerId
    local targetPlayer = CoreGetPlayerByIdentifier(targetId)
    local targetSource = GetSourceFromIdentifier(targetPlayer)
    local grade = tonumber(data.grade) or 0
    local job = tostring(data.job or "police")
    
    if not targetPlayer then
        return cb({ok = false, error = "target_offline"})
    end
    
    local success = CoreSetJob(targetPlayer, job, grade)
    cb(success and {ok = true} or {ok = false, error = "setjob_failed"})
    
    local adminDiscord = GetDiscordId(source)
    local targetDiscord = GetDiscordId(targetSource)
    
    DiscordLog(WEBHOOK_HIRE, {
        username = "FRKN Police Job Log System",
        title = success and "🧾 Player Hired" or "⚠️ Hire Player Failed",
        description = success and "Player has been hired successfully." or "Failed to hire player.",
        color = success and 5793266 or 15158332,
        footer = string.format("Police Job • %s", os.date("%d.%m.%Y %H:%M")),
        kv_inline = true,
        kv = {
            Admin = string.format("%s (%d)", SafeGetPlayerName(source), source),
            ["Admin Discord"] = adminDiscord and string.format("<@%s>", adminDiscord) or "No Discord linked",
            Target = string.format("%s (%d)", SafeGetPlayerName(targetSource), targetSource),
            ["Target Discord"] = targetDiscord and string.format("<@%s>", targetDiscord) or "No Discord linked",
            Job = job,
            Grade = tostring(grade)
        }
    })
end)

CreateCallback('frkn-policejob:firePlayer', function(source, cb, data)
    local targetId = data.playerId
    local targetPlayer = CoreGetPlayerByIdentifier(targetId)
    local targetSource = GetSourceFromIdentifier(targetPlayer)
    
    if not targetPlayer then
        return cb({ok = false, error = "target_offline"})
    end
    
    local success = CoreSetJob(targetPlayer, "unemployed", 0)
    cb(success and {ok = true} or {ok = false, error = "setjob_failed"})
    
    DiscordLog(WEBHOOK_FIRE, {
        username = "FRKN Police Job Log System",
        title = success and "❌ Player Fired" or "⚠️ Fire Player Failed",
        description = success and "Player has been fired (set to unemployed)." or "Failed to fire player.",
        color = success and 15158332 or 15105570,
        footer = string.format("Police Job • %s", os.date("%d.%m.%Y %H:%M")),
        kv_inline = true,
        kv = {
            Admin = string.format("%s (%d)", SafeGetPlayerName(source), source),
            Target = string.format("%s (%d)", SafeGetPlayerName(targetSource), targetSource),
            ["New Job"] = "unemployed",
            ["New Grade"] = "0"
        }
    })
end)

CreateCallback('frkn-policejob:updatePlayerGrade', function(source, cb, data)
    local targetId = data.playerId
    local targetPlayer = CoreGetPlayerByIdentifier(targetId)
    local targetSource = GetSourceFromIdentifier(targetPlayer)
    local grade = tonumber(data.grade) or 0
    local job = tostring(data.job or "police")
    
    if not targetPlayer then
        return cb({ok = false, error = "target_offline"})
    end
    
    local success = CoreSetJob(targetPlayer, job, grade)
    cb(success and {ok = true} or {ok = false, error = "setjob_failed"})
    
    DiscordLog(WEBHOOK_UPDATE_PLAYER_GRADE, {
        username = "FRKN Police Job Log System",
        title = success and "🛡️ Grade Updated" or "⚠️ Grade Update Failed",
        description = success and "Player grade has been updated." or "Failed to update player grade.",
        color = success and 5793266 or 15158332,
        footer = string.format("Police Job • %s", os.date("%d.%m.%Y %H:%M")),
        kv_inline = true,
        kv = {
            Admin = string.format("%s (%d)", SafeGetPlayerName(source), source),
            Target = string.format("%s (%d)", SafeGetPlayerName(targetSource), targetSource),
            Job = job,
            ["New Grade"] = tostring(grade)
        }
    })
end)

local dutyData = {}

local function SetDutyState(source, onDuty)
    if CoreName == "es_extended" and ESX then
        local player = ESX.GetPlayerFromId(source)
        if player then
            
            TriggerClientEvent("esx:setJob", source, player.job)
        end
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = exports[CoreName]:GetCoreObject().Functions.GetPlayer(source)
        if player then
            player.Functions.SetJobDuty(onDuty)
            TriggerEvent("QBCore:Server:SetDuty", source, onDuty)
            TriggerClientEvent("QBCore:Client:SetDuty", source, onDuty)
        end
    end
    
    local playerState = Player(source).state
    playerState:set('onDuty', onDuty and 1 or 0, true)
    
    return onDuty
end

CreateCallback('frkn-policejob:server:getDuty', function(source, cb)
    local job, grade = GetPlayerJob(source)
    if not job then
        return cb(false, 0)
    end
    
    local playerState = Player(source).state
    local dutyState = playerState.onDuty or 0
    
    cb(true, dutyState)
end)

CreateCallback('frkn-policejob:server:setDuty', function(source, cb, data)
    local job = tostring(data.job or "civ")
    local state = tonumber(data.state)
    
    if state ~= 0 and state ~= 1 then
        local playerState = Player(source).state
        state = playerState.onDuty == 1 and 0 or 1
    end
    
    local success = SetDutyState(source, state == 1)
    local sid = GetStableIdentifier(source)
    
    if not dutyData[job] then
        dutyData[job] = {}
    end
    
    if not dutyData[job][sid] then
        dutyData[job][sid] = {
            src = source,
            name = SafeGetPlayerName(source),
            job = job,
            onDuty = state
        }
    else
        dutyData[job][sid].onDuty = state
    end
    
    cb(true, state)
    
    DiscordLog(WEBHOOK_DUTY, {
        username = "FRKN Police Job Log System",
        title = state == 1 and "🟢 Duty On" or "🔴 Duty Off",
        description = state == 1 and "Duty enabled." or "Duty disabled.",
        color = state == 1 and 3066993 or 15158332,
        footer = string.format("Police Job • %s", os.date("%d.%m.%Y %H:%M")),
        kv_inline = true,
        kv = {
            Player = string.format("%s (%d)", SafeGetPlayerName(source), source),
            Job = job,
            From = tostring(state == 1 and 0 or 1),
            To = tostring(state)
        }
    })
end)

local function GetTranslation(key, subs)
    if Lang and Lang.t then
        local success, result = pcall(function() return Lang:t(key, subs) end)
        if success then return result end
    end
    
    local fallbacks = {
        ["success.paid_card"] = "Paiement par carte effectué!",
        ["success.paid_cash"] = "Paiement en espèces effectué!",
        ["error.not_enough_bank"] = "Pas assez d'argent en banque!",
        ["error.not_enough_cash"] = "Pas assez d'argent liquide!"
    }
    return fallbacks[key] or key
end

CreateCallback('frkn-policejob:processPayment', function(source, cb, paymentType, items, totalPrice)
    print("^2[FRKN Police]^7 processPayment called - type: " .. tostring(paymentType) .. ", total: " .. tostring(totalPrice))
    local success = false
    local message = ""
    
    if paymentType == "card" then
        local bankMoney = GetPlayerMoney(source, "bank")
        print("^2[FRKN Police]^7 Bank money: " .. tostring(bankMoney))
        if totalPrice <= bankMoney then
            RemoveMoney(source, "bank", totalPrice)
            GiveShopItems(source, items)
            success = true
            message = GetTranslation("success.paid_card", {amount = totalPrice})
        else
            message = GetTranslation("error.not_enough_bank")
        end
    elseif paymentType == "cash" then
        local cashMoney = GetPlayerMoney(source, "cash")
        print("^2[FRKN Police]^7 Cash money: " .. tostring(cashMoney))
        if totalPrice <= cashMoney then
            RemoveMoney(source, "cash", totalPrice)
            GiveShopItems(source, items)
            success = true
            message = GetTranslation("success.paid_cash", {amount = totalPrice})
        else
            message = GetTranslation("error.not_enough_cash")
        end
    end
    
    print("^2[FRKN Police]^7 Payment result: " .. tostring(success) .. " - " .. message)
    cb({ok = success, message = message})
    
    local itemsList = "-"
    if type(items) == "table" and next(items) then
        local itemsArr = {}
        for _, item in ipairs(items) do
            local label = item.label or item.name or item.item or "item"
            local count = item.count or item.quantity or item.amount or 1
            table.insert(itemsArr, string.format("%s x%s", label, count))
        end
        itemsList = table.concat(itemsArr, "\n")
    end
    
    DiscordLog(WEBHOOK_PAYMENT, {
        username = "FRKN Police Job Log System",
        title = success and "🧾 Payment Success" or "🧾 Payment Failed",
        description = success and "Purchase processed." or message,
        color = success and 3066993 or 15158332,
        footer = string.format("Police Shop • %s", os.date("%d.%m.%Y %H:%M")),
        kv_inline = true,
        kv = {
            Player = string.format("%s (%d)", SafeGetPlayerName(source), source),
            Type = tostring(paymentType or "-"),
            Total = string.format("$%s", tostring(totalPrice or 0))
        },
        fields = {
            {name = "Items", value = itemsList, inline = false}
        }
    })
end)

function GiveShopItems(source, items)
    for _, item in ipairs(items or {}) do
        local itemName = item.itemName or item.id
        local qty = tonumber(item.qty) or 1
        AddItem(source, itemName, qty)
    end
end

CreateCallback('frkn-evidence:saveScan', function(source, cb, data)
    local cid = GetPlayerCid(source)
    local evidenceId = data.evidence_id or ""
    
    if evidenceId == "" then
        return cb({
            ok = false,
            msg = Lang.t("error.invalid_data"),
            code = "invalid_data",
            cacheData = cacheData,
            saveEvidence = cacheData.evidence_scans or {}
        })
    end
    
    for _, scan in ipairs(cacheData.evidence_scans or {}) do
        if tostring(scan.evidence_id) == tostring(evidenceId) then
            return cb({
                ok = false,
                msg = Lang.t("error.already_scanned"),
                code = "already_scanned",
                cacheData = cacheData,
                saveEvidence = cacheData.evidence_scans or {}
            })
        end
    end
    
    local scanType = data.type or ""
    local container = data.container or ""
    local street = data.street or ""
    local created = tonumber(data.created) or 0
    local citizenid = data.citizenid or ""
    local victim = data.victim or ""
    local shooter = data.shooter or ""
    local shot = data.shot or ""
    local memo = data.memo or ""
    
    local insertId = MySQL.insert.await(
        'INSERT INTO frkn_evidence_scans (evidence_id, type, container, street, created, citizenid, victim, shooter, shot, memo, source_identifier) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
        {evidenceId, scanType, container, street, created, citizenid, victim, shooter, shot, memo, cid}
    )
    
    if insertId then
        local newScan = {
            id = insertId,
            evidence_id = evidenceId,
            type = scanType,
            container = container,
            street = street,
            created = created,
            citizenid = citizenid,
            victim = victim,
            shooter = shooter,
            shot = shot,
            memo = memo,
            source_identifier = cid,
            inserted_at = os.date("%Y-%m-%d %H:%M:%S")
        }
        
        table.insert(cacheData.evidence_scans, 1, newScan)
        TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
        
        cb({
            ok = true,
            msg = Lang.t("success.scan_saved"),
            cacheData = cacheData,
            saveEvidence = cacheData.evidence_scans
        })
    else
        cb({
            ok = false,
            msg = Lang.t("error.db_insert_failed"),
            code = "db_insert_failed",
            cacheData = cacheData,
            saveEvidence = cacheData.evidence_scans or {}
        })
    end
end)

CreateCallback('frkn-evidence:updateScan', function(source, cb, data)
    local evidenceId = data.evidence_id or ""
    local memo = data.memo or ""
    
    if evidenceId == "" then
        return cb({
            ok = false,
            msg = Lang.t("error.invalid_data"),
            code = "invalid_data",
            cacheData = cacheData,
            saveEvidence = cacheData.evidence_scans or {}
        })
    end
    
    local affected = MySQL.update.await(
        'UPDATE frkn_evidence_scans SET memo = ? WHERE evidence_id = ? ORDER BY id DESC LIMIT 1',
        {memo, evidenceId}
    )
    
    if affected and affected > 0 then
        
        local latestId = nil
        local latestIndex = nil
        
        for i, scan in ipairs(cacheData.evidence_scans or {}) do
            if tostring(scan.evidence_id) == tostring(evidenceId) then
                local scanId = tonumber(scan.id) or 0
                if not latestId or latestId < scanId then
                    latestId = scanId
                    latestIndex = i
                end
            end
        end
        
        if latestIndex then
            cacheData.evidence_scans[latestIndex].memo = memo
        end
        
        TriggerClientEvent('frkn-policejob:setClient', -1, cacheData)
        
        cb({
            ok = true,
            msg = Lang.t("success.scan_updated"),
            cacheData = cacheData,
            saveEvidence = cacheData.evidence_scans or {}
        })
    else
        cb({
            ok = false,
            msg = Lang.t("error.db_update_failed"),
            code = "db_update_failed",
            cacheData = cacheData,
            saveEvidence = cacheData.evidence_scans or {}
        })
    end
end)

function DiscordLog(webhook, data)
    if not webhook or webhook == "" then return end
    
    local payload = {}
    local mentions = {}
    
    if data.allowed_users and type(data.allowed_users) == "table" then
        local userSet = {}
        for _, userId in ipairs(data.allowed_users) do
            local id = tostring(userId)
            if id ~= "" and not userSet[id] then
                userSet[id] = true
                table.insert(mentions, string.format("<@%s>", id))
            end
        end
        
        if #mentions > 0 then
            payload.content = table.concat(mentions, " ")
            payload.allowed_mentions = {users = data.allowed_users}
        end
    end
    
    if data.content and data.content ~= "" then
        payload.content = (payload.content and (payload.content .. " ") or "") .. tostring(data.content)
    end
    
    if data.title or data.description or data.fields or data.kv then
        local embed = {
            title = data.title,
            description = data.description,
            color = tonumber(data.color) or 3092790,
            timestamp = data.timestamp or os.date("!%Y-%m-%dT%H:%M:%SZ")
        }
        
        if data.url then embed.url = data.url end
        if data.thumbnail then embed.thumbnail = {url = data.thumbnail} end
        if data.image then embed.image = {url = data.image} end
        
        if data.footer then
            if type(data.footer) == "table" then
                embed.footer = {text = data.footer.text, icon_url = data.footer.icon_url}
            else
                embed.footer = {text = tostring(data.footer)}
            end
        end
        
        local fields = {}
        
        if type(data.fields) == "table" then
            for _, field in ipairs(data.fields) do
                table.insert(fields, {
                    name = tostring(field.name),
                    value = tostring(field.value),
                    inline = not not field.inline
                })
            end
        end
        
        if data.kv then
            for key, value in pairs(data.kv) do
                table.insert(fields, {
                    name = tostring(key),
                    value = tostring(value),
                    inline = data.kv_inline or false
                })
            end
        end
        
        if #fields > 0 then
            embed.fields = fields
        end
        
        payload.embeds = {embed}
    end
    
    if data.username then payload.username = data.username end
    if data.avatar_url then payload.avatar_url = data.avatar_url end
    
    PerformHttpRequest(webhook, function(statusCode, response)
        
    end, 'POST', json.encode(payload), {['Content-Type'] = 'application/json'})
end

RegisterNetEvent('frkn-policejob:sendServerData')
AddEventHandler('frkn-policejob:sendServerData', function(targetId)
    local source = source
    local job, grade = GetPlayerJob(source)
    local name = SafeGetPlayerName(source)
    local cid = GetPlayerCid(source)
    
    local data = {
        job = job,
        grade = grade,
        name = name,
        cid = cid,
        level = grade
    }
    
    if targetId and targetId ~= -1 then
        TriggerClientEvent('frkn-policejob:sendData', targetId, data)
    end
    
    TriggerClientEvent('frkn-policejob:sendData', source, data)
end)

RegisterNetEvent('frkn-policejob:closeBadgeS')
AddEventHandler('frkn-policejob:closeBadgeS', function(targetId)
    local source = source
    
    if targetId and targetId ~= -1 then
        TriggerClientEvent('frkn-policejob:closeBadge', targetId)
    end
    
    TriggerClientEvent('frkn-policejob:closeBadge', source)
end)

RegisterNetEvent('frkn-policejob:server:SyncSpikes')
AddEventHandler('frkn-policejob:server:SyncSpikes', function(data)
    TriggerClientEvent('frkn-policejob:client:SyncSpikes', -1, data)
end)

RegisterNetEvent('frkn-policejob:fingerRequest')
AddEventHandler('frkn-policejob:fingerRequest', function(targetId)
    local source = source
    local target = tonumber(targetId)
    
    if not target then return end
    
    TriggerClientEvent('frkn-policejob:fingerResponse', source, {ok = true, target = target})
    TriggerClientEvent('frkn-policejob:fingerNotify', target, source)
end)

function GetPlayerMoney(source, accountType)
    if CoreName == "es_extended" and ESX then
        local player = ESX.GetPlayerFromId(source)
        if player then
            
            local esxAccountType = accountType == "cash" and "money" or accountType
            local account = player.getAccount(esxAccountType)
            return account and account.money or 0
        end
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = exports[CoreName]:GetCoreObject().Functions.GetPlayer(source)
        if player then
            return player.Functions.GetMoney(accountType)
        end
    end
    return 0
end

function AddMoney(source, accountType, amount)
    if CoreName == "es_extended" and ESX then
        local player = ESX.GetPlayerFromId(source)
        if player then
            local esxAccountType = accountType == "cash" and "money" or accountType
            player.addAccountMoney(esxAccountType, amount)
        end
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = exports[CoreName]:GetCoreObject().Functions.GetPlayer(source)
        if player then
            player.Functions.AddMoney(accountType, amount)
        end
    end
end

function RemoveMoney(source, accountType, amount)
    if CoreName == "es_extended" and ESX then
        local player = ESX.GetPlayerFromId(source)
        if player then
            local esxAccountType = accountType == "cash" and "money" or accountType
            player.removeAccountMoney(esxAccountType, amount)
        end
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = exports[CoreName]:GetCoreObject().Functions.GetPlayer(source)
        if player then
            player.Functions.RemoveMoney(accountType, amount)
        end
    end
end

function AddItem(source, item, count, info)
    if CoreName == "es_extended" and ESX then
        local player = ESX.GetPlayerFromId(source)
        if player then
            player.addInventoryItem(item, count)
        end
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = exports[CoreName]:GetCoreObject().Functions.GetPlayer(source)
        if player then
            player.Functions.AddItem(item, count, false, info)
        end
    end
end

function RemoveItem(source, item, count)
    if CoreName == "es_extended" and ESX then
        local player = ESX.GetPlayerFromId(source)
        if player then
            player.removeInventoryItem(item, count)
        end
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = exports[CoreName]:GetCoreObject().Functions.GetPlayer(source)
        if player then
            player.Functions.RemoveItem(item, count)
        end
    end
end

function GetItemByName(player, item)
    if CoreName == "es_extended" then
        return player.getInventoryItem(item)
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        return player.Functions.GetItemByName(item)
    end
    return nil
end

function CoreGetPlayerByIdentifier(identifier)
    if CoreName == "es_extended" and ESX then
        return ESX.GetPlayerFromIdentifier(identifier) or ESX.GetPlayerFromId(tonumber(identifier))
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        local Core = exports[CoreName]:GetCoreObject()
        return Core.Functions.GetPlayerByCitizenId(identifier) or Core.Functions.GetPlayer(tonumber(identifier))
    end
    return nil
end

function GetSourceFromIdentifier(player)
    if not player then return nil end
    
    if CoreName == "es_extended" then
        return player.source
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        return player.PlayerData and player.PlayerData.source
    end
    
    return player.playerId or player.source or player
end

function CoreSetJob(player, job, grade)
    if CoreName == "es_extended" then
        player.setJob(job, grade)
        return true
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        return player.Functions.SetJob(job, grade)
    end
    return false
end

print("^2[FRKN Police Job]^7 Server script fully loaded!")
print("^2[FRKN Police Job]^7 Framework: ^3" .. (CoreName or "Unknown") .. "^7")

local alcoholItems = (FRKN and FRKN.alcohol) or {}

for itemName, _ in pairs(alcoholItems) do
    RegisterUsableItem(itemName)
end

RegisterNetEvent('frkn-policejob:drinkAlcohol')
AddEventHandler('frkn-policejob:drinkAlcohol', function(itemName)
    local source = source
    local player = GetPlayer(source)
    if not player then return end
    
    local isValidAlcohol = false
    for name, _ in pairs(alcoholItems) do
        if name == itemName then
            isValidAlcohol = true
            break
        end
    end
    
    if not isValidAlcohol then return end
    
    RemoveItem(source, itemName, 1)
end)

CreateCallback('frkn-policejob:GetPlayerStatus', function(source, cb, targetId)
    local targetPlayer = GetPlayer(targetId)
    if not targetPlayer then
        return cb({})
    end
    
    local targetSource = GetPlayerSource(targetPlayer)
    local statusList = {}
    
    if targetSource and playerData.status[targetSource] then
        if next(playerData.status[targetSource]) then
            for statusName, statusData in pairs(playerData.status[targetSource]) do
                table.insert(statusList, statusData.text)
            end
        end
    end
    
    cb(statusList)
end)

RegisterNetEvent('frkn-policejob:server:UpdateStatus')
AddEventHandler('frkn-policejob:server:UpdateStatus', function(statusData)
    local source = source
    playerData.status[source] = statusData
end)

RegisterServerEvent('frkn-policejob:server:VehicS')
AddEventHandler('frkn-policejob:server:VehicS', function()
    local source = source
    TriggerClientEvent('frkn-policejob:deleteVehicle', source)
end)

RegisterServerEvent('frkn-policejob:server:ParkingVio')
AddEventHandler('frkn-policejob:server:ParkingVio', function()
    local source = source
    TriggerClientEvent('frkn-policejob:deleteVehicle', source)
    TriggerClientEvent('frkn-policejob:notify', source, 'success', Lang.t('success.parking_violation'))
end)

RegisterServerEvent('frkn-policejob:server:PDIm')
AddEventHandler('frkn-policejob:server:PDIm', function()
    local source = source
    TriggerClientEvent('frkn-policejob:client:ImpoundVehicle', source, true)
end)

RegisterNetEvent('frkn-policejob:server:KidnapPlayer')
AddEventHandler('frkn-policejob:server:KidnapPlayer', function(targetId)
    local source = source
    
    local sourcePlayer = GetPlayer(source)
    local targetPlayer = GetPlayer(targetId)
    
    if not sourcePlayer or not targetPlayer then return end
    
    TriggerClientEvent('frkn-policejob:client:GetKidnappedTarget', targetId, source)
    TriggerClientEvent('frkn-policejob:client:GetKidnappedDragger', source, targetId)
end)

RegisterNetEvent('frkn-policejob:searchPlayer')
AddEventHandler('frkn-policejob:searchPlayer', function(targetId)
    TriggerClientEvent('frkn-policejob:inventoryBusy', targetId)
    TriggerClientEvent('frkn-policejob:notify', targetId, 'info', Lang.t('general.robbing'))
    
    Wait((FRKN and FRKN.PoliceSearch and FRKN.PoliceSearch.SearchTime) or 5000)
    
    TriggerClientEvent('frkn-policejob:inventoryFree', targetId)
end)

RegisterNetEvent('police:server:SearchPlayer')
AddEventHandler('police:server:SearchPlayer', function()
    local source = source
    local player = GetPlayer(source)
    if not player then return end
    
    local closestPlayer, distance = GetClosestPlayer(source)
    
    if closestPlayer ~= -1 and distance < 2.5 then
        local targetPlayer = GetPlayer(tonumber(closestPlayer))
        if not targetPlayer then return end
        
        if GetResourceState("qb-inventory") == "started" then
            exports['qb-inventory']:OpenInventoryById(source, tonumber(closestPlayer))
        end
    end
end)

RegisterNetEvent('frkn-policejob:server:NotifyOtherPlayer')
AddEventHandler('frkn-policejob:server:NotifyOtherPlayer', function(targetId, message, type, duration)
    TriggerClientEvent('frkn-policejob:notify', targetId, type, message, duration)
end)

CreateThread(function()
    while not FRKN do Wait(100) end
    RegisterUsableItem((FRKN and FRKN.HandCuffItem) or "handcuffs")
    RegisterUsableItem((FRKN and FRKN.CuffKeyItem) or "cuffkeys")
end)

CreateCallback('frkn-policejob:cuffControl', function(source, cb, items)
    local player = GetPlayer(source)
    local hasItem, itemData = HasAnyItem(player, items)
    cb(hasItem, itemData)
end)

CreateCallback('frkn-policejob:server:getCuffStatus', function(source, cb, targetId)
    local targetPlayer = GetPlayer(targetId)
    local cid = GetPlayerCid(targetId)
    
    if playerData.cuffed[cid] then
        cb(playerData.cuffed[cid])
    else
        cb({})
    end
end)

CreateCallback('frkn-policejob:moneyControl', function(source, cb, data)
    local price = data.price
    local playerMoney = GetPlayerMoney(source, "bank")
    local requiredAmount = tonumber(price)
    
    if playerMoney >= requiredAmount then
        cb(true)
    else
        cb(false)
    end
end)

CreateCallback('frkn-policejob:characterDetail', function(source, cb, targetId)
    local name = nil
    local jobLabel = nil
    local jobName = "Unknown"
    local identifier = nil
    
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = GetPlayer(tonumber(targetId))
        if player then
            local charinfo = player.PlayerData.charinfo
            local job = player.PlayerData.job
            
            name = (charinfo.firstname or "") .. " " .. (charinfo.lastname or "")
            jobLabel = job.label or job.name or "Unknown"
            jobName = job.name or "Unknown"
            identifier = player.PlayerData.citizenid or player.PlayerData.identifier
        end
    elseif CoreName == "es_extended" then
        local player = GetPlayer(tonumber(targetId))
        if player then
            name = player.getName()
            jobLabel = player.job and player.job.label or "Unknown"
            jobName = player.job and player.job.name or "Unknown"
            identifier = player.identifier
        end
    end
    
    cb({
        name = name or "Unknown",
        job = jobLabel or "Unknown",
        identifier = identifier or "Unknown",
        jobName = jobName or "Unknown"
    })
end)

CreateCallback('frkn-policejob:server:getWorkers', function(source, cb, data)
    local job = tostring(data.job or "civ")
    local result = {
        online = {},
        offline = {}
    }
    
    if dutyData[job] then
        for sid, worker in pairs(dutyData[job]) do
            if worker.onDuty == 1 then
                table.insert(result.online, {
                    name = worker.name,
                    job = worker.job,
                    src = worker.src,
                    onDuty = 1
                })
            else
                table.insert(result.offline, {
                    name = worker.name,
                    job = worker.job,
                    src = worker.src,
                    onDuty = 0
                })
            end
        end
    end
    
    table.sort(result.online, function(a, b) return (a.name or "") < (b.name or "") end)
    table.sort(result.offline, function(a, b) return (a.name or "") < (b.name or "") end)
    
    cb(result)
end)

local function GetOnlinePolice()
    local result = {}
    
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        for _, playerId in pairs(GetPlayers()) do
            local player = GetPlayer(playerId)
            if player and player.PlayerData.job and player.PlayerData.job.name == "police" then
                local charinfo = player.PlayerData.charinfo or {}
                local name = ((charinfo.firstname or "") .. " " .. (charinfo.lastname or "")):gsub("^%s*(.-)%s*$", "%1")
                
                table.insert(result, {
                    source = playerId,
                    identifier = player.PlayerData.citizenid,
                    name = name,
                    job = "police",
                    grade = player.PlayerData.job.grade.level or player.PlayerData.job.grade or 0,
                    onDuty = GetPlayerDutyStatus(playerId)
                })
            end
        end
    elseif CoreName == "es_extended" then
        for _, playerId in pairs(GetPlayers() or {}) do
            local player = GetPlayer(tonumber(playerId.source or playerId))
            if player and player.job and player.job.name == "police" then
                local firstName = player.get and player.get("firstName") or nil
                local lastName = player.get and player.get("lastName") or nil
                local name = ((firstName or "") .. " " .. (lastName or "")):gsub("^%s*(.-)%s*$", "%1")
                if name == " " then
                    name = player.getName and player.getName() or ""
                end
                
                table.insert(result, {
                    source = player.source,
                    identifier = player.identifier,
                    name = name,
                    job = "police",
                    grade = player.job.grade or 0,
                    onDuty = GetPlayerDutyStatus(player.source)
                })
            end
        end
    end
    
    return result
end

local function GetOfflinePolice()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local result = MySQL.query.await('SELECT citizenid, charinfo, job FROM players WHERE job LIKE ?', {'%"name":"police"%'})
        local list = {}
        
        for _, row in ipairs(result or {}) do
            local jobData = type(row.job) == "string" and json.decode(row.job) or row.job
            if jobData and jobData.name == "police" then
                local charinfo = type(row.charinfo) == "string" and json.decode(row.charinfo) or row.charinfo or {}
                local name = ((charinfo.firstname or "") .. " " .. (charinfo.lastname or "")):gsub("^%s*(.-)%s*$", "%1")
                
                table.insert(list, {
                    identifier = row.citizenid,
                    name = name,
                    job = "police",
                    grade = jobData.grade.level or jobData.grade or 0
                })
            end
        end
        
        return list
    else
        local result = MySQL.query.await('SELECT identifier, firstname, lastname, job, job_grade FROM users WHERE job = ?', {'police'})
        local list = {}
        
        for _, row in ipairs(result or {}) do
            local name = ((row.firstname or "") .. " " .. (row.lastname or "")):gsub("^%s*(.-)%s*$", "%1")
            
            table.insert(list, {
                identifier = row.identifier,
                name = name,
                job = row.job,
                grade = row.job_grade or 0
            })
        end
        
        return list
    end
end

local function GetAllPolice()
    local online = GetOnlinePolice()
    local offline = GetOfflinePolice()
    
    local onlineIds = {}
    for _, player in ipairs(online) do
        onlineIds[player.identifier] = true
    end
    
    local offlineFiltered = {}
    for _, player in ipairs(offline) do
        if not onlineIds[player.identifier] then
            table.insert(offlineFiltered, player)
        end
    end
    
    return online, offlineFiltered
end

CreateCallback('frkn-boss:getPolice', function(source, cb)
    local online, offline = GetAllPolice()
    cb({online = online, offline = offline})
end)

CreateCallback('frkn-policejob:server:getHistory', function(source, cb)
    local sid = GetStableIdentifier(source)
    local historyList = playerData.dutyHistory[sid] and playerData.dutyHistory[sid].list or {}
    local currentDuty = playerData.dutyHistory[sid] and playerData.dutyHistory[sid].open or nil
    
    local formattedList = {}
    for _, entry in ipairs(historyList) do
        table.insert(formattedList, {
            job = entry.job,
            name = entry.name,
            start = entry.start,
            stop = entry.stop,
            minutes = entry.minutes,
            start_str = os.date("%H:%M:%S", entry.start),
            stop_str = os.date("%H:%M:%S", entry.stop)
        })
    end
    
    local currentFormatted = nil
    if currentDuty then
        currentFormatted = {
            job = currentDuty.job,
            name = currentDuty.name,
            t = currentDuty.t,
            start_str = os.date("%H:%M:%S", currentDuty.t)
        }
    end
    
    cb({
        open = currentFormatted,
        list = formattedList
    })
end)

RegisterNetEvent('frkn:ox_open_stash')
AddEventHandler('frkn:ox_open_stash', function(stashId)
    local source = source
    local slots = FRKN.EvidenceStashSettings and FRKN.EvidenceStashSettings.slots or 30
    local maxWeight = FRKN.EvidenceStashSettings and FRKN.EvidenceStashSettings.maxWeight or 100000
    
    if GetResourceState("ox_inventory") == "started" then
        exports.ox_inventory:RegisterStash(stashId, stashId, slots, maxWeight, false)
        exports.ox_inventory:forceOpenInventory(source, 'stash', {id = stashId})
    end
end)

CreateCallback('frkn-policejob:GetEvidenceMetas', function(source, cb)
    local metas, count = GetEvidenceMetas(source)
    cb(metas, count)
end)

function GetPlayer(source)
    if CoreName == "es_extended" and ESX then
        return ESX.GetPlayerFromId(source)
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        return exports[CoreName]:GetCoreObject().Functions.GetPlayer(source)
    end
    return nil
end

function GetPlayerSource(player)
    if not player then return nil end
    
    if CoreName == "es_extended" then
        return player.source
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        return player.PlayerData and player.PlayerData.source
    end
    
    return player.source or player.playerId
end

function GetClosestPlayer(source)
    local players = GetPlayers()
    local closestDistance = -1
    local closestPlayer = -1
    local sourcePed = GetPlayerPed(source)
    local sourceCoords = GetEntityCoords(sourcePed)
    
    for _, playerId in ipairs(players) do
        local targetId = tonumber(playerId)
        if targetId ~= source then
            local targetPed = GetPlayerPed(targetId)
            local targetCoords = GetEntityCoords(targetPed)
            local distance = #(sourceCoords - targetCoords)
            
            if closestDistance == -1 or distance < closestDistance then
                closestPlayer = targetId
                closestDistance = distance
            end
        end
    end
    
    return closestPlayer, closestDistance
end

function HasAnyItem(player, items)
    if not player or type(items) ~= "table" then return false, nil end
    
    for _, itemName in ipairs(items) do
        local item = GetItemByName(player, itemName)
        if item and item.amount > 0 then
            return true, item
        end
    end
    
    return false, nil
end

function GetPlayerDutyStatus(source)
    local playerState = Player(source).state
    return playerState.onDuty or 0
end

function RegisterUsableItem(itemName)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        if QBCore and QBCore.Functions and QBCore.Functions.CreateUseableItem then
            QBCore.Functions.CreateUseableItem(itemName, function(source, item)
                TriggerClientEvent('frkn-policejob:client:useItem', source, item.name)
            end)
        end
    elseif CoreName == "es_extended" and ESX then
        ESX.RegisterUsableItem(itemName, function(source)
            TriggerClientEvent('frkn-policejob:client:useItem', source, itemName)
        end)
    end
end

Lang = Lang or {}
Lang.t = Lang.t or function(key, vars)
    local translations = {
        ["error.not_enough_bank"] = "Not enough money in bank",
        ["error.not_enough_cash"] = "Not enough cash",
        ["error.not_permission"] = "You don't have permission",
        ["error.invalid_data"] = "Invalid data",
        ["error.already_scanned"] = "Evidence already scanned",
        ["error.db_insert_failed"] = "Database insert failed",
        ["error.db_update_failed"] = "Database update failed",
        ["error.target_offline"] = "Target player is offline",
        ["error.not_in_community"] = "Player is not in community service",
        ["error.need_evidence_tube"] = "You need an evidence tube",
        ["error.need_evidence_bag"] = "You need an evidence bag",
        ["success.vault"] = "Transaction successful",
        ["success.scan_saved"] = "Evidence scan saved",
        ["success.scan_updated"] = "Evidence scan updated",
        ["success.paid_card"] = "Paid with card: $" .. (vars and vars.amount or 0),
        ["success.paid_cash"] = "Paid with cash: $" .. (vars and vars.amount or 0),
        ["success.parking_violation"] = "Vehicle removed for parking violation",
        ["success.picked_blood"] = "Blood sample collected",
        ["success.picked_evidence"] = "Evidence collected",
        ["success.community_finished_self"] = "Community service completed",
        ["success.community_finished_other"] = "Community service completed for " .. (vars and vars.name or "player"),
        ["general.robbing"] = "Being searched..."
    }
    
    return translations[key] or key
end

CreateThread(function()
    Wait(2000)
    print("^2========================================^7")
    print("^2[FRKN Police Job]^7 Fully Initialized!")
    print("^2[FRKN Police Job]^7 Framework: ^3" .. (CoreName or "Unknown") .. "^7")
    print("^2[FRKN Police Job]^7 All systems operational!")
    print("^2========================================^7")
end)

