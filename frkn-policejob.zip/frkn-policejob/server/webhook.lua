-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

WEBHOOK_PAYMENT = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk" 
WEBHOOK_VEHICLE = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk"
WEBHOOK_COMMUNITY  = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk"
WEBHOOK_DUTY = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk"
WEBHOOK_PERMS = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk"
WEBHOOK_MONEY = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk"
WEBHOOK_FIRE = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk"
WEBHOOK_HIRE = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk"
WEBHOOK_UPDATE_PLAYER_GRADE = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk"
WEBHOOK_UPDATE_SYSTEM_GRADE = "https://discord.com/api/webhooks/1541916594022653974/LEkVV-wsoYkWljRVwBxotbd8DCotUpiriyKtH5t250NxEk5H-P69aDwSTiKNuJUOaCKk"
