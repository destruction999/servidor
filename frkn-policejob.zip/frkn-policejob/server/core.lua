-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Core = nil
CoreName = nil
CoreReady = false

CreateThread(function()
    for _, v in pairs(Cores) do
        local state = GetResourceState(v.ResourceName)
        if state == "starting" or state == "started" then
            CoreName = v.ResourceName
            Core = v.GetFramework()
            CoreReady = true
            break
        end
    end
end)

function GetActiveInventory()
    if GetResourceState("qb-inventory") == "started" then
        return "qb-inventory"
    elseif GetResourceState("qs-inventory") == "started" then
        return "qs-inventory"
    elseif GetResourceState("ps-inventory") == "started" then
        return "ps-inventory"
    elseif GetResourceState("lj-inventory") == "started" then
        return "lj-inventory"
    elseif GetResourceState("ox_inventory") == "started" then
        return "ox_inventory"
    elseif GetResourceState("codem-inventory") == "started" then
        return "codem-inventory"
    elseif GetResourceState("inventory") == "started" then
        return "inventory"
    end
    return nil
end

function GetPlayer(source)
    if CoreName == "qbx_core" then
        return Core:GetPlayer(source)
    elseif CoreName == "qb-core" then
        return Core.Functions.GetPlayer(source)
    elseif CoreName == "es_extended" then
        return Core.GetPlayerFromId(source)
    end
end

function GetPlayers()
    if CoreName == "qbx_core" then
        return Core:GetQBPlayers()
    elseif CoreName == "qb-core" then
        return Core.Functions.GetPlayers()
    elseif CoreName == "es_extended" then
        return Core.GetExtendedPlayers()
    end
    return {}
end

function GetPlayerSource(player)
    if not player then return nil end
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        return player.PlayerData.source
    elseif CoreName == "es_extended" then
        return player.source
    end
    return nil
end

function AddItem(source, name, amount, metadata)
    if CoreName == "qbx_core" then
        return Core:AddItem(source, name, amount, metadata)
    elseif CoreName == "qb-core" then
        local player = Core.Functions.GetPlayer(source)
        return player and player.Functions.AddItem(name, amount, false, metadata)

    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('ox_inventory') == 'started'
        local hasCheeza = GetResourceState('inventory') == 'started'

        if hasQs then
            return exports['qs-inventory']:AddItem(source, name, amount, false, metadata)
        elseif hasEsx then
            return player and player.addInventoryItem(name, amount)
        elseif hasOx then
            return exports['ox_inventory']:AddItem(source, name, amount, metadata)
        elseif hasCheeza then
            local item = { type = "item_standard", name = name, metadata = metadata }
            local inv = { type = "player", id = source }
            return exports['inventory']:AddItemToInventory(source, item, amount, inv)
        end
    end
end

function AddMoney(src, type, amount, description)
    amount = tonumber(amount) or 0
    src = tonumber(src) or 0
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(src)
        if p and (type == "cash" or type == "bank") then
            p.Functions.AddMoney(type, amount, description)
        end
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(src)
        if p and (type == "cash" or type == "bank") then
            p.Functions.AddMoney(type, amount, description)
        end
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(src)
        if player then
            if type == "bank" then
                player.addAccountMoney("bank", amount, description)
            elseif type == "cash" then
                player.addMoney(amount, description)
            end
        end
    end
end

function RemoveMoney(src, type, amount, description)
    amount = tonumber(amount) or 0
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(src)
        if p then p.Functions.RemoveMoney(type, amount, description) end
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(src)
        if p then p.Functions.RemoveMoney(type, amount, description) end
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(src)
        if not p then return end
        if type == "bank" then
            p.removeAccountMoney("bank", amount, description)
        elseif type == "cash" then
            p.removeMoney(amount, description)
        end
    end
end

function GetPlayerMoney(src, type)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(src)
        return p and p.PlayerData.money[type] or 0
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(src)
        return p and p.PlayerData.money[type] or 0
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(src)
        if not p then return 0 end
        local acType = type == "cash" and "money" or "bank"
        local acc = p.getAccount(acType)
        return acc and acc.money or 0
    end
    return 0
end

function TransferVehicle(loserIdentifier, winnerIdentifier, carPlate, loserLicense)
    if not loserIdentifier or not winnerIdentifier or not carPlate then return end

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local vehicles = MySQL.Sync.fetchAll("SELECT * FROM player_vehicles WHERE citizenid = @citizenid AND plate = @plate", {
            ['@citizenid'] = loserIdentifier,
            ['@plate'] = carPlate
        })

        for _, veh in pairs(vehicles) do
            MySQL.Sync.execute("DELETE FROM player_vehicles WHERE id = @id", {
                ['@id'] = veh.id
            })

            MySQL.Sync.execute("INSERT INTO player_vehicles (license, citizenid, plate, vehicle, mods, hash, garage, state) VALUES (@license, @cid, @plate, @vehicle, @mods, @hash, @garage, @state)", {
                ['@license'] = loserLicense or veh.license or "UNKNOWN_LICENSE",
                ['@cid'] = winnerIdentifier,
                ['@plate'] = veh.plate,
                ['@vehicle'] = veh.vehicle,
                ['@mods'] = veh.mods,
                ['@hash'] = veh.hash,
                ['@garage'] = veh.garage or "pillboxgarage",
                ['@state'] = veh.state or 0
            })
        end

    elseif CoreName == "es_extended" then
        local vehicles = MySQL.Sync.fetchAll("SELECT * FROM owned_vehicles WHERE owner = @owner AND plate = @plate", {
            ['@owner'] = loserIdentifier,
            ['@plate'] = carPlate
        })

        for _, veh in pairs(vehicles) do
            MySQL.Sync.execute("DELETE FROM owned_vehicles WHERE id = @id", {
                ['@id'] = veh.id
            })

            MySQL.Sync.execute("INSERT INTO owned_vehicles (owner, plate, vehicle, stored, type) VALUES (@owner, @plate, @vehicle, @stored, @type)", {
                ['@owner'] = winnerIdentifier,
                ['@plate'] = veh.plate,
                ['@vehicle'] = veh.vehicle,
                ['@stored'] = veh.stored or 1,
                ['@type'] = veh.type or "car"
            })
        end
    end
end

function GetPlayerCid(source)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        return p and p.PlayerData.citizenid
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        return p and p.PlayerData.citizenid
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        return p and p.getIdentifier and p.getIdentifier()
    end
    return nil
end

function GetIdentifier(source)
    source = tonumber(source)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        return p and p.PlayerData.citizenid
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        return p and p.PlayerData.citizenid
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        return p and p.identifier
    end
end

function Notify(source, text, length, type)
    if CoreName == "qbx_core" then
        Core:Notify(source, text, type, length)
    elseif CoreName == "qb-core" then
        Core.Functions.Notify(source, text, type, length)
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        if p then p.showNotification(text) end
    end
end

function GetPlayerJob(source)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        if not p or not p.PlayerData.job then return nil, nil end
        return p.PlayerData.job.name, p.PlayerData.job.grade.level
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        if not p or not p.PlayerData.job then return nil, nil end
        return p.PlayerData.job.name, p.PlayerData.job.grade.level
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        if not p or not p.job then return nil, nil end
        return p.job.name, p.job.grade
    end
    return nil, nil
end

function GetPlayerJobDuty(source)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        return p and p.PlayerData.job and p.PlayerData.job.onduty or false
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        return p and p.PlayerData.job and p.PlayerData.job.onduty or false
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        return p and p.job and p.job.onDuty or false
    end
    return false
end

function SetPlayerJobDuty(source, state)
    local on = (state == true or state == 1)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        if p and p.Functions and p.Functions.SetJobDuty then
            p.Functions.SetJobDuty(on)
        elseif p and p.PlayerData.job then
            p.PlayerData.job.onduty = on
        end
        return GetPlayerJobDuty(source)
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        if p and p.Functions and p.Functions.SetJobDuty then
            p.Functions.SetJobDuty(on)
        elseif p and p.PlayerData.job then
            p.PlayerData.job.onduty = on
        end
        return GetPlayerJobDuty(source)
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        if p and p.job then
            p.job.onDuty = on
        end
        return GetPlayerJobDuty(source)
    end
    return false
end

function to01(x) return (x == 1 or x == true) and 1 or 0 end

function to01(x) 
    return (x == 1 or x == true) and 1 or 0 
end

function GetPlayerJobDutyInt(source)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        return p and p.PlayerData.job and to01(p.PlayerData.job.onduty) or 0
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        return p and p.PlayerData.job and to01(p.PlayerData.job.onduty) or 0
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        if p then
            local dutyStatus = p.getMeta('jobDuty')
            
            if dutyStatus == "true" or dutyStatus == 1 or dutyStatus == "1" then
                return 1
            else
                return 0
            end
        end
    end
    return 0
end

function SetPlayerJobDutyInt(source, state)
    local on = to01(state) == 1
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        if p and p.Functions and p.Functions.SetJobDuty then
            p.Functions.SetJobDuty(on)
        elseif p and p.PlayerData.job then
            p.PlayerData.job.onduty = on
        end
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        if p and p.Functions and p.Functions.SetJobDuty then
            p.Functions.SetJobDuty(on)
        elseif p and p.PlayerData.job then
            p.PlayerData.job.onduty = on
        end
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        if p then
            
            p.setMeta('jobDuty', on and "true" or "false")
            
            if p.job then
                p.job.onDuty = on
                TriggerClientEvent('esx:setJob', source, p.job)
            end
            
        end
    end
    
    return GetPlayerJobDutyInt(source)
end

function SetPlayerJobDutyIntAlternative(source, state)
    local on = to01(state) == 1
    
    if CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        if p and p.job then
            local currentJob = {
                name = p.job.name,
                label = p.job.label,
                grade = p.job.grade,
                grade_name = p.job.grade_name,
                grade_label = p.job.grade_label,
                grade_salary = p.job.grade_salary,
                skin_male = p.job.skin_male or {},
                skin_female = p.job.skin_female or {},
                onDuty = on 
            }
            
            p.setJob(currentJob.name, currentJob.grade)
            Wait(500) 
            
            p.job.onDuty = on
            
            TriggerClientEvent('esx:setJob', source, currentJob)
            
        end
    end
    
    return GetPlayerJobDutyInt(source)
end

function ESXToggleDuty(source)
    if CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        if p and p.job then
            local currentDuty = p.job.onDuty or false
            local newDuty = not currentDuty
            
            p.job.onDuty = newDuty
            
            TriggerClientEvent('esx:setJob', source, p.job)
            
            if p.identifier then
                MySQL.Async.execute('UPDATE users SET job_duty = @duty WHERE identifier = @identifier', {
                    ['@duty'] = newDuty and 1 or 0,
                    ['@identifier'] = p.identifier
                })
            end
            
            return newDuty
        end
    end
    return false
end

function GetPlayerGrade(source)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        return p and p.PlayerData.job and p.PlayerData.job.grade and p.PlayerData.job.grade.level or 0
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        return p and p.PlayerData.job and p.PlayerData.job.grade and p.PlayerData.job.grade.level or 0
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        return p and p.job and p.job.grade or 0
    end
    return 0
end

function IsDeptJob(jobName)
    if not jobName or jobName == '' then return false end
    for _, dept in pairs(FRKN.Departments or {}) do
        if dept and (dept.job == jobName or (type(dept.jobs) == 'table' and dept.jobs[jobName])) then
            return true
        end
    end
    return false
end

function GetPlayerJobAndGradeName(src)
    if CoreName == "qbx_core" then
        local player = Core:GetPlayer(src)
        if not player or not player.PlayerData.job then return nil, 0 end
        local job = player.PlayerData.job.label
        local grade = player.PlayerData.job.grade.name or ''
        local gradeLevel = tonumber(player.PlayerData.job.grade.level) or 0
        return job, grade, gradeLevel
    elseif CoreName == "qb-core" then
        local player = Core.Functions.GetPlayer(src)
        if not player or not player.PlayerData.job then
            return nil, 0
        end
        local job = player.PlayerData.job.label
        local grade = ''
        local gradeLevel = 0
        if type(player.PlayerData.job.grade) == "table" then
            grade = player.PlayerData.job.grade.name or 0
            gradeLevel = tonumber(player.PlayerData.job.grade.level) or 0
        else
            grade = player.PlayerData.job.grade.name or 0
            gradeLevel = tonumber(player.PlayerData.job.grade) or 0
        end
        return job, grade , gradeLevel

    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(src)
        if not player or not player.job then
            return nil, 0
        end
        local job = player.job.label
        local grade = ''
        local gradeLevel = 0
        
            grade = tonumber(player.job.grade_label) 
            gradeLevel = tonumber(player.job.grade) 
        
        return job, grade, gradeLevel
    end
    return nil, 0
end

function GetPlayerJobAndGrade(src)
    if CoreName == "qbx_core" then
        local player = Core:GetPlayer(src)
        if not player or not player.PlayerData.job then return nil, 0 end
        return player.PlayerData.job.name, tonumber(player.PlayerData.job.grade.level) or 0
    elseif CoreName == "qb-core" then
        local player = Core.Functions.GetPlayer(src)
        if not player or not player.PlayerData.job then
            return nil, 0
        end
        local job = player.PlayerData.job.name
        local grade = 0
        if type(player.PlayerData.job.grade) == "table" then
            grade = tonumber(player.PlayerData.job.grade.level) or 0
        else
            grade = tonumber(player.PlayerData.job.grade) or 0
        end
        return job, grade

    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(src)
        if not player or not player.job then
            return nil, 0
        end
        local job = player.job.name
        local grade = 0
        if type(player.job.grade) == "table" then
            grade = tonumber(player.job.grade.level) or 0
        else
            grade = tonumber(player.job.grade) or 0
        end
        return job, grade
    end
    return nil, 0
end

function GetPlayerName(source)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        if not p or not p.PlayerData.charinfo then return "Unknown" end
        return ("%s %s"):format(p.PlayerData.charinfo.firstname or "", p.PlayerData.charinfo.lastname or "")
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        if not p or not p.PlayerData.charinfo then return "Unknown" end
        return ("%s %s"):format(p.PlayerData.charinfo.firstname or "", p.PlayerData.charinfo.lastname or "")
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(source)
        return p and p.name or "Unknown"
    end
    return "Unknown"
end

function GetPlayerNameInPlayer(player)
    if CoreName == "qbx_core" or CoreName == "qb-core" then
        if player and player.PlayerData and player.PlayerData.charinfo then
            return ("%s %s"):format(player.PlayerData.charinfo.firstname or "", player.PlayerData.charinfo.lastname or "")
        end
        return "Unknown"
    elseif CoreName == "es_extended" then
        return player.name 
    end
end

function GetSourceFromIdentifier(identifier)
    for _, src in pairs(GetPlayers()) do
        local ids = GetPlayerIdentifiers(src)
        for _, id in pairs(ids) do
            if id == identifier then
                return tonumber(src)
            end
        end
    end
    return nil
end

function IsAdmin(src)
    if CoreName == "qbx_core" then
        return Core:HasPermission(src, FRKN.AdminPermission or 'admin')
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(src)
        if not p then return false end
        return Core.Functions.HasPermission(p.PlayerData.source, FRKN.AdminPermission or 'admin')
    elseif CoreName == "es_extended" then
        local p = Core.GetPlayerFromId(src)
        if not p then return false end
        local grp = p.getGroup and p.getGroup() or "user"
        return grp == (FRKN.AdminPermission or 'admin')
    end
    return false
end

function CoreGetPlayerByIdentifier(identifier)
    if CoreName == "es_extended" then
        if Core.GetPlayerFromIdentifier then
            return Core.GetPlayerFromIdentifier(identifier)
        end
        if Core.GetExtendedPlayers then
            local list = Core.GetExtendedPlayers()
            for _, x in pairs(list) do
                if x and x.getIdentifier and x.getIdentifier() == identifier then
                    return x
                end
            end
        end
        return nil
    else
        if Core.Functions and Core.Functions.GetPlayerByCitizenId then
            return Core.Functions.GetPlayerByCitizenId(identifier)
        end
        return nil
    end
end

function CoreSetJob(player, job, grade)
    if not player then return false end

    if CoreName == "es_extended" then
        if player.setJob then
            player.setJob(job, grade)

            if job == "unemployed" then
                local identifier = player.identifier
                if identifier then
                    MySQL.update('UPDATE users SET job = ?, job_grade = ? WHERE identifier = ?', 
                        { 'unemployed', 0, identifier })
                end
            end

            return true
        end
    else
        if player.Functions and player.Functions.SetJob then
            player.Functions.SetJob(job, grade)
            if job == "unemployed" then
                local cid = player.PlayerData and player.PlayerData.citizenid
                if cid then
                    local unemployedJson = '{"onduty":true,"isboss":false,"type":"none","label":"Civilian","name":"unemployed","grade":{"payment":10,"isboss":false,"name":"Freelancer","level":0}}'
                    MySQL.update('UPDATE players SET job = ? WHERE citizenid = ?', { unemployedJson, cid })
                end
            end
            return true
        end
    end

    return false
end

function CoreGetPlayerByIdentifier(identifier)
    if not identifier then return nil end
    if CoreName == "es_extended" then
        if Core.GetPlayerFromIdentifier then
            local p = Core.GetPlayerFromIdentifier(identifier)
            if p then return p end
        end
        if Core.GetExtendedPlayers then
            local list = Core.GetExtendedPlayers()
            for _, x in pairs(list) do
                if x and x.getIdentifier and x.getIdentifier() == identifier then
                    return x
                end
            end
        end
        return nil
    else
        if Core.Functions and Core.Functions.GetPlayerByCitizenId then
            local p = Core.Functions.GetPlayerByCitizenId(identifier)
            if p then return p end
        end
        if Core.Functions and Core.Functions.GetPlayers then
            for _, src in ipairs(Core.Functions.GetPlayers()) do
                local pl = Core.Functions.GetPlayer(src)
                if pl and pl.PlayerData and pl.PlayerData.citizenid == identifier then
                    return pl
                end
            end
        end
        return nil
    end
end

function getDiscordImg(src)
    local identifiers = GetPlayerIdentifiers(src)
    if identifiers == nil then
        return "../images/defaultpp.webp"
    end

    local myIdentifier = nil
    for _, identifier in pairs(identifiers) do
        if string.find(identifier, "license:") then
            myIdentifier = identifier
        end
    end
    while myIdentifier == nil do Citizen.Wait(0) end

    local myDiscord = nil
    for _, identifier in pairs(identifiers) do
        if string.find(identifier, "discord:") then
            myDiscord = string.gsub(identifier, "discord:", "")
        end
    end
    local discordProfileAvatar = "../images/defaultpp.webp"
    while myDiscord == nil do Citizen.Wait(5000) if myDiscord == nil then break end end
    local endpoint = ("users/%s"):format(myDiscord)
    local member = DiscordRequest("GET", endpoint, {})
    local memberData = json.decode(member.data)
    if memberData ~= nil then
        discordProfileAvatar = "https://cdn.discordapp.com/avatars/" .. myDiscord .. "/" .. memberData.avatar
    end
    return discordProfileAvatar
end

function DiscordRequest(method, endpoint, jsondata, reason)
    local FormattedToken = "Bot " .. FRKN.BotToken
    local data = nil
    PerformHttpRequest("https://discord.com/api/"..endpoint, function(errorCode, resultData, resultHeaders) data = {data=resultData, code=errorCode, headers=resultHeaders}
    end, method, #jsondata > 0 and jsondata or "", {["Content-Type"] = "application/json", ["Authorization"] = FormattedToken, ['X-Audit-Log-Reason'] = reason})
    while data == nil do Citizen.Wait(0) end
    return data
end

function RemoveItem(source, name, amount, metadata)
    if CoreName == "qbx_core" then
        return Core:RemoveItem(source, name, amount, metadata)
    elseif CoreName == "qb-core" then
        local player = Core.Functions.GetPlayer(source)
        if player then
            player.Functions.RemoveItem(name, amount, metadata)
        end

    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('ox_inventory') == 'started'
        local hasCodem = GetResourceState('codem-inventory') == 'started'
        local hasCheeza = GetResourceState('inventory') == 'started'

        if hasQs then
            return exports['qs-inventory']:RemoveItem(source, name, amount, metadata)

        elseif hasEsx then
            return player and player.removeInventoryItem(name, amount)

        elseif hasOx then
            return exports["ox_inventory"]:RemoveItem(source, name, amount, metadata)

        elseif hasCodem then
            return exports["codem-inventory"]:RemoveItem(source, name, amount, metadata)

        elseif hasCheeza then
            local item = { type = "item_standard", name = name, metadata = metadata }
            local inv = { type = "player", id = source }
            return exports['inventory']:RemoveItemFromInventory(source, item, amount, inv)
        else
            
        end
    end
end

function GetItemByName(player, name)
    local src = player.PlayerData and player.PlayerData.source or player.source
    local hasOx = GetResourceState('ox_inventory') == 'started'

    if CoreName == "qbx_core" or CoreName == "qb-core" then
        if hasOx then
            return exports.ox_inventory:GetItem(src, name, nil, true)
        else
            return player and player.Functions and player.Functions.GetItemByName(name)
        end
    elseif CoreName == "es_extended" then
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasCodem = GetResourceState('codem-inventory') == 'started'
        local hasCheeza = GetResourceState('inventory') == 'started'

        if hasQs then
            return exports['qs-inventory']:GetItem(src, name)
        elseif hasEsx then
            return player.getInventoryItem(name)
        elseif hasOx then
            local item = exports.ox_inventory:GetItem(src, name, nil, true)
            return item
        elseif hasCodem then
            return exports['codem-inventory']:GetItemByName(src, name)
        elseif hasCheeza then
            local inv = exports['inventory']:getInventory(src)
            for _, itemData in pairs(inv) do
                if itemData.name == name then
                    return itemData
                end
            end
            return nil
        end
    end
end

function HasAnyItem(xPlayer, items)
    if not items then return false end

    if type(items) == "string" then
        items = { items }
    end

    for _, itemName in pairs(items) do
        local item = nil
        if CoreName == 'es_extended' then
            item = xPlayer.hasItem(itemName)
        else
            item = xPlayer.Functions.GetItemByName(itemName)
        end

        if item and (item.amount or item.count or 0) > 0 then
            return true
        end
    end
    return false 
end

function GetClosestPlayer(source, coords)
    local ped = GetPlayerPed(source)
    local players = GetPlayers()
    local closestDistance, closestPlayer = -1, -1
    if coords then coords = type(coords) == 'table' and vector3(coords.x, coords.y, coords.z) or coords end
    if not coords then coords = GetEntityCoords(ped) end
    for i = 1, #players do
        local playerId = players[i]
        local playerPed = GetPlayerPed(playerId)
        if playerPed ~= ped then
            local playerCoords = GetEntityCoords(playerPed)
            local distance = #(playerCoords - coords)
            if closestDistance == -1 or distance < closestDistance then
                closestPlayer = playerId
                closestDistance = distance
            end
        end
    end
    return closestPlayer, closestDistance
end

RegisterNetEvent('frkn-policejob:OpenStash')
AddEventHandler('frkn-policejob:OpenStash', function(stashId, maxw, maxs)
    local src = source
    local hasQs = GetResourceState('qs-inventory') == 'started'
    local hasCheeza = GetResourceState('inventory') == 'started'

    if hasQs then 
        exports["qs-inventory"]:RegisterStash(src, stashId, maxs, maxw)

    elseif FRKN.Inventory == 'new-qb-inventory' then
        exports["qb-inventory"]:OpenInventory(src, stashId, {
            maxweight = maxw,
            slots = maxs
        })

    elseif hasCheeza then
        exports['inventory']:OpenInventory({
            type = "stash",
            id = stashId,
            maxWeight = maxw,
            slots = maxs
        }, src)

    else
        exports["qb-inventory"]:OpenInventory("stash", stashId, {
            maxweight = maxw,
            slots = maxs
        }, src)
    end
end)

function GetEvidenceMetas(source)
    local hasOx = GetResourceState('ox_inventory') == 'started'
    local hasQs = GetResourceState('qs-inventory') == 'started'
    local hasCheeza = GetResourceState('inventory') == 'started'

    if CoreName == "qbx_core" or CoreName == "qb-core" then
        if hasOx then
            local bagItems = exports.ox_inventory:Search(source, 'slots', 'evidence_bag_full') or {}
            local tubeItems = exports.ox_inventory:Search(source, 'slots', 'evidence_tube_full') or {}
            local bag, tube = {}, {}
            for i = 1, #bagItems do
                bag[#bag+1] = bagItems[i].metadata or bagItems[i].info or {}
            end
            for i = 1, #tubeItems do
                tube[#tube+1] = tubeItems[i].metadata or tubeItems[i].info or {}
            end
            return bag, tube
        else
            local p = CoreName == "qbx_core" and Core:GetPlayer(source) or Core.Functions.GetPlayer(source)
            local items = (p and p.PlayerData and p.PlayerData.items) or {}
            local bag, tube = {}, {}

            for _, it in pairs(items) do
                if it and it.name == 'evidence_bag_full' and it.info then 
                    bag[#bag+1] = it.info 
                end
                if it and it.name == 'evidence_tube_full' and it.info then 
                    tube[#tube+1] = it.info 
                end
            end

            return bag, tube
        end

    elseif hasOx then
        
        local bagItems = exports.ox_inventory:Search(source, 'slots', 'evidence_bag_full') or {}
        local tubeItems = exports.ox_inventory:Search(source, 'slots', 'evidence_tube_full') or {}
        local bag, tube = {}, {}

        for i = 1, #bagItems do
            local it = bagItems[i]
            bag[#bag+1] = it.metadata or it.info or {}
        end

        for i = 1, #tubeItems do
            local it = tubeItems[i]
            tube[#tube+1] = it.metadata or it.info or {}
        end

        return bag, tube

    elseif hasQs then
        local inv = exports['qs-inventory']:GetInventory(source) or {}
        local bag, tube = {}, {}

        for _, it in pairs(inv) do
            if it and it.name == 'evidence_bag_full' and (it.info or it.metadata or it.meta) then 
                bag[#bag+1] = it.info or it.metadata or it.meta 
            end
            if it and it.name == 'evidence_tube_full' and (it.info or it.metadata or it.meta) then 
                tube[#tube+1] = it.info or it.metadata or it.meta 
            end
        end

        return bag, tube

    elseif hasCheeza then
        local inv = exports['inventory']:getInventory(source) or {}
        local bag, tube = {}, {}

        for _, it in pairs(inv) do
            if it and it.name == 'evidence_bag_full' and (it.info or it.metadata) then 
                bag[#bag+1] = it.info or it.metadata 
            end
            if it and it.name == 'evidence_tube_full' and (it.info or it.metadata) then 
                tube[#tube+1] = it.info or it.metadata 
            end
        end

        return bag, tube
    end

    return {}, {}
end

function GetItem(p, name)
    if CoreName == "qbx_core" or CoreName == "qb-core" then
        return p and p.Functions and p.Functions.GetItemByName(name)

    elseif CoreName == "es_extended" then
        local player = p
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('ox_inventory') == 'started'
        local hasCodem = GetResourceState('codem-inventory') == 'started'
        local hasCheeza = GetResourceState('inventory') == 'started'

        if hasQs then
            return exports['qs-inventory']:GetItem(source, name)
        elseif hasEsx then
            return player.getInventoryItem(name)
        elseif hasOx then
            return exports["ox_inventory"]:GetItem(source, name)
        elseif hasCodem then
            return exports["codem-inventory"]:GetItemByName(source, name)
        elseif hasCheeza then
            local inv = exports['inventory']:getInventory(source) or {}
            for _, it in pairs(inv) do
                if it.name == name then
                    return it
                end
            end
            return nil
        else
            
        end
    end
end

function GetItemCount(source, item)
    if CoreName == "qbx_core" then
        local p = Core:GetPlayer(source)
        local it = p and p.Functions.GetItemByName(item)
        return it and it.amount or 0
    elseif CoreName == "qb-core" then
        local p = Core.Functions.GetPlayer(source)
        local it = p and p.Functions.GetItemByName(item)
        return it and it.amount or 0

    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('ox_inventory') == 'started'
        local hasCheeza = GetResourceState('inventory') == 'started'

        if hasQs then
            local itm = exports['qs-inventory']:GetItem(source, item)
            return itm and itm.amount or 0

        elseif hasEsx then
            local itm = player.getInventoryItem(item)
            return itm and (itm.count or itm.amount or 0) or 0

        elseif hasOx then
            local result = exports["ox_inventory"]:Search(source, 'count', item)
            return result or 0

        elseif hasCheeza then
            local inv = exports['inventory']:getInventory(source) or {}
            for _, it in pairs(inv) do
                if it.name == item then
                    return it.count or it.amount or 0
                end
            end
            return 0

        else
            
            return 0
        end
    end
end

function IsAlcoholItem(itemName)
    return FRKN and FRKN.alcohol and FRKN.alcohol[itemName] ~= nil
end

function RegisterUsableItem(name)
    while CoreReady == false do Citizen.Wait(0) end

    local function onUse(source, item)
        local handcuffItem = (FRKN and FRKN.HandCuffItem) or "handcuffs"
        local cuffKeyItem = (FRKN and FRKN.CuffKeyItem) or "cuffkeys"
        
        if name == handcuffItem then 
            TriggerClientEvent('frkn-policejob:client:cuffplayer', source, false)
        elseif name == cuffKeyItem then
            TriggerClientEvent('frkn-policejob:client:UnCuffPlayer', source)
        elseif IsAlcoholItem(name) then
            TriggerClientEvent('consumables:client:DrinkAlcohol', source, name, (FRKN and FRKN.alcohol and FRKN.alcohol[name]) or 0)
        end
    end

    local hasQs = GetResourceState('qs-inventory') == 'started'
    local hasCheeza = GetResourceState('inventory') == 'started'

    if hasQs then
        exports['qs-inventory']:CreateUsableItem(name, function(source, item)
            onUse(source, item)
        end)
    elseif CoreName == "qbx_core" then
        Core.Functions.CreateUseableItem(name, function(source, item)
            onUse(source, item)
        end)
    elseif CoreName == "qb-core" then
        Core.Functions.CreateUseableItem(name, function(source, item)
            onUse(source, item)
        end)
    elseif CoreName == "es_extended" then
        Core.RegisterUsableItem(name, function(source, item)
            onUse(source, item)
        end)
    elseif hasCheeza then
        exports['inventory']:RegisterUsableItem(name, function(source, item)
            onUse(source, item)
        end)
    end
end

CreateThread(function()
    while not FRKN do Wait(100) end
    FRKN.ServerCallbacks = FRKN.ServerCallbacks or {}
end)

function CreateCallback(name, cb)
    if not FRKN then FRKN = {} end
    if not FRKN.ServerCallbacks then FRKN.ServerCallbacks = {} end
    FRKN.ServerCallbacks[name] = cb
end

function TriggerCallback(name, source, cb, ...)
    if not FRKN.ServerCallbacks[name] then return end
    FRKN.ServerCallbacks[name](source, cb, ...)
end

RegisterNetEvent('frkn-policejob:server:triggerCallback', function(name, ...)
    local src = source
    TriggerCallback(name, src, function(...)
        TriggerClientEvent('frkn-policejob:client:triggerCallback', src, name, ...)
    end, ...)
end)

CreateCallback('frkn-policejob:hasVehicleModel', function(source, cb, model)
    local src = source
    local identifier = GetPlayerCid(src) or GetPlayerIdentifier(src)
    local VehicleTableName = FRKN.VehicleTableName or 'player_vehicles'
    if VehicleTableName == 'owned_vehicles' then
        local modelHash = joaat(model)
        MySQL.Async.fetchAll('SELECT vehicle FROM owned_vehicles WHERE owner = ?', {identifier}, function(rows)
            for _, r in ipairs(rows or {}) do
                local v = type(r.vehicle) == 'string' and json.decode(r.vehicle) or r.vehicle
                if v and tonumber(v.model) == tonumber(modelHash) then cb(true) return end
            end
            cb(false)
        end)
    else
        MySQL.Async.fetchScalar('SELECT 1 FROM player_vehicles WHERE citizenid = ? AND vehicle = ? LIMIT 1', {identifier, model}, function(found)
            cb(found and true or false)
        end)
    end
end)

CreateCallback('frkn-policejob:savePurchasedVehicle', function(source, cb, payload)
    local src = source
    local identifier = GetPlayerCid(src) or GetPlayerIdentifier(src)
    local VehicleTableName = FRKN.VehicleTableName or 'player_vehicles'
    local model = payload.vehicle
    local plate = payload.plate
    local props = payload.vehicleprops
    local propsJson = type(props) == 'table' and json.encode(props) or (props or "{}")
    local price = tonumber(payload.price) or 0
    local garageName = FRKN.GarageName or "pillboxgarage"

    local function log(ok, why)
        local pname = GetPlayerName(src) or "Unknown"
        local title = ok and "🚗 Vehicle Saved" or "🚫 Vehicle Not Saved"
        local desc = ok and "Purchase stored successfully." or tostring(why or "Database rejected.")
        local color = ok and 3066993 or 15158332
        local items = {}
        if type(props) == "table" then
            if props.color1 then items[#items+1] = ("Primary: %s"):format(tostring(props.color1)) end
            if props.color2 then items[#items+1] = ("Secondary: %s"):format(tostring(props.color2)) end
            if props.plate then items[#items+1] = ("PropsPlate: %s"):format(tostring(props.plate)) end
        end

        local did = GetDiscordId(src)
        local mention = did and ("<@"..did..">") or "Not connected to Discord"

        DiscordLog(WEBHOOK_VEHICLE, {
            username = "FRKN Police Job Log System",
            title = title,
            description = desc,
            color = color,
            footer = ("Police Shop • %s"):format(os.date("%d.%m.%Y %H:%M")),
            kv_inline = true,
            kv = {
                Props = (#items>0) and table.concat(items, " | ") or "-",
                Model = tostring(model),
                Plate = tostring(plate),
                Discord = mention,           
                Price = ("$%s"):format(price),
                Garage = tostring(garageName),
                Table = tostring(VehicleTableName),
                CID = tostring(identifier),
                Player = ("%s (%d)"):format(pname, src)
            },
            allowed_users = did and { did } or nil 
        })
    end

    if VehicleTableName == 'owned_vehicles' then
        local modelHash = joaat(model)
        MySQL.Async.fetchAll('SELECT vehicle FROM owned_vehicles WHERE owner = ?', {identifier}, function(rows)
            for _, r in ipairs(rows or {}) do
                local v = type(r.vehicle) == 'string' and json.decode(r.vehicle) or r.vehicle
                if v and tonumber(v.model) == tonumber(modelHash) then
                    log(false, "Duplicate model for owner")
                    cb(false)
                    return
                end
            end
            MySQL.Async.execute([[
                INSERT INTO owned_vehicles (owner, plate, vehicle, type, job, stored, parking, pound, mileage, glovebox, trunk)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ]], {identifier, plate, propsJson, "car", "civ", 0, garageName, 0, 0, "[]", "[]"}, function(aff)
                if aff and aff > 0 then
                    RemoveMoney(src, 'cash', price)
                    log(true)
                    cb(true)
                else
                    log(false, "Insert failed")
                    cb(false)
                end
            end)
        end)
    else
        local license
        for _, id in ipairs(GetPlayerIdentifiers(src)) do if id:match("^license:") then license = id break end end
        MySQL.Async.fetchScalar('SELECT 1 FROM player_vehicles WHERE citizenid = ? AND vehicle = ? LIMIT 1', {identifier, model}, function(found)
            if found then
                log(false, "Duplicate record")
                cb(false)
                return
            end
            MySQL.Async.execute([[
                INSERT INTO player_vehicles (
                    license, citizenid, vehicle, hash, mods, plate, fakeplate, garage,
                    fuel, engine, body, state, depotprice, drivingdistance
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ]], {license, identifier, model, joaat(model), propsJson, plate, nil, garageName, 100, 1000, 1000, 0, 0, 0}, function(aff)
                if aff and aff > 0 then
                    RemoveMoney(src, 'cash', price)
                    log(true)
                    cb(true)
                else
                    log(false, "Insert failed")
                    cb(false)
                end
            end)
        end)
    end
end)

