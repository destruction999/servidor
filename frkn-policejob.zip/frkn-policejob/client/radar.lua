


radarOn = false
remoteOpen = false

local RadarState = {
    fastMode = false,
    frontLocked = false,
    rearLocked = false,
    frontMaxSpeed = nil,
    rearMaxSpeed = nil,
    sensitivity = 1,
    sizeModifier = 1
}

local POLICE_VEHICLE_CLASS = 18

local RadarConfig = {
    frontOffset = (FRKN and FRKN.Radar and FRKN.Radar.frontOffset) or 3.5,
    backOffset = (FRKN and FRKN.Radar and FRKN.Radar.backOffset) or 3.5,
    height = (FRKN and FRKN.Radar and FRKN.Radar.height) or 0.5,
    radius = (FRKN and FRKN.Radar and FRKN.Radar.radius) or 3.2,
    frontPlateDistance = (FRKN and FRKN.Radar and FRKN.Radar.plateDistance and FRKN.Radar.plateDistance.front) or 70.0,
    backPlateDistance = (FRKN and FRKN.Radar and FRKN.Radar.plateDistance and FRKN.Radar.plateDistance.back) or 70.0
}

local function GetVehicleSpeedAndPlate(vehicle)
    local speed = math.floor(GetEntitySpeed(vehicle) * 3.6 + 0.5)
    local plate = (GetVehicleNumberPlateText(vehicle) or ""):gsub("%s+$", "")
    return speed, plate
end

local function RaycastVehicle(startPos, endPos, radius, ignoreEntity)
    local shapeTest = StartShapeTestCapsule(
        startPos.x, startPos.y, startPos.z,
        endPos.x, endPos.y, endPos.z,
        radius, 2, ignoreEntity or 0, 7
    )
    
    local _, hit, _, _, entity = GetShapeTestResult(shapeTest)
    
    if hit == 1 and entity ~= 0 and IsEntityAVehicle(entity) then
        return entity
    end
    
    return 0
end

local function IsInPoliceVehicle()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    if vehicle == 0 then
        return false, "error.not_in_vehicle"
    end
    
    if GetVehicleClass(vehicle) ~= POLICE_VEHICLE_CLASS then
        return false, "error.not_in_police_vehicle"
    end
    
    return true, vehicle
end

local function StartRadarLoop()
    CreateThread(function()
        local frontMaxSpeed = 0
        local frontMaxPlate = ""
        local rearMaxSpeed = 0
        local rearMaxPlate = ""
        local patrolMaxSpeed = 0
        
        while radarOn do
            local ped = PlayerPedId()
            local vehicle = GetVehiclePedIsIn(ped, false)
            
            if vehicle ~= 0 then
                local vehPos = GetEntityCoords(vehicle)
                local vehForward = GetEntityForwardVector(vehicle)
                local upVector = vector3(0.0, 0.0, 1.0)
                
                local frontStart = vehPos + (vehForward * RadarConfig.frontOffset) + (upVector * RadarConfig.height)
                local frontEnd = vehPos + (vehForward * RadarConfig.frontPlateDistance) + (upVector * RadarConfig.height)
                local rearStart = vehPos - (vehForward * RadarConfig.backOffset) + (upVector * RadarConfig.height)
                local rearEnd = vehPos - (vehForward * RadarConfig.backPlateDistance) + (upVector * RadarConfig.height)
                
                local frontVehicle = RaycastVehicle(frontStart, frontEnd, RadarConfig.radius, vehicle)
                local rearVehicle = RaycastVehicle(rearStart, rearEnd, RadarConfig.radius, vehicle)
                
                local frontSpeed, frontPlate = 0, ""
                if frontVehicle ~= 0 then
                    frontSpeed, frontPlate = GetVehicleSpeedAndPlate(frontVehicle)
                    if frontSpeed > frontMaxSpeed then
                        frontMaxSpeed = frontSpeed
                        frontMaxPlate = frontPlate
                    end
                end
                
                local rearSpeed, rearPlate = 0, ""
                if rearVehicle ~= 0 then
                    rearSpeed, rearPlate = GetVehicleSpeedAndPlate(rearVehicle)
                    if rearSpeed > rearMaxSpeed then
                        rearMaxSpeed = rearSpeed
                        rearMaxPlate = rearPlate
                    end
                end
                
                local currentMax = math.max(frontSpeed, rearSpeed, frontMaxSpeed, rearMaxSpeed)
                if currentMax > patrolMaxSpeed then
                    patrolMaxSpeed = currentMax
                end
                
                SendNUIMessage({
                    action = "radar",
                    front = {
                        live = frontSpeed,
                        livePlate = frontPlate,
                        fast = frontMaxSpeed,
                        fastPlate = frontMaxPlate
                    },
                    back = {
                        live = rearSpeed,
                        livePlate = rearPlate,
                        fast = rearMaxSpeed,
                        fastPlate = rearMaxPlate
                    },
                    patrol = patrolMaxSpeed
                })
            end
            
            Wait(120)
        end
    end)
end

RegisterCommand("radaron", function()
    if radarOn then
        ExecuteCommand("radaroff")
        return
    end
    
    radarOn = true
    SendNUIMessage({action = "radar_visible", state = true})
    StartRadarLoop()
end, false)

RegisterCommand("radaroff", function()
    radarOn = false
    SendNUIMessage({
        action = "radar",
        front = {live = 0, fast = 0},
        back = {live = 0, fast = 0},
        patrol = 0
    })
    SendNUIMessage({action = "radar_visible", state = false})
end, false)

RegisterCommand("lockfront", function()
    if RadarState.frontMaxSpeed then
        RadarState.frontLocked = true
        Notify(Lang.t("success.front_locked"))
    else
        Notify(Lang.t("error.front_no_data"))
    end
end, false)

RegisterCommand("unlockfront", function()
    RadarState.frontLocked = false
    Notify(Lang.t("success.front_unlocked"))
end, false)

RegisterCommand("lockrear", function()
    if RadarState.rearMaxSpeed then
        RadarState.rearLocked = true
        Notify(Lang.t("success.rear_locked"))
    else
        Notify(Lang.t("error.rear_no_data"))
    end
end, false)

RegisterCommand("unlockrear", function()
    RadarState.rearLocked = false
    Notify(Lang.t("success.rear_unlocked"))
end, false)

RegisterCommand("fastmode", function()
    RadarState.fastMode = not RadarState.fastMode
    Notify(Lang.t(RadarState.fastMode and "success.fast_on" or "success.fast_off"))
end, false)

RegisterCommand("remote", function()
    remoteOpen = not remoteOpen
    SendNUIMessage({action = "toggleRemote", state = remoteOpen})
    SetNuiFocus(remoteOpen, remoteOpen)
end, false)

RegisterNetEvent("frkn-policejob:radarOn", function()
    local success, vehicleOrError = IsInPoliceVehicle()
    
    if not success then
        return Notify(Lang.t(vehicleOrError), "error")
    end
    
    ExecuteCommand("radaron")
    
    CreateThread(function()
        while true do
            Wait(500)
            
            if not IsPedInAnyVehicle(PlayerPedId(), false) then
                radarOn = false
                SendNUIMessage({action = "playerLeftVehicle"})
                break
            end
        end
    end)
end)

RegisterNetEvent("frkn-policejob:radarRemote", function()
    local success, vehicleOrError = IsInPoliceVehicle()
    
    if not success then
        return Notify(Lang.t(vehicleOrError), "error")
    end
    
    Wait(100)
    SetNuiFocus(true, true)
    ExecuteCommand("remote")
end)

RegisterNUICallback("closeRemote", function(data, cb)
    SetNuiFocus(false, false)
    cb({ok = true})
end)

RegisterNUICallback("radarError", function(data, cb)
    Notify(Lang.t("error.radar_not_active"), "error")
    SetNuiFocus(false, false)
end)

RegisterNUICallback("nuiClose", function()
    SetNuiFocus(false, false)
end)

RegisterNUICallback("remote", function(data, cb)
    local operation = data and data.op or ""
    
    local commands = {
        radaron = "radaron",
        radaroff = "radaroff",
        lockfront = "lockfront",
        unlockfront = "unlockfront",
        lockrear = "lockrear",
        unlockrear = "unlockrear",
        fastmode = "fastmode"
    }
    
    if commands[operation] then
        ExecuteCommand(commands[operation])
    elseif operation == "sensitivity" then
        local direction = data.dir
        if direction == "up" then
            RadarState.sensitivity = (RadarState.sensitivity or 1) + 1
        else
            RadarState.sensitivity = (RadarState.sensitivity or 1) - 1
        end
    elseif operation == "size" then
        RadarState.sizeModifier = tonumber(data.value) or RadarState.sizeModifier
    end
    
    cb({ok = true})
end)

