


local hasInitialized = false
local isOnDuty = false

local function GetDutyKvpKey(job)
    return string.format("frkn-policejob:%s:onDuty", job)
end

local function GetStoredDutyState(job)
    local value = GetResourceKvpInt(GetDutyKvpKey(job)) or 0
    return value == 1
end

local function SaveDutyState(job, state)
    SetResourceKvpInt(GetDutyKvpKey(job), state and 1 or 0)
end

local function GetPlayerInfo()
    local name = GetPlayerName(PlayerId())
    local job = GetPlayerJob()
    local identifier = GetPlayerIdentifier() or tostring(GetPlayerServerId(PlayerId()))
    
    return name, identifier, job, isOnDuty
end

function Duty_GetWorkers(job, callback)
    job = job or GetPlayerJob()
    
    TriggerCallback("frkn-policejob:server:getWorkers", function(data)
        if callback then
            callback(data)
        end
    end, {job = job})
end

function Duty_GetHistory(callback)
    TriggerCallback("frkn-policejob:server:getHistory", function(data)
        if callback then
            callback(data)
        end
    end)
end

function Duty_PushWorkersToUI(job)
    Duty_GetWorkers(job, function(data)
        if type(data) ~= "table" then return end
        
        SendNUIMessage({
            action = "duty_set_workers",
            data = data
        })
    end)
end

function Duty_PushHistoryToUI()
    Duty_GetHistory(function(data)
        if type(data) ~= "table" then return end
        
        SendNUIMessage({
            action = "duty_set_history",
            data = data
        })
    end)
end

local function GetDutyState(callback)
    TriggerCallback("frkn-policejob:server:getDuty", function(success, dutyValue)
        if success then
            isOnDuty = dutyValue == 1
            local job = GetPlayerJob()
            SaveDutyState(job, isOnDuty)
        end
        
        if callback then
            callback(isOnDuty)
        end
    end)
end

local function SetDutyState(newState)
    local job = GetPlayerJob()
    
    if newState == nil then
        newState = not isOnDuty
    end
    
    TriggerCallback("frkn-policejob:server:setDuty", function(success, dutyValue)
        if not success then return end
        
        isOnDuty = dutyValue == 1
        SaveDutyState(job, isOnDuty)
    end, {
        job = job,
        state = newState and 1 or 0
    })
end

function OpenDutyMenu(menuIndex)
    GetDutyState(function(currentDuty)
        isOnDuty = currentDuty
        
        local name = GetPlayerName(PlayerId())
        local identifier = GetPlayerIdentifier() or tostring(GetPlayerServerId(PlayerId()))
        local job = GetPlayerJob()
        
        local workersData, historyData
        
        local function TryOpenMenu()
            if workersData and historyData then
                SendNUIMessage({
                    action = "openMenu",
                    menu = "duty-menu",
                    name = name,
                    cid = identifier,
                    job = job,
                    duty = isOnDuty and 1 or 0,
                    workers = workersData,
                    history = historyData,
                    index = menuIndex or 1
                })
                
                SetNuiFocus(true, true)
            end
        end
        
        Duty_GetWorkers(job, function(data)
            workersData = data or {online = {}, offline = {}}
            TryOpenMenu()
        end)
        
        Duty_GetHistory(function(data)
            historyData = data or {open = nil, list = {}}
            TryOpenMenu()
        end)
    end)
end

AddEventHandler("onResourceStart", function(resourceName)
    if GetCurrentResourceName() ~= resourceName or hasInitialized then
        return
    end
    
    hasInitialized = true
    Wait(150)
    
    local job = GetPlayerJob()
    local storedDuty = GetStoredDutyState(job)
    
    GetDutyState(function(serverDuty)
        if storedDuty and not serverDuty then
            SetDutyState(true)
        elseif not storedDuty and serverDuty then
            isOnDuty = true
            SaveDutyState(job, true)
        end
    end)
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1500)
        
        if NetworkIsPlayerActive(PlayerId()) then
            local job = GetPlayerJob()
            local storedDuty = GetStoredDutyState(job)
            
            GetDutyState(function(serverDuty)
                if storedDuty and not serverDuty then
                    SetDutyState(true)
                elseif not storedDuty and serverDuty then
                    isOnDuty = true
                    SaveDutyState(job, true)
                end
            end)
            
            break
        end
    end
end)

RegisterNUICallback("duty_toggle", function(data, cb)
    local job = GetPlayerJob()
    
    TriggerCallback("frkn-policejob:server:setDuty", function(success, dutyValue)
        if not success then
            return cb("nok")
        end
        
        isOnDuty = dutyValue == 1 or dutyValue == true
        SaveDutyState(job, isOnDuty)
        
        Duty_GetWorkers(job, function(workers)
            Duty_GetHistory(function(history)
                SendNUIMessage({
                    action = "duty_update",
                    duty = isOnDuty and 1 or 0,
                    workers = workers or {online = {}, offline = {}},
                    history = history or {open = nil, list = {}},
                    cid = GetPlayerIdentifier(),
                    name = GetPlayerName()
                })
                
                if isOnDuty then
                    if FRKN.Duty and FRKN.Duty.On then
                        FRKN.Duty.On(job, GetPlayerIdentifier(), GetPlayerName())
                    end
                else
                    if FRKN.Duty and FRKN.Duty.Off then
                        FRKN.Duty.Off(job, GetPlayerIdentifier(), GetPlayerName())
                    end
                end
                
                cb("ok")
            end)
        end)
    end, {
        job = job,
        state = -1 
    })
end)

