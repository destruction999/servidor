


fingerOpen = false
fingerLoop = false

local DISABLED_CONTROLS = {1, 2, 24, 25, 106, 142, 241, 242, 257}
local ENABLED_CONTROLS = {21, 22, 30, 31, 32, 33, 34, 35}

local function HandleControls()
    for _, control in ipairs(DISABLED_CONTROLS) do
        DisableControlAction(0, control, true)
    end
    
    for _, control in ipairs(ENABLED_CONTROLS) do
        EnableControlAction(0, control, true)
    end
end

local function StartControlLoop()
    if fingerLoop then return end
    
    fingerLoop = true
    CreateThread(function()
        while fingerOpen do
            HandleControls()
            Wait(0)
        end
        fingerLoop = false
    end)
end

function OpenFingerUI()
    fingerOpen = true
    SetNuiFocusKeepInput(true)
    SetNuiFocus(true, true)
    SendNUIMessage({action = "fingerPrint"})
    StartControlLoop()
end

function CloseFingerUI()
    fingerOpen = false
    fingerLoop = false
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
end

local function FindClosestPlayer(players)
    if #players == 0 then return nil end
    
    local myCoords = GetEntityCoords(PlayerPedId())
    local closest = {player = nil, distance = nil}
    
    for _, player in ipairs(players) do
        local targetId = GetPlayerFromServerId(player.id)
        
        if targetId and targetId ~= -1 then
            local targetPed = GetPlayerPed(targetId)
            local targetCoords = GetEntityCoords(targetPed)
            local distance = #(myCoords - targetCoords)
            
            if not closest.distance or distance < closest.distance then
                closest.distance = distance
                closest.player = player
            end
        end
    end
    
    return closest.player
end

RegisterNetEvent("frkn-policejob:openFingerPrint", function()
    Wait(200)
    OpenFingerUI()
end)

RegisterNetEvent("frkn-policejob:fingerResponse", function(data)
    
end)

RegisterNetEvent("frkn-policejob:fingerNotify", function()
    SendNUIMessage({action = "fingerScan"})
end)

RegisterNUICallback("startFingerScan", function(data, cb)
    GetNearbyPlayers(3.0, function(players)
        local closestPlayer = FindClosestPlayer(players)
        
        if closestPlayer then
            cb(closestPlayer)
            TriggerServerEvent("frkn-policejob:fingerRequest", closestPlayer.id)
        else
            cb(false)
        end
    end)
end)

