


local badgeObject = nil
local isBadgeActive = false

local BADGE_CONFIG = {
    animDict = "paper_1_rcm_alt1-8",
    animName = "player_one_dual-8",
    propModel = `prop_fib_badge`,
    boneIndex = 28422,
    offset = {
        pos = vector3(0.06, 0.021, -0.04),
        rot = vector3(-90.0, 0.0, -101.0)
    }
}

local function CleanupBadge()
    local ped = PlayerPedId()
    
    if DoesEntityExist(ped) then
        ClearPedTasks(ped)
    end
    
    if badgeObject and DoesEntityExist(badgeObject) then
        DetachEntity(badgeObject, true, true)
        DeleteEntity(badgeObject)
    end
    
    badgeObject = nil
    isBadgeActive = false
end

local function LoadAssets()
    
    if not HasAnimDictLoaded(BADGE_CONFIG.animDict) then
        RequestAnimDict(BADGE_CONFIG.animDict)
        local timeout = 0
        while not HasAnimDictLoaded(BADGE_CONFIG.animDict) and timeout < 100 do
            Wait(10)
            timeout = timeout + 1
        end
        if timeout >= 100 then return false end
    end
    
    if not HasModelLoaded(BADGE_CONFIG.propModel) then
        RequestModel(BADGE_CONFIG.propModel)
        local timeout = 0
        while not HasModelLoaded(BADGE_CONFIG.propModel) and timeout < 100 do
            Wait(10)
            timeout = timeout + 1
        end
        if timeout >= 100 then return false end
    end
    
    return true
end

local function ShowBadge(duration)
    if isBadgeActive then return end
    
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    if vehicle ~= 0 then
        return 
    end
    
    isBadgeActive = true
    
    if not LoadAssets() then
        isBadgeActive = false
        return
    end
    
    TaskPlayAnim(ped, BADGE_CONFIG.animDict, BADGE_CONFIG.animName, 2.0, 2.0, -1, 49, 0.0, false, false, false)
    
    local boneIndex = GetPedBoneIndex(ped, BADGE_CONFIG.boneIndex)
    badgeObject = CreateObject(BADGE_CONFIG.propModel, 0.0, 0.0, 0.0, true, true, false)
    
    if DoesEntityExist(badgeObject) then
        AttachEntityToEntity(
            badgeObject, ped, boneIndex,
            BADGE_CONFIG.offset.pos.x, BADGE_CONFIG.offset.pos.y, BADGE_CONFIG.offset.pos.z,
            BADGE_CONFIG.offset.rot.x, BADGE_CONFIG.offset.rot.y, BADGE_CONFIG.offset.rot.z,
            true, true, false, true, 2, true
        )
    end
    
    local closestPlayer = GetClosestPlayer(3.0)
    TriggerServerEvent("frkn-policejob:sendServerData", closestPlayer)
    
    SetTimeout(duration, function()
        CleanupBadge()
        TriggerServerEvent("frkn-policejob:closeBadgeS", closestPlayer)
    end)
end

RegisterNetEvent("frkn-policejob:showBadge", function()
    ShowBadge(FRKN.BadgeTime)
end)

RegisterCommand("badge", function()
    ShowBadge(FRKN.BadgeTime)
end, false)

RegisterNetEvent("frkn-policejob:sendData", function(data)
    SendNUIMessage({
        action = "openMenu",
        menu = "badge-menu",
        data = data
    })
end)

RegisterNetEvent("frkn-policejob:closeBadge", function()
    SendNUIMessage({
        action = "closeMenu",
        menu = "badge-menu"
    })
    CleanupBadge()
end)

AddEventHandler("onResourceStop", function(resourceName)
    if GetCurrentResourceName() == resourceName then
        CleanupBadge()
    end
end)

local badgeObject = nil
local isBadgeActive = false

local BADGE_CONFIG = {
    animDict = "paper_1_rcm_alt1-8",
    animName = "player_one_dual-8",
    propModel = `prop_fib_badge`,
    boneIndex = 28422,
    offset = {
        pos = vector3(0.06, 0.021, -0.04),
        rot = vector3(-90.0, 0.0, -101.0)
    }
}

local function CleanupBadge()
    local ped = PlayerPedId()
    
    if DoesEntityExist(ped) then
        ClearPedTasks(ped)
    end
    
    if badgeObject and DoesEntityExist(badgeObject) then
        DetachEntity(badgeObject, true, true)
        DeleteEntity(badgeObject)
    end
    
    badgeObject = nil
    isBadgeActive = false
end

local function LoadAssets()
    
    if not HasAnimDictLoaded(BADGE_CONFIG.animDict) then
        RequestAnimDict(BADGE_CONFIG.animDict)
        local timeout = 0
        while not HasAnimDictLoaded(BADGE_CONFIG.animDict) and timeout < 100 do
            Wait(10)
            timeout = timeout + 1
        end
        if timeout >= 100 then return false end
    end
    
    if not HasModelLoaded(BADGE_CONFIG.propModel) then
        RequestModel(BADGE_CONFIG.propModel)
        local timeout = 0
        while not HasModelLoaded(BADGE_CONFIG.propModel) and timeout < 100 do
            Wait(10)
            timeout = timeout + 1
        end
        if timeout >= 100 then return false end
    end
    
    return true
end

local function ShowBadge(duration)
    if isBadgeActive then return end
    
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    if vehicle ~= 0 then
        return 
    end
    
    isBadgeActive = true
    
    if not LoadAssets() then
        isBadgeActive = false
        return
    end
    
    TaskPlayAnim(ped, BADGE_CONFIG.animDict, BADGE_CONFIG.animName, 2.0, 2.0, -1, 49, 0.0, false, false, false)
    
    local boneIndex = GetPedBoneIndex(ped, BADGE_CONFIG.boneIndex)
    badgeObject = CreateObject(BADGE_CONFIG.propModel, 0.0, 0.0, 0.0, true, true, false)
    
    if DoesEntityExist(badgeObject) then
        AttachEntityToEntity(
            badgeObject, ped, boneIndex,
            BADGE_CONFIG.offset.pos.x, BADGE_CONFIG.offset.pos.y, BADGE_CONFIG.offset.pos.z,
            BADGE_CONFIG.offset.rot.x, BADGE_CONFIG.offset.rot.y, BADGE_CONFIG.offset.rot.z,
            true, true, false, true, 2, true
        )
    end
    
    local closestPlayer = GetClosestPlayer(3.0)
    TriggerServerEvent("frkn-policejob:sendServerData", closestPlayer)
    
    SetTimeout(duration, function()
        CleanupBadge()
        TriggerServerEvent("frkn-policejob:closeBadgeS", closestPlayer)
    end)
end

RegisterNetEvent("frkn-policejob:showBadge", function()
    ShowBadge(FRKN.BadgeTime)
end)

RegisterCommand("badge", function()
    ShowBadge(FRKN.BadgeTime)
end, false)

RegisterNetEvent("frkn-policejob:sendData", function(data)
    SendNUIMessage({
        action = "openMenu",
        menu = "badge-menu",
        data = data
    })
end)

RegisterNetEvent("frkn-policejob:closeBadge", function()
    SendNUIMessage({
        action = "closeMenu",
        menu = "badge-menu"
    })
    CleanupBadge()
end)

AddEventHandler("onResourceStop", function(resourceName)
    if GetCurrentResourceName() == resourceName then
        CleanupBadge()
    end
end)

