


local GSRState = {
    hasGSR = false,
    isWashing = false,
    threadActive = false,
    lastShot = 0,
    cooldown = 1500
}

local function CleanGSR()
    TriggerServerEvent("frkn-gsr:server:clear")
    GSRState.hasGSR = false
    GSRState.isWashing = false
    GSRState.threadActive = false
    Notify(Lang.t("success.wash_gsr"), "success")
end

local function CancelWash()
    GSRState.isWashing = false
    Notify(Lang.t("error.cancel_wash"), "error")
end

local function StartWashProgress()
    if GSRState.isWashing then return end
    
    GSRState.isWashing = true
    
    Progressbar("wash_gsr", Lang.t("general.wash_gsr"), FRKN.Progressbar.Gsr, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true
    }, {}, {}, {}, CleanGSR, CancelWash)
end

local function CheckWaterStatus()
    if GSRState.threadActive then return end
    
    GSRState.threadActive = true
    
    CreateThread(function()
        local wasInWater = false
        
        while GSRState.threadActive and GSRState.hasGSR do
            local ped = PlayerPedId()
            local inWater = IsEntityInWater(ped) or IsPedSwimming(ped)
            
            if inWater and not GSRState.isWashing then
                StartWashProgress()
                wasInWater = true
            elseif not inWater and wasInWater and GSRState.isWashing then
                TriggerEvent("progressbar:client:cancel")
                wasInWater = false
            end
            
            Wait(inWater and 150 or 300)
        end
        
        GSRState.threadActive = false
    end)
end

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local sleep = IsPedArmed(ped, 4) or GSRState.hasGSR and 50 or 800
        
        if IsPedShooting(ped) then
            local now = GetGameTimer()
            
            if (now - GSRState.lastShot) > GSRState.cooldown then
                GSRState.hasGSR = true
                GSRState.lastShot = now
                
                TriggerServerEvent("frkn-gsr:server:shot")
                CheckWaterStatus()
            end
            
            sleep = 0
        elseif GSRState.hasGSR and not GSRState.threadActive then
            CheckWaterStatus()
        end
        
        Wait(sleep)
    end
end)

RegisterNetEvent("frkn-gsr:client:hasResult", function(targetId, result)
    Wait(FRKN.Progressbar.GsrCheck)
    Notify(Lang.t(result and "success.gsr_positive" or "error.gsr_negative"), result and "success" or "error")
end)

RegisterNetEvent("frkn-policejob:cl:gsr_check", function()
    local target = GetClosestPlayer(1.0)
    
    if not target or target == -1 then
        return Notify(Lang.t("error.none_nearby_gsr"), "error")
    end
    
    Progressbar("gsr_check", Lang.t("general.gsr_checking"), FRKN.Progressbar.GsrCheck, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true
    }, {}, {}, {}, function() end, function()
        Notify(Lang.t("error.canceled"), "error")
    end)
    
    TriggerServerEvent("frkn-gsr:server:has", target)
end)

RegisterCommand("gsrcheck", function(_, args)
    local targetId = tonumber(args[1])
    if targetId and targetId >= 1 then
        TriggerServerEvent("frkn-gsr:server:has", targetId)
    end
end, false)

