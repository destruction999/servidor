


local isInService = false
local shouldFinish = false
local remainingTasks = 0
local taskLocations = {}
local isDoingTask = false
local cleaningProp = nil
local cleaningBroom = nil
local isLoopActive = false

local COMPONENTS = {
    MASK = 1,
    PANTS = 4,
    SHIRT = 8,
    JACKET = 11,
    ARMS = 3,
    SHOES = 6,
    ACCESSORIES = 7
}

local function ApplyServiceOutfit()
    local ped = PlayerPedId()
    local isMale = IsPedModel(ped, "mp_m_freemode_01")
    local gender = isMale and "male" or "female"
    local outfit = FRKN.Outfits[gender]
    
    if not outfit then return end
    
    SetPedComponentVariation(ped, COMPONENTS.MASK, outfit.mask.item, outfit.mask.texture)
    SetPedComponentVariation(ped, COMPONENTS.PANTS, outfit.pants.item, outfit.pants.texture)
    SetPedComponentVariation(ped, COMPONENTS.SHIRT, outfit.shirt.item, outfit.shirt.texture)
    SetPedComponentVariation(ped, COMPONENTS.JACKET, outfit.jacket.item, outfit.jacket.texture)
    SetPedComponentVariation(ped, COMPONENTS.ARMS, outfit.arms.item, outfit.arms.texture)
    SetPedComponentVariation(ped, COMPONENTS.SHOES, outfit.shoes.item, outfit.shoes.texture)
    SetPedComponentVariation(ped, COMPONENTS.ACCESSORIES, outfit.accessories.item, outfit.accessories.texture)
end

local function IsLocationUsed(location, excludeLocation)
    
    for _, usedLoc in ipairs(taskLocations) do
        if location.coords.x == usedLoc.coords.x and
           location.coords.y == usedLoc.coords.y and
           location.coords.z == usedLoc.coords.z then
            return true
        end
    end
    
    if excludeLocation then
        if location.coords.x == excludeLocation.coords.x and
           location.coords.y == excludeLocation.coords.y and
           location.coords.z == excludeLocation.coords.z then
            return true
        end
    end
    
    return false
end

function FillActionTable(excludeLocation)
    local availableLocations = FRKN.ServiceLocations
    
    while #taskLocations < 5 do
        local randomLoc = availableLocations[math.random(1, #availableLocations)]
        
        if not IsLocationUsed(randomLoc, excludeLocation) then
            table.insert(taskLocations, randomLoc)
        end
    end
end

local function RemoveAction(action)
    for i, loc in ipairs(taskLocations) do
        if action.coords.x == loc.coords.x and
           action.coords.y == loc.coords.y and
           action.coords.z == loc.coords.z then
            table.remove(taskLocations, i)
            return
        end
    end
end

local function CreateCleaningProp()
    local ped = PlayerPedId()
    
    RequestModel("prop_tool_broom")
    while not HasModelLoaded("prop_tool_broom") do
        Wait(10)
    end
    
    local prop = CreateObject(GetHashKey("prop_tool_broom"), 0.0, 0.0, 0.0, true, true, false)
    SetEntityCollision(prop, false, false)
    
    AttachEntityToEntity(
        prop, ped, GetPedBoneIndex(ped, 28422),
        -0.005, 0.0, 0.0, 360.0, 360.0, 0.0,
        true, true, false, true, 1, true
    )
    
    SetModelAsNoLongerNeeded("prop_tool_broom")
    return prop
end

local function CommunityCleanStop()
    local ped = PlayerPedId()
    ClearPedTasks(ped)
    
    if cleaningBroom and DoesEntityExist(cleaningBroom) then
        DeleteEntity(cleaningBroom)
    end
    
    cleaningBroom = nil
    cleaningProp = false
end

function CommunityCleanStart(callback)
    if cleaningProp then return end
    
    cleaningProp = true
    local ped = PlayerPedId()
    cleaningBroom = CreateCleaningProp()
    
    local animDict = "amb@world_human_janitor@male@idle_a"
    local animName = "idle_a"
    
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do
        Wait(10)
    end
    
    TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, -1, 1, 0, false, false, false)
    
    CreateThread(function()
        while cleaningProp do
            DisableAllControlActions(0)
            EnableControlAction(0, 1, true)  
            EnableControlAction(0, 2, true)  
            Wait(0)
        end
    end)
    
    Progressbar("cleaning", Lang:t("general.community_progress_cleaning"), 9000, false, false, {
        disableMovement = false,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true
    }, {
        dict = animDict,
        clip = animName,
        flags = 49
    }, {}, {}, function()
        CommunityCleanStop()
        if callback then callback() end
    end, nil, false)
end

local function DoGardeningTask()
    local ped = PlayerPedId()
    
    TaskStartScenarioInPlace(ped, "world_human_gardener_plant", 0, false)
    
    Progressbar("gardening", Lang:t("general.community_progress_gardening"), 19000, false, false, {
        disableMovement = false,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true
    }, {}, {}, {}, function()
        
    end, function()
        
    end)
    
    Wait(20000)
    ClearPedTasks(ped)
    isDoingTask = false
end

RegisterNetEvent("frkn-policejob:inCommunityService")
AddEventHandler("frkn-policejob:inCommunityService", function(taskCount)
    taskCount = tonumber(taskCount) or 0
    
    if isInService or taskCount <= 0 then
        remainingTasks = 0
        isInService = false
        shouldFinish = false
        return
    end
    
    remainingTasks = taskCount
    FillActionTable()
    
    if FRKN.Outfits.enabled then
        ApplyServiceOutfit()
    end
    
    local spawnLoc = FRKN.ServiceLocation
    SetEntityCoords(PlayerPedId(), spawnLoc.x, spawnLoc.y, spawnLoc.z, false, false, false, false)
    
    Notify(Lang:t("general.community_started", {count = remainingTasks}), "success")
    
    isInService = true
    shouldFinish = false
    StartCommunityLoop()
    
    while remainingTasks > 0 and not shouldFinish do
        local ped = PlayerPedId()
        local pedPos = GetEntityCoords(ped)
        local distance = #(pedPos - vector3(spawnLoc.x, spawnLoc.y, spawnLoc.z))
        
        if distance > 45.0 then
            if IsPedInAnyVehicle(ped, false) then
                ClearPedTasksImmediately(ped)
            end
            
            SetEntityCoords(ped, spawnLoc.x, spawnLoc.y, spawnLoc.z, false, false, false, false)
            TriggerServerEvent("frkn-policejob:extendService")
            
            remainingTasks = remainingTasks + FRKN.ServiceExtensionOnEscape
            Notify(Lang:t("error.communation_warning"), "error")
        end
        
        Wait(20000)
    end
    
    TriggerServerEvent("frkn-policejob:finishCommunityService")
    isInService = false
end)

RegisterNetEvent("frkn-policejob:finishCommunityService")
AddEventHandler("frkn-policejob:finishCommunityService", function()
    shouldFinish = true
    isInService = false
    remainingTasks = 0
end)

function StartCommunityLoop()
    if isLoopActive then return end
    if not isInService or remainingTasks <= 0 then return end
    
    isLoopActive = true
    
    CreateThread(function()
        while isInService and remainingTasks > 0 do
            local sleepTime = 1200
            local ped = PlayerPedId()
            local pedPos = GetEntityCoords(ped)
            
            local isNearTask = false
            for _, loc in ipairs(taskLocations) do
                if #(pedPos - loc.coords) < 25.0 then
                    isNearTask = true
                    break
                end
            end
            
            if isNearTask then
                sleepTime = 0
            end
            
            local remainingText = string.format("Community Remaining: ~o~%s~w~", math.floor(remainingTasks))
            drawFancy2dText(remainingText, {0.05, 0.05})
            
            DrawAvailableActions()
            DisableViolentActions()
            
            for i, loc in ipairs(taskLocations) do
                local distance = #(pedPos - loc.coords)
                
                if distance < 1.5 then
                    DrawText3D(pedPos.x, pedPos.y, pedPos.z, Lang:t("general.community_prompt"))
                    
                    if IsControlJustReleased(1, 38) then 
                        RemoveAction(loc)
                        FillActionTable(loc)
                        
                        isDoingTask = true
                        TriggerServerEvent("frkn-policejob:completeService")
                        remainingTasks = remainingTasks - 1
                        
                        if loc.type == "cleaning" then
                            CommunityCleanStart(function()
                                isDoingTask = false
                            end)
                        elseif loc.type == "gardening" then
                            DoGardeningTask()
                        end
                        
                        if remainingTasks == 0 then
                            Notify(Lang:t("general.community_completed"), "success")
                            if propIndex ~= -1 then
                                ClearPedProp(ped, 0)
                            end
                        end
                    end
                end
            end
            
            Wait(sleepTime)
        end
        
        isLoopActive = false
    end)
end

function DrawAvailableActions()
    local pedPos = GetEntityCoords(PlayerPedId())
    
    for _, loc in ipairs(taskLocations) do
        local distance = #(pedPos - loc.coords)
        
        if distance < 40.0 then
            DrawMarker(20, loc.coords.x, loc.coords.y, loc.coords.z + 0.05,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.25, 0.25, 0.25, 255, 255, 255, 100,
                false, true, 2, false, nil, nil, false)
        end
    end
end

function DisableViolentActions()
    local ped = PlayerPedId()
    
    if isDoingTask then
        DisableAllControlActions(0)
    end
    
    RemoveAllPedWeapons(ped, true)
    DisableControlAction(2, 37, true)  
    DisablePlayerFiring(ped, true)
    DisableControlAction(0, 106, true) 
    DisableControlAction(0, 140, true) 
    DisableControlAction(0, 141, true) 
    DisableControlAction(0, 142, true) 
    
    if IsDisabledControlJustPressed(2, 37) or IsDisabledControlJustPressed(0, 106) then
        SetCurrentPedWeapon(ped, -1569615261, true) 
    end
end

function drawFancy2dText(text, position, scale, r, g, b, a)
    scale = scale or 0.6
    r = r or 255
    g = g or 150
    b = b or 50
    a = a or 255
    
    SetTextFont(7)
    SetTextScale(scale, scale)
    SetTextCentre(false)
    SetTextRightJustify(false)
    SetTextDropShadow(4, 0, 0, 0, 255)
    SetTextColour(r, g, b, a)
    SetTextEdge(2, 0, 0, 0, 255)
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(table.unpack(position))
end

function DrawText3D(x, y, z, text)
    local onScreen, screenX, screenY = World3dToScreen2d(x, y, z)
    
    if onScreen then
        local scale = 0.35
        local textLength = string.len(text) / 370
        
        DrawRect(screenX, screenY + 0.0125, 0.015 + textLength, 0.03, 15, 15, 15, 180)
        
        SetTextScale(scale, scale)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 230)
        SetTextCentre(true)
        SetTextDropshadow(2, 2, 0, 0, 0)
        SetTextOutline()
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(screenX, screenY)
    end
end

RegisterNetEvent("frkn:police:sendPublic")
AddEventHandler("frkn:police:sendPublic", function()
    Wait(100)
    
    local closestPlayer, distance = GetClosestPlayer(3.0)
    
    if closestPlayer == -1 or distance > 3.0 then
        Notify(Lang:t("error.none_nearby_community"), "error")
        return
    end
    
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "openMenu",
        menu = "communication-menu"
    })
end)

RegisterNUICallback("communication", function(data, cb)
    if not data.amount then
        Notify(Lang:t("error.communityservice"))
        return
    end
    
    local closestPlayer, distance = GetClosestPlayer()
    
    if closestPlayer == -1 or distance > 3.0 then
        Notify(Lang:t("error.none_nearby_gsr"), "error")
        return
    end
    
    local amount = tonumber(data.amount)
    
    if not amount then
        Notify(Lang:t("error.community_empty"), "error")
        return
    end
    
    if amount > ((FRKN and FRKN.CommunicationService and FRKN.CommunicationService.MaxCommunity) or 100) then
        Notify(Lang:t("error.communityservice_max", {value = ((FRKN and FRKN.CommunicationService and FRKN.CommunicationService.MaxCommunity) or 100)}), "error")
        return
    end
    
    TriggerServerEvent("frkn-policejob:server:sendcommunityservice", {
        id = closestPlayer,
        kamu = amount
    })
end)

local communityCommand = (FRKN and FRKN.CommunicationService and FRKN.CommunicationService.Command) or "communityend"
RegisterCommand(communityCommand, function(source, args)
    local isPolice, job, grade = IsDeptJob()
    
    if not isPolice then
        Notify(Lang:t("error.not_permission"), "error")
        return
    end
    
    local hasPermission = false
    local allowedGrades = (FRKN and FRKN.CommunicationService and FRKN.CommunicationService.Grade) or {}
    for _, allowedGrade in ipairs(allowedGrades) do
        if tonumber(grade) == tonumber(allowedGrade) then
            hasPermission = true
            break
        end
    end
    
    if not hasPermission then
        Notify(Lang:t("error.not_permission"), "error")
        return
    end
    
    local targetId = tonumber(args[1])
    
    if not targetId then
        Notify(Lang:t("error.invalid_id"), "error")
        return
    end
    
    TriggerServerEvent("frkn-policejob:finishCommunityService", targetId)
end, false)

RegisterNetEvent("QBCore:Client:OnPlayerLoaded")
AddEventHandler("QBCore:Client:OnPlayerLoaded", function()
    TriggerCallback("frkn-policejob:getCount", function(count)
        TriggerEvent("frkn-policejob:inCommunityService", tonumber(count) or 0)
    end)
end)

AddEventHandler("onResourceStart", function()
    TriggerCallback("frkn-policejob:getCount", function(count)
        TriggerEvent("frkn-policejob:inCommunityService", tonumber(count) or 0)
    end)
end)

local isInService = false
local shouldFinish = false
local remainingTasks = 0
local taskLocations = {}
local isDoingTask = false
local cleaningProp = nil
local cleaningBroom = nil
local isLoopActive = false

local COMPONENTS = {
    MASK = 1,
    PANTS = 4,
    SHIRT = 8,
    JACKET = 11,
    ARMS = 3,
    SHOES = 6,
    ACCESSORIES = 7
}

local function ApplyServiceOutfit()
    local ped = PlayerPedId()
    local isMale = IsPedModel(ped, "mp_m_freemode_01")
    local outfit = nil
    
    if isMale then
        outfit = FRKN.Outfits.male
        if outfit then
            SetPedComponentVariation(ped, COMPONENTS.MASK, outfit.mask.item, outfit.mask.texture)
            SetPedComponentVariation(ped, COMPONENTS.PANTS, outfit.pants.item, outfit.pants.texture)
            SetPedComponentVariation(ped, COMPONENTS.SHIRT, outfit.shirt.item, outfit.shirt.texture)
            SetPedComponentVariation(ped, COMPONENTS.JACKET, outfit.jacket.item, outfit.jacket.texture)
            SetPedComponentVariation(ped, COMPONENTS.ARMS, outfit.arms.item, outfit.arms.texture)
            SetPedComponentVariation(ped, COMPONENTS.SHOES, outfit.shoes.item, outfit.shoes.texture)
            SetPedComponentVariation(ped, COMPONENTS.ACCESSORIES, outfit.accessories.item, outfit.accessories.texture)
        end
    elseif IsPedModel(ped, "mp_f_freemode_01") then
        outfit = FRKN.Outfits.female
        if outfit then
            SetPedComponentVariation(ped, COMPONENTS.MASK, outfit.mask.item, outfit.mask.texture)
            SetPedComponentVariation(ped, COMPONENTS.PANTS, outfit.pants.item, outfit.pants.texture)
            SetPedComponentVariation(ped, COMPONENTS.SHIRT, outfit.shirt.item, outfit.shirt.texture)
            SetPedComponentVariation(ped, COMPONENTS.JACKET, outfit.jacket.item, outfit.jacket.texture)
            SetPedComponentVariation(ped, COMPONENTS.ARMS, outfit.arms.item, outfit.arms.texture)
            SetPedComponentVariation(ped, COMPONENTS.SHOES, outfit.shoes.item, outfit.shoes.texture)
            SetPedComponentVariation(ped, COMPONENTS.ACCESSORIES, outfit.accessories.item, outfit.accessories.texture)
        end
    end
end

local function IsLocationUsed(location, excludeLocation)
    
    for _, usedLoc in ipairs(taskLocations) do
        if location.coords.x == usedLoc.coords.x and
           location.coords.y == usedLoc.coords.y and
           location.coords.z == usedLoc.coords.z then
            return true
        end
    end
    
    if excludeLocation then
        if location.coords.x == excludeLocation.coords.x and
           location.coords.y == excludeLocation.coords.y and
           location.coords.z == excludeLocation.coords.z then
            return true
        end
    end
    
    return false
end

function FillActionTable(excludeLocation)
    local availableLocations = FRKN.ServiceLocations
    
    while #taskLocations < 5 do
        local randomIndex = math.random(1, #availableLocations)
        local randomLoc = availableLocations[randomIndex]
        
        if not IsLocationUsed(randomLoc, excludeLocation) then
            table.insert(taskLocations, randomLoc)
        end
    end
end

local function RemoveAction(action)
    for i, loc in ipairs(taskLocations) do
        if action.coords.x == loc.coords.x and
           action.coords.y == loc.coords.y and
           action.coords.z == loc.coords.z then
            table.remove(taskLocations, i)
            return
        end
    end
end

local function CreateCleaningProp()
    local ped = PlayerPedId()
    
    RequestModel("prop_tool_broom")
    while not HasModelLoaded("prop_tool_broom") do
        Wait(10)
    end
    
    local prop = CreateObject(GetHashKey("prop_tool_broom"), 0.0, 0.0, 0.0, true, true, false)
    SetEntityCollision(prop, false, false)
    
    AttachEntityToEntity(
        prop, ped, GetPedBoneIndex(ped, 28422),
        -0.005, 0.0, 0.0, 360.0, 360.0, 0.0,
        true, true, false, true, 1, true
    )
    
    SetModelAsNoLongerNeeded("prop_tool_broom")
    return prop
end

local function CommunityCleanStop()
    local ped = PlayerPedId()
    ClearPedTasks(ped)
    
    if cleaningBroom and DoesEntityExist(cleaningBroom) then
        DeleteEntity(cleaningBroom)
    end
    
    cleaningBroom = nil
    cleaningProp = false
end

function CommunityCleanStart(callback)
    if cleaningProp then return end
    
    cleaningProp = true
    local ped = PlayerPedId()
    cleaningBroom = CreateCleaningProp()
    
    local animDict = "amb@world_human_janitor@male@idle_a"
    local animName = "idle_a"
    
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do
        Wait(10)
    end
    
    TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, -1, 1, 0, false, false, false)
    
    CreateThread(function()
        while cleaningProp do
            DisableAllControlActions(0)
            EnableControlAction(0, 1, true)  
            EnableControlAction(0, 2, true)  
            Wait(0)
        end
    end)
    
    Progressbar("cleaning", Lang:t("general.community_progress_cleaning"), 9000, false, false, {
        disableMovement = false,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true
    }, {
        dict = animDict,
        clip = animName,
        flags = 49
    }, {}, {}, function()
        CommunityCleanStop()
        if callback then callback() end
    end, nil, false)
end

RegisterNetEvent("frkn-policejob:inCommunityService")
AddEventHandler("frkn-policejob:inCommunityService", function(taskCount)
    taskCount = tonumber(taskCount) or 0
    
    if isInService or taskCount <= 0 then
        remainingTasks = 0
        isInService = false
        shouldFinish = false
        return
    end
    
    remainingTasks = taskCount
    FillActionTable()
    
    if FRKN.Outfits.enabled then
        ApplyServiceOutfit()
    end
    
    local spawnLoc = FRKN.ServiceLocation
    SetEntityCoords(PlayerPedId(), spawnLoc.x, spawnLoc.y, spawnLoc.z, false, false, false, false)
    
    Notify(Lang:t("general.community_started", {count = remainingTasks}), "success")
    
    isInService = true
    shouldFinish = false
    StartCommunityLoop()
    
    while remainingTasks > 0 and not shouldFinish do
        local ped = PlayerPedId()
        local pedPos = GetEntityCoords(ped)
        local distance = #(pedPos - vector3(spawnLoc.x, spawnLoc.y, spawnLoc.z))
        
        if distance > 45.0 then
            if IsPedInAnyVehicle(ped, false) then
                ClearPedTasksImmediately(ped)
            end
            
            SetEntityCoords(ped, spawnLoc.x, spawnLoc.y, spawnLoc.z, false, false, false, false)
            TriggerServerEvent("frkn-policejob:extendService")
            
            remainingTasks = remainingTasks + FRKN.ServiceExtensionOnEscape
            Notify(Lang:t("error.communation_warning"), "error")
        end
        
        Wait(20000)
    end
    
    TriggerServerEvent("frkn-policejob:finishCommunityService")
    isInService = false
end)

RegisterNetEvent("frkn-policejob:finishCommunityService")
AddEventHandler("frkn-policejob:finishCommunityService", function()
    shouldFinish = true
    isInService = false
    remainingTasks = 0
end)

function StartCommunityLoop()
    if isLoopActive then return end
    if not isInService or remainingTasks <= 0 then return end
    
    isLoopActive = true
    
    CreateThread(function()
        while isInService and remainingTasks > 0 do
            local sleepTime = 1200
            local ped = PlayerPedId()
            local pedPos = GetEntityCoords(ped)
            
            local isNearTask = false
            for _, loc in ipairs(taskLocations) do
                if #(pedPos - loc.coords) < 25.0 then
                    isNearTask = true
                    break
                end
            end
            
            if isNearTask then
                sleepTime = 0
            end
            
            local remainingText = string.format("Community Remaining: ~o~%s~w~", math.floor(remainingTasks))
            drawFancy2dText(remainingText, {0.05, 0.05})
            
            DrawAvailableActions()
            DisableViolentActions()
            
            for i, loc in ipairs(taskLocations) do
                local distance = #(pedPos - loc.coords)
                
                if distance < 1.5 then
                    DrawText3D(pedPos.x, pedPos.y, pedPos.z, Lang:t("general.community_prompt"))
                    
                    if IsControlJustReleased(1, 38) then 
                        RemoveAction(loc)
                        FillActionTable(loc)
                        
                        isDoingTask = true
                        TriggerServerEvent("frkn-policejob:completeService")
                        remainingTasks = remainingTasks - 1
                        
                        if loc.type == "cleaning" then
                            CommunityCleanStart(function()
                                isDoingTask = false
                            end)
                        elseif loc.type == "gardening" then
                            TaskStartScenarioInPlace(ped, "world_human_gardener_plant", 0, false)
                            
                            Progressbar("gardening", Lang:t("general.community_progress_gardening"), 19000, false, false, {
                                disableMovement = false,
                                disableCarMovement = false,
                                disableMouse = false,
                                disableCombat = true
                            }, {}, {}, {}, function()
                                
                            end, function()
                                
                            end)
                            
                            Wait(20000)
                            ClearPedTasks(ped)
                            isDoingTask = false
                        end
                        
                        if remainingTasks == 0 then
                            Notify(Lang:t("general.community_completed"), "success")
                            if propIndex and propIndex ~= -1 then
                                ClearPedProp(ped, 0)
                            end
                        end
                    end
                end
            end
            
            Wait(sleepTime)
        end
        
        isLoopActive = false
    end)
end

function DrawAvailableActions()
    local pedPos = GetEntityCoords(PlayerPedId())
    
    for _, loc in ipairs(taskLocations) do
        local distance = #(pedPos - loc.coords)
        
        if distance < 40.0 then
            DrawMarker(20, loc.coords.x, loc.coords.y, loc.coords.z + 0.05,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.25, 0.25, 0.25, 255, 255, 255, 100,
                false, true, 2, false, nil, nil, false)
        end
    end
end

function DisableViolentActions()
    local ped = PlayerPedId()
    
    if isDoingTask == true then
        DisableAllControlActions(0)
    end
    
    RemoveAllPedWeapons(ped, true)
    DisableControlAction(2, 37, true)  
    DisablePlayerFiring(ped, true)
    DisableControlAction(0, 106, true) 
    DisableControlAction(0, 140, true) 
    DisableControlAction(0, 141, true) 
    DisableControlAction(0, 142, true) 
    
    if IsDisabledControlJustPressed(2, 37) then
        SetCurrentPedWeapon(ped, -1569615261, true) 
    end
    
    if IsDisabledControlJustPressed(0, 106) then
        SetCurrentPedWeapon(ped, -1569615261, true) 
    end
end

function drawFancy2dText(text, position, scale, r, g, b, a)
    scale = scale or 0.6
    r = r or 255
    g = g or 150
    b = b or 50
    a = a or 255
    
    SetTextFont(7)
    SetTextScale(scale, scale)
    SetTextCentre(false)
    SetTextRightJustify(false)
    SetTextDropShadow(4, 0, 0, 0, 255)
    SetTextColour(r, g, b, a)
    SetTextEdge(2, 0, 0, 0, 255)
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(table.unpack(position))
end

function DrawText3D(x, y, z, text)
    local onScreen, screenX, screenY = World3dToScreen2d(x, y, z)
    local camCoords = table.unpack(GetGameplayCamCoords())
    
    if onScreen then
        local scale = 0.35
        local textLength = string.len(text) / 370
        
        DrawRect(screenX, screenY + 0.0125, 0.015 + textLength, 0.03, 15, 15, 15, 180)
        
        SetTextScale(scale, scale)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 230)
        SetTextCentre(true)
        SetTextDropshadow(2, 2, 0, 0, 0)
        SetTextOutline()
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(screenX, screenY)
    end
end

function DisplayHelpText(text)
    SetTextComponentFormat("STRING")
    AddTextComponentString(text)
    DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

RegisterNetEvent("frkn:police:sendPublic")
AddEventHandler("frkn:police:sendPublic", function()
    Wait(100)
    
    local closestPlayer, distance = GetClosestPlayer(3.0)
    
    if closestPlayer == -1 or distance > 3.0 then
        Notify(Lang:t("error.none_nearby_community"), "error")
        return
    end
    
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "openMenu",
        menu = "communication-menu"
    })
end)

RegisterNUICallback("communication", function(data, cb)
    if not data.amount then
        Notify(Lang:t("error.communityservice"))
        return
    end
    
    local closestPlayer, distance = GetClosestPlayer()
    
    if closestPlayer == -1 or distance > 3.0 then
        Notify(Lang:t("error.none_nearby_gsr"), "error")
        return
    end
    
    local amount = tonumber(data.amount)
    
    if not amount then
        Notify(Lang:t("error.community_empty"), "error")
        return
    end
    
    if amount > ((FRKN and FRKN.CommunicationService and FRKN.CommunicationService.MaxCommunity) or 100) then
        Notify(Lang:t("error.communityservice_max", {value = ((FRKN and FRKN.CommunicationService and FRKN.CommunicationService.MaxCommunity) or 100)}), "error")
        return
    end
    
    TriggerServerEvent("frkn-policejob:server:sendcommunityservice", {
        id = closestPlayer,
        kamu = amount
    })
end)

RegisterCommand("testsender", function()
    local testId = 2
    TriggerServerEvent("frkn-policejob:server:sendcommunityservice", {
        id = testId,
        kamu = 1
    })
end, false)

local communityCommand2 = (FRKN and FRKN.CommunicationService and FRKN.CommunicationService.Command) or "communityend"
RegisterCommand(communityCommand2 .. "_alt", function(source, args)
    local isPolice, job, grade = IsDeptJob()
    
    if not isPolice then
        Notify(Lang:t("error.not_permission"), "error")
        return
    end
    
    local hasPermission = false
    local allowedGrades2 = (FRKN and FRKN.CommunicationService and FRKN.CommunicationService.Grade) or {}
    for _, allowedGrade in ipairs(allowedGrades2) do
        if tonumber(grade) == tonumber(allowedGrade) then
            hasPermission = true
            break
        end
    end
    
    if not hasPermission then
        Notify(Lang:t("error.not_permission"), "error")
        return
    end
    
    local targetId = tonumber(args[1])
    
    if not targetId then
        Notify(Lang:t("error.invalid_id"), "error")
        return
    end
    
    TriggerServerEvent("frkn-policejob:finishCommunityService", targetId)
end, false)

function tableContains(table, element)
    for _, value in ipairs(table) do
        if value == element then
            return true
        end
    end
    return false
end

RegisterNetEvent("QBCore:Client:OnPlayerLoaded")
AddEventHandler("QBCore:Client:OnPlayerLoaded", function()
    TriggerCallback("frkn-policejob:getCount", function(count)
        TriggerEvent("frkn-policejob:inCommunityService", tonumber(count) or 0)
    end)
end)

AddEventHandler("onResourceStart", function()
    TriggerCallback("frkn-policejob:getCount", function(count)
        TriggerEvent("frkn-policejob:inCommunityService", tonumber(count) or 0)
    end)
end)

RegisterNetEvent("kamu:ver")
AddEventHandler("kamu:ver", function(data)
    ExecuteCommand("kamuver")
end)

