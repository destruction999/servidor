


local menuOpen = false
local controlsActive = false

local isHandcuffed = false
local isEscorted = false
local isEscortingPlayer = false
local cuffObject = nil
local cuffType = 49
local cuffFaceType = nil
local cuffAnimDict = nil
local cuffAnimName = nil
local cuffAnimLoaded = false
local inventoryLocked = false

local alcoholLevel = 0
local alcoholActive = false
local statusEffects = {}
local statusLabels = {
    alcohol = Lang:t("general.alcohol"),
    heavyalcohol = Lang:t("general.heavy_alcohol")
}

local hasOxInventory = GetResourceState("ox_inventory") == "started"
local hasQBInventory = GetResourceState("qb-inventory") == "started"
local hasQSInventory = GetResourceState("qs-inventory") == "started"
local hasPSInventory = GetResourceState("ps-inventory") == "started"
local hasLJInventory = GetResourceState("lj-inventory") == "started"
local hasCodemInventory = GetResourceState("codem-inventory") == "started"
local hasQuasarInventory = GetResourceState("inventory") == "started"

local function CloseAllInventories()
    if hasOxInventory then
        exports.ox_inventory:closeInventory()
    end
    if hasQBInventory then
        TriggerEvent("qb-inventory:client:closeInventory")
    end
    if hasQSInventory then
        TriggerEvent("qs-inventory:client:closeInventory")
        TriggerEvent("qs-inventory:closeInventory")
    end
    if hasPSInventory then
        TriggerEvent("ps-inventory:client:closeInventory")
    end
    if hasLJInventory then
        TriggerEvent("lj-inventory:client:closeInventory")
    end
    if hasCodemInventory then
        TriggerEvent("codem-inventory:client:closeInventory")
        TriggerEvent("cd-inventory:client:closeInventory")
    end
    if hasQuasarInventory then
        exports.inventory:CloseInventory()
    end
    SetNuiFocus(false, false)
end

local function SetInventoryBusy(state)
    if hasOxInventory then
        LocalPlayer.state.invBusy = state
        LocalPlayer.state.invHotkeys = not state
    end
    if hasQBInventory then
        TriggerEvent("qb-inventory:client:set:busy", state)
    end
    if hasQSInventory then
        TriggerEvent("qs-inventory:client:set:busy", state)
    end
    if hasPSInventory then
        TriggerEvent("ps-inventory:client:set:busy", state)
    end
    if hasLJInventory then
        TriggerEvent("lj-inventory:client:set:busy", state)
    end
    if hasCodemInventory then
        TriggerEvent("codem-inventory:client:set:busy", state)
        TriggerEvent("cd-inventory:client:set:busy", state)
    end
    if hasQuasarInventory then
        exports.inventory:LockInventory(state)
    end
end

local function LockInventory(lock)
    if lock then
        SetInventoryBusy(true)
        CloseAllInventories()
        inventoryLocked = true
    else
        SetInventoryBusy(false)
        inventoryLocked = false
    end
end

local function BuildCommand(command, args)
    if not args or args == "" then
        return command
    end
    
    if type(args) == "string" then
        return command .. " " .. args
    elseif type(args) == "table" then
        local argStrings = {}
        for _, arg in ipairs(args) do
            table.insert(argStrings, tostring(arg))
        end
        return command .. " " .. table.concat(argStrings, " ")
    else
        return command .. " " .. tostring(args)
    end
end

local function GetFacePosition(targetServerId)
    local ped = PlayerPedId()
    local targetPed = GetPlayerPed(GetPlayerFromServerId(targetServerId))
    
    if IsPedFacingPed(targetPed, ped, 60.0) then
        return "front"
    else
        return "back"
    end
end

local function OpenActionMenu()
    if not IsDeptJob() then
        Notify(Lang:t("error.not_authorized"))
        return
    end
    
    if not GetPlayerJobDuty() then
        Notify(Lang:t("error.not_on_duty"))
        return
    end
    
    if menuOpen then
        CloseActionMenu()
        return
    end
    
    local job, grade = GetPlayerJob()
    menuOpen = true
    
    SendNUIMessage({
        action = "openMenu",
        menu = "action-menu",
        grade = grade,
        actionMenu = FRKN.ActionMenu
    })
    
    CreateThread(function()
        while menuOpen do
            DisableControlAction(0, 172, true) 
            DisableControlAction(0, 173, true) 
            DisableControlAction(0, 174, true) 
            DisableControlAction(0, 175, true) 
            DisableControlAction(0, 201, true) 
            DisableControlAction(0, 177, true) 
            DisableControlAction(0, 322, true) 
            
            if IsDisabledControlJustPressed(0, 172) then
                SendNUIMessage({action = "navigate", key = "ArrowUp"})
            elseif IsDisabledControlJustPressed(0, 173) then
                SendNUIMessage({action = "navigate", key = "ArrowDown"})
            elseif IsDisabledControlJustPressed(0, 174) then
                SendNUIMessage({action = "navigate", key = "ArrowLeft"})
            elseif IsDisabledControlJustPressed(0, 175) then
                SendNUIMessage({action = "navigate", key = "ArrowRight"})
            elseif IsDisabledControlJustPressed(0, 201) then
                SendNUIMessage({action = "select"})
            elseif IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 322) then
                SendNUIMessage({action = "back"})
            end
            
            Wait(0)
        end
        controlsActive = false
    end)
    
    controlsActive = true
end

function CloseActionMenu()
    if not menuOpen then return end
    
    menuOpen = false
    controlsActive = false
    SendNUIMessage({action = "closeAction"})
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
end

RegisterCommand("openMenuF6", OpenActionMenu, false)
RegisterKeyMapping("openMenuF6", "Open ActionMenu", "keyboard", "F6")

RegisterNUICallback("closeAction", function(data, cb)
    CloseActionMenu()
    if cb then cb(true) end
end)

RegisterNUICallback("close", function(data, cb)
    fingerOpen = false
    closeExtraCam()
    charCam(false) 
    CloseActionMenu()
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    cb(true)
end)

RegisterNUICallback("menu:select", function(data, cb)
    local event = data and data.event or {}
    local side = event.side or "client"
    local name = event.name
    local args = event.args or {}
    
    if not name or name == "" then
        if cb then cb(false) end
        return
    end
    
    if side == "client" then
        TriggerEvent(name, args)
    elseif side == "server" then
        TriggerServerEvent(name, args)
    elseif side == "command" then
        ExecuteCommand(BuildCommand(name, args))
    end
    
    CloseActionMenu()
    SetNuiFocus(false, false)
    
    if cb then cb(true) end
end)

AddEventHandler("onResourceStop", function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    menuOpen = false
    controlsActive = false
end)

RegisterCommand("addTint", function(source, args)
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    if vehicle == 0 then
        Notify("You are not in a vehicle.", "error")
        return
    end
    
    local tintLevel = tonumber(args[1]) or 1
    SetVehicleWindowTint(vehicle, tintLevel)
    Notify("Window tint applied: " .. tintLevel, "success")
end, false)

RegisterNetEvent("frkn:vehicle:checkTint", function()
    local illegalTints = {1, 2, 3}
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local vehicle, distance = GetClosestVehicle(coords)
    
    if distance >= 5 then return end
    
    local inVehicle = IsPedInAnyVehicle(ped, false)
    if not inVehicle then
        TaskStartScenarioInPlace(ped, "CODE_HUMAN_MEDIC_TEND_TO_DEAD", 0, true)
    end
    
    Progressbar("camfilmcheck", Lang:t("general.vehicle_tint_control"), 
        tonumber(FRKN.Progressbar.TintControl) or 2000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true
    }, {
        animDict = "",
        anim = "",
        flags = 128
    }, {}, {}, function()
        local isIllegal = false
        local tintLevel = GetVehicleWindowTint(vehicle)
        
        for _, illegal in ipairs(illegalTints) do
            if illegal == tintLevel then
                isIllegal = true
                break
            end
        end
        
        if isIllegal then
            Notify(Lang:t("error.vehicle_tint") .. " (Tint ID: " .. tintLevel .. ")", "error")
        else
            Notify(Lang:t("success.vehicle_tint") .. " (Tint ID: " .. tintLevel .. ")", "success")
        end
        
        if not inVehicle then
            ClearPedTasksImmediately(ped)
        end
    end, function()
        if not inVehicle then
            ClearPedTasksImmediately(ped)
        end
    end)
end)

RegisterNetEvent("frkn:vehicle:removeTint", function()
    local illegalTints = {1, 2, 3}
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local vehicle, distance = GetClosestVehicle(coords)
    
    if IsPedInAnyVehicle(ped) then
        Notify(Lang:t("error.not_in_vehicle"), "error")
        return
    end
    
    if distance >= 5 then
        Notify(Lang:t("error.not_car_distance"), "error")
        return
    end
    
    local tintLevel = GetVehicleWindowTint(vehicle)
    local isIllegal = false
    
    for _, illegal in ipairs(illegalTints) do
        if illegal == tintLevel then
            isIllegal = true
            break
        end
    end
    
    if not isIllegal then
        Notify(Lang:t("success.vehicle_tint") .. " (Tint ID: " .. (tintLevel or -1) .. ")", "success")
        return
    end
    
    Wait(500)
    RequestAnimDict("mini@repair")
    while not HasAnimDictLoaded("mini@repair") do
        Wait(10)
    end
    
    TaskPlayAnim(ped, "mini@repair", "fixing_a_player", 3.0, -1.0, -1, 49, 0, false, false, false)
    
    Progressbar("camfilmremove", Lang:t("general.vehicle_tint_remove"), 16000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true
    }, {
        animDict = "mini@repair",
        anim = "fixing_a_player",
        flags = 49
    }, {}, {}, function()
        SetVehicleWindowTint(vehicle, 0)
        TriggerServerEvent("updateVehicle", GetVehicleProperties(vehicle))
        Notify(Lang:t("success.vehicle_tint_removed"), "success")
        ClearPedTasksImmediately(ped)
    end, function()
        ClearPedTasksImmediately(ped)
    end)
end)

RegisterNetEvent("frkn:vehicle:breakLock", function()
    local ped = PlayerPedId()
    local vehicle = GetClosestVehicle(GetEntityCoords(ped), 5.0, 0, 70)
    
    if vehicle == 0 or not DoesEntityExist(vehicle) then
        Notify(Lang:t("error.not_found"), "error")
        return
    end
    
    local pedCoords = GetEntityCoords(ped)
    local vehCoords = GetEntityCoords(vehicle)
    local distance = #(pedCoords - vehCoords)
    
    if distance > 2.0 then
        Notify(Lang:t("error.not_car_distance"), "error")
        return
    end
    
    local plate = GetPlate(vehicle)
    
    loadAnimDict("missheistfbi3b_ig7")
    TaskPlayAnim(ped, "missheistfbi3b_ig7", "lift_fibagent_loop", 8.0, -8.0, -1, 50, 0, false, false, false)
    
    Progressbar("vehicle_repair", Lang:t("general.vehicle_doorlock"), FRKN.Progressbar.BreakLock, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true
    }, {}, {}, {}, function()
        TriggerEvent("animations:client:EmoteCommandStart", {"c"})
        TriggerEvent("vehiclekeys:client:SetOwner", plate)
        SetVehicleDoorsLocked(vehicle, 1)
        SetVehicleDoorsLockedForAllPlayers(vehicle, false)
        Notify(Lang:t("success.vehicle_locked_success"), "success")
    end, function()
        Notify(Lang:t("error.transaction_cancelled"), "error")
    end)
end)

RegisterNetEvent("frkn-policejob:client:VehicleScuff", function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local vehicle, distance = GetClosestVehicleWithDistanceCheck(coords, 5.0)
    
    if not DoesEntityExist(vehicle) then
        Notify(Lang:t("error.not_car_distance"), "error")
        return
    end
    
    TaskStartScenarioInPlace(ped, "CODE_HUMAN_MEDIC_TEND_TO_DEAD", 0, true)
    
    Progressbar("random_task", Lang:t("general.progbar_impound"), FRKN.Progressbar.Impound, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true
    }, {}, {}, {}, function()
        TriggerServerEvent("frkn-policejob:server:VehicS")
        Notify(Lang:t("success.pd_impound"), "success")
    end, function() end)
end)

RegisterNetEvent("frkn-policejob:client:ParkingViolation", function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local vehicle = GetClosestVehicle(coords, 2.0, 0, 71)
    
    if not DoesEntityExist(vehicle) then
        Notify(Lang:t("error.not_car_distance"), "error")
        return
    end
    
    TaskStartScenarioInPlace(ped, "CODE_HUMAN_MEDIC_TEND_TO_DEAD", 0, true)
    
    Progressbar("random_task", Lang:t("general.progbar_impound"), FRKN.Progressbar.Impound, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true
    }, {}, {}, {}, function()
        TriggerServerEvent("frkn-policejob:server:ParkingVio")
    end, function() end)
end)

RegisterNetEvent("frkn-policejob:deleteVehicle", function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsUsing(ped)
    
    if vehicle ~= 0 then
        SetEntityAsMissionEntity(vehicle, true, true)
        DeleteVehicle(vehicle)
    else
        local coords = GetEntityCoords(ped)
        local vehicles = GetGamePool("CVehicle")
        
        for _, veh in pairs(vehicles) do
            local vehCoords = GetEntityCoords(veh)
            if #(coords - vehCoords) <= 5.0 then
                SetEntityAsMissionEntity(veh, true, true)
                DeleteVehicle(veh)
            end
        end
    end
end)

RegisterNetEvent("frkn:vehicle:checkTuning", function()
    local ped = PlayerPedId()
    
    if not IsPedInAnyVehicle(ped, false) then
        Notify(Lang:t("error.not_in_vehicle"), "error")
        return
    end
    
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    if not DoesEntityExist(vehicle) then
        Notify(Lang:t("error.not_car_distance"), "error")
        return
    end
    
    Progressbar("random_task", Lang:t("general.progbar_tuning"), FRKN.Progressbar.Tuning, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true
    }, {}, {}, {}, function()
        local engineHealth = math.floor(GetVehicleEngineHealth(vehicle))
        local bodyHealth = math.floor(GetVehicleBodyHealth(vehicle))
        local turbo = IsToggleModOn(vehicle, 18) and Lang:t("general.turbo_on") or Lang:t("general.turbo_off")
        local brakes = GetVehicleMod(vehicle, 12) ~= -1 and Lang:t("general.mod_upgraded") or Lang:t("general.mod_stock")
        local transmission = GetVehicleMod(vehicle, 13) ~= -1 and Lang:t("general.mod_upgraded") or Lang:t("general.mod_stock")
        local suspension = GetVehicleMod(vehicle, 15) ~= -1 and Lang:t("general.mod_upgraded") or Lang:t("general.mod_stock")
        
        CarNotify(Lang:t("general.tuning_status", {
            engine = engineHealth,
            body = bodyHealth,
            turbo = turbo,
            brakes = brakes,
            transmission = transmission,
            suspension = suspension
        }), "primary", 6000)
    end, function() end)
end)

local function ApplyCuffAnimation(faceType, isHardCuff)
    local ped = PlayerPedId()
    local animDict = "mp_arresting"
    local animName = "idle"
    
    if faceType == "front" then
        animDict = "anim@move_m@prisoner_cuffed"
        animName = "idle"
    end
    
    cuffAnimDict = animDict
    cuffAnimName = animName
    
    while not HasAnimDictLoaded(animDict) do
        RequestAnimDict(animDict)
        Wait(10)
    end
    
    TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, -1, cuffType, 0.0, false, false, false)
    
    if not cuffAnimLoaded then
        RequestAnimSet("move_m@prisoner_cuffed")
        while not HasAnimSetLoaded("move_m@prisoner_cuffed") do
            Wait(0)
        end
        SetPedMovementClipset(ped, "move_m@prisoner_cuffed", 0.25)
        cuffAnimLoaded = true
    end
    
    local cuffModel = "p_cs_cuffs_02_s"
    local cuffHash = GetHashKey(cuffModel)
    
    if not HasModelLoaded(cuffHash) then
        RequestModel(cuffHash)
        while not HasModelLoaded(cuffHash) do
            Wait(1)
        end
    end
    
    cuffObject = CreateObject(cuffHash, GetEntityCoords(ped), true, true, true)
    local netId = ObjToNet(cuffObject)
    SetNetworkIdExistsOnAllMachines(netId, true)
    SetNetworkIdCanMigrate(netId, false)
    NetworkSetNetworkIdDynamic(netId, true)
    
    local boneIndex = GetPedBoneIndex(ped, 60309)
    
    if faceType == "front" then
        AttachEntityToEntity(cuffObject, ped, boneIndex, -0.058, 0.005, 0.09, 290.0, 95.0, 120.0, true, false, false, false, 0, true)
    else
        AttachEntityToEntity(cuffObject, ped, boneIndex, -0.055, 0.06, 0.04, 265.0, 155.0, 80.0, true, false, false, false, 0, true)
    end
end

local function RemoveCuffs()
    local ped = PlayerPedId()
    
    isHandcuffed = false
    isEscorted = false
    TriggerEvent("hospital:client:isEscorted", isEscorted)
    
    DetachEntity(ped, true, false)
    
    if cuffObject and DoesEntityExist(cuffObject) then
        DeleteObject(cuffObject)
        cuffObject = nil
    end
    
    ClearPedTasksImmediately(ped)
    ResetPedMovementClipset(ped, 0.25)
    
    cuffAnimLoaded = false
    cuffAnimDict = nil
    cuffAnimName = nil
    
    LockInventory(false)
end

RegisterNetEvent("frkn-policejob:client:GetCuffed", function(playerId, isHardCuff, faceType, isCuffing)
    local ped = PlayerPedId()
    cuffFaceType = faceType
    
    if isCuffing then
        if isHandcuffed then return end
        
        TriggerServerEvent("frkn-policejob:server:SetHandcuffStatus", true, faceType)
        ClearPedTasksImmediately(ped)
        
        local currentWeapon = GetSelectedPedWeapon(ped)
        if currentWeapon ~= GetHashKey("weapon_unarmed") then
            SetCurrentPedWeapon(ped, GetHashKey("weapon_unarmed"), true)
        end
        
        if not isHardCuff then
            cuffType = 49
        else
            local targetPed = GetPlayerPed(GetPlayerFromServerId(playerId))
            local targetHeading = GetEntityHeading(targetPed)
            
            TriggerServerEvent("InteractSound_SV:PlayOnSource", "Cuff", 0.2)
            
            loadAnimDict("mp_arrest_paired")
            SetEntityCoords(ped, GetOffsetFromEntityInWorldCoords(targetPed, 0.0, 0.45, 0.0))
            Wait(100)
            SetEntityHeading(ped, targetHeading)
            TaskPlayAnim(ped, "mp_arrest_paired", "crook_p2_back_right", 3.0, 3.0, -1, 32, 0, false, false, false)
            Wait(3500)
            cuffType = 49
        end
        
        isHandcuffed = true
        ApplyCuffAnimation(faceType, isHardCuff)
        
        if not isHardCuff then
            Notify(Lang:t("general.cuff"), "primary")
        else
            Notify(Lang:t("general.cuff"), "primary")
        end
    else
        RemoveCuffs()
        TriggerServerEvent("frkn-policejob:server:SetHandcuffStatus", false)
        TriggerServerEvent("InteractSound_SV:PlayOnSource", "Uncuff", 0.2)
        Notify(Lang:t("success.uncuffed"), "success")
    end
end)

local function HandCuffAnimation(isHardCuff)
    local ped = PlayerPedId()
    
    if isHandcuffed then
        TriggerServerEvent("InteractSound_SV:PlayOnSource", "Cuff", 0.2)
    else
        TriggerServerEvent("InteractSound_SV:PlayOnSource", "Uncuff", 0.2)
        DetachEntity(cuffObject, true, false)
        DeleteEntity(cuffObject)
    end
    
    if isHardCuff then
        loadAnimDict("mp_arrest_paired")
        Wait(100)
        TaskPlayAnim(ped, "mp_arrest_paired", "cop_p2_back_right", 3.0, 3.0, -1, 48, 0, false, false, false)
        TriggerServerEvent("InteractSound_SV:PlayOnSource", "Cuff", 0.2)
        Wait(3500)
        TaskPlayAnim(ped, "mp_arrest_paired", "exit", 3.0, 3.0, -1, 48, 0, false, false, false)
    else
        loadAnimDict("mp_arresting")
        Wait(100)
        TaskPlayAnim(ped, "mp_arresting", "a_uncuff", 3.0, 3.0, -1, 48, 0, false, false, false)
        DetachEntity(cuffObject, true, false)
        DeleteEntity(cuffObject)
        TriggerServerEvent("InteractSound_SV:PlayOnSource", "Cuff", 0.2)
        Wait(3500)
        TaskPlayAnim(ped, "mp_arresting", "exit", 3.0, 3.0, -1, 48, 0, false, false, false)
    end
end

RegisterNetEvent("frkn-policejob:client:UnCuffPlayer", function()
    local targetId, distance = GetClosestPlayer()
    
    if targetId == -1 or distance >= 1.5 then
        Notify(Lang:t("error.none_nearby"), "error")
        return
    end
    
    local hasKey = HasItem(FRKN.CuffKeyItem)
    if not hasKey or hasKey == 0 or hasKey == "0" then
        Notify(Lang:t("error.notitem_uncuff"), "error")
        return
    end
    
    local targetPed = targetId
    if IsPedInAnyVehicle(targetPed) or IsPedInAnyVehicle(PlayerPedId()) then
        Notify(Lang:t("error.vehicle_cuff"), "error")
        return
    end
    
    local facePos = GetFacePosition(targetId)
    local serverId = targetId
    
    TriggerCallback("frkn-policejob:server:getCuffStatus", function(status)
        if not status or not status.cuffed then
            Notify(Lang:t("error.target_not_cuffed"), "error")
            return
        end
        
        if facePos ~= status.item then
            Notify(Lang:t("error.cuff_position"), "error")
            return
        end
        
        TriggerServerEvent("frkn-policejob:server:CuffPlayer", serverId, false, facePos, false)
        HandCuffAnimation(false)
    end, serverId)
end)

RegisterNetEvent("frkn-policejob:client:cuffplayer", function(isHardCuff)
    if type(isHardCuff) == "table" and #isHardCuff == 0 then
        isHardCuff = false
    end
    
    if IsPedRagdoll(PlayerPedId()) then
        Wait(2000)
        return
    end
    
    local targetId, distance = GetClosestPlayer()
    
    if targetId == -1 or distance >= 1.5 then
        Notify(Lang:t("error.none_nearby"), "error")
        return
    end
    
    local hasCuffs = HasItem(FRKN.HandCuffItem)
    if not hasCuffs or hasCuffs == 0 or hasCuffs == "0" then
        Notify(Lang:t("error.notitem_cuff"), "error")
        return
    end
    
    local targetPed = targetId
    if IsPedInAnyVehicle(targetPed) or IsPedInAnyVehicle(PlayerPedId()) then
        Notify(Lang:t("error.vehicle_cuff"), "error")
        return
    end
    
    local facePos = GetFacePosition(targetId)
    local serverId = targetId
    
    TriggerCallback("frkn-policejob:server:getCuffStatus", function(status)
        if status and status.cuffed then
            Notify(Lang:t("error.target_already_cuffed"), "error")
            return
        end
        
        TriggerServerEvent("frkn-policejob:server:CuffPlayer", serverId, isHardCuff, facePos, true)
        HandCuffAnimation(isHardCuff and true or false)
    end, serverId)
end)

exports("IsHandcuffed", function()
    return isHandcuffed
end)

RegisterNetEvent("frkn-policejob:client:PutPlayerInVehicle", function()
    local targetId, distance = GetClosestPlayer()
    
    if targetId == -1 or distance >= 2.5 then
        Notify(Lang:t("error.none_nearby"), "error")
        return
    end
    
    TriggerCallback("frkn-policejob:server:getCuffStatus", function(isCuffed)
        if isCuffed then
            TriggerServerEvent("frkn-policejob:server:PutPlayerInVehicle", targetId)
        else
            Notify(Lang:t("error.not_cuffed"), "error")
        end
    end, targetId)
end)

RegisterNetEvent("frkn-policejob:client:PutInVehicle", function()
    local ped = PlayerPedId()
    local vehicle = GetClosestVehicle(GetEntityCoords(ped))
    
    if not DoesEntityExist(vehicle) then return end
    
    local maxSeats = GetVehicleMaxNumberOfPassengers(vehicle)
    
    for seat = maxSeats, 0, -1 do
        if IsVehicleSeatFree(vehicle, seat) then
            if IsPedInAnyVehicle(ped, false) then
                DetachEntity(ped, true, false)
            end
            SetPedIntoVehicle(ped, vehicle, seat)
            return
        end
    end
end)

RegisterNetEvent("frkn-policejob:client:SetOutVehicle", function()
    local ped = PlayerPedId()
    
    if not IsPedInAnyVehicle(ped, false) then return end
    
    local vehicle = GetVehiclePedIsIn(ped, false)
    TaskLeaveVehicle(ped, vehicle, 16)
    Wait(600)
    ClearPedTasks(ped)
    ClearPedTasksImmediately(ped)
    
    local serverId = GetPlayerServerId(PlayerId())
    TriggerCallback("frkn-policejob:server:getCuffStatus", function(status)
        if status and status.cuffed then
            local animDict = "mp_arresting"
            local animName = "idle"
            
            if status.item == "front" then
                animDict = "anim@move_m@prisoner_cuffed"
                animName = "idle"
            end
            
            RequestAnimDict(animDict)
            while not HasAnimDictLoaded(animDict) do
                Wait(0)
            end
            
            TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, -1, 49, 0.0, false, false, false)
            
            if cuffObject and DoesEntityExist(cuffObject) then
                local boneIndex = GetPedBoneIndex(ped, 60309)
                
                if status.item == "front" then
                    AttachEntityToEntity(cuffObject, ped, boneIndex, -0.058, 0.005, 0.09, 290.0, 95.0, 120.0, true, false, false, false, 0, true)
                else
                    AttachEntityToEntity(cuffObject, ped, boneIndex, -0.055, 0.06, 0.04, 265.0, 155.0, 80.0, true, false, false, false, 0, true)
                end
            end
        end
    end, serverId)
end)

RegisterNetEvent("frkn-policejob:client:SetPlayerOutVehicle", function()
    local targetId, distance = GetClosestPlayer()
    
    if targetId == -1 or distance >= 2.5 then
        Notify(Lang:t("error.none_nearby"), "error")
        return
    end
    
    TriggerServerEvent("frkn-policejob:server:SetPlayerOutVehicle", targetId)
end)

RegisterNetEvent("frkn-policejob:client:EscortPlayer", function()
    local targetId, distance = GetClosestPlayer()
    
    if targetId == -1 or distance >= 2.5 then
        Notify(Lang:t("error.none_nearby"), "error")
        return
    end
    
    TriggerCallback("frkn-policejob:server:getCuffStatus", function(isCuffed)
        if isCuffed then
            TriggerServerEvent("frkn-policejob:server:EscortPlayer", targetId)
        else
            Notify(Lang:t("error.not_cuffed"), "error")
        end
    end, targetId)
end)

RegisterNetEvent("frkn-policejob:client:GetEscorted", function(dragId)
    local ped = PlayerPedId()
    
    if not isEscorted then
        isEscorted = true
        local draggerPed = GetPlayerPed(GetPlayerFromServerId(dragId))
        
        TriggerServerEvent("frkn-policejob:server:isEscortingPlayer", true, dragId)
        SetEntityCoords(ped, GetOffsetFromEntityInWorldCoords(draggerPed, 0.0, 0.45, 0.0))
        AttachEntityToEntity(ped, draggerPed, 11816, 0.45, 0.45, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
    else
        isEscorted = false
        TriggerServerEvent("frkn-policejob:server:isEscortingPlayer", false, dragId)
        DetachEntity(ped, true, false)
    end
    
    TriggerEvent("hospital:client:isEscorted", isEscorted)
end)

RegisterNetEvent("frkn-policejob:client:setEscortStatus", function(status)
    isEscortingPlayer = status
end)

RegisterNetEvent("frkn-policejob:client:DeEscort", function()
    isEscorted = false
    TriggerEvent("hospital:client:isEscorted", isEscorted)
    DetachEntity(PlayerPedId(), true, false)
end)

RegisterNetEvent("frkn:police:carry", function()
    local targetId, distance = GetClosestPlayer()
    
    if targetId == -1 or distance >= 2.5 then
        Notify(Lang:t("error.none_nearby"), "error")
        return
    end
    
    local targetPed = GetPlayerPed(targetId)
    if not IsPedInAnyVehicle(targetPed) and not isHandcuffed and not isEscorted then
        TriggerServerEvent("frkn-policejob:server:KidnapPlayer", targetId)
    end
end)

RegisterNetEvent("frkn-policejob:client:GetKidnappedTarget", function(kidnapperId)
    local ped = PlayerPedId()
    
    if not isEscorted then
        isEscorted = true
        local kidnapper = GetPlayerPed(GetPlayerFromServerId(kidnapperId))
        
        RequestAnimDict("nm")
        while not HasAnimDictLoaded("nm") do
            Wait(10)
        end
        
        AttachEntityToEntity(ped, kidnapper, 0, 0.27, 0.15, 0.63, 0.5, 0.5, 0.0, false, false, false, false, 2, false)
        TaskPlayAnim(ped, "nm", "firemans_carry", 8.0, -8.0, 100000, 33, 0, false, false, false)
    else
        isEscorted = false
        DetachEntity(ped, true, false)
        ClearPedTasksImmediately(ped)
    end
end)

RegisterNetEvent("frkn-policejob:client:GetKidnappedDragger", function()
    if not isEscorting then
        local ped = PlayerPedId()
        
        RequestAnimDict("missfinale_c2mcs_1")
        while not HasAnimDictLoaded("missfinale_c2mcs_1") do
            Wait(10)
        end
        
        TaskPlayAnim(ped, "missfinale_c2mcs_1", "fin_c2_mcs_1_camman", 8.0, -8.0, 100000, 49, 0, false, false, false)
        isEscorting = true
    else
        local ped = PlayerPedId()
        ClearPedSecondaryTask(ped)
        ClearPedTasksImmediately(ped)
        isEscorting = false
    end
    
    TriggerEvent("hospital:client:SetEscortingState", isEscorting)
    TriggerEvent("qb-kidnapping:client:SetKidnapping", isEscorting)
end)

CreateThread(function()
    while true do
        local sleep = 250
        
        if isEscorted or isEscortingPlayer or isHandcuffed then
            sleep = 0
            
            if isEscorted then
                DisableAllControlActions(0)
                EnableControlAction(0, 1, true)   
                EnableControlAction(0, 2, true)   
                EnableControlAction(0, 245, true) 
                EnableControlAction(0, 38, true)  
                EnableControlAction(0, 322, true) 
                EnableControlAction(0, 249, true) 
                EnableControlAction(0, 46, true)  
            end
            
            if isEscortingPlayer then
                DisableControlAction(0, 21, true) 
                DisableControlAction(0, 22, true) 
            end
            
            if isHandcuffed then
                DisableControlAction(0, 24, true)  
                DisableControlAction(0, 25, true)  
                DisableControlAction(0, 37, true)  
                DisableControlAction(0, 45, true)  
                DisableControlAction(0, 22, true)  
                DisableControlAction(0, 44, true)  
                DisableControlAction(0, 23, true)  
                DisableControlAction(0, 288, true) 
                DisableControlAction(0, 289, true) 
                DisableControlAction(0, 170, true) 
                DisableControlAction(0, 167, true) 
                DisableControlAction(0, 26, true)  
                DisableControlAction(0, 73, true)  
                DisableControlAction(2, 199, true) 
                DisableControlAction(0, 59, true)  
                DisableControlAction(0, 71, true)  
                DisableControlAction(0, 72, true)  
                DisableControlAction(2, 36, true)  
                DisableControlAction(0, 264, true) 
                DisableControlAction(0, 257, true) 
                DisableControlAction(0, 140, true) 
                DisableControlAction(0, 141, true) 
                DisableControlAction(0, 142, true) 
                DisableControlAction(0, 143, true) 
                DisableControlAction(0, 75, true)  
                DisableControlAction(27, 75, true) 
                EnableControlAction(0, 249, true)  
                EnableControlAction(0, 46, true)   
                
                if not inventoryLocked then
                    LockInventory(true)
                end
                
                local ped = PlayerPedId()
                local animDict = "mp_arresting"
                local animName = "idle"
                
                if cuffFaceType == "front" then
                    animDict = "anim@move_m@prisoner_cuffed"
                    animName = "idle"
                end
                
                if not cuffAnimLoaded then
                    RequestAnimSet("move_m@prisoner_cuffed")
                    while not HasAnimSetLoaded("move_m@prisoner_cuffed") do
                        Wait(0)
                    end
                    SetPedMovementClipset(ped, "move_m@prisoner_cuffed", 0.25)
                    cuffAnimLoaded = true
                end
                
                if cuffAnimDict ~= animDict or cuffAnimName ~= animName then
                    loadAnimDict(animDict)
                    TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, -1, 49, 0.0, false, false, false)
                    cuffAnimDict = animDict
                    cuffAnimName = animName
                elseif not IsEntityPlayingAnim(ped, cuffAnimDict, cuffAnimName, 3) then
                    TaskPlayAnim(ped, cuffAnimDict, cuffAnimName, 8.0, -8.0, -1, 49, 0.0, false, false, false)
                end
            else
                
                if inventoryLocked then
                    LockInventory(false)
                end
                
                if cuffAnimLoaded then
                    local ped = PlayerPedId()
                    ClearPedSecondaryTask(ped)
                    ResetPedMovementClipset(ped, 0.25)
                    cuffAnimLoaded = false
                    cuffAnimDict = nil
                    cuffAnimName = nil
                end
            end
        end
        
        Wait(sleep)
    end
end)

RegisterNetEvent("frkn-policejob:client:SetStatus", function(statusType, duration)
    if duration > 0 then
        if statusLabels[statusType] then
            if statusEffects[statusType] then
                if statusEffects[statusType].time < 20 then
                    statusEffects[statusType] = {
                        text = statusLabels[statusType],
                        time = duration
                    }
                    Notify(statusEffects[statusType].text, "error")
                end
            else
                statusEffects[statusType] = {
                    text = statusLabels[statusType],
                    time = duration
                }
                Notify(statusEffects[statusType].text, "error")
            end
        end
    else
        if statusLabels[statusType] then
            statusEffects[statusType] = nil
        end
    end
    
    TriggerServerEvent("frkn-policejob:server:UpdateStatus", statusEffects)
end)

RegisterNetEvent("frkn-policejob:alcoholtest", function()
    local job, grade = GetPlayerJob()
    
    if not IsDeptJob(job) then
        return Notify(Lang:t("error.only_police"), "error")
    end
    
    local targetId, distance = GetClosestPlayer(1.5)
    
    if not targetId then
        return Notify(Lang:t("error.none_nearby_gsr"), "error")
    end
    
    TriggerCallback("frkn-policejob:GetPlayerStatus", function(status)
        local message = ""
        
        if type(status) == "table" and next(status) then
            local statusList = {}
            for _, effect in ipairs(status) do
                local text = type(effect) == "table" and (effect.label or effect.text or json.encode(effect)) or tostring(effect)
                table.insert(statusList, text)
            end
            message = table.concat(statusList, "\n")
        else
            message = tostring(status or "")
        end
        
        if message ~= "" then
            Notify(message, "error")
        else
            Notify(Lang:t("success.no_alcohol_detected"), "success")
        end
    end, targetId)
end)

RegisterNetEvent("consumables:client:DrinkAlcohol", function(itemName)
    Progressbar("drink_alcohol", Lang:t("general.liqour_progress"), FRKN.Progressbar.Alcohol, false, true, {
        disableMovement = false,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true
    }, {
        animDict = "mp_player_intdrink",
        anim = "loop_bottle",
        flags = 49
    }, {
        model = "prop_cs_beer_bot_40oz",
        bone = 60309,
        coords = vec3(0.0, 0.0, -0.05),
        rotation = vec3(0.0, 0.0, -40)
    }, {}, function()
        TriggerServerEvent("frkn-policejob:drinkAlcohol", itemName)
        alcoholLevel = alcoholLevel + 1
        AlcoholLoop()
        
        if alcoholLevel > 1 and alcoholLevel < 4 then
            TriggerEvent("frkn-policejob:client:SetStatus", "alcohol", 200)
        elseif alcoholLevel >= 4 then
            TriggerEvent("frkn-policejob:client:SetStatus", "heavyalcohol", 200)
        end
    end, function()
        Notify(Lang:t("error.canceled"), "error")
    end)
end)

function AlcoholLoop()
    if not alcoholActive then
        alcoholActive = true
        CreateThread(function()
            while true do
                Wait(10)
                if alcoholLevel > 0 then
                    Wait(900000) 
                    alcoholLevel = alcoholLevel - 1
                else
                    alcoholActive = false
                    break
                end
            end
        end)
    end
end

RegisterCommand("setammo", function()
    local ped = PlayerPedId()
    local weapon = GetSelectedPedWeapon(ped)
    local unarmed = GetHashKey("weapon_unarmed")
    
    if weapon ~= unarmed and weapon ~= 0 then
        SetPedAmmo(ped, weapon, 250)
        SetAmmoInClip(ped, weapon, 250)
        TriggerEvent("chat:addMessage", {
            args = {"Ammunition: Dolu"}
        })
    else
        TriggerEvent("chat:addMessage", {
            args = {"Silah seçili değil"}
        })
    end
end, false)

local function RestoreCuffStatus()
    local serverId = GetPlayerServerId(PlayerId())
    
    TriggerCallback("frkn-policejob:server:getCuffStatus", function(status)
        if status and status.cuffed then
            ApplyCuffAnimation(status.face or "back", status.hard or true)
            TriggerServerEvent("frkn-policejob:server:SetHandcuffStatus", true, status.face or "back")
        else
            RemoveCuffs()
            TriggerServerEvent("frkn-policejob:server:SetHandcuffStatus", false)
        end
    end, serverId)
end

AddEventHandler("QBCore:Client:OnPlayerLoaded", RestoreCuffStatus)
AddEventHandler("playerSpawned", RestoreCuffStatus)
AddEventHandler("esx:playerLoaded", RestoreCuffStatus)

AddEventHandler("onResourceStop", function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    
    if isHandcuffed then
        local ped = PlayerPedId()
        ClearPedTasksImmediately(ped)
        ResetPedMovementClipset(ped, 0.25)
        
        if cuffObject and DoesEntityExist(cuffObject) then
            DeleteObject(cuffObject)
        end
    end
    
    if menuOpen then
        CloseActionMenu()
    end
    
    if inventoryLocked then
        LockInventory(false)
    end
    
    isHandcuffed = false
    isEscorted = false
    isEscortingPlayer = false
    menuOpen = false
    controlsActive = false
end)

print("^2[Police Job]^0 Script loaded successfully!")

