


local ClothingCamera = {
    cam = nil,
    ped = nil,
    offset = 1.0,
    height = 0.65,
    zoomIndex = 2,
    rotating = false,
    comparing = false
}

local COMPONENT_MAP = {
    mask = 1,
    hair = 2,
    arms = 3,
    ["t-shirt"] = 8,
    torso2 = 11,
    pants = 4,
    shoes = 6,
    accessory = 7,
    vest = 9
}

local CAM_ZOOM_LEVELS = {
    {camOffset = 0.7, camHeight = 0.45},
    {camOffset = 0.9, camHeight = 0.25},
    {camOffset = 1.2, camHeight = 0.25},
    {camOffset = 1.5, camHeight = 0.25}
}

function GetComponentId(name)
    return COMPONENT_MAP[name]
end

local function GetCurrentOutfit()
    local ped = PlayerPedId()
    local outfit = {
        components = {},
        props = {}
    }
    
    for i = 0, 11 do
        outfit.components[i] = {
            drawable = GetPedDrawableVariation(ped, i),
            texture = GetPedTextureVariation(ped, i)
        }
    end
    
    for i = 0, 7 do
        outfit.props[i] = {
            drawable = GetPedPropIndex(ped, i),
            texture = GetPedPropTextureIndex(ped, i)
        }
    end
    
    return outfit
end

RegisterNUICallback("saveClothing", function(data, cb)
    local outfit = GetCurrentOutfit()
    TriggerServerEvent("frkn-policejob:saveClothing", data.name, outfit)
    
    Wait(500)
    
    if cb then
        cb({
            ok = true,
            clothing = cacheData.clothing
        })
    end
end)

RegisterNUICallback("deleteClothing", function(data, cb)
    TriggerServerEvent("frkn-policejob:deleteClothing", data.id)
    
    if cb then
        cb({ok = true})
    end
end)

RegisterNUICallback("applyPoliceUniform", function(data, cb)
    local ped = PlayerPedId()
    local outfit = data.outfitData
    
    if outfit then
        for slot, item in pairs(outfit) do
            if item.item and item.texture then
                if slot == "hat" or slot == "glass" then
                    local propIndex = slot == "hat" and 0 or 1
                    ClearPedProp(ped, propIndex)
                    
                    if item.item ~= -1 then
                        SetPedPropIndex(ped, propIndex, item.item, item.texture, true)
                    end
                else
                    local componentId = GetComponentId(slot)
                    if componentId then
                        SetPedComponentVariation(ped, componentId, item.item, item.texture, 0)
                    end
                end
            end
        end
    end
    
    cb({ok = true})
end)

RegisterNUICallback("applyMyClothes", function(data, cb)
    local ped = PlayerPedId()
    local outfit = data.data
    
    if outfit then
        
        for index, item in pairs(outfit.components or {}) do
            local idx = tonumber(index)
            if idx and item.drawable and item.texture then
                SetPedComponentVariation(ped, idx, item.drawable, item.texture, 0)
            end
        end
        
        for index, item in pairs(outfit.props or {}) do
            local idx = tonumber(index)
            if idx and item.drawable and item.texture then
                ClearPedProp(ped, idx)
                
                if item.drawable ~= -1 then
                    SetPedPropIndex(ped, idx, item.drawable, item.texture, true)
                end
            end
        end
    end
    
    cb({ok = true})
end)

local function IsAnyCamActive()
    for i = 1, 10 do
        local cam = GetRenderingCam()
        if cam ~= -1 and IsCamActive(cam) then
            return true
        end
    end
    return false
end

local function UpdateCameraPosition()
    if not ClothingCamera.cam or not ClothingCamera.ped then return end
    
    local offset = GetOffsetFromEntityInWorldCoords(
        ClothingCamera.ped,
        0.0,
        ClothingCamera.offset,
        ClothingCamera.height
    )
    
    SetCamCoord(ClothingCamera.cam, offset.x, offset.y, offset.z)
    SetCamRot(ClothingCamera.cam, -10.0, 0.0, GetEntityHeading(ClothingCamera.ped) + 180)
end

function charCam(enable)
    if enable then
        ClothingCamera.zoomIndex = 2
        
        if DoesCamExist(ClothingCamera.cam) then return end
        
        while IsAnyCamActive() do
            Citizen.Wait(500)
        end
        
        if ClothingCamera.cam then
            DestroyCam(ClothingCamera.cam, false)
            RenderScriptCams(false, true, 500, true, false)
            Citizen.Wait(500)
            DestroyCam(ClothingCamera.cam, false)
        end
        
        local playerPos = GetEntityCoords(PlayerPedId())
        local playerHeading = GetEntityHeading(PlayerPedId())
        
        RequestModel(GetHashKey("mp_m_freemode_01"))
        while not HasModelLoaded(GetHashKey("mp_m_freemode_01")) do
            Citizen.Wait(0)
        end
        
        ClothingCamera.ped = CreatePed(
            2,
            GetHashKey("mp_m_freemode_01"),
            playerPos.x, playerPos.y, playerPos.z - 1,
            playerHeading,
            false, true
        )
        
        FreezeEntityPosition(ClothingCamera.ped, true)
        SetEntityVisible(ClothingCamera.ped, false)
        SetEntityNoCollisionEntity(PlayerPedId(), ClothingCamera.ped, true)
        
        local camPos = GetOffsetFromEntityInWorldCoords(
            ClothingCamera.ped,
            0.0,
            ClothingCamera.offset,
            ClothingCamera.height
        )
        
        ClothingCamera.cam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
        SetCamActive(ClothingCamera.cam, true)
        RenderScriptCams(true, true, 500, true, true)
        SetCamCoord(ClothingCamera.cam, camPos.x, camPos.y, camPos.z)
        SetCamRot(ClothingCamera.cam, -10.0, 0.0, GetEntityHeading(ClothingCamera.ped) + 180)
        
        ClothingCamera.offset = 1.0
        ClothingCamera.height = 0.65
        
        Citizen.CreateThread(function()
            while DoesCamExist(ClothingCamera.cam) and not ClothingCamera.rotating do
                local offset = GetOffsetFromEntityInWorldCoords(
                    PlayerPedId(),
                    0.0,
                    ClothingCamera.offset,
                    ClothingCamera.height
                )
                
                SetCamCoord(ClothingCamera.cam, offset.x, offset.y, offset.z)
                SetCamRot(ClothingCamera.cam, -10.0, 0.0, GetEntityHeading(PlayerPedId()) + 180)
                
                Citizen.Wait(0)
            end
        end)
    else
        
        ClothingCamera.rotating = true 
        
        if ClothingCamera.ped and DoesEntityExist(ClothingCamera.ped) then
            DeletePed(ClothingCamera.ped)
        end
        
        ClearTimecycleModifier()
        
        if ClothingCamera.cam and DoesCamExist(ClothingCamera.cam) then
            SetCamActive(ClothingCamera.cam, false)
            DestroyCam(ClothingCamera.cam, true)
        end
        
        RenderScriptCams(false, false, 0, true, false)
        DestroyAllCams(true)
        
        ClothingCamera.cam = nil
        ClothingCamera.ped = nil
        ClothingCamera.rotating = false
    end
end

RegisterCommand("resetcam", function()
    ForceResetCamera()
end, false)

function ForceResetCamera()
    ClothingCamera.rotating = true
    if ClothingCamera.ped and DoesEntityExist(ClothingCamera.ped) then
        DeletePed(ClothingCamera.ped)
    end
    ClearTimecycleModifier()
    RenderScriptCams(false, false, 0, true, false)
    DestroyAllCams(true)
    ClothingCamera.cam = nil
    ClothingCamera.ped = nil
    ClothingCamera.rotating = false
end

RegisterNUICallback("closeClothingCam", function(data, cb)
    ForceResetCamera()
    if cb then cb("ok") end
end)

RegisterNUICallback("cameraZoom", function(data, cb)
    if not DoesCamExist(ClothingCamera.cam) then return end
    
    if data.delta < 0 and ClothingCamera.zoomIndex < #CAM_ZOOM_LEVELS then
        ClothingCamera.zoomIndex = ClothingCamera.zoomIndex + 1
    elseif data.delta > 0 and ClothingCamera.zoomIndex > 1 then
        ClothingCamera.zoomIndex = ClothingCamera.zoomIndex - 1
    end
    
    local level = CAM_ZOOM_LEVELS[ClothingCamera.zoomIndex]
    ClothingCamera.offset = level.camOffset
    ClothingCamera.height = level.camHeight
    
    if ClothingCamera.offset == 1.5 then
        SetCamNearDof(ClothingCamera.cam, 0.9)
        SetCamFarDof(ClothingCamera.cam, 1.5)
    else
        SetCamNearDof(ClothingCamera.cam, 0.4)
        SetCamFarDof(ClothingCamera.cam, 1.1)
    end
    
    SetCamDofStrength(ClothingCamera.cam, 1.0)
    
    local newPos = GetOffsetFromEntityInWorldCoords(
        ClothingCamera.ped,
        0.05,
        ClothingCamera.offset,
        ClothingCamera.height
    )
    
    SetCamCoord(ClothingCamera.cam, newPos.x, newPos.y, newPos.z + 0.2)
    
    cb("ok")
end)

RegisterNUICallback("cameraRotate", function(data, cb)
    local rotationAmount = data.direction == "left" and -5 or 5
    local currentHeading = GetEntityHeading(PlayerPedId())
    local newHeading = currentHeading + (rotationAmount * 0.3)
    
    SetEntityHeading(PlayerPedId(), newHeading)
    
    ClothingCamera.rotating = true
    Citizen.Wait(500)
    ClothingCamera.rotating = false
    
    cb("ok")
end)

RegisterNUICallback("cameraHeight", function(data, cb)
    if not DoesCamExist(ClothingCamera.cam) then return end
    
    if data.direction == "up" then
        ClothingCamera.height = ClothingCamera.height + 0.05
    elseif data.direction == "down" then
        ClothingCamera.height = ClothingCamera.height - 0.05
    end
    
    local newPos = GetOffsetFromEntityInWorldCoords(
        ClothingCamera.ped,
        0.05,
        ClothingCamera.offset,
        ClothingCamera.height
    )
    
    SetCamCoord(ClothingCamera.cam, newPos.x, newPos.y, newPos.z + 0.2)
    
    cb("ok")
end)

RegisterNUICallback("cameraAdjust", function(data, cb)
    ClothingCamera.offset = 1.0
    ClothingCamera.height = 0.65
    ClothingCamera.zoomIndex = 2
    
    if ClothingCamera.cam and ClothingCamera.ped then
        local newPos = GetOffsetFromEntityInWorldCoords(
            ClothingCamera.ped,
            0.0,
            ClothingCamera.offset,
            ClothingCamera.height
        )
        
        SetCamCoord(ClothingCamera.cam, newPos.x, newPos.y, newPos.z)
        SetCamRot(ClothingCamera.cam, -10.0, 0.0, GetEntityHeading(ClothingCamera.ped) + 180)
    end
    
    cb("ok")
end)

