-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Core = nil
CoreName = nil
CoreReady = false

if not FRKN then FRKN = {} end
FRKN.ServerCallbacks = FRKN.ServerCallbacks or {}

CreateThread(function()
    for _, v in pairs(Cores) do
        local state = GetResourceState(v.ResourceName)
        if state == "starting" or state == "started" then
            CoreName = v.ResourceName
            Core = v.GetFramework()
            CoreReady = true
            PlayerData = GetPlayerData()
            break
        end
    end
end)

function TriggerCallback(name, cb, ...)
    if not FRKN then FRKN = {} end
    if not FRKN.ServerCallbacks then FRKN.ServerCallbacks = {} end
    FRKN.ServerCallbacks[name] = cb
    TriggerServerEvent('frkn-policejob:server:triggerCallback', name, ...)
end

RegisterNetEvent('frkn-policejob:client:triggerCallback', function(name, ...)
    if FRKN.ServerCallbacks[name] then
        FRKN.ServerCallbacks[name](...)
        FRKN.ServerCallbacks[name] = nil
    end
end)

RegisterNetEvent('frkn:police:searchPerson', function()
    local player, distance, playerId = GetClosestPlayerPed(5.0)
    local ped = PlayerPedId()
    local hasWeapon, weaponHash = GetCurrentPedWeapon(ped, false)
    local PlayerData = GetPlayerData()

    if IsPedInAnyVehicle(ped, false) then
        Notify(Lang:t("error.not_in_vehicle"), "error")
        return
    end

    local isDead = false
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        isDead = PlayerData.metadata and (PlayerData.metadata.isdead or PlayerData.metadata.inlaststand) or false
    elseif CoreName == "es_extended" then
        isDead = IsPedDeadOrDying(ped, true)
    end

    if not isDead then
        if player ~= -1 and distance < 2.5 then
            if hasWeapon then
                if FRKN.PoliceSearch.weapons[weaponHash] then
                    Notify(Lang:t("error.restricted_weapon"), "error")
                    return
                end

                local playerPed = player
                local animDict, anim, progressBarTime = "", "", 0
                local isCuffed = FRKN.PoliceSearch.handsupAnim.animcontrol and (IsEntityPlayingAnim(playerPed, FRKN.PoliceSearch.handsupAnim.dict, FRKN.PoliceSearch.handsupAnim.name, 3) or IsEntityPlayingAnim(playerPed, "mp_arresting", "idle", 3)) or not FRKN.PoliceSearch.handsupAnim.animcontrol
                local isDeadOrWounded = FRKN.PoliceSearch.deadAnim.animcontrol and (IsEntityPlayingAnim(playerPed, "dead", "dead_a", 3) or IsEntityPlayingAnim(playerPed, "combat@damage@writhe", "writhe_loop", 3) or IsTargetDead(playerId)) or not FRKN.PoliceSearch.deadAnim.animcontrol

                if isCuffed then
                    animDict = FRKN.PoliceSearch.robAnim.dict
                    anim = FRKN.PoliceSearch.robAnim.name
                    progressBarTime = math.random(3000, 4500)
                elseif isDeadOrWounded then
                    animDict = FRKN.PoliceSearch.deadAnim.dict
                    anim = FRKN.PoliceSearch.deadAnim.name
                    progressBarTime = math.random(10000, 13000)
                else
                    Notify(Lang:t("error.target_not_ready"), "error")
                    return
                end

                RequestAnimDict(animDict)
                while not HasAnimDictLoaded(animDict) do
                    Wait(0)
                end

                TaskPlayAnim(ped, animDict, anim, 8.0, -8.0, -1, 49, 0, false, false, false)
                TriggerServerEvent('frkn-policejob:searchPlayer', playerId)

                Progressbar("robbing_player", Lang:t("general.robbing"), progressBarTime, false, true, {
                    disableMovement = true,
                    disableCarMovement = true,
                    disableMouse = false,
                    disableCombat = true,
                }, {}, {}, {}, function()
                    local plyCoords = GetEntityCoords(playerPed)
                    local pos = GetEntityCoords(ped)
                    if #(pos - plyCoords) < 2.5 then
                        StopAnimTask(ped, animDict, anim, 1.0)

                        if FRKN.Inventory == 'qb-inventory' or FRKN.Inventory == 'ps-inventory' then
                            TriggerServerEvent("police:server:SearchPlayer", "otherplayer", playerId)
                        elseif FRKN.Inventory == 'ox_inventory' then
                            exports.ox_inventory:openNearbyInventory()
                        elseif FRKN.Inventory == 'new-qb-inventory' then
                            TriggerServerEvent("police:server:SearchPlayer", "otherplayer", playerId)
                        elseif FRKN.Inventory == 'inventory' then
                            exports['inventory']:OpenInventory({
                                type = "otherplayer",
                                id = playerId
                            })
                        elseif FRKN.Inventory == 'quasar_inventory' then
                            exports['qs-inventory']:openInventory({
                                type = "otherplayer",
                                id = playerId
                            })
                        elseif FRKN.Inventory == 'tgiann-inventory' then
                            exports['tgiann-inventory']:OpenOtherInventory(playerId)
                        end

                        Notify(Lang:t("success.robbery_success"), "success")
                    else
                        Notify(Lang:t("error.none_nearby"), "error")
                    end
                end, function()
                    StopAnimTask(ped, animDict, anim, 1.0)
                    Notify(Lang:t("error.canceled"), "error")
                end)
            else
                Notify(Lang:t("error.need_weapon"), "error")
            end
        else
            Notify(Lang:t("error.none_nearby"), "error")
        end
    end
end)

RegisterNetEvent('frkn-policejob:inventoryBusy')
AddEventHandler('frkn-policejob:inventoryBusy',function()
    if FRKN.Inventory == 'ox_inventory' then 
        LocalPlayer.state.invBusy = true
    end
end)

RegisterNetEvent('frkn-policejob:inventoryFree')
AddEventHandler('frkn-policejob:inventoryFree', function()
    if FRKN.Inventory == 'ox_inventory' then 
        LocalPlayer.state.invBusy = false
    end
end)

function Notify(text, type, length)
    length = length or 5000
    if CoreName == "qbx_core" then
        Core:Notify(text, type, length)
    elseif CoreName == "qb-core" then
        Core.Functions.Notify(text, type, length)
    elseif CoreName == "es_extended" then
        Core.ShowNotification(text)
    end
end

function CarNotify(text, typ, length)
    local t = tostring(typ or 'primary'):lower()
    local map = {
        info = 'primary', primary = 'primary', notice = 'primary', warn = 'error', warning = 'error',
        ok = 'success', success = 'success',
        err = 'error', error = 'error', danger = 'error'
    }
    local qbType = map[t] or 'primary'
    local ms = tonumber(length) or 5000

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        Core.Functions.Notify(text, qbType, ms)
        return
    end

    if CoreName == "es_extended" then
        if lib and lib.notify then
            local libType = (qbType == 'success' and 'success') or (qbType == 'error' and 'error') or 'inform'
            lib.notify({ description = text, type = libType, duration = ms })
        else
            Core.ShowNotification(text)
        end
        return
    end

end

local ESX_PROGRESS_RESOURCE = ESX_PROGRESS_RESOURCE

local function use_esx_export(opts, onFinish, onCancel)
    local res = {}
    if type(ESX_PROGRESS_RESOURCE) == "string" then res[#res+1] = ESX_PROGRESS_RESOURCE end
    res[#res+1] = GetCurrentResourceName()
    res[#res+1] = "esx_progressbar"
    local animation = nil
    if opts.anim and ((opts.anim.dict and opts.anim.dict ~= "") and (opts.anim.clip and opts.anim.clip ~= "")) then
        animation = { type = "anim", dict = opts.anim.dict, lib = opts.anim.clip }
    elseif opts.anim and opts.anim.scenario then
        animation = { type = "Scenario", Scenario = opts.anim.scenario }
    end
    local options = {
        animation = animation,
        FreezePlayer = opts.disable and (opts.disable.move == true),
        onFinish = function() if onFinish then onFinish() end end,
        onCancel = function() if onCancel then onCancel() end end
    }
    for _, r in ipairs(res) do
        local ok, ret = pcall(function()
            return exports[r]:Progressbar(opts.label or "", opts.duration or 1500, options)
        end)
        if ok and ret then return true end
    end
    return false
end

local function use_ox_lib(opts, onFinish, onCancel)
    if not lib or not lib.progressBar then return false end
    local ok = lib.progressBar({
        duration = opts.duration,
        label = opts.label,
        useWhileDead = opts.useWhileDead,
        canCancel = opts.canCancel,
        disable = {
            move = opts.disable.move,
            car = opts.disable.car,
            mouse = opts.disable.mouse,
            combat = opts.disable.combat,
        },
        anim = {
            dict = opts.anim.dict,
            clip = opts.anim.clip,
            flag = opts.anim.flags or opts.anim.flag,
        },
        prop = opts.prop,
        propTwo = opts.propTwo
    })
    if ok then if onFinish then onFinish() end else if onCancel then onCancel() end end
    return true
end

local function use_mythic(opts, onFinish, onCancel)
    local ok = pcall(function() return exports['mythic_progbar'] ~= nil end)
    if not ok then return false end
    exports['mythic_progbar']:Progress({
        name = tostring(opts.name or 'task'),
        duration = opts.duration,
        label = opts.label,
        useWhileDead = opts.useWhileDead,
        canCancel = opts.canCancel,
        controlDisables = {
            disableMovement = opts.disable.move,
            disableCarMovement = opts.disable.car,
            disableMouse = opts.disable.mouse,
            disableCombat = opts.disable.combat,
        },
        animation = {
            animDict = opts.anim.dict,
            anim = opts.anim.clip,
            flags = opts.anim.flags or 49,
        },
        prop = opts.prop,
        propTwo = opts.propTwo
    }, function(status)
        if status then
            if onCancel then onCancel() end
        else
            if onFinish then onFinish() end
        end
    end)
    return true
end

local function use_progressBars(opts, onFinish, onCancel)
    local ok = pcall(function() return exports['progressBars'] ~= nil end)
    if not ok then return false end
    exports['progressBars']:startUI(opts.duration, opts.label or '')
    Citizen.SetTimeout(opts.duration, function() if onFinish then onFinish() end end)
    return true
end

function StartProgress(opts, onFinish, onCancel)
    local name = tostring(opts.name or 'task')
    local label = tostring(opts.label or '')
    local duration = tonumber(opts.duration) or 1500
    local useWhileDead = opts.useWhileDead or false
    local canCancel = (opts.canCancel ~= false)

    local d = opts.disable or {}
    local disable = {
        move = d.move or d.disableMovement or false,
        car = d.car or d.disableCarMovement or false,
        mouse = d.mouse or d.disableMouse or false,
        combat = d.combat or d.disableCombat or false,
    }

    local a = opts.anim or {}
    local anim = {
        dict = a.dict or a.animDict or '',
        clip = a.clip or a.anim or '',
        flags = a.flags or a.flag or 49,
        scenario = a.scenario
    }

    local prop = opts.prop or {}
    local propTwo = opts.propTwo or {}

    if Core and Core.Functions and Core.Functions.Progressbar then
        Core.Functions.Progressbar(name, label, duration, useWhileDead, canCancel, disable, anim, prop, propTwo,
            function() if onFinish then onFinish() end end,
            function() if onCancel then onCancel() end end
        )
        return
    end

    local used =
        use_esx_export({
            name = name, label = label, duration = duration, useWhileDead = useWhileDead, canCancel = canCancel,
            disable = disable, anim = anim, prop = prop, propTwo = propTwo
        }, onFinish, onCancel)
        or use_ox_lib({
            name = name, label = label, duration = duration, useWhileDead = useWhileDead, canCancel = canCancel,
            disable = disable, anim = anim, prop = prop, propTwo = propTwo
        }, onFinish, onCancel)
        or use_mythic({
            name = name, label = label, duration = duration, useWhileDead = useWhileDead, canCancel = canCancel,
            disable = disable, anim = anim, prop = prop, propTwo = propTwo
        }, onFinish, onCancel)
        or use_progressBars({
            name = name, label = label, duration = duration, useWhileDead = useWhileDead, canCancel = canCancel,
            disable = disable, anim = anim, prop = prop, propTwo = propTwo
        }, onFinish, onCancel)

    if not used then
        Citizen.SetTimeout(duration, function() if onFinish then onFinish() end end)
    end
end

function Progressbar(name, label, duration, useWhileDead, canCancel, disable, anim, prop, propTwo, onFinish, onCancel)
    StartProgress({
        name = name,
        label = label,
        duration = duration,
        useWhileDead = useWhileDead,
        canCancel = canCancel,
        disable = disable,
        anim = anim,
        prop = prop,
        propTwo = propTwo
    }, onFinish, onCancel)
end

function GetPlate(vehicle)
    if not vehicle or vehicle == 0 then return nil end
    local function _san(p) p = tostring(p or ''):gsub('^%s*(.-)%s*$', '%1'); return string.upper(p) end
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local p = Core.Functions.GetPlate(vehicle)
        if p and p ~= "" then return _san(p) end
    elseif CoreName == "es_extended" then
        local props = (Core and Core.Game and Core.Game.GetVehicleProperties and Core.Game.GetVehicleProperties(vehicle)) or nil
        if props and props.plate and props.plate ~= "" then return _san(props.plate) end
    end
    local native = GetVehicleNumberPlateText(vehicle)
    if native and native ~= "" then return _san(native) end
    return nil
end

function loadAnimDict(dict)
    if not dict or dict == "" then return end
    if HasAnimDictLoaded(dict) then return end
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(0)
    end
end

function GetClosestPlayerPed(radius)
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local closestPed = nil
    local closestDist = radius
    local closestPlayer = nil 

    for _, id in ipairs(GetActivePlayers()) do
        if id ~= PlayerId() then
            local targetPed = GetPlayerPed(id)
            local targetCoords = GetEntityCoords(targetPed)
            local dist = #(targetCoords - playerCoords)
            
            if dist < closestDist then
                closestDist = dist
                closestPed = targetPed
                closestPlayer = GetPlayerServerId(id) 
            end
        end
    end
    
    return closestPed, closestDist, closestPlayer
end

function GetClosestPlayer(radius)
    radius = radius or 5.0
    local closestPlayer, closestDist = -1, radius + 0.01
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local ply, dist = Core.Functions.GetClosestPlayer()
        if ply ~= -1 and dist <= radius then
            return GetPlayerServerId(ply), dist
        end

    elseif CoreName == "es_extended" then
        if Core and Core.Game and Core.Game.GetClosestPlayer then
            local ply, dist = Core.Game.GetClosestPlayer()
            if ply ~= -1 and dist <= radius then
                return GetPlayerServerId(ply), dist
            end
        end
    end

    for _, id in ipairs(GetActivePlayers()) do
        if id ~= PlayerId() then
            local tgtPed = GetPlayerPed(id)
            local dist = #(GetEntityCoords(tgtPed) - coords)
            if dist < closestDist then
                closestPlayer, closestDist = GetPlayerServerId(id), dist
            end
        end
    end

    if closestPlayer ~= -1 and closestDist <= radius then
        return closestPlayer, closestDist
    end
    return -1, -1
end

function OpenStash(sType, stashId, id)
    local hasOx = GetResourceState('ox_inventory') == 'started'
    local hasQb = GetResourceState('qb-inventory') == 'started'
    local hasQs = GetResourceState('qs-inventory') == 'started'
    local hasCheeza = GetResourceState('inventory') == 'started'
    local Table = FRKN.EvidenceStashSettings

    if hasOx then 
        local name = string.format('%s_%s', sType, id)
        TriggerServerEvent('frkn:ox_open_stash', name)

    elseif hasQb then 
        TriggerEvent('inventory:client:SetCurrentStash', stashId)
        TriggerServerEvent('inventory:server:OpenInventory', 'stash', stashId , {
            maxweight = Table.maxWeight,
            slots = Table.slots,
        })
        TriggerServerEvent('frkn-policejob:OpenStash', stashId, Table.maxWeight, Table.slots)

    elseif hasQs then 
        local qsStashId = sType .. "_" .. id
        local other = {
            maxweight = Table.maxWeight,
            slots = Table.slots
        }
        TriggerServerEvent("inventory:server:OpenInventory", "stash", qsStashId, other)
        TriggerEvent("inventory:client:SetCurrentStash", qsStashId)

    elseif hasCheeza then 
        local cheezaStashId = {
            type = "stash",
            id = sType .. "_" .. id,
            maxWeight = Table.maxWeight,
            slots = Table.slots
        }
        exports['inventory']:OpenInventory(cheezaStashId)

    else
        
    end
end

function IsTargetDead(playerId)
    if not playerId or playerId == -1 then return false end

    local ped = GetPlayerPed(GetPlayerFromServerId(playerId))
    if not DoesEntityExist(ped) then return false end

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local pdata = Core.Functions.GetPlayerData()
        if pdata and pdata.metadata and pdata.metadata["isdead"] then
            return true
        end

    elseif CoreName == "es_extended" then
        local pdata = Core.GetPlayerData()
        if pdata then
            if pdata.isDead ~= nil and pdata.isDead == true then
                return true
            end
            if pdata.dead ~= nil and pdata.dead == true then
                return true
            end
        end
    end

    if IsPedDeadOrDying(ped, true) then
        return true
    end

    return false
end

function GetPlayerData()
    if CoreName == "qbx_core" then
        return Core:GetPlayerData()
    elseif CoreName == "qb-core" then
        return Core.Functions.GetPlayerData()
    elseif CoreName == "es_extended" then
        return Core.GetPlayerData()
    end
end

function GetClosestVehicle(coords)
    local ped = PlayerPedId()
    local vehicles = GetGamePool('CVehicle')
    local closestDistance = -1
    local closestVehicle = -1
    if coords then
        coords = type(coords) == 'table' and vec3(coords.x, coords.y, coords.z) or coords
    else
        coords = GetEntityCoords(ped)
    end
    for i = 1, #vehicles, 1 do
        local vehicleCoords = GetEntityCoords(vehicles[i])
        local distance = #(vehicleCoords - coords)

        if closestDistance == -1 or closestDistance > distance then
            closestVehicle = vehicles[i]
            closestDistance = distance
        end
    end
    return closestVehicle, closestDistance
end

function GetClosestVehicleWithDistanceCheck(coords, maxDistance)
    local ped = PlayerPedId()
    local vehicles = GetGamePool('CVehicle')
    local closestDistance = -1
    local closestVehicle = -1

    if not coords then
        coords = GetEntityCoords(ped)
    end

    for i = 1, #vehicles, 1 do
        local vehicleCoords = GetEntityCoords(vehicles[i])
        local distance = #(vehicleCoords - coords)

        if distance <= maxDistance then
            if closestDistance == -1 or closestDistance > distance then
                closestVehicle = vehicles[i]
                closestDistance = distance
            end
        end
    end

    return closestVehicle, closestDistance
end

function GetPlayerGender()
    local ped = PlayerPedId()
    local model = GetEntityModel(ped)

    if model == GetHashKey("mp_m_freemode_01") then
        return "male"
    elseif model == GetHashKey("mp_f_freemode_01") then
        return "female"
    else
        return "male" 
    end
end

function GetPlayerName()
    if CoreName == "qbx_core" then
        local pd = Core:GetPlayerData()
        if pd and pd.charinfo then
            return ("%s %s"):format(pd.charinfo.firstname or "", pd.charinfo.lastname or "")
        end
    elseif CoreName == "qb-core" then
        local pd = Core.Functions.GetPlayerData()
        if pd and pd.charinfo then
            return ("%s %s"):format(pd.charinfo.firstname or "", pd.charinfo.lastname or "")
        end
    elseif CoreName == "es_extended" then
        local pd = Core.GetPlayerData()
        return pd and pd.name
    end
    return nil
end

function GetPlayerMoney()
    local playerData

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        playerData = Core.Functions.GetPlayerData()
        if playerData and playerData.money then
            return {
                cash = playerData.money["cash"] or 0,
                bank = playerData.money["bank"] or 0
            }
        end

    elseif CoreName == "es_extended" then
        local playerData = Core.GetPlayerData()
            if not playerData then
                return { cash = 0, bank = 0 }
            end
        
            local cash, bank = 0, 0
        
            if playerData.money then
                cash = tonumber(playerData.money) or 0
            elseif playerData.accounts then
                for _, acc in ipairs(playerData.accounts) do
                    if acc.name == "money" then
                        cash = tonumber(acc.money) or 0
                    end
                end
            end
        
            if playerData.accounts then
                for _, acc in ipairs(playerData.accounts) do
                    if acc.name == "bank" then
                        bank = tonumber(acc.money) or 0
                        break
                    end
                end
            end
        
            return {
                cash = cash,
                bank = bank
            }
        end
    return { cash = 0, bank = 0 }
end

function GetIdentifier(source, idtype)
    if GetConvarInt('sv_fxdkMode', 0) == 1 then return 'license:fxdk' end
    return GetPlayerIdentifierByType(source, idtype or 'license')
end

function IsDeptJob()
    local job, grade = GetPlayerJob()
    if not job or job == '' then return false end

    for _, dept in pairs(FRKN.Departments or {}) do
        if dept and (dept.job == job or (type(dept.jobs) == 'table' and dept.jobs[job])) then
            return true, dept, grade
        end
    end

    return false
end

function GetPlayerJobDuty()
    if CoreName == "qbx_core" then
        local pd = Core:GetPlayerData()
        return pd and pd.job and pd.job.onduty or false
    elseif CoreName == "qb-core" then
        local pd = Core.Functions.GetPlayerData()
        return pd and pd.job and pd.job.onduty or false
    elseif CoreName == "es_extended" then
        local pd = Core.GetPlayerData()
        return pd and pd.job and pd.job.onDuty or false
    end
    return false
end

function GetPlayerJob()
    if CoreName == "qbx_core" then
        local pd = Core:GetPlayerData()
        return pd and pd.job and pd.job.name, pd and pd.job and pd.job.grade and pd.job.grade.level
    elseif CoreName == "qb-core" then
        local pd = Core.Functions.GetPlayerData()
        return pd and pd.job and pd.job.name, pd and pd.job and pd.job.grade and pd.job.grade.level
    elseif CoreName == "es_extended" then
        local pd = Core.GetPlayerData()
        return pd and pd.job and pd.job.name, pd and pd.job and pd.job.grade
    end
    return nil, nil
end

function GetPlayerGradeName()
    if CoreName == "qbx_core" then
        local pd = Core:GetPlayerData()
        return pd and pd.job and pd.job.grade and pd.job.grade.name
    elseif CoreName == "qb-core" then
        local pd = Core.Functions.GetPlayerData()
        return pd and pd.job and pd.job.grade and pd.job.grade.name
    elseif CoreName == "es_extended" then
        local pd = Core.GetPlayerData()
        return pd and pd.job and pd.job.grade_label
    end
    return nil
end

function GetPlayerIdentifier()
    if CoreName == "qbx_core" then
        local pd = Core:GetPlayerData()
        return pd and pd.citizenid
    elseif CoreName == "qb-core" then
        local pd = Core.Functions.GetPlayerData()
        return pd and pd.citizenid
    elseif CoreName == "es_extended" then
        local pd = Core.GetPlayerData()
        return pd and pd.identifier
    end
end

local inventorySystem
local codemInv   = 'codem-inventory'
local oxInv      = 'ox_inventory'
local qsProInv   = 'qs-inventory-pro'
local origenInv  = 'origen_inventory'
local cheezaInv  = 'inventory'

if GetResourceState(codemInv) == 'started' then
    inventorySystem = 'codem'
elseif GetResourceState(oxInv) == 'started' then
    inventorySystem = 'ox'
elseif GetResourceState(qsProInv) == 'started' then
    inventorySystem = 'qs-pro'
elseif GetResourceState(origenInv) == 'started' then
    inventorySystem = 'origen'
elseif GetResourceState(cheezaInv) == 'started' then
    inventorySystem = 'cheeza'
end

HasItem = function()
    if inventorySystem == 'codem' then
        return function(items)
            local playerInventory = exports[codemInv]:getUserInventory()
            local result = {}
            if type(items) == 'table' then
                for k in pairs(items) do result[k] = 0 end
                for _, itemData in pairs(playerInventory) do
                    local name = tostring(itemData.name)
                    if items[name] then
                        result[name] = result[name] + (itemData.amount or 0)
                    end
                end
                return result
            else
                local count = 0
                for _, itemData in pairs(playerInventory) do
                    if tostring(itemData.name) == items then
                        count = count + (itemData.amount or 0)
                    end
                end
                return count
            end
        end

    elseif inventorySystem == 'ox' then
        return function(items)
            if type(items) == 'table' then
                local keys, result = {}, {}
                for k in pairs(items) do keys[#keys+1] = k; result[k] = 0 end
                local returned = exports[oxInv]:Search('count', keys)
                for k in pairs(items) do
                    result[k] = returned[k] or 0
                end
                return result
            else
                return exports[oxInv]:Search('count', items)
            end
        end

    elseif inventorySystem == 'qs-pro' then
        return function(items)
            local playerInventory = exports[qsProInv]:getUserInventory()
            if type(items) == 'table' then
                local result = {}
                for k in pairs(items) do result[k] = 0 end
                for _, itemData in pairs(playerInventory) do
                    local name = tostring(itemData.name)
                    if items[name] then
                        result[name] = result[name] + (itemData.count or itemData.amount or 0)
                    end
                end
                return result
            else
                local total = 0
                for _, itemData in pairs(playerInventory) do
                    if tostring(itemData.name) == items then
                        total = total + (itemData.count or itemData.amount or 0)
                    end
                end
                return total
            end
        end

    elseif inventorySystem == 'origen' then
        return function(items)
            local playerInventory = exports[origenInv]:GetInventory()
            local result, count = {}, 0
            if type(items) == 'table' then
                for k in pairs(items) do result[k] = 0 end
                for _, itemData in pairs(playerInventory) do
                    local name = tostring(itemData.name)
                    if items[name] then
                        result[name] = result[name] + (itemData.amount or 0)
                    end
                end
                return result
            else
                for _, itemData in pairs(playerInventory) do
                    if tostring(itemData.name) == items then
                        count = count + (itemData.amount or 0)
                    end
                end
                return count
            end
        end

    elseif CoreName == 'es_extended' then
        return function(items)
            local pd = Core.GetPlayerData() or {}
            local inv = pd.inventory or {}
            local result, count = {}, 0
            if type(items) == 'table' then
                for k in pairs(items) do result[k] = 0 end
                for _, itemData in pairs(inv) do
                    if items[itemData.name] then
                        result[itemData.name] = (itemData.count or itemData.amount)
                    end
                end
                return result
            else
                for _, itemData in pairs(inv) do
                    if itemData.name == items then
                        return itemData.count or itemData.amount
                    end
                end
                return 0
            end
        end
        elseif inventorySystem == 'cheeza' then
            return function(items)
                local inv = exports['inventory']:getInventory(source)
                if type(items) == 'table' then
                    local result = {}
                    for k in pairs(items) do result[k] = 0 end
                    for _, itemData in pairs(inv) do
                        if items[itemData.name] then
                            result[itemData.name] = result[itemData.name] + (itemData.count or itemData.amount or 0)
                        end
                    end
                    return result
                else
                    local total = 0
                    for _, itemData in pairs(inv) do
                        if itemData.name == items then
                            total = total + (itemData.count or itemData.amount or 0)
                        end
                    end
                    return total
                end
            end
    elseif CoreName == 'qb-core' or CoreName == 'qbx_core' then
        return function(items)
            local pd = Core.Functions.GetPlayerData() or {}
            local inv = pd.items or {}
            if type(items) == 'table' then
                local result = {}
                for k in pairs(items) do result[k] = 0 end
                for _, itm in ipairs(inv) do
                    if items[itm.name] then
                        result[itm.name] = itm.amount or itm.count
                    end
                end
                return result
            else
                for _, itm in ipairs(inv) do
                    if itm.name == items then
                        return itm.amount or itm.count
                    end
                end
                return 0
            end
        end

    else
        return function() return 0 end
    end
end

function GetNearbyPlayers(radius, cb)
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local nearbyPlayers = {}
    local activePlayers = GetActivePlayers()
    local totalToCheck = 0
    local completed = 0

    for _, playerId in ipairs(activePlayers) do
        local targetPed = GetPlayerPed(playerId)
        local targetCoords = GetEntityCoords(targetPed)
        local distance = #(playerCoords - targetCoords)

        if distance <= radius and playerId ~= PlayerId() then
            local serverId = GetPlayerServerId(playerId)
            totalToCheck = totalToCheck + 1

            TriggerCallback("frkn-policejob:characterDetail", function(data)
                table.insert(nearbyPlayers, {
                    id = serverId,
                    name = data and data.name or "Unknown",
                    job = data and data.job or "Unknown",
                    jobName = data and data.jobName or "Unknown",
                    identifier = data and data.identifier or "Unknown",
                })

                completed = completed + 1
                if completed == totalToCheck then
                    cb(nearbyPlayers)
                end
            end, serverId)
        end
    end

    if totalToCheck == 0 then
        cb({})
    end
end

function getVehiclePlate(vehicle)
    return GetVehicleNumberPlateText(vehicle) or "UNKNOWN"
end

function GetVehicleProperties(vehicle)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        if DoesEntityExist(vehicle) then
            local pearlescentColor, wheelColor = GetVehicleExtraColours(vehicle)

            local colorPrimary, colorSecondary = GetVehicleColours(vehicle)
            if GetIsVehiclePrimaryColourCustom(vehicle) then
                local r, g, b = GetVehicleCustomPrimaryColour(vehicle)
                colorPrimary = { r, g, b }
            end

            if GetIsVehicleSecondaryColourCustom(vehicle) then
                local r, g, b = GetVehicleCustomSecondaryColour(vehicle)
                colorSecondary = { r, g, b }
            end

            local extras = {}
            for extraId = 0, 12 do
                if DoesExtraExist(vehicle, extraId) then
                    local state = IsVehicleExtraTurnedOn(vehicle, extraId) == 1
                    extras[tostring(extraId)] = state
                end
            end

            local modLivery = GetVehicleMod(vehicle, 48)
            if GetVehicleMod(vehicle, 48) == -1 and GetVehicleLivery(vehicle) ~= 0 then
                modLivery = GetVehicleLivery(vehicle)
            end

            local tireHealth = {}
            for i = 0, 3 do
                tireHealth[i] = GetVehicleWheelHealth(vehicle, i)
            end

            local tireBurstState = {}
            for i = 0, 5 do
                tireBurstState[i] = IsVehicleTyreBurst(vehicle, i, false)
            end

            local tireBurstCompletely = {}
            for i = 0, 5 do
                tireBurstCompletely[i] = IsVehicleTyreBurst(vehicle, i, true)
            end

            local windowStatus = {}
            for i = 0, 7 do
                windowStatus[i] = IsVehicleWindowIntact(vehicle, i) == 1
            end

            local doorStatus = {}
            for i = 0, 5 do
                doorStatus[i] = IsVehicleDoorDamaged(vehicle, i) == 1
            end

            local xenonColor
            local hasCustom, r, g, b = GetVehicleXenonLightsCustomColor(vehicle)
            if hasCustom then
                xenonColor = table.pack(r, g, b)
            else
                xenonColor = GetVehicleXenonLightsColor(vehicle)
            end

            return {
                model = GetEntityModel(vehicle),
                plate = GetVehicleNumberPlateText(vehicle),
                plateIndex = GetVehicleNumberPlateTextIndex(vehicle),
                bodyHealth = Round(GetVehicleBodyHealth(vehicle), 0.1),
                engineHealth = Round(GetVehicleEngineHealth(vehicle), 0.1),
                tankHealth = Round(GetVehiclePetrolTankHealth(vehicle), 0.1),
                fuelLevel = Round(GetVehicleFuelLevel(vehicle), 0.1),
                dirtLevel = Round(GetVehicleDirtLevel(vehicle), 0.1),
                oilLevel = Round(GetVehicleOilLevel(vehicle), 0.1),
                color1 = colorPrimary,
                color2 = colorSecondary,
                pearlescentColor = pearlescentColor,
                dashboardColor = GetVehicleDashboardColour(vehicle),
                wheelColor = wheelColor,
                wheels = GetVehicleWheelType(vehicle),
                wheelSize = GetVehicleWheelSize(vehicle),
                wheelWidth = GetVehicleWheelWidth(vehicle),
                tireHealth = tireHealth,
                tireBurstState = tireBurstState,
                tireBurstCompletely = tireBurstCompletely,
                windowTint = GetVehicleWindowTint(vehicle),
                windowStatus = windowStatus,
                doorStatus = doorStatus,
                neonEnabled = {
                    IsVehicleNeonLightEnabled(vehicle, 0),
                    IsVehicleNeonLightEnabled(vehicle, 1),
                    IsVehicleNeonLightEnabled(vehicle, 2),
                    IsVehicleNeonLightEnabled(vehicle, 3)
                },
                neonColor = table.pack(GetVehicleNeonLightsColour(vehicle)),
                interiorColor = GetVehicleInteriorColour(vehicle),
                extras = extras,
                tyreSmokeColor = table.pack(GetVehicleTyreSmokeColor(vehicle)),
                xenonColor = xenonColor,
                modSpoilers = GetVehicleMod(vehicle, 0),
                modFrontBumper = GetVehicleMod(vehicle, 1),
                modRearBumper = GetVehicleMod(vehicle, 2),
                modSideSkirt = GetVehicleMod(vehicle, 3),
                modExhaust = GetVehicleMod(vehicle, 4),
                modFrame = GetVehicleMod(vehicle, 5),
                modGrille = GetVehicleMod(vehicle, 6),
                modHood = GetVehicleMod(vehicle, 7),
                modFender = GetVehicleMod(vehicle, 8),
                modRightFender = GetVehicleMod(vehicle, 9),
                modRoof = GetVehicleMod(vehicle, 10),
                modEngine = GetVehicleMod(vehicle, 11),
                modBrakes = GetVehicleMod(vehicle, 12),
                modTransmission = GetVehicleMod(vehicle, 13),
                modHorns = GetVehicleMod(vehicle, 14),
                modSuspension = GetVehicleMod(vehicle, 15),
                modArmor = GetVehicleMod(vehicle, 16),
                modKit17 = GetVehicleMod(vehicle, 17),
                modTurbo = IsToggleModOn(vehicle, 18),
                modKit19 = GetVehicleMod(vehicle, 19),
                modSmokeEnabled = IsToggleModOn(vehicle, 20),
                modKit21 = GetVehicleMod(vehicle, 21),
                modXenon = IsToggleModOn(vehicle, 22),
                modFrontWheels = GetVehicleMod(vehicle, 23),
                modBackWheels = GetVehicleMod(vehicle, 24),
                modCustomTiresF = GetVehicleModVariation(vehicle, 23),
                modCustomTiresR = GetVehicleModVariation(vehicle, 24),
                modPlateHolder = GetVehicleMod(vehicle, 25),
                modVanityPlate = GetVehicleMod(vehicle, 26),
                modTrimA = GetVehicleMod(vehicle, 27),
                modOrnaments = GetVehicleMod(vehicle, 28),
                modDashboard = GetVehicleMod(vehicle, 29),
                modDial = GetVehicleMod(vehicle, 30),
                modDoorSpeaker = GetVehicleMod(vehicle, 31),
                modSeats = GetVehicleMod(vehicle, 32),
                modSteeringWheel = GetVehicleMod(vehicle, 33),
                modShifterLeavers = GetVehicleMod(vehicle, 34),
                modAPlate = GetVehicleMod(vehicle, 35),
                modSpeakers = GetVehicleMod(vehicle, 36),
                modTrunk = GetVehicleMod(vehicle, 37),
                modHydrolic = GetVehicleMod(vehicle, 38),
                modEngineBlock = GetVehicleMod(vehicle, 39),
                modAirFilter = GetVehicleMod(vehicle, 40),
                modStruts = GetVehicleMod(vehicle, 41),
                modArchCover = GetVehicleMod(vehicle, 42),
                modAerials = GetVehicleMod(vehicle, 43),
                modTrimB = GetVehicleMod(vehicle, 44),
                modTank = GetVehicleMod(vehicle, 45),
                modWindows = GetVehicleMod(vehicle, 46),
                modKit47 = GetVehicleMod(vehicle, 47),
                modLivery = modLivery,
                modKit49 = GetVehicleMod(vehicle, 49),
                liveryRoof = GetVehicleRoofLivery(vehicle),
            }
        else
            return
        end
    elseif CoreName == "es_extended" then
        if not DoesEntityExist(vehicle) then
            return
        end
    
        local colorPrimary, colorSecondary = GetVehicleColours(vehicle)
        local pearlescentColor, wheelColor = GetVehicleExtraColours(vehicle)
        local hasCustomPrimaryColor = GetIsVehiclePrimaryColourCustom(vehicle)
        local dashboardColor = GetVehicleDashboardColor(vehicle)
        local interiorColor = GetVehicleInteriorColour(vehicle)
        local customPrimaryColor = nil
        if hasCustomPrimaryColor then
            customPrimaryColor = { GetVehicleCustomPrimaryColour(vehicle) }
        end
    
        local hasCustomXenonColor, customXenonColorR, customXenonColorG, customXenonColorB = GetVehicleXenonLightsCustomColor(vehicle)
        local customXenonColor = nil
        if hasCustomXenonColor then
            customXenonColor = { customXenonColorR, customXenonColorG, customXenonColorB }
        end
    
        local hasCustomSecondaryColor = GetIsVehicleSecondaryColourCustom(vehicle)
        local customSecondaryColor = nil
        if hasCustomSecondaryColor then
            customSecondaryColor = { GetVehicleCustomSecondaryColour(vehicle) }
        end
    
        local extras = {}
        for extraId = 0, 20 do
            if DoesExtraExist(vehicle, extraId) then
                extras[tostring(extraId)] = IsVehicleExtraTurnedOn(vehicle, extraId)
            end
        end
    
        local doorsBroken, windowsBroken, tyreBurst = {}, {}, {}
        local numWheels = tostring(GetVehicleNumberOfWheels(vehicle))
    
        local TyresIndex = { 
            ["2"] = { 0, 4 }, 
            ["3"] = { 0, 1, 4, 5 }, 
            ["4"] = { 0, 1, 4, 5 }, 
            ["6"] = { 0, 1, 2, 3, 4, 5 }, 
        }
    
        if TyresIndex[numWheels] then
            for _, idx in pairs(TyresIndex[numWheels]) do
                tyreBurst[tostring(idx)] = IsVehicleTyreBurst(vehicle, idx, false)
            end
        end
    
        for windowId = 0, 7 do 
            RollUpWindow(vehicle, windowId) 
            windowsBroken[tostring(windowId)] = not IsVehicleWindowIntact(vehicle, windowId)
        end
    
        local numDoors = GetNumberOfVehicleDoors(vehicle)
        if numDoors and numDoors > 0 then
            for doorsId = 0, numDoors do
                doorsBroken[tostring(doorsId)] = IsVehicleDoorDamaged(vehicle, doorsId)
            end
        end
    
        return {
            model = GetEntityModel(vehicle),
            doorsBroken = doorsBroken,
            windowsBroken = windowsBroken,
            tyreBurst = tyreBurst,
            tyresCanBurst = GetVehicleTyresCanBurst(vehicle),
            plate = Trim(GetVehicleNumberPlateText(vehicle)),
            plateIndex = GetVehicleNumberPlateTextIndex(vehicle),
    
            bodyHealth = Round(GetVehicleBodyHealth(vehicle), 1),
            engineHealth = Round(GetVehicleEngineHealth(vehicle), 1),
            tankHealth = Round(GetVehiclePetrolTankHealth(vehicle), 1),
    
            fuelLevel = Round(GetVehicleFuelLevel(vehicle), 1),
            dirtLevel = Round(GetVehicleDirtLevel(vehicle), 1),
            color1 = colorPrimary,
            color2 = colorSecondary,
            customPrimaryColor = customPrimaryColor,
            customSecondaryColor = customSecondaryColor,
    
            pearlescentColor = pearlescentColor,
            wheelColor = wheelColor,
    
            dashboardColor = dashboardColor,
            interiorColor = interiorColor,
    
            wheels = GetVehicleWheelType(vehicle),
            windowTint = GetVehicleWindowTint(vehicle),
            xenonColor = GetVehicleXenonLightsColor(vehicle),
            customXenonColor = customXenonColor,
    
            neonEnabled = { IsVehicleNeonLightEnabled(vehicle, 0), IsVehicleNeonLightEnabled(vehicle, 1), IsVehicleNeonLightEnabled(vehicle, 2), IsVehicleNeonLightEnabled(vehicle, 3) },
    
            neonColor = table.pack(GetVehicleNeonLightsColour(vehicle)),
            extras = extras,
            tyreSmokeColor = table.pack(GetVehicleTyreSmokeColor(vehicle)),
    
            modSpoilers = GetVehicleMod(vehicle, 0),
            modFrontBumper = GetVehicleMod(vehicle, 1),
            modRearBumper = GetVehicleMod(vehicle, 2),
            modSideSkirt = GetVehicleMod(vehicle, 3),
            modExhaust = GetVehicleMod(vehicle, 4),
            modFrame = GetVehicleMod(vehicle, 5),
            modGrille = GetVehicleMod(vehicle, 6),
            modHood = GetVehicleMod(vehicle, 7),
            modFender = GetVehicleMod(vehicle, 8),
            modRightFender = GetVehicleMod(vehicle, 9),
            modRoof = GetVehicleMod(vehicle, 10),
            modRoofLivery = GetVehicleRoofLivery(vehicle),
    
            modEngine = GetVehicleMod(vehicle, 11),
            modBrakes = GetVehicleMod(vehicle, 12),
            modTransmission = GetVehicleMod(vehicle, 13),
            modHorns = GetVehicleMod(vehicle, 14),
            modSuspension = GetVehicleMod(vehicle, 15),
            modArmor = GetVehicleMod(vehicle, 16),
    
            modTurbo = IsToggleModOn(vehicle, 18),
            modSmokeEnabled = IsToggleModOn(vehicle, 20),
            modXenon = IsToggleModOn(vehicle, 22),
    
            modFrontWheels = GetVehicleMod(vehicle, 23),
            modCustomFrontWheels = GetVehicleModVariation(vehicle, 23),
            modBackWheels = GetVehicleMod(vehicle, 24),
            modCustomBackWheels = GetVehicleModVariation(vehicle, 24),
    
            modPlateHolder = GetVehicleMod(vehicle, 25),
            modVanityPlate = GetVehicleMod(vehicle, 26),
            modTrimA = GetVehicleMod(vehicle, 27),
            modOrnaments = GetVehicleMod(vehicle, 28),
            modDashboard = GetVehicleMod(vehicle, 29),
            modDial = GetVehicleMod(vehicle, 30),
            modDoorSpeaker = GetVehicleMod(vehicle, 31),
            modSeats = GetVehicleMod(vehicle, 32),
            modSteeringWheel = GetVehicleMod(vehicle, 33),
            modShifterLeavers = GetVehicleMod(vehicle, 34),
            modAPlate = GetVehicleMod(vehicle, 35),
            modSpeakers = GetVehicleMod(vehicle, 36),
            modTrunk = GetVehicleMod(vehicle, 37),
            modHydrolic = GetVehicleMod(vehicle, 38),
            modEngineBlock = GetVehicleMod(vehicle, 39),
            modAirFilter = GetVehicleMod(vehicle, 40),
            modStruts = GetVehicleMod(vehicle, 41),
            modArchCover = GetVehicleMod(vehicle, 42),
            modAerials = GetVehicleMod(vehicle, 43),
            modTrimB = GetVehicleMod(vehicle, 44),
            modTank = GetVehicleMod(vehicle, 45),
            modWindows = GetVehicleMod(vehicle, 46),
            modLivery = GetVehicleMod(vehicle, 48) == -1 and GetVehicleLivery(vehicle) or GetVehicleMod(vehicle, 48),
            modLightbar = GetVehicleMod(vehicle, 49),
        }
    end
end

function Trim(s)
    if s == nil then return "" end
    return (tostring(s):match("^%s*(.-)%s*$"))
end

CreateThread(function()
    while not inventorySystem do Wait(100) end 
    HasItem = HasItem()
end)

