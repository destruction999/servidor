-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts


cacheData = {}
heliControl = false
garageIndex = 1
deptBlips = {}
addedStaticZones = {}
npcPeds = npcPeds or {}
markerThread = markerThread or false

local function Init()
    
end

AddEventHandler("QBCore:Client:OnPlayerLoaded", function()
    Init()
    TriggerServerEvent("frkn-policejob:dataPostClient")
    createDeptBlips()
end)

RegisterNetEvent("esx:playerLoaded")
AddEventHandler("esx:playerLoaded", function()
    Init()
    TriggerServerEvent("frkn-policejob:dataPostClient")
    createDeptBlips()
end)

RegisterNetEvent("QBCore:Client:OnPlayerUnload")
AddEventHandler("QBCore:Client:OnPlayerUnload", function()
    Init()
end)

RegisterNetEvent("frkn-policejob:setClient")
AddEventHandler("frkn-policejob:setClient", function(data)
    cacheData = data
    createDeptBlips()
end)

Citizen.CreateThread(function()
    
    while not NetworkIsPlayerActive(PlayerId()) do
        Citizen.Wait(1000)
    end
    
    while not FRKN or not FRKN.Departments do
        Citizen.Wait(500)
    end
    
    TriggerServerEvent("frkn-policejob:dataPostClient")
    Init()
    createDeptBlips()
end)

Citizen.CreateThread(function()
    Citizen.Wait(5000) 
    if FRKN and FRKN.Departments then
        createDeptBlips()
    end
end)

function clearDeptBlips()
    for i = 1, #deptBlips do
        if DoesBlipExist(deptBlips[i]) then
            RemoveBlip(deptBlips[i])
        end
    end
    deptBlips = {}
end

function createDeptBlips()
    clearDeptBlips()
    
    for _, dept in pairs((FRKN and FRKN.Departments) or {}) do
        local blipData = dept.blip
        if blipData and blipData.coords then
            local blip = AddBlipForCoord(blipData.coords.x, blipData.coords.y, blipData.coords.z)
            
            SetBlipSprite(blip, blipData.sprite or 60)
            SetBlipDisplay(blip, 4)
            SetBlipScale(blip, blipData.scale or 0.9)
            SetBlipColour(blip, blipData.color or 0)
            SetBlipAsShortRange(blip, blipData.shortRange ~= false)
            
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString(blipData.label or dept.label or "Department")
            EndTextCommandSetBlipName(blip)
            
            table.insert(deptBlips, blip)
        end
    end
end

function _uniq(prefix, data, index)
    local x = math.floor(data.coords.x * 100)
    local y = math.floor(data.coords.y * 100)
    local z = math.floor(data.coords.z * 100)
    
    if data.name and data.name ~= "" then
        return data.name
    end
    
    return string.format("%s_%d_%d_%d_%d", prefix, x, y, z, index or 1)
end

function IsPolice()
    return IsDeptJob() == true
end

function canAccess(jobList)
    if not jobList or next(jobList) == nil then
        return true
    end
    
    local job, grade = GetPlayerJob()
    local onDuty = GetPlayerJobDuty()
    
    if not onDuty then
        return false
    end
    
    if type(jobList[1]) ~= "nil" then
        for _, allowedJob in ipairs(jobList) do
            if allowedJob == job then
                return true
            end
        end
        return false
    end
    
    return jobList[job] == true
end

function canAccessForDuty(jobList)
    if not jobList or next(jobList) == nil then
        return true
    end
    
    local job = GetPlayerJob()
    
    if type(jobList[1]) ~= "nil" then
        for _, allowedJob in ipairs(jobList) do
            if allowedJob == job then
                return true
            end
        end
        return false
    end
    
    return jobList[job] == true
end

function onFoot()
    return not IsPedInAnyVehicle(PlayerPedId(), false)
end

function canAccessOnFoot(jobList)
    return onFoot() and canAccess(jobList)
end

function heliPadOccupied(heliData)
    local spawnCoords = heliData.spawnCoords or heliData.coords
    local radius = heliData.radius or heliData.distance or 15.0
    
    local handle, vehicle = FindFirstVehicle()
    local occupied = false
    local found = true
    local checkPos = vector3(spawnCoords.x, spawnCoords.y, spawnCoords.z)
    
    while found do
        if vehicle ~= 0 and DoesEntityExist(vehicle) then
            local model = GetEntityModel(vehicle)
            if IsThisModelAHeli(model) then
                local vehPos = GetEntityCoords(vehicle)
                local distance = #(vehPos - checkPos)
                if distance <= radius then
                    occupied = true
                    break
                end
            end
        end
        found, vehicle = FindNextVehicle(handle)
    end
    
    EndFindVehicle(handle)
    return occupied
end

function loadModel(model)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end
end

function nearestHeli(maxDist, fromPos)
    local ped = PlayerPedId()
    local currentVeh = 0
    
    if IsPedInAnyVehicle(ped, false) then
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and IsThisModelAHeli(GetEntityModel(veh)) then
            currentVeh = veh
        end
    end
    
    if currentVeh == 0 then
        fromPos = fromPos or GetEntityCoords(ped)
        maxDist = maxDist or 20.0
        local closestVeh = 0
        
        for _, vehicle in ipairs(GetGamePool("CVehicle")) do
            if DoesEntityExist(vehicle) and IsThisModelAHeli(GetEntityModel(vehicle)) then
                local distance = #(GetEntityCoords(vehicle) - fromPos)
                if distance < maxDist then
                    maxDist = distance
                    closestVeh = vehicle
                end
            end
        end
        
        currentVeh = closestVeh
    end
    
    return currentVeh
end

function deleteVeh(vehicle)
    if vehicle == 0 then return false end
    
    NetworkRequestControlOfEntity(vehicle)
    local timeout = GetGameTimer() + 1500
    
    while not NetworkHasControlOfEntity(vehicle) do
        if GetGameTimer() > timeout then break end
        NetworkRequestControlOfEntity(vehicle)
        Wait(50)
    end
    
    SetEntityAsMissionEntity(vehicle, true, true)
    DeleteVehicle(vehicle)
    
    if DoesEntityExist(vehicle) then
        DeleteEntity(vehicle)
    end
    
    return not DoesEntityExist(vehicle)
end

function heliController()
    if CoreName ~= "qb-core" and CoreName ~= "qbx-core" then return end
    if FRKN.Interaction.Target ~= "qb-drawtext" then return end
    
    CreateThread(function()
        local textShown = false
        
        while true do
            Wait(0)
            
            local ped = PlayerPedId()
            local inHeli = IsPedInAnyHeli(ped)
            local pedPos = inHeli and GetEntityCoords(GetVehiclePedIsIn(ped, false)) or GetEntityCoords(ped)
            
            local nearHeliPad = false
            for i = 1, #FRKN.Coords.Heli do
                local heliData = FRKN.Coords.Heli[i]
                if heliData and heliData.coords then
                    local heliPos = vector3(heliData.coords.x, heliData.coords.y, heliData.coords.z)
                    local distance = #(pedPos - heliPos)
                    if distance <= (heliData.distance or 10.0) then
                        nearHeliPad = true
                        break
                    end
                end
            end
            
            if not inHeli then
                if textShown then
                    exports["qb-core"]:HideText()
                    textShown = false
                end
            else
                if not textShown then
                    Wait(2000)
                    exports["qb-core"]:DrawText(Lang:t("general.heli_return") .. " [E]", "left")
                    Wait(1000)
                    textShown = true
                end
                
                if IsControlJustReleased(0, 38) then
                    local vehicle = GetVehiclePedIsIn(ped, false)
                    if vehicle ~= 0 and DoesEntityExist(vehicle) then
                        TaskLeaveVehicle(ped, vehicle, 16)
                        Wait(500)
                        DeleteVehicle(vehicle)
                    end
                    exports["qb-core"]:HideText()
                    return
                end
            end
        end
    end)
end

function spawnNPC(zoneData)
    if not zoneData.npc or not zoneData.npc.enabled then return end
    if zoneData.ped and DoesEntityExist(zoneData.ped) then return end
    
    loadModel(zoneData.npc.model)
    
    local spawnPos = vector3(
        zoneData.coords.x,
        zoneData.coords.y,
        zoneData.coords.z + (zoneData.npc.z or 0.0)
    )
    
    local ped = CreatePed(4, zoneData.npc.model, spawnPos.x, spawnPos.y, spawnPos.z, 
        zoneData.npc.heading or 0.0, false, true)
    
    zoneData.ped = ped
    
    SetEntityHeading(ped, zoneData.npc.heading or 0.0)
    SetEntityInvincible(ped, true)
    FreezeEntityPosition(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
end

function deleteNPC(zoneData)
    if zoneData.ped and DoesEntityExist(zoneData.ped) then
        DeleteEntity(zoneData.ped)
        zoneData.ped = nil
    end
end

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    
    for _, ped in ipairs(npcPeds or {}) do
        if DoesEntityExist(ped) then
            DeleteEntity(ped)
        end
    end
    npcPeds = {}
end)

function clearStaticZones()
    for _, zoneName in pairs(addedStaticZones) do
        if FRKN.Interaction.Target == "qb-target" then
            exports["qb-target"]:RemoveZone(zoneName)
        elseif FRKN.Interaction.Target == "ox_target" then
            exports.ox_target:removeZone(zoneName)
        end
    end
    addedStaticZones = {}
end

clearStaticZones()

function openMenu(menuType, menuIndex)
    SetNuiFocus(true, true)
    
    if menuType == "report-menu" then
        SendNUIMessage({
            action = "openMenu",
            menu = menuType,
            name = GetPlayerName(),
            index = menuIndex
        })
        
    elseif menuType == "shop" then
        local job, grade = GetPlayerJob()
        SendNUIMessage({
            action = "shopOpen",
            menu = menuType,
            items = FRKN.Items,
            categories = FRKN.Categories,
            currency = FRKN.Currency,
            path = FRKN.InventoryImagePath,
            job = job,
            grade = grade,
            index = menuIndex
        })
        
    elseif menuType == "clothing-menu" then
        local gender = GetPlayerGender()
        local clothingData = FRKN.Cloths[gender]
        
        charCam(true)
        SendNUIMessage({
            action = "openMenu",
            menu = menuType,
            clothingData = cacheData.clothing,
            cloths = clothingData,
            index = menuIndex
        })
        
    elseif menuType == "vehicle-menu" then
        local job, grade = GetPlayerJob()
        local garageVehicles = (FRKN.Garage or {})[menuIndex] or {}
        local filteredVehicles = {}
        
        garageIndex = menuIndex
        
        for model, vehData in pairs(garageVehicles) do
            local hasAccess = false
            if vehData.ranks and type(vehData.ranks) == "table" then
                for _, rank in ipairs(vehData.ranks) do
                    if tonumber(rank) == tonumber(grade) then
                        hasAccess = true
                        break
                    end
                end
            end
            if hasAccess then
                filteredVehicles[model] = vehData
            end
        end
        
        SendNUIMessage({
            action = "openMenu",
            menu = menuType,
            vehicles = filteredVehicles,
            job = job,
            grade = grade,
            index = menuIndex,
            garage = menuIndex
        })
        
    elseif menuType == "extra-menu" then
        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(ped, false)
        local extras = {}
        local liveries = {}
        local colors = {}
        local pushbarId = nil
        local lightbarId = nil
        local pushbarState = false
        local lightbarState = false
        local sirenActive = false
        local vehicleName = "VEHICLE"
        
        if vehicle and vehicle ~= 0 then
            
            for i = 0, 20 do
                if DoesExtraExist(vehicle, i) then
                    local isOn = IsVehicleExtraTurnedOn(vehicle, i) == 1
                    table.insert(extras, {
                        id = i,
                        label = string.format("Extra %d", i),
                        state = isOn
                    })
                end
            end
            
            pushbarId = modelExtra(vehicle, "pushbar")
            lightbarId = modelExtra(vehicle, "lightbar")
            
            if pushbarId then
                pushbarState = IsVehicleExtraTurnedOn(vehicle, pushbarId) == 1
            end
            if lightbarId then
                lightbarState = IsVehicleExtraTurnedOn(vehicle, lightbarId) == 1
            end
            
            sirenActive = IsVehicleSirenOn(vehicle)
            
            local model = GetEntityModel(vehicle)
            if model ~= 0 then
                vehicleName = GetLabelText(GetDisplayNameFromVehicleModel(model))
                if not vehicleName or vehicleName == "NULL" then
                    vehicleName = tostring(model)
                end
            end
            
            local liveryCount = GetVehicleLiveryCount(vehicle)
            local currentLivery = GetVehicleLivery(vehicle) or 0
            
            for i = 0, liveryCount - 1 do
                table.insert(liveries, {
                    index = i,
                    label = string.format("Livery %d", i),
                    current = i == currentLivery
                })
            end
        end
        
        for _, colorData in ipairs(FRKN.VehicleColors or {}) do
            table.insert(colors, {
                type = "color",
                key = colorData.key,
                label = colorData.label,
                primary = colorData.primary,
                secondary = colorData.secondary
            })
        end
        
        local job, grade = GetPlayerJob()
        local categories = {}
        
        if FRKN.ExtraMenu.quick then
            table.insert(categories, {
                key = "quick",
                label = Lang:t("general.vehCategory_quick"),
                grade = grade,
                items = {
                    {type = "named_extra", name = "pushbar", id = pushbarId, label = "Pushbar", exists = pushbarId ~= nil, state = pushbarState},
                    {type = "named_extra", name = "lightbar", id = lightbarId, label = "Lightbar", exists = lightbarId ~= nil, state = lightbarState},
                    {type = "siren", label = "Siren", active = sirenActive, options = {"toggle", "on", "off", "mute"}}
                }
            })
        end
        
        if FRKN.ExtraMenu.extras then
            table.insert(categories, {
                key = "extras",
                label = Lang:t("general.vehCategory_extras"),
                grade = grade,
                items = extras
            })
        end
        
        if FRKN.ExtraMenu.liveries then
            table.insert(categories, {
                key = "liveries",
                label = Lang:t("general.vehCategory_liveries"),
                grade = grade,
                items = liveries
            })
        end
        
        if FRKN.ExtraMenu.engine then
            table.insert(categories, {
                key = "engine",
                label = Lang:t("general.vehCategory_tuning"),
                grade = grade,
                items = {
                    {label = "x0.5", value = 0.5},
                    {label = "x1.0", value = 1.0},
                    {label = "x1.5", value = 1.5},
                    {label = "x2.0", value = 2.0},
                    {label = "x3.0", value = 3.0}
                }
            })
        end
        
        if FRKN.ExtraMenu.colors then
            table.insert(categories, {
                key = "colors",
                label = Lang:t("general.vehCategory_colors"),
                grade = grade,
                items = colors
            })
        end
        
        openExtraCamFront(vehicle)
        
        local features = (vehicle and vehicle ~= 0) and buildFeatures(vehicle) or {
            img = nil,
            name = "VEHICLE",
            desc = "You can customize your special police car through this page.",
            fuel = 0,
            speed = 0,
            damage = 0
        }
        
        SendNUIMessage({
            action = "openMenu",
            menu = menuType,
            job = job,
            grade = grade,
            extras = categories,
            features = features,
            index = menuIndex
        })
        
    elseif menuType == "boss-menu" then
        local job, grade = GetPlayerJob()
        local policeList = getPolices()
        local deptIndex = 1
        local deptData = FRKN.Departments[deptIndex]
        local identifier = GetPlayerIdentifier()
        local money = GetPlayerMoney()
        
        SendNUIMessage({
            action = "openMenu",
            menu = menuType,
            job = job,
            grade = grade,
            gradeName = GetPlayerGradeName(),
            polices = policeList,
            data = cacheData.bossMenu or {},
            reports = cacheData.report or {},
            perms = cacheData.job_perms or {},
            grades = cacheData.job_grades or {},
            name = GetPlayerName(),
            vault = cacheData.job_vaults or {},
            logs = cacheData.job_logs or {},
            index = menuIndex,
            gradeList = (deptData and deptData.grades) or {},
            cid = identifier,
            money = money
        })
        
    elseif menuType == "duty-menu" then
        OpenDutyMenu(1)
        
    elseif menuType == "heli-menu" then
        local job, grade = GetPlayerJob()
        local heliList = (FRKN.Heli or {})[menuIndex] or {}
        local filteredHelis = {}
        
        for model, heliData in pairs(heliList) do
            local hasAccess = false
            if heliData.ranks and type(heliData.ranks) == "table" then
                for _, rank in ipairs(heliData.ranks) do
                    if tonumber(rank) == tonumber(grade) then
                        hasAccess = true
                        break
                    end
                end
            end
            if hasAccess then
                filteredHelis[model] = heliData
            end
        end
        
        garageIndex = menuIndex
        SendNUIMessage({
            action = "openMenu",
            menu = menuType,
            vehicles = filteredHelis,
            helis = filteredHelis,
            job = job,
            grade = grade,
            index = menuIndex,
            garage = menuIndex,
            type = "heli"
        })
        
    elseif menuType == "evidence-menu" then
        TriggerCallback("frkn-policejob:GetEvidenceMetas", function(bagEvidence, tubeEvidence)
            local function normType(evidenceType)
                if evidenceType == "gsr_impact" or evidenceType == "gsr_shooter" then
                    return "gunpowder"
                end
                return evidenceType or ""
            end
            
            local allEvidence = {}
            
            local function pushFrom(evidenceList, containerType)
                if evidenceList and #evidenceList > 0 then
                    for i = 1, #evidenceList do
                        local ev = evidenceList[i] or {}
                        table.insert(allEvidence, {
                            evidence_id = tostring(ev.evidence_id or ""),
                            type = normType(ev.type or (containerType == "tube" and "blood" or "gunpowder")),
                            container = containerType,
                            street = tostring(ev.street or ""),
                            created = tonumber(ev.created or 0) or 0,
                            citizenid = tostring(ev.citizenid or ""),
                            victim = tostring(ev.victim or ""),
                            shooter = tostring(ev.shooter or ""),
                            shot = tostring(ev.shot or "")
                        })
                    end
                end
            end
            
            pushFrom(tubeEvidence, "tube")
            pushFrom(bagEvidence, "bag")
            
            local job, grade = GetPlayerJob()
            SendNUIMessage({
                action = "openMenu",
                menu = menuType,
                job = job,
                grade = grade,
                index = menuIndex,
                evidences = allEvidence,
                saveEvidence = cacheData.evidence_scans,
                active_index = #allEvidence > 0 and 1 or 0
            })
        end)
        
    elseif menuType == "evidencestash-menu" then
        local job, grade = GetPlayerJob()
        SendNUIMessage({
            action = "openMenu",
            menu = menuType,
            job = job,
            grade = grade,
            index = menuIndex,
            list = FRKN.EvidenceStashList
        })
    end
end

RegisterNUICallback("close", function(data, cb)
    SetNuiFocus(false, false)
    closeExtraCam()
    charCam(false)
    
    if data.currentMenu then
        remoteOpen = false
    end
    
    CloseFingerUI()
end)

function InVehicle()
    return IsPedInAnyVehicle(PlayerPedId(), false)
end

RegisterNetEvent("frkn-policejob:notify")
AddEventHandler("frkn-policejob:notify", function(type, message)
    Notify(message, type)
end)

function newReqId()
    return string.format("%d:%d", GetPlayerServerId(PlayerId()), math.random(100000, 999999))
end

