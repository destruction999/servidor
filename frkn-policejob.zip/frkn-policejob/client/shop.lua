


local function ProcessPayment(paymentType, data, cb)
    TriggerCallback("frkn-policejob:processPayment", function(response)
        Notify(response.message)
        cb(response)
    end, paymentType, data.items, data.total)
end

RegisterNUICallback("payWithCard", function(data, cb)
    ProcessPayment("card", data, cb)
end)

RegisterNUICallback("payWithCash", function(data, cb)
    ProcessPayment("cash", data, cb)
end)

