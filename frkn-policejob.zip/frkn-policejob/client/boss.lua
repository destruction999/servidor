


function getPolices()
    local p = promise.new()
    
    TriggerCallback("frkn-boss:getPolice", function(result)
        p:resolve(result or {online = {}, offline = {}})
    end)
    
    return Citizen.Await(p)
end

function IsDeptJobName(jobName)
    if not jobName or jobName == "" then
        return false
    end
    
    for _, dept in pairs(FRKN.Departments or {}) do
        if dept then
            if dept.job == jobName or (type(dept.jobs) == "table" and dept.jobs[jobName]) then
                return true
            end
        end
    end
    
    return false
end

RegisterNUICallback("getPolices", function(data, cb)
    cb(getPolices())
end)

RegisterNUICallback("updateGradePerm", function(data, cb)
    TriggerServerEvent("frkn-policejob:updateGradePerm", data)
    cb({ok = true})
end)

RegisterNUICallback("updatePlayerGrade", function(data, cb)
    TriggerCallback("frkn-policejob:updatePlayerGrade", function(response)
        cb(response)
    end, data)
end)

RegisterNUICallback("hirePlayer", function(data, cb)
    TriggerCallback("frkn-policejob:hirePlayer", function(response)
        cb(response)
    end, data)
end)

RegisterNUICallback("firePlayer", function(data, cb)
    TriggerCallback("frkn-policejob:firePlayer", function(response)
        cb(response)
    end, data)
end)

RegisterNUICallback("vaultTransfer", function(data, cb)
    TriggerCallback("frkn-policejob:vaultTransfer", function(response)
        cb(response)
    end, data)
    
    Wait(1000)
    
    money = GetPlayerMoney()
    
    SendNUIMessage({
        action = "updateLogs",
        logs = cacheData.job_logs or {},
        index = index,
        money = money
    })
end)

RegisterNUICallback("getNearbyPlayers", function(data, cb)
    GetNearbyPlayers(5.0, function(players)
        local filtered = {}
        
        for _, player in ipairs(players or {}) do
            if not IsDeptJobName(player.jobName) then
                table.insert(filtered, player)
            end
        end
        
        cb({ok = true, players = filtered})
    end)
end)

function getPolices()
    local p = promise.new()
    TriggerCallback("frkn-boss:getPolice", function(result)
        p:resolve(result or {online = {}, offline = {}})
    end)
    return Citizen.Await(p)
end

function IsDeptJobName(jobName)
    if not jobName or jobName == "" then return false end
    
    for _, dept in pairs(FRKN.Departments or {}) do
        if dept and (dept.job == jobName or (type(dept.jobs) == "table" and dept.jobs[jobName])) then
            return true
        end
    end
    
    return false
end

local function SimpleCallback(eventName)
    return function(data, cb)
        TriggerCallback(eventName, cb, data)
    end
end

RegisterNUICallback("getPolices", function(data, cb)
    cb(getPolices())
end)

RegisterNUICallback("updateGradePerm", function(data, cb)
    TriggerServerEvent("frkn-policejob:updateGradePerm", data)
    cb({ok = true})
end)

RegisterNUICallback("updatePlayerGrade", SimpleCallback("frkn-policejob:updatePlayerGrade"))
RegisterNUICallback("hirePlayer", SimpleCallback("frkn-policejob:hirePlayer"))
RegisterNUICallback("firePlayer", SimpleCallback("frkn-policejob:firePlayer"))

RegisterNUICallback("vaultTransfer", function(data, cb)
    TriggerCallback("frkn-policejob:vaultTransfer", cb, data)
    
    Wait(1000)
    SendNUIMessage({
        action = "updateLogs",
        logs = cacheData.job_logs or {},
        index = index,
        money = GetPlayerMoney()
    })
end)

RegisterNUICallback("getNearbyPlayers", function(data, cb)
    GetNearbyPlayers(5.0, function(players)
        local filtered = {}
        for _, player in ipairs(players or {}) do
            if not IsDeptJobName(player.jobName) then
                table.insert(filtered, player)
            end
        end
        cb({ok = true, players = filtered})
    end)
end)

