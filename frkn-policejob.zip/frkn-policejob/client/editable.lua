

function init()
    print("[FRKN Police] init() called")
    
    if not FRKN or not FRKN.Coords then 
        print("[FRKN Police] ERROR: FRKN.Coords not found!")
        return 
    end
    
    print("[FRKN Police] FRKN.Coords found, processing...")

    for _, ped in ipairs(npcPeds or {}) do
        if DoesEntityExist(ped) then DeleteEntity(ped) end
    end
    npcPeds = {}

    local markers = {}
    
    for sectionName, section in pairs(FRKN.Coords) do
        print("[FRKN Police] Processing section: " .. tostring(sectionName))
        for _, v in ipairs(section or {}) do
            local hasEnabled = (v.marker and v.marker.enabled) or (v.npc and v.npc.enabled)
        
            if not hasEnabled then
                goto continue
            end
            
            print("[FRKN Police] Found enabled marker/npc: " .. tostring(v.name))
        
            if v.marker and v.marker.enabled and v.coords then
                local cx, cy, cz = v.coords.x or v.coords[1], v.coords.y or v.coords[2], v.coords.z or v.coords[3]
                if cx and cy and cz then
                    markers[#markers+1] = {
                        pos = vector3(cx, cy, cz),
                        type = v.marker.type or 1,
                        scale = v.marker.scale or 0.6,
                        z = v.marker.z or 0.0,
                        color = v.marker.color or { r=255, g=255, b=255, a=180 },
                        dist = v.distance or 20.0
                    }
                    print("[FRKN Police] Marker added at: " .. cx .. ", " .. cy .. ", " .. cz)
                end
            end
        
            if v.npc and v.npc.enabled then
                spawnNPC(v)
                if v.ped and DoesEntityExist(v.ped) then
                    npcPeds[#npcPeds+1] = v.ped
                end
            end
        
            ::continue::
        end
    end
    
    print("[FRKN Police] Total markers to display: " .. #markers)
    
    if not markerThread and #markers > 0 then
        markerThread = true
        print("[FRKN Police] Starting marker thread...")
        CreateThread(function()
            while true do
                local pp = GetEntityCoords(PlayerPedId())
                local sleep = 1000
            
                for i = 1, #markers do
                    local m = markers[i]
                    local dist = #(pp - m.pos)
                
                    if dist <= m.dist then
                        sleep = 0
                        DrawMarker(
                            m.type,
                            m.pos.x, m.pos.y, m.pos.z + m.z,
                            0.0, 0.0, 0.0,
                            0.0, 0.0, 0.0,
                            m.scale, m.scale, m.scale,
                            m.color.r, m.color.g, m.color.b, m.color.a,
                            false, false, 2, false, nil, nil, false
                        )
                    end
                end
            
                Wait(sleep)
            end
        end)
    end

    if FRKN.Interaction.Target == 'qb-target' then
        for i, v in ipairs(FRKN.Coords.Report or {}) do
            local idx = i
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.report_interact'),
                    canInteract = function() return canAccess(v.jobs) end,
                    action = function()
                        local rem = remainingMinutes(idx)
                        if rem > 0 then
                            Notify(Lang:t('error.report_cooldown', { minutes = rem }), "error")
                            return
                        end
                        CurrentReportZone = idx
                        openMenu('report-menu', idx)
                    end
                }},
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.BossMenu or {}) do
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.boss_interact'),
                    canInteract = function()
                        if not canAccess(v.jobs) then return false end
                        local _, grade = GetPlayerJob()
                        grade = tonumber(grade) or 0
                        for _, g in ipairs(FRKN.BossOpenGrade or {}) do
                            if grade >= tonumber(g) then return true end
                        end
                        return false
                    end,
                    action = function() openMenu('boss-menu', i) end
                }},
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.Clothes or {}) do
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.clothes_interact'),
                    canInteract = function() return canAccess(v.jobs) end,
                    action = function() openMenu('clothing-menu', i) end
                }},
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.Garage or {}) do
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.garage_interact'),
                    canInteract = function() return canAccessOnFoot(v.jobs) end,
                    action = function() openMenu('vehicle-menu', i) end
                }},
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.ExtrasMenu or {}) do
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.extrasmenu_interact'),
                    canInteract = function() return canAccess(v.jobs) and CanOpenExtrasMenu() end,
                    action = function() if CanOpenExtrasMenu() then openMenu('extra-menu', i) end end
                }},
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.DutySystem or {}) do
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.duty_interact'),
                    canInteract = function() return canAccessForDuty(v.jobs) end,
                    action = function() openMenu('duty-menu', i) end
                }},
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.Heli or {}) do
            local center = vector3(v.coords.x, v.coords.y, v.coords.z)
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, center, v.distance or 2.5, {
                name = v.name, debugPoly = false, useZ = true
            }, {
                options = {
                    {
                        icon = v.icon,
                        label = Lang:t('general.heli_interact'),
                        canInteract = function() return canAccessOnFoot(v.jobs) end,
                        action = function() openMenu('heli-menu', i) end
                    },
                    {
                        icon = v.icon, 
                        label = Lang:t('general.heli_return'),
                        canInteract = function() return canAccessOnFoot(v.jobs) end,
                        action = function()
                            local veh = nearestHeli(25.0, center)
                            if veh ~= 0 then
                                local ped = PlayerPedId()
                                if GetVehiclePedIsIn(ped, false) == veh then
                                    TaskLeaveVehicle(ped, veh, 16)
                                    Wait(600)
                                end
                                deleteVeh(veh)
                            end
                        end
                    }
                },
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.Armory or {}) do
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.armory_interact'),
                    canInteract = function() return canAccess(v.jobs) end,
                    action = function() openMenu('shop', i) end
                }},
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.Evidence or {}) do
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.evidence_interact'),
                    canInteract = function() return canAccess(v.jobs) end,
                    action = function() openMenu('evidence-menu', i) end
                }},
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.EvidenceStash or {}) do
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.evidencestash_interact'),
                    canInteract = function() return canAccess(v.jobs) end,
                    action = function() openMenu('evidencestash-menu', i) end
                }},
                distance = v.distance or 1.5
            })
        end

        for i, v in ipairs(FRKN.Coords.PersonStash or {}) do
            exports[FRKN.Interaction.Target]:AddCircleZone(v.name, vector3(v.coords.x, v.coords.y, v.coords.z), v.distance or 2.0, { name = v.name, debugPoly = false, useZ = true }, {
                options = {{
                    icon = v.icon,
                    label = Lang:t('general.personstash_interact'),
                    canInteract = function() return canAccess(v.jobs) end,
                    action = function() personStash() end
                }},
                distance = v.distance or 1.5
            })
        end

    elseif FRKN.Interaction.Target == 'ox_target' then

        clearStaticZones()
        for i, v in ipairs(FRKN.Coords.Report or {}) do
        local idx = i
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.report_interact'),
                canInteract = function() return canAccess(v.jobs) end,
                onSelect = function()
                    local rem = remainingMinutes(idx)
                    if rem > 0 then
                        Notify(Lang:t('error.report_cooldown', { minutes = rem }), "error")
                        return
                    end
                    CurrentReportZone = idx
                    openMenu('report-menu', idx)
                end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.Armory or {}) do
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.armory_interact'),
                canInteract = function() return canAccess(v.jobs) end,
                onSelect = function() openMenu('shop', i) end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.Clothes or {}) do
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.clothes_interact'),
                canInteract = function() return canAccess(v.jobs) end,
                onSelect = function() openMenu('clothing-menu', i) end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.Garage or {}) do
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.garage_interact'),
                canInteract = function() return canAccessOnFoot(v.jobs) end,
                onSelect = function() openMenu('vehicle-menu', i) end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.ExtrasMenu or {}) do
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.extrasmenu_interact'),
                canInteract = function() return canAccess(v.jobs) and CanOpenExtrasMenu() end,
                onSelect = function() if CanOpenExtrasMenu() then openMenu('extra-menu', i) end end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.BossMenu or {}) do
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.boss_interact'),
                canInteract = function()
                    if not canAccess(v.jobs) then return false end
                    local _, grade = GetPlayerJob()
                    grade = tonumber(grade) or 0
                    for _, g in ipairs(FRKN.BossOpenGrade or {}) do
                        if grade >= tonumber(g) then return true end
                    end
                    return false
                end,
                onSelect = function() openMenu('boss-menu', i) end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.DutySystem or {}) do
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.duty_interact'),
                canInteract = function() return canAccessForDuty(v.jobs) end,
                onSelect = function() openMenu('duty-menu', i) end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.Evidence or {}) do
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.evidence_interact'),
                canInteract = function() return canAccess(v.jobs) end,
                onSelect = function() openMenu('evidence-menu', i) end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.EvidenceStash or {}) do
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.evidencestash_interact'),
                canInteract = function() return canAccess(v.jobs) end,
                onSelect = function() openMenu('evidencestash-menu', i) end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.PersonStash or {}) do
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = vector3(v.coords.x, v.coords.y, v.coords.z),
            radius = v.distance or 2,
            options = {{
                distance = v.distance or 1.5,
                icon = v.icon,
                label = Lang:t('general.personstash_interact'),
                canInteract = function() return canAccess(v.jobs) end,
                onSelect = function() PersonStash() end
            }},
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    for i, v in ipairs(FRKN.Coords.Heli or {}) do
        local center = vector3(v.coords.x, v.coords.y, v.coords.z)
        local zoneId = exports[FRKN.Interaction.Target]:addSphereZone({
            coords = center,
            radius = v.distance or 2.0,
            options = {
                {
                    distance = v.distance or 1.8,
                    icon = v.icon,
                    label = Lang:t('general.heli_interact'),
                    canInteract = function() return canAccessOnFoot(v.jobs) end,
                    onSelect = function() openMenu('heli-menu', i) end
                },
                {
                    distance = v.distance or 1.8,
                    icon = v.icon, 
                    label = Lang:t('general.heli_return'),
                    canInteract = function() return canAccessOnFoot(v.jobs) end,
                    onSelect = function()
                        local veh = nearestHeli(25.0, center)
                        if veh ~= 0 then
                            local ped = PlayerPedId()
                            if GetVehiclePedIsIn(ped, false) == veh then
                                TaskLeaveVehicle(ped, veh, 16)
                                Wait(600)
                            end
                            deleteVeh(veh)
                        end
                    end
                }
            },
        })
        if zoneId then addedStaticZones[#addedStaticZones+1] = zoneId end
    end

    elseif FRKN.Interaction.Target == 'qb-drawtext' then

        local points, zones, byName = {}, {}, {}

        function addPoint(kind, idx, v, labelKey, onOpen, canFn)
            local name = ('frkn_%s_%s'):format(kind, idx)
            points[#points+1] = { name = name, pos = vector3(v.coords.x, v.coords.y, v.coords.z), labelKey = labelKey, open = onOpen, can = canFn or function() return canAccess(v.jobs) end, dist = v.distance or 2.0 }
            byName[name] = points[#points]
            zones[#zones+1] = BoxZone:Create(points[#points].pos, v.distance or 2.0, v.distance or 2.0, { name = name, debugPoly = false, minZ = v.coords.z - 1.0, maxZ = v.coords.z + 1.0 })
        end

        for i, v in ipairs(FRKN.Coords.Report or {}) do
            local idx = i
            addPoint('report', idx, v, 'general.report_interact', function()
                local rem = remainingMinutes(idx)
                if rem > 0 then
                    Notify(Lang:t('error.report_cooldown', { minutes = rem }), "error")
                    return
                end
                CurrentReportZone = idx
                openMenu('report-menu', idx)
            end)
        end

        for i, v in ipairs(FRKN.Coords.BossMenu or {}) do
            addPoint('boss', i, v, 'general.boss_interact', function() openMenu('boss-menu', i) end, function()
                if not canAccess(v.jobs) then return false end
                local _, grade = GetPlayerJob()
                grade = tonumber(grade) or 0
                for _, g in ipairs(FRKN.BossOpenGrade or {}) do
                    if grade >= tonumber(g) then return true end
                end
                return false
            end)
        end

        for i, v in ipairs(FRKN.Coords.Clothes or {}) do
            addPoint('clothes', i, v, 'general.clothes_interact', function() openMenu('clothing-menu', i) end)
        end

        for i, v in ipairs(FRKN.Coords.Armory or {}) do
            addPoint('armory', i, v, 'general.armory_interact', function() openMenu('shop', i) end)
        end

        for i, v in ipairs(FRKN.Coords.Garage or {}) do
            addPoint('garage', i, v, 'general.garage_interact', function() openMenu('vehicle-menu', i) end, function()
                return canAccessOnFoot(v.jobs)
            end)
        end

        for i, v in ipairs(FRKN.Coords.ExtrasMenu or {}) do
            addPoint('extras', i, v, 'general.extrasmenu_interact', function() if CanOpenExtrasMenu() then openMenu('extra-menu', i) end end, function()
                return canAccess(v.jobs) and CanOpenExtrasMenu()
            end)
        end

        for i, v in ipairs(FRKN.Coords.DutySystem or {}) do
            addPoint('duty', i, v, 'general.duty_interact', function() openMenu('duty-menu', i) end)
        end

        for i, v in ipairs(FRKN.Coords.Evidence or {}) do
            addPoint('evidence', i, v, 'general.evidence_interact', function() openMenu('evidence-menu', i) end)
        end

        for i, v in ipairs(FRKN.Coords.EvidenceStash or {}) do
            addPoint('evidencestash', i, v, 'general.evidencestash_interact', function() openMenu('evidencestash-menu', i) end)
        end

        for i, v in ipairs(FRKN.Coords.PersonStash or {}) do
            addPoint('personstash', i, v, 'general.personstash_interact', function() personStash() end)
        end

        for i, v in ipairs(FRKN.Coords.Heli or {}) do
            addPoint('heli', i, v, 'general.heli_interact', function()
                if heliPadOccupied(v) then
                    Notify(Lang:t('error.heli_pad_occupied'), 'error')
                    return
                end
                openMenu('heli-menu', i)
            end, function()
                return canAccessOnFoot(v.jobs)
            end)
        end

        local combo = ComboZone:Create(zones, { name = 'frkn_combo', debugPoly = false })
        local active, shown = nil, false

        combo:onPlayerInOut(function(inside, _, zone)
            if inside then
                local pt = byName[zone.name]
                if pt and pt.can() then
                    active = pt
                    exports['qb-core']:DrawText(Lang:t(pt.labelKey) .. ' [E]', 'left')
                    shown = true
                else
                    if shown then 
                        exports['qb-core']:HideText() 
                    end
                    shown = false
                    active = nil
                end
            else
                if shown then
                     exports['qb-core']:HideText() 
                end
                shown = false
                if active and active.name == zone.name then active = nil end
            end
        end)

        CreateThread(function()
            while true do
                Wait(0)
                if active and IsControlJustPressed(0, 38) then
                    active.open()
                    Wait(250)
                end
            end
        end)
      elseif FRKN.Interaction.Target == 'ox_lib' then
        local points, zones, byName = {}, {}, {}

        function addPoint(kind, idx, v, labelKey, onOpen, canFn)
            local name = ('frkn_%s_%s'):format(kind, idx)
            local checkFn = canFn
            if not checkFn then
                if kind == 'duty' then
                    checkFn = function() return canAccessForDuty(v.jobs) end
                else
                    checkFn = function() return canAccess(v.jobs) end
                end
            end
            points[#points+1] = {
                name = name,
                kind = kind,
                pos = vector3(v.coords.x, v.coords.y, v.coords.z),
                labelKey = labelKey,
                open = onOpen,
                can = checkFn,
                dist = v.distance or 2.0
            }
            byName[name] = points[#points]
            zones[#zones+1] = BoxZone:Create(points[#points].pos, v.distance or 2.0, v.distance or 2.0, {
                name = name, debugPoly = false, minZ = v.coords.z - 1.0, maxZ = v.coords.z + 1.0
            })
        end

        for i, v in ipairs(FRKN.Coords.Report or {}) do
            local idx = i
            addPoint('report', idx, v, 'general.report_interact', function()
                local rem = remainingMinutes(idx)
                if rem > 0 then
                    Notify(Lang:t('error.report_cooldown', { minutes = rem }), "error")
                    return
                end
                CurrentReportZone = idx
                openMenu('report-menu', idx)
            end)
        end

        for i, v in ipairs(FRKN.Coords.BossMenu or {}) do
            addPoint('boss', i, v, 'general.boss_interact', function() openMenu('boss-menu', i) end, function()
                if not canAccess(v.jobs) then return false end
                local _, grade = GetPlayerJob()
                grade = tonumber(grade) or 0
                for _, g in ipairs(FRKN.BossOpenGrade or {}) do
                    if grade >= tonumber(g) then return true end
                end
                return false
            end)
        end

        for i, v in ipairs(FRKN.Coords.Clothes or {}) do
            addPoint('clothes', i, v, 'general.clothes_interact', function() openMenu('clothing-menu', i) end)
        end

        for i, v in ipairs(FRKN.Coords.Armory or {}) do
            addPoint('armory', i, v, 'general.armory_interact', function() openMenu('shop', i) end)
        end

        for i, v in ipairs(FRKN.Coords.Garage or {}) do
            addPoint('garage', i, v, 'general.garage_interact', function() openMenu('vehicle-menu', i) end, function()
                return canAccessOnFoot(v.jobs)
            end)
        end

        for i, v in ipairs(FRKN.Coords.ExtrasMenu or {}) do
            addPoint('extras', i, v, 'general.extrasmenu_interact', function() if CanOpenExtrasMenu() then openMenu('extra-menu', i) end end, function()
                return canAccess(v.jobs) and CanOpenExtrasMenu()
            end)
        end

        for i, v in ipairs(FRKN.Coords.DutySystem or {}) do
            addPoint('duty', i, v, 'general.duty_interact', function() openMenu('duty-menu', i) end)
        end

        for i, v in ipairs(FRKN.Coords.Evidence or {}) do
            addPoint('evidence', i, v, 'general.evidence_interact', function() openMenu('evidence-menu', i) end)
        end

        for i, v in ipairs(FRKN.Coords.EvidenceStash or {}) do
            addPoint('evidencestash', i, v, 'general.evidencestash_interact', function() openMenu('evidencestash-menu', i) end)
        end

        for i, v in ipairs(FRKN.Coords.PersonStash or {}) do
            addPoint('personstash', i, v, 'general.personstash_interact', function() personStash() end)
        end

        for i, v in ipairs(FRKN.Coords.Heli or {}) do
            addPoint('heli', i, v, 'general.heli_interact', function() openMenu('heli-menu', i) end, function()
                return canAccessOnFoot(v.jobs)
            end)
        end

        function nearestHeli(radius, center)
            local handle, veh = FindFirstVehicle()
            local found, best, bestDist = false, nil, radius + 0.1
            local cx, cy, cz = center.x, center.y, center.z
            repeat
                if DoesEntityExist(veh) then
                    local model = GetEntityModel(veh)
                    if IsThisModelAHeli(model) then
                        local x, y, z = table.unpack(GetEntityCoords(veh))
                        local d = #(vector3(x, y, z) - vector3(cx, cy, cz))
                        if d <= radius and d < bestDist then
                            bestDist = d
                            best = veh
                        end
                    end
                end
                found, veh = FindNextVehicle(handle)
            until not found
            EndFindVehicle(handle)
            return best
        end

        local combo = ComboZone:Create(zones, { name = 'frkn_combo_oxlib', debugPoly = false })
        local active, shown, currentLabelKey = nil, false, nil

        function showFor(pt, labelKey)
            local text = Lang:t(labelKey) .. ' [E]'
            if shown and currentLabelKey == labelKey then return end
            if shown then lib.hideTextUI() shown = false end
            lib.showTextUI(text, {
                position = 'left-center',
                icon = 'box-archive',
                style = { borderRadius = 8, backgroundColor = '#1d1d1d', color = 'white' }
            })
            shown = true
            currentLabelKey = labelKey
        end

        combo:onPlayerInOut(function(inside, _, zone)
            if inside then
                local pt = byName[zone.name]
                if pt and pt.can() then
                    active = pt
                else
                    if shown then lib.hideTextUI() end
                    shown = false
                    currentLabelKey = nil
                    active = nil
                end
            else
                if shown then lib.hideTextUI() end
                shown = false
                currentLabelKey = nil
                if active and active.name == zone.name then active = nil end
            end
        end)

        CreateThread(function()
            while true do
                Wait(0)
                if not active then goto cont end

                local labelKey = active.labelKey
                if active.kind == 'heli' then
                    local heli = nearestHeli((active.dist or 2.0) + 3.0, active.pos)
                    if heli and DoesEntityExist(heli) then
                        labelKey = 'general.heli_return'
                        if IsControlJustReleased(0, 38) then
                            if NetworkGetEntityOwner(heli) ~= PlayerId() then
                                NetworkRequestControlOfEntity(heli)
                                local t = GetGameTimer() + 500
                                while not NetworkHasControlOfEntity(heli) and GetGameTimer() < t do Wait(0) end
                            end
                            if DoesEntityExist(heli) then DeleteEntity(heli) end
                            if shown then lib.hideTextUI() shown = false end
                            currentLabelKey = nil
                            goto cont
                        end
                    else
                        if IsControlJustReleased(0, 38) then
                            active.open()
                            Wait(250)
                        end
                    end
                else
                    if IsControlJustReleased(0, 38) then
                        active.open()
                        Wait(250)
                    end
                end

                showFor(active, labelKey)

                ::cont::
            end
        end)
    elseif FRKN.Interaction.Target == 'custom' then
        
    end

end

CreateThread(function()
    
    while not FRKN or not FRKN.Coords do
        Wait(500)
    end
    Wait(1000) 
    init()
end)

AddEventHandler('onClientResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    CreateThread(function()
        while not FRKN or not FRKN.Coords do
            Wait(500)
        end
        Wait(1000)
        init()
    end)
end)
