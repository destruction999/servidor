


local EVIDENCE_TYPES = {
    BLOOD = "blood",
    GSR_SHOOTER = "gsr_shooter",
    GSR_IMPACT = "gsr_impact"
}

local ANIM_DICT = {
    KNEEL_ENTER = "amb@medic@standing@kneel@enter",
    KNEEL_IDLE = "amb@medic@standing@kneel@idle_a"
}

local evidenceCache = {}
local flashlightFOV = math.cos(math.rad(25.0))

function IsPolice()
    local job, grade = GetPlayerJob()
    return isDeptJob(job)
end

function StreetAt(x, y, z)
    local streetHash, crossingHash = GetStreetNameAtCoord(x + 0.0, y + 0.0, z + 0.0)
    local streetName = GetStreetNameFromHashKey(streetHash or 0)
    return streetName or ""
end

local function GetCameraInfo()
    local rot = GetGameplayCamRot(2)
    local coord = GetGameplayCamCoord()
    
    local pitch = math.rad(rot.x)
    local yaw = math.rad(rot.z)
    
    local direction = vector3(
        -math.sin(yaw) * math.abs(math.cos(pitch)),
        math.cos(yaw) * math.abs(math.cos(pitch)),
        math.sin(pitch)
    )
    
    return coord, direction
end

local function RaycastFromCamera(distance)
    local startPos, direction = GetCameraInfo()
    distance = distance or 120.0
    local endPos = startPos + (direction * distance)
    
    local rayHandle = StartShapeTestRay(
        startPos.x, startPos.y, startPos.z,
        endPos.x, endPos.y, endPos.z,
        61, PlayerPedId(), 0
    )
    
    local _, hit, hitPos = GetShapeTestResult(rayHandle)
    return hit == 1, hitPos
end

local function HasLineOfSight(ped, targetPos)
    local headPos = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
    
    local rayHandle = StartShapeTestRay(
        headPos.x, headPos.y, headPos.z,
        targetPos.x, targetPos.y, targetPos.z,
        61, ped, 0
    )
    
    local _, hit, hitPos = GetShapeTestResult(rayHandle)
    
    if hit == 0 then return true end
    
    local distance = #(hitPos - targetPos)
    return distance < 0.25
end

local function Draw3DText(x, y, z, text)
    local onScreen, screenX, screenY = World3dToScreen2d(x, y, z)
    if not onScreen then return end
    
    SetTextScale(0.32, 0.32)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextCentre(1)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(screenX, screenY)
end

local function PlayPickupAnimation()
    local ped = PlayerPedId()
    
    RequestAnimDict(ANIM_DICT.KNEEL_ENTER)
    RequestAnimDict(ANIM_DICT.KNEEL_IDLE)
    
    while not HasAnimDictLoaded(ANIM_DICT.KNEEL_ENTER) or 
          not HasAnimDictLoaded(ANIM_DICT.KNEEL_IDLE) do
        Wait(0)
    end
    
    TaskPlayAnim(ped, ANIM_DICT.KNEEL_ENTER, "enter", 3.0, -1, -1, 49, 0, false, false, false)
    Wait(900)
    TaskPlayAnim(ped, ANIM_DICT.KNEEL_IDLE, "idle_a", 3.0, -1, -1, 49, 0, false, false, false)
    Wait(800)
    ClearPedTasks(ped)
end

RegisterNetEvent("frkn-evidence:client:pickup", function(data)
    if not data or not data.id then return end
    
    PlayPickupAnimation()
    TriggerServerEvent("frkn-evidence:pickup", data.id)
end)

RegisterNetEvent("frkn-evidence:syncChunk", function(chunk)
    for _, item in ipairs(chunk) do
        evidenceCache[item.id] = item.ev
    end
end)

RegisterNetEvent("frkn-evidence:add", function(id, evidence)
    evidenceCache[id] = evidence
end)

RegisterNetEvent("frkn-evidence:remove", function(id)
    evidenceCache[id] = nil
end)

AddEventHandler("gameEventTriggered", function(eventName, eventData)
    if eventName ~= "CEventNetworkEntityDamage" then return end
    
    local config = FRKN and FRKN.Evidence and FRKN.Evidence.BloodDrop
    if not config or not config.enabled then return end
    
    local victim = eventData[1]
    if victim == 0 or not IsEntityAPed(victim) then return end
    
    local coords = GetEntityCoords(victim)
    local _, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z + 1.0, false)
    local finalZ = (groundZ and groundZ ~= 0.0) and (groundZ + 0.02) or coords.z
    
    local victimServerId = nil
    if IsPedAPlayer(victim) then
        local playerIndex = NetworkGetPlayerIndexFromPed(victim)
        if playerIndex ~= -1 then
            victimServerId = GetPlayerServerId(playerIndex)
        end
    end
    
    TriggerServerEvent("frkn-evidence:create", {
        t = EVIDENCE_TYPES.BLOOD,
        x = coords.x,
        y = coords.y,
        z = finalZ,
        street = StreetAt(coords.x, coords.y, finalZ),
        victim = victimServerId
    })
end)

CreateThread(function()
    while true do
        Wait(0)
        
        local config = FRKN and FRKN.Evidence and FRKN.Evidence.GSRDrop
        if not config or not config.enabled then goto continue end
        
        local ped = PlayerPedId()
        if not IsPedShooting(ped) then goto continue end
        
        local serverId = GetPlayerServerId(PlayerId())
        local shotId = string.format("%s-%d", serverId, GetGameTimer())
        
        local pedCoords = GetEntityCoords(ped)
        local forward = GetEntityForwardVector(ped)
        local gsrPos = pedCoords + (forward * 1.8)
        
        local _, groundZ = GetGroundZFor_3dCoord(gsrPos.x, gsrPos.y, gsrPos.z, false)
        local finalZ = (groundZ and groundZ ~= 0.0) and (groundZ + 0.01) or gsrPos.z
        
        TriggerServerEvent("frkn-evidence:create", {
            t = EVIDENCE_TYPES.GSR_SHOOTER,
            x = gsrPos.x,
            y = gsrPos.y,
            z = finalZ,
            street = StreetAt(gsrPos.x, gsrPos.y, finalZ),
            shot = shotId
        })
        
        local hasImpact, impactPos = GetPedLastWeaponImpactCoord(ped)
        
        if not hasImpact or not impactPos or not impactPos.z then
            hasImpact, impactPos = RaycastFromCamera()
        end
        
        if impactPos and impactPos.z then
            TriggerServerEvent("frkn-evidence:create", {
                t = EVIDENCE_TYPES.GSR_IMPACT,
                x = impactPos.x,
                y = impactPos.y,
                z = impactPos.z + 0.01,
                street = StreetAt(impactPos.x, impactPos.y, impactPos.z),
                shot = shotId
            })
        end
        
        ::continue::
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        
        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)
        local isFlashlight = weapon == GetHashKey("WEAPON_FLASHLIGHT")
        local isAiming = IsPlayerFreeAiming(PlayerId()) or IsControlPressed(0, 25)
        
        if not (isFlashlight and isAiming) then goto continue end
        
        local camPos, camDir = GetCameraInfo()
        local pedPos = GetEntityCoords(ped)
        
        local config = (FRKN and FRKN.Evidence and FRKN.Evidence.FlashlightMarker) or {}
        local maxDistance = config.maxDistance or 10.0
        local markerScale = config.scale or 0.18
        
        local gsrShots = {}
        local gsrByPlayer = {}
        
        for id, evidence in pairs(evidenceCache) do
            if evidence.t == EVIDENCE_TYPES.GSR_SHOOTER and evidence.shot and evidence.shot ~= "" then
                gsrShots[evidence.shot] = vector3(evidence.x, evidence.y, evidence.z)
                
                local playerId = tostring(evidence.by or "")
                gsrByPlayer[playerId] = gsrByPlayer[playerId] or {}
                table.insert(gsrByPlayer[playerId], {
                    pos = vector3(evidence.x, evidence.y, evidence.z),
                    time = evidence.time or 0
                })
            end
        end
        
        local closestId = nil
        local closestDot = -1
        local closestPos = nil
        
        for id, evidence in pairs(evidenceCache) do
            local z = evidence.z
            
            if evidence.t == EVIDENCE_TYPES.BLOOD or evidence.t == EVIDENCE_TYPES.GSR_SHOOTER then
                local _, groundZ = GetGroundZFor_3dCoord(evidence.x, evidence.y, evidence.z + 1.0, false)
                if groundZ ~= 0.0 then
                    z = groundZ + 0.02
                end
            end
            
            local evidencePos = vector3(evidence.x, evidence.y, z)
            local distance = #(pedPos - evidencePos)
            
            if distance <= maxDistance then
                local toEvidence = evidencePos - camPos
                local toEvidenceLen = #toEvidence
                
                if toEvidenceLen > 0.001 then
                    toEvidence = toEvidence / toEvidenceLen
                    local dotProduct = (camDir.x * toEvidence.x) + (camDir.y * toEvidence.y) + (camDir.z * toEvidence.z)
                    
                    if dotProduct >= flashlightFOV and HasLineOfSight(ped, evidencePos) then
                        
                        local r, g, b = 255, 255, 255
                        
                        if evidence.t == EVIDENCE_TYPES.BLOOD then
                            r, g, b = 220, 30, 80
                        elseif evidence.t == EVIDENCE_TYPES.GSR_SHOOTER then
                            r, g, b = 255, 200, 40
                        elseif evidence.t == EVIDENCE_TYPES.GSR_IMPACT then
                            r, g, b = 40, 180, 255
                        end
                        
                        DrawMarker(2, evidence.x, evidence.y, z + 0.05, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                            markerScale, markerScale, markerScale, r, g, b, 185, false, true, 0, false, nil, nil, false)
                        
                        if dotProduct > closestDot then
                            closestDot = dotProduct
                            closestId = id
                            closestPos = evidencePos
                        end
                        
                        if evidence.t == EVIDENCE_TYPES.GSR_IMPACT then
                            local shooterPos = nil
                            
                            if evidence.shot and gsrShots[evidence.shot] then
                                shooterPos = gsrShots[evidence.shot]
                            else
                                local playerId = tostring(evidence.by or "")
                                local playerGSR = gsrByPlayer[playerId]
                                
                                if playerGSR then
                                    local minDist = 999.0
                                    for _, gsr in ipairs(playerGSR) do
                                        local dist = #(evidencePos - gsr.pos)
                                        if dist < minDist then
                                            minDist = dist
                                            shooterPos = gsr.pos
                                        end
                                    end
                                    
                                    if minDist > 12.0 then
                                        shooterPos = nil
                                    end
                                end
                            end
                            
                            if shooterPos then
                                DrawLine(evidencePos.x, evidencePos.y, evidencePos.z + 0.03,
                                    shooterPos.x, shooterPos.y, shooterPos.z + 0.03,
                                    40, 180, 255, 200)
                            end
                        end
                    end
                end
            end
        end
        
        if closestId then
            local evidence = evidenceCache[closestId]
            local promptText
            
            if evidence.t == EVIDENCE_TYPES.BLOOD then
                promptText = Lang:t("general.take_blood")
            elseif evidence.t == EVIDENCE_TYPES.GSR_IMPACT then
                promptText = Lang:t("general.take_fragment")
            else
                promptText = Lang:t("general.take_gsr")
            end
            
            Draw3DText(closestPos.x, closestPos.y, closestPos.z + 0.25, promptText)
            
            if IsControlJustPressed(0, 38) then 
                PlayPickupAnimation()
                TriggerServerEvent("frkn-evidence:pickup", closestId)
            end
        end
        
        ::continue::
    end
end)

RegisterNUICallback("saveEvidenceScan", function(data, cb)
    TriggerCallback("frkn-evidence:saveScan", function(result)
        cb(result)
    end, data.evidence or {})
end)

RegisterNUICallback("updateEvidenceScan", function(data, cb)
    TriggerCallback("frkn-evidence:updateScan", function(result)
        cb(result)
    end, data.evidence or {})
end)

RegisterNUICallback("selectDrawer", function(data, cb)
    local isQS = GetResourceState("qs-inventory") == "started"
    local separator = isQS and "_" or "-"
    local drawerName = "Drawer " .. separator .. data.id
    
    SetNuiFocus(false, false)
    OpenStash("Evidence", drawerName, tostring(data.id))
end)

function PersonStash()
    local identifier = GetPlayerIdentifier()
    if not identifier or identifier == "" then return end
    
    local isQS = GetResourceState("qs-inventory") == "started"
    local separator = isQS and "_" or "-"
    local stashName = "PersonStash " .. separator .. identifier
    
    OpenStash("Personal Storage", stashName, identifier)
end

