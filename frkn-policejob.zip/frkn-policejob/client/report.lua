


ReportCooldowns = {}
CurrentReportZone = nil

function nowMs()
    return GetGameTimer()
end

function remainingMinutes(zoneId)
    local cooldownEnd = ReportCooldowns[zoneId] or 0
    local remaining = cooldownEnd - nowMs()
    
    if remaining <= 0 then
        return 0
    end
    
    return math.ceil(remaining / 60000)
end

function startCooldown(zoneId)
    local cooldownDuration = math.floor((FRKN.ReportCooldownMinutes or 10) * 60000)
    ReportCooldowns[zoneId] = nowMs() + cooldownDuration
end

RegisterNUICallback("reportSubmit", function(data, cb)
    TriggerServerEvent("frkn-policejob:reportSubmit", data)
    
    if CurrentReportZone then
        startCooldown(CurrentReportZone)
        CurrentReportZone = nil
    end
    
    if cb then
        cb({ok = true})
    end
end)

RegisterNUICallback("deleteReport", function(data, cb)
    TriggerServerEvent("frkn-policejob:deleteReport", data.id)
    
    if cb then
        cb({ok = true})
    end
end)

