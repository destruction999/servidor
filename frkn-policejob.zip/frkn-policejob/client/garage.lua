


local previewCam = nil
local extrasCam = nil
local currentCamMode = nil
local heliControl = false
local garageIndex = 1

local VEHICLE_EXTRAS_MAP = {
    [2046537925] = { pushbar = 1, lightbar = 2 },
    [-1627000575] = { pushbar = 1, lightbar = 2 },
    [1912215274] = { pushbar = 1, lightbar = 2 },
    [-1973172295] = { pushbar = 1, lightbar = 2 }
}

local function DeleteVehicleSafe(vehicle)
    if not vehicle or not DoesEntityExist(vehicle) then return end
    
    SetEntityAsMissionEntity(vehicle, true, true)
    DeleteVehicle(vehicle)
end

function GeneratePlate()
    local plate = string.format("%s%s%s%03d",
        string.char(math.random(65, 90)),
        string.char(math.random(65, 90)),
        string.char(math.random(65, 90)),
        math.random(0, 999)
    )
    return string.upper(plate)
end

local function GetPlayerVehicle()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then return nil end
    return GetVehiclePedIsIn(ped, false)
end

function IsGarageVehicle(modelHash)
    
    for _, garage in pairs(FRKN.Coords.Garage or {}) do
        for model, _ in pairs(garage) do
            if joaat(model) == modelHash then
                return true
            end
        end
    end
    
    for _, model in ipairs(FRKN.ExtrasCarList or {}) do
        if joaat(model) == modelHash then
            return true
        end
    end
    
    return false
end

function CanOpenExtrasMenu()
    local vehicle = GetPlayerVehicle()
    if not vehicle then return false end
    
    local model = GetEntityModel(vehicle)
    return IsGarageVehicle(model)
end

function SpawnRentedVehicle(data, category)
    heliControl = false
    
    local modelName = data.model
    if not modelName then return end
    
    local modelHash = type(modelName) == "string" and joaat(modelName) or modelName
    
    if not IsModelInCdimage(modelHash) or not IsModelAVehicle(modelHash) then
        return nil
    end
    
    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do
        Wait(0)
    end
    
    local ped = PlayerPedId()
    local spawnCoords
    
    if category == "heli" then
        spawnCoords = FRKN.Coords.Heli[garageIndex].spawnCoords
        heliControl = true
        heliController()
    else
        spawnCoords = FRKN.Coords.Garage[garageIndex].spawnCoords
    end
    
    local vehicle = CreateVehicle(
        modelHash,
        spawnCoords.x, spawnCoords.y, spawnCoords.z, spawnCoords.w,
        true, false
    )
    
    local plate = GetVehicleNumberPlateText(vehicle)
    
    if category == "car" then
        ApplyCarCustomization(vehicle)
    elseif category == "heli" then
        ApplyHeliCustomization(vehicle)
    end
    
    SetEntityAsMissionEntity(vehicle, true, true)
    SetVehicleOnGroundProperly(vehicle)
    TaskWarpPedIntoVehicle(ped, vehicle, -1)
    SetModelAsNoLongerNeeded(modelHash)
    
    FRKN.GiveKey(plate)
    
    return vehicle
end

function ApplyCarCustomization(vehicle)
    SetVehicleModKit(vehicle, 0)
    
    for i = 0, 49 do
        SetVehicleMod(vehicle, i, -1, false)
    end
    
    ToggleVehicleMod(vehicle, 18, false) 
    ToggleVehicleMod(vehicle, 20, false) 
    ToggleVehicleMod(vehicle, 22, false) 
    
    local liveryCount = GetVehicleLiveryCount(vehicle)
    if liveryCount and liveryCount > 0 then
        SetVehicleMod(vehicle, 48, -1, false)
        SetVehicleLivery(vehicle, 0)
    end
    
    for i = 0, 14 do
        if DoesExtraExist(vehicle, i) then
            SetVehicleExtra(vehicle, i, true)
        end
    end
    
    for i = 0, 3 do
        SetVehicleNeonLightEnabled(vehicle, i, false)
    end
    
    SetVehicleSiren(vehicle, false)
    local color = FRKN.VehicleColor
    SetVehicleColours(vehicle, color, color)
end

function ApplyHeliCustomization(vehicle)
    local liveryCount = GetVehicleLiveryCount(vehicle)
    if liveryCount and liveryCount > 0 then
        SetVehicleLivery(vehicle, 0)
    end
    SetVehicleSiren(vehicle, false)
end

local function EnsureCamera()
    if not extrasCam then
        extrasCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    end
    SetCamActive(extrasCam, true)
    RenderScriptCams(true, true, 800, true, true)
end

function SetCamFront(vehicle)
    if not vehicle or vehicle == 0 then return end
    
    EnsureCamera()
    
    local offset = GetOffsetFromEntityInWorldCoords(vehicle, 3.5, 2.5, 1.2)
    SetCamCoord(extrasCam, offset.x, offset.y, offset.z)
    PointCamAtEntity(extrasCam, vehicle, 0.0, 0.0, 0.5, true)
    currentCamMode = "front"
end

function SetCamRoof(vehicle)
    if not vehicle or vehicle == 0 then return end
    
    EnsureCamera()
    
    local min, max = GetModelDimensions(GetEntityModel(vehicle))
    local coords = GetEntityCoords(vehicle)
    local height = coords.z + (max.z - min.z) + 1.6
    
    SetCamCoord(extrasCam, coords.x, coords.y, height)
    PointCamAtEntity(extrasCam, vehicle, 0.0, 0.0, 0.0, true)
    currentCamMode = "roof"
end

function OpenExtraCamFront()
    local vehicle = GetPlayerVehicle()
    SetCamFront(vehicle)
end

function CloseExtraCam()
    if extrasCam then
        RenderScriptCams(false, true, 600, true, true)
        DestroyCam(extrasCam, false)
        extrasCam = nil
        currentCamMode = nil
    end
end

local function FirstExistingExtra(vehicle, extraList)
    for _, extraId in ipairs(extraList) do
        if DoesExtraExist(vehicle, extraId) then
            return extraId
        end
    end
    return nil
end

function GetModelExtra(vehicle, extraName)
    local model = GetEntityModel(vehicle)
    local mapping = VEHICLE_EXTRAS_MAP[model]
    
    if mapping and mapping[extraName] then
        local extraId = mapping[extraName]
        if DoesExtraExist(vehicle, extraId) then
            return extraId
        end
    end
    
    if extraName == "pushbar" then
        return FirstExistingExtra(vehicle, {1, 3, 7, 9, 11})
    elseif extraName == "lightbar" then
        return FirstExistingExtra(vehicle, {2, 12, 13, 8})
    end
    
    return nil
end

function BuildFeatures(vehicle)
    local model = GetEntityModel(vehicle)
    local displayName = GetDisplayNameFromVehicleModel(model)
    local label = GetLabelText(displayName)
    
    if not label or label == "NULL" then
        label = tostring(model)
    end
    
    local modelName = string.lower(displayName) or tostring(model)
    local imageUrl = string.format(
        "https://raw.githubusercontent.com/MericcaN41/gta5carimages/refs/heads/main/images/%s.png",
        string.lower(modelName)
    )
    
    local fuel = GetVehicleFuelLevel and GetVehicleFuelLevel(vehicle) or 50.0
    fuel = math.max(0, math.min(100, fuel))
    fuel = math.floor(fuel + 0.5)
    
    local maxSpeed = GetVehicleEstimatedMaxSpeed(vehicle) * 3.6
    local speedRating = math.floor(math.min(100.0, (maxSpeed / 320.0) * 100.0) + 0.5)
    
    local bodyHealth = GetVehicleBodyHealth(vehicle)
    bodyHealth = math.max(0, math.min(1000, bodyHealth))
    local damagePercent = math.floor(((1000.0 - bodyHealth) / 1000.0) * 100.0 + 0.5)
    
    return {
        img = imageUrl,
        name = label,
        model = modelName,
        desc = "You can customize your special police car through this page.",
        fuel = fuel,
        speed = speedRating,
        damage = damagePercent
    }
end

RegisterNUICallback("buyVehicle", function(data, cb)
    local model = data.model
    local category = data.category
    
    if category == "heli" then
        SpawnRentedVehicle({model = model}, category)
        cb({ok = true})
        return
    end
    
    TriggerCallback("frkn-policejob:hasVehicleModel", function(hasVehicle)
        if hasVehicle then
            TriggerEvent("frkn-policejob:notify", "error", Lang:t("error.vehicle_already_owned"))
            if cb then cb({ok = false}) end
            return
        end
        
        TriggerCallback("frkn-policejob:moneyControl", function(hasMoney)
            if not hasMoney then
                TriggerEvent("frkn-policejob:notify", "error", Lang:t("error.not_enough_money"))
                if cb then cb({ok = false}) end
                return
            end
            
            local vehicle = SpawnRentedVehicle({model = model}, category)
            if not vehicle or not DoesEntityExist(vehicle) then
                TriggerEvent("frkn-policejob:notify", "error", Lang:t("error.vehicle_spawn_failed"))
                if cb then cb({ok = false}) end
                return
            end
            
            local plate = GetVehicleNumberPlateText(vehicle)
            local props = GetVehicleProperties(vehicle)
            local mods = data.mods or {}
            local price = tonumber(data.price) or 0
            
            TriggerCallback("frkn-policejob:savePurchasedVehicle", function(success)
                if not success then
                    DeleteVehicleSafe(vehicle)
                    TriggerEvent("frkn-policejob:notify", "error", Lang:t("error.vehicle_already_owned"))
                    if cb then cb({ok = false}) end
                    return
                end
                
                TriggerEvent("frkn-policejob:notify", "success", Lang:t("success.vehicle_rented"))
                if cb then cb({ok = true, plate = plate}) end
            end, {
                plate = plate,
                vehicleprops = props,
                vehicle = model,
                mods = mods,
                price = price
            })
        end, data)
    end, model)
end)

RegisterNUICallback("camPreset", function(data, cb)
    local vehicle = GetPlayerVehicle()
    local mode = (data and data.mode) or "front"
    
    if mode == "roof" then
        SetCamRoof(vehicle)
    else
        SetCamFront(vehicle)
    end
    
    cb({ok = true})
end)

RegisterNUICallback("toggleExtra", function(data, cb)
    local vehicle = GetPlayerVehicle()
    if not vehicle or not data or type(data.id) ~= "number" then
        cb({ok = false})
        return
    end
    
    local extraId = data.id
    if not DoesExtraExist(vehicle, extraId) then
        cb({ok = false})
        return
    end
    
    local isOn = IsVehicleExtraTurnedOn(vehicle, extraId) == 1
    SetVehicleExtra(vehicle, extraId, isOn)
    cb({ok = true})
end)

RegisterNUICallback("toggleNamedExtra", function(data, cb)
    local vehicle = GetPlayerVehicle()
    if not vehicle or not data or type(data.name) ~= "string" then
        cb({ok = false})
        return
    end
    
    local extraId = (data.id and tonumber(data.id)) or GetModelExtra(vehicle, data.name)
    
    if not extraId or not DoesExtraExist(vehicle, extraId) then
        cb({ok = false})
        return
    end
    
    local isOn = IsVehicleExtraTurnedOn(vehicle, extraId) == 1
    SetVehicleExtra(vehicle, extraId, isOn)
    cb({ok = true})
end)

RegisterNUICallback("setLivery", function(data, cb)
    local vehicle = GetPlayerVehicle()
    if not vehicle or not data then
        cb({ok = false})
        return
    end
    
    local liveryCount = GetVehicleLiveryCount(vehicle)
    if not liveryCount or liveryCount < 1 then
        cb({ok = false})
        return
    end
    
    local index = tonumber(data.index)
    if not index or index < 0 or index >= liveryCount then
        cb({ok = false})
        return
    end
    
    SetVehicleLivery(vehicle, index)
    cb({ok = true})
end)

RegisterNUICallback("siren", function(data, cb)
    local vehicle = GetPlayerVehicle()
    if not vehicle or not data or type(data.mode) ~= "string" then
        cb({ok = false})
        return
    end
    
    local mode = string.lower(data.mode)
    
    if mode == "on" then
        SetVehicleSiren(vehicle, true)
        SetVehicleHasMutedSirens(vehicle, false)
    elseif mode == "off" then
        SetVehicleSiren(vehicle, false)
    elseif mode == "mute" then
        SetVehicleSiren(vehicle, true)
        SetVehicleHasMutedSirens(vehicle, true)
    else
        local isOn = IsVehicleSirenOn(vehicle)
        SetVehicleSiren(vehicle, not isOn)
    end
    
    cb({ok = true})
end)

RegisterNUICallback("engine", function(data, cb)
    local vehicle = GetPlayerVehicle()
    if not vehicle or not data then
        cb({ok = false})
        return
    end
    
    local mult = tonumber(data.mult) or 1.0
    mult = math.max(0.1, math.min(5.0, mult))
    
    SetVehicleEngineTorqueMultiplier(vehicle, mult)
    SetVehicleEnginePowerMultiplier(vehicle, (mult - 1.0) * 50.0)
    
    Notify(Lang:t("success.engine_power_set", {mult = string.format("%.1f", mult)}))
    cb({ok = true})
end)

RegisterNUICallback("setColor", function(data, cb)
    local vehicle = GetPlayerVehicle()
    if not vehicle or vehicle == 0 then
        cb({ok = false})
        return
    end
    
    local primary = tonumber(data.primary) or 0
    local secondary = tonumber(data.secondary) or primary
    
    SetVehicleColours(vehicle, primary, secondary)
    cb({ok = true})
end)

RegisterCommand("setvehiclecolour", function(source, args)
    local vehicle = GetPlayerVehicle()
    if not vehicle or vehicle == 0 then return end
    
    local colorName = string.lower(args[1] or "")
    
    local COLOR_PRESETS = {
        black = {0, 0},
        white = {111, 111},
        red = {27, 27},
        blue = {64, 64},
        green = {55, 55},
        yellow = {88, 88},
        orange = {38, 38},
        pink = {135, 135},
        purple = {145, 145},
        brown = {108, 108},
        silver = {4, 4},
        grey = {13, 13},
        gold = {37, 37},
        lime = {92, 92},
        cyan = {70, 70},
        turquoise = {71, 71},
        bronze = {90, 90},
        midnightblue = {141, 141},
        cream = {107, 107}
    }
    
    local colors = COLOR_PRESETS[colorName]
    if colors then
        SetVehicleColours(vehicle, colors[1], colors[2])
    end
end)

