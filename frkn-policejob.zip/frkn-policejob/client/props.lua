


local placedProps = {}
local spikeStrips = {}
local closestSpikeIndex = nil

local targetSystem = nil
if GetResourceState("ox_target") == "started" then
    targetSystem = "ox"
elseif GetResourceState("qb-target") == "started" then
    targetSystem = "qb"
end

local function RadToDeg(radians)
    return radians * 180.0 / math.pi
end

local function RotationToDirection(rotation)
    local pitch = rotation.x * math.pi / 180.0
    local yaw = rotation.y * math.pi / 180.0
    local roll = rotation.z * math.pi / 180.0
    
    return vector3(
        -math.sin(roll) * math.abs(math.cos(pitch)),
        math.cos(roll) * math.abs(math.cos(pitch)),
        math.sin(pitch)
    )
end

local function RaycastFromCamera(distance)
    local camRot = GetGameplayCamRot(2)
    local camPos = GetGameplayCamCoord()
    local direction = RotationToDirection(camRot)
    local destination = camPos + (direction * distance)
    
    local rayHandle = StartShapeTestRay(
        camPos.x, camPos.y, camPos.z,
        destination.x, destination.y, destination.z,
        -1, PlayerPedId(), 0
    )
    
    local _, hit, coords, surfaceNormal, entity = GetShapeTestResult(rayHandle)
    return coords, surfaceNormal, entity, hit == 1
end

local function PointEntityAtDirection(entity, direction, keepHeading)
    if not direction then return end
    
    local x, y, z = direction.x, direction.y, direction.z
    local pitch = RadToDeg(math.atan2(-x, z))
    local yaw = RadToDeg(math.atan2(y, z))
    local roll = keepHeading and GetEntityHeading(entity) or 0.0
    
    SetEntityRotation(entity, pitch, yaw, roll, 2, true)
end

local function GetEntityBoundingBox(entity)
    local min, max = GetModelDimensions(GetEntityModel(entity))
    
    local corners = {
        vector3(min.x, min.y, min.z),
        vector3(max.x, min.y, min.z),
        vector3(max.x, max.y, min.z),
        vector3(min.x, max.y, min.z),
        vector3(min.x, min.y, max.z),
        vector3(max.x, min.y, max.z),
        vector3(max.x, max.y, max.z),
        vector3(min.x, max.y, max.z)
    }
    
    local worldCorners = {}
    for i = 1, #corners do
        local worldPos = GetOffsetFromEntityInWorldCoords(entity, corners[i].x, corners[i].y, corners[i].z)
        worldCorners[i] = vector3(worldPos.x, worldPos.y, worldPos.z)
    end
    
    return worldCorners
end

local function DrawEntityBoundingBox(entity, isValid)
    local coords = GetEntityCoords(entity)
    local r = isValid and 0 or 255
    local g = isValid and 200 or 0
    local b = 0
    
    local corners = GetEntityBoundingBox(entity)
    
    local edges = {
        {1, 2}, {2, 3}, {3, 4}, {4, 1}, 
        {5, 6}, {6, 7}, {7, 8}, {8, 5}, 
        {1, 5}, {2, 6}, {3, 7}, {4, 8}  
    }
    
    for _, edge in ipairs(edges) do
        local p1 = corners[edge[1]]
        local p2 = corners[edge[2]]
        DrawLine(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, r, g, b, 180)
    end
end

local function CheckEntityFootprint(entity, multiplier)
    local min, max = GetModelDimensions(GetEntityModel(entity))
    local size = max - min
    local radius = math.max(math.abs(size.x), math.abs(size.y)) * 0.5 * (multiplier or 1.0)
    
    local entityPos = GetEntityCoords(entity)
    local objects = GetGamePool("CObject")
    
    for i = 1, #objects do
        local obj = objects[i]
        if obj ~= entity and DoesEntityExist(obj) then
            local objPos = GetEntityCoords(obj)
            local distance = #(objPos - entityPos)
            if distance < radius then
                return false
            end
        end
    end
    
    return true
end

local function RemovePropTarget(entity)
    if not DoesEntityExist(entity) then return end
    
    if targetSystem == "qb" then
        if exports["qb-target"] and exports["qb-target"].RemoveTargetEntity then
            exports["qb-target"]:RemoveTargetEntity(entity, "all")
        end
    elseif targetSystem == "ox" then
        if exports.ox_target and exports.ox_target.removeEntity then
            exports.ox_target:removeEntity(entity)
        end
    end
end

function AddPropTarget(entity)
    if not DoesEntityExist(entity) then return end
    
    RemovePropTarget(entity)
    
    if targetSystem == "qb" then
        exports["qb-target"]:AddTargetEntity(entity, {
            options = {
                {
                    icon = "fa-solid fa-pen",
                    label = "Edit Prop",
                    type = "client",
                    event = "frkn-policejob:prop:edit",
                    entity = entity
                },
                {
                    icon = "fa-solid fa-trash",
                    label = "Delete Prop",
                    type = "client",
                    event = "frkn-policejob:prop:delete",
                    entity = entity
                }
            },
            distance = 2.0
        })
    elseif targetSystem == "ox" then
        local options = {
            {
                name = "frkn_prop_edit",
                icon = "fa-solid fa-pen",
                label = "Edit Prop",
                distance = 2.0,
                onSelect = function()
                    TriggerEvent("frkn-policejob:prop:edit", {entity = entity})
                end
            },
            {
                name = "frkn_prop_delete",
                icon = "fa-solid fa-trash",
                label = "Delete Prop",
                distance = 2.0,
                onSelect = function()
                    TriggerEvent("frkn-policejob:prop:delete", {entity = entity})
                end
            }
        }
        
        if exports.ox_target and exports.ox_target.addLocalEntity then
            exports.ox_target:addLocalEntity(entity, options)
        else
            exports.ox_target:addEntity(entity, options)
        end
    end
end

local function FinalizeProp(entity, freeze)
    local netId = ObjToNet(entity)
    if netId ~= 0 then
        SetNetworkIdExistsOnAllMachines(netId, true)
        SetNetworkIdCanMigrate(netId, true)
        NetworkRequestControlOfNetworkId(netId)
    end
    
    SetEntityAlpha(entity, 255, false)
    SetEntityCollision(entity, true, true)
    FreezeEntityPosition(entity, freeze)
    
    table.insert(placedProps, entity)
end

RegisterNetEvent("frkn-policejob:prop:delete")
AddEventHandler("frkn-policejob:prop:delete", function(data)
    local entity = (type(data) == "table" and data.entity) or data
    
    if entity and DoesEntityExist(entity) then
        DeleteEntity(entity)
    end
end)

RegisterNetEvent("frkn-policejob:prop:edit")
AddEventHandler("frkn-policejob:prop:edit", function(data)
    local entity = (type(data) == "table" and data.entity) or data
    
    if not entity or not DoesEntityExist(entity) then return end
    
    local model = GetEntityModel(entity)
    ChooseSpawnLocation(model, vector4(0, 0, 0, 0), {
        tilt = false,
        validate = true,
        footprint = true,
        keepHeading = true,
        array = {count = 1},
        editEntity = entity,
        maxDistance = FRKN.PropsSettings.maxDistance,
        zLimit = FRKN.PropsSettings.zLimit
    })
end)

local function GetGroundZ(x, y, z)
    local found, groundZ = GetGroundZFor_3dCoord(x, y, z, false)
    return found and groundZ or z
end

function ChooseSpawnLocation(modelName, offset, options, shouldFreeze)
    options = options or {}
    
    local allowTilt = options.tilt ~= false
    local validateFootprint = options.validate ~= false
    local checkFootprint = options.footprint ~= false
    local keepHeading = options.keepHeading ~= false
    local arrayConfig = options.array or {count = 1, spacing = 1.5, axis = "x"}
    local arrayCount = math.max(tonumber(arrayConfig.count or 1), 1)
    local arraySpacing = tonumber(arrayConfig.spacing or 1.5)
    local arrayAxis = tostring(arrayConfig.axis or "x"):lower()
    local editEntity = options.editEntity
    local maxDistance = tonumber(options.maxDistance or 5.0)
    local zLimit = options.zLimit
    
    local ped = PlayerPedId()
    local pedPos = GetEntityCoords(ped)
    local previewEntity = nil
    
    if editEntity and DoesEntityExist(editEntity) then
        previewEntity = editEntity
        SetEntityAlpha(previewEntity, 150, true)
        SetEntityCollision(previewEntity, false, false)
        FreezeEntityPosition(previewEntity, true)
        arrayCount = 1
    else
        previewEntity = CreateObject(GetHashKey(modelName), 
            pedPos.x + offset.x, pedPos.y + offset.y, pedPos.z + offset.z, 
            true, true, false)
        SetEntityAlpha(previewEntity, 150, true)
        SetEntityCollision(previewEntity, false, false)
        FreezeEntityPosition(previewEntity, true)
    end
    
    local arrayEntities = {}
    if not editEntity and arrayCount > 1 then
        for i = 1, arrayCount - 1 do
            local entity = CreateObject(GetHashKey(modelName), pedPos.x, pedPos.y, pedPos.z, true, true, false)
            SetEntityAlpha(entity, 120, true)
            SetEntityCollision(entity, false, false)
            FreezeEntityPosition(entity, true)
            arrayEntities[i] = entity
        end
    end
    
    local zOffset = 0.0
    local positionOffset = vector3(0.0, 0.0, 0.0)
    
    while true do
        BlockWeaponWheelThisFrame()
        
        pedPos = GetEntityCoords(ped)
        local hitCoords, surfaceNormal = RaycastFromCamera(100.0)
        
        if hitCoords then
            local targetX = hitCoords.x + offset.x + positionOffset.x
            local targetY = hitCoords.y + offset.y + positionOffset.y
            local groundZ = GetGroundZ(targetX, targetY, hitCoords.z + offset.z)
            
            if IsDisabledControlPressed(0, 21) then 
                zOffset = zOffset + 0.01
                if zLimit and zOffset > zLimit then zOffset = zLimit end
            end
            if IsDisabledControlPressed(0, 36) then 
                zOffset = zOffset - 0.01
                if zOffset < 0.0 then zOffset = 0.0 end
            end
            
            local finalZ = groundZ + zOffset
            local targetPos = vector3(targetX, targetY, finalZ)
            
            local distanceToPed = #(targetPos - pedPos)
            if distanceToPed > maxDistance then
                local direction = (targetPos - pedPos) / distanceToPed
                targetPos = vector3(
                    pedPos.x + direction.x * maxDistance,
                    pedPos.y + direction.y * maxDistance,
                    pedPos.z + direction.z * maxDistance
                )
                local newGroundZ = GetGroundZ(targetPos.x, targetPos.y, targetPos.z)
                targetPos = vector3(targetPos.x, targetPos.y, newGroundZ + zOffset)
            end
            
            SetEntityCoords(previewEntity, targetPos.x, targetPos.y, targetPos.z)
            
            if allowTilt and surfaceNormal then
                PointEntityAtDirection(previewEntity, surfaceNormal, keepHeading)
            end
        end
        
        DisableControlAction(0, 81, true) 
        if IsDisabledControlJustPressed(0, 81) then
            local heading = GetEntityHeading(previewEntity)
            local step = IsDisabledControlPressed(0, 36) and 1.0 or 7.5
            SetEntityHeading(previewEntity, heading + step)
        end
        
        DisableControlAction(0, 99, true) 
        if IsDisabledControlJustPressed(0, 99) then
            local heading = GetEntityHeading(previewEntity)
            local step = IsDisabledControlPressed(0, 36) and 1.0 or 7.5
            SetEntityHeading(previewEntity, heading - step)
        end
        
        DisableControlAction(0, 27, true) 
        if IsDisabledControlPressed(0, 27) then
            local step = IsDisabledControlPressed(0, 36) and 0.1 or 0.05
            positionOffset = vector3(positionOffset.x + step, positionOffset.y, positionOffset.z)
        end
        
        DisableControlAction(0, 173, true) 
        if IsDisabledControlPressed(0, 173) then
            local step = IsDisabledControlPressed(0, 36) and 0.1 or 0.05
            positionOffset = vector3(positionOffset.x - step, positionOffset.y, positionOffset.z)
        end
        
        DisableControlAction(0, 174, true) 
        if IsDisabledControlPressed(0, 174) then
            local step = IsDisabledControlPressed(0, 36) and 0.1 or 0.05
            positionOffset = vector3(positionOffset.x, positionOffset.y + step, positionOffset.z)
        end
        
        DisableControlAction(0, 175, true) 
        if IsDisabledControlPressed(0, 175) then
            local step = IsDisabledControlPressed(0, 36) and 0.1 or 0.05
            positionOffset = vector3(positionOffset.x, positionOffset.y - step, positionOffset.z)
        end
        
        DisableControlAction(0, 20, true) 
        if IsDisabledControlJustPressed(0, 20) then
            zOffset = 0.0
            local currentPos = GetEntityCoords(previewEntity)
            PlaceObjectOnGroundProperly(previewEntity)
            local newGroundZ = GetGroundZ(currentPos.x, currentPos.y, currentPos.z)
            SetEntityCoords(previewEntity, currentPos.x, currentPos.y, newGroundZ)
        end
        
        if not editEntity then
            if IsDisabledControlJustPressed(0, 44) then 
                arrayCount = math.max(1, arrayCount - 1)
            elseif IsDisabledControlJustPressed(0, 38) then 
                arrayCount = math.min(9, arrayCount + 1)
            end
            
            local neededCount = math.max(arrayCount - 1, 0)
            local currentCount = #arrayEntities
            
            if neededCount > currentCount then
                for i = currentCount + 1, neededCount do
                    local entity = CreateObject(GetHashKey(modelName), pedPos.x, pedPos.y, pedPos.z, true, true, false)
                    SetEntityAlpha(entity, 120, true)
                    SetEntityCollision(entity, false, false)
                    FreezeEntityPosition(entity, true)
                    arrayEntities[i] = entity
                end
            elseif neededCount < currentCount then
                for i = currentCount, neededCount + 1, -1 do
                    if DoesEntityExist(arrayEntities[i]) then
                        DeleteEntity(arrayEntities[i])
                    end
                    arrayEntities[i] = nil
                end
            end
        end
        
        local rotation = GetEntityRotation(previewEntity, 2)
        local heading = GetEntityHeading(previewEntity)
        local mainPos = GetEntityCoords(previewEntity)
        local fwd, right, up = GetEntityMatrix(previewEntity)
        local axisVector = (arrayAxis == "y" and right) or (arrayAxis == "z" and up) or fwd
        
        local isValid = true
        if validateFootprint then
            isValid = CheckEntityFootprint(previewEntity, 1.0)
        end
        
        for i = 1, #arrayEntities do
            local offset = arraySpacing * i
            local arrayPos = vector3(
                mainPos.x + axisVector.x * offset,
                mainPos.y + axisVector.y * offset,
                mainPos.z + axisVector.z * offset
            )
            
            local distToPed = #(arrayPos - pedPos)
            if distToPed > maxDistance then
                local dir = (arrayPos - pedPos) / distToPed
                arrayPos = vector3(
                    pedPos.x + dir.x * maxDistance,
                    pedPos.y + dir.y * maxDistance,
                    pedPos.z + dir.z * maxDistance
                )
            end
            
            local arrayGroundZ = GetGroundZ(arrayPos.x, arrayPos.y, arrayPos.z)
            local entity = arrayEntities[i]
            
            SetEntityCoords(entity, arrayPos.x, arrayPos.y, arrayGroundZ + zOffset)
            SetEntityRotation(entity, rotation.x, rotation.y, rotation.z, 2, true)
            SetEntityHeading(entity, heading)
            
            if validateFootprint and isValid then
                isValid = CheckEntityFootprint(entity, 1.0)
            end
        end
        
        if checkFootprint then
            DrawEntityBoundingBox(previewEntity, isValid)
            for i = 1, #arrayEntities do
                DrawEntityBoundingBox(arrayEntities[i], isValid)
            end
        end
        
        if IsControlJustReleased(0, 191) then 
            local results = {}
            
            if #arrayEntities > 0 then
                local allEntities = {previewEntity}
                for i = 1, #arrayEntities do
                    table.insert(allEntities, arrayEntities[i])
                end
                
                for _, entity in ipairs(allEntities) do
                    local pos = GetEntityCoords(entity)
                    local head = GetEntityHeading(entity)
                    
                    FinalizeProp(entity, shouldFreeze)
                    AddPropTarget(entity)
                    PlaceObjectOnGroundProperly(entity)
                    
                    table.insert(results, vector4(
                        pos.x - offset.x,
                        pos.y - offset.y,
                        pos.z - offset.z,
                        head
                    ))
                end
                
                return results
            else
                local pos = GetEntityCoords(previewEntity)
                local head = GetEntityHeading(previewEntity)
                
                FinalizeProp(previewEntity, false)
                AddPropTarget(previewEntity)
                
                return vector4(pos.x - offset.x, pos.y - offset.y, pos.z - offset.z, head), rotation
            end
        end
        
        DisableControlAction(0, 200, true) 
        if IsDisabledControlJustPressed(0, 200) then
            for i = 1, #arrayEntities do
                DeleteEntity(arrayEntities[i])
            end
            
            if editEntity then
                SetEntityAlpha(previewEntity, 255, false)
                SetEntityCollision(previewEntity, true, true)
                FreezeEntityPosition(previewEntity, false)
                AddPropTarget(previewEntity)
            else
                DeleteEntity(previewEntity)
            end
            
            return "exit"
        end
        
        Wait(0)
    end
end

RegisterNetEvent("frkn:props:place")
AddEventHandler("frkn:props:place", function(data)
    local job, grade = GetPlayerJob()
    local requiredGrade = data.grade or 0
    local playerGrade = tonumber(grade) or 0
    
    if requiredGrade > playerGrade then
        Notify(Lang:t("error.not_permission"))
        return
    end
    
    Wait(100)
    SendNUIMessage({action = "openMenu", menu = "prop-menu"})
    
    local result = ChooseSpawnLocation(data.prop, vector4(0, 0, 0, 0), {
        tilt = false,
        validate = true,
        footprint = true,
        keepHeading = true,
        array = {count = data.count, spacing = data.spacing, axis = "x"},
        maxDistance = FRKN.PropsSettings.maxDistance,
        zLimit = FRKN.PropsSettings.zLimit
    }, data.freeze)
    
    SendNUIMessage({action = "closeMenu"})
    
    if data.prop == "P_ld_stinger_s" then
        if result == "exit" then return end
        
        local function toVec3(v)
            if not v or not v.x or not v.y or not v.z then return nil end
            return vector3(tonumber(v.x), tonumber(v.y), tonumber(v.z))
        end
        
        if type(result) == "table" and result[1] then
            for _, pos in ipairs(result) do
                local coords = toVec3(pos)
                if coords then
                    table.insert(spikeStrips, {coords = coords})
                end
            end
        else
            local coords = toVec3(result)
            if coords then
                table.insert(spikeStrips, {coords = coords})
            end
        end
        
        TriggerServerEvent("frkn-policejob:server:SyncSpikes", spikeStrips)
    end
end)

function GetClosestSpike()
    local pedPos = GetEntityCoords(PlayerPedId(), true)
    local closestIndex = nil
    local closestDist = nil
    local maxDist = 50.0
    
    for i, spike in pairs(spikeStrips) do
        local spikePos = vector3(spike.coords.x, spike.coords.y, spike.coords.z)
        local dist = #(pedPos - spikePos)
        
        if not closestIndex or dist < closestDist then
            closestIndex = i
            closestDist = dist
        end
    end
    
    closestSpikeIndex = (closestDist and closestDist <= maxDist) and closestIndex or nil
end

CreateThread(function()
    while true do
        local sleepTime = 1000
        GetClosestSpike()
        
        if closestSpikeIndex then
            sleepTime = 0
            local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
            
            if vehicle and vehicle ~= 0 then
                local wheels = {
                    {bone = "wheel_lf", index = 0},
                    {bone = "wheel_rf", index = 1},
                    {bone = "wheel_lm", index = 2},
                    {bone = "wheel_rm", index = 3},
                    {bone = "wheel_lr", index = 4},
                    {bone = "wheel_rr", index = 5}
                }
                
                for _, wheel in ipairs(wheels) do
                    local wheelPos = GetWorldPositionOfEntityBone(vehicle, GetEntityBoneIndexByName(vehicle, wheel.bone))
                    local spike = GetClosestObjectOfType(wheelPos.x, wheelPos.y, wheelPos.z, 15.0, "P_ld_stinger_s", 1, 1, 1)
                    
                    if spike ~= 0 then
                        local spikePos = GetEntityCoords(spike, false)
                        local distance = #(wheelPos - spikePos)
                        
                        if distance < 1.8 then
                            if not IsVehicleTyreBurst(vehicle, wheel.index, true) or not IsVehicleTyreBurst(vehicle, wheel.index, false) then
                                SetVehicleTyreBurst(vehicle, wheel.index, false, 1000.0)
                            end
                        end
                    end
                end
            end
        end
        
        Wait(sleepTime)
    end
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    
    for _, entity in ipairs(placedProps) do
        if DoesEntityExist(entity) then
            DeleteEntity(entity)
        end
    end
    placedProps = {}
end)

AddEventHandler("onResourceStart", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    
    for _, entity in ipairs(placedProps) do
        if DoesEntityExist(entity) then
            DeleteEntity(entity)
        end
    end
    placedProps = {}
end)

