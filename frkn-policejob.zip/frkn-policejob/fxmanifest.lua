-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts
-- Join our Discord : https://discord.com/invite/R9KgyCkXJp

fx_version 'cerulean'
game 'gta5'

escrow_ignore {
	'client/core.lua',
	'client/editable.lua',
	'server/core.lua',
	'server/webhook.lua',
	'locales/*.lua',
	'shared/*.lua',
}

shared_scripts {
	'@ox_lib/init.lua',
	
	'shared/locale.lua',
	'locales/fr.lua',
	'locales/en.lua',
	'locales/*.lua',
	'shared/cores.lua',
    'shared/config.lua',
}

client_scripts {
	'client/core.lua',
	'client/clothing.lua', 
	'client/editable.lua',
	'client/client.lua',
	'client/actionmenu.lua',
	'client/badge.lua',
	'client/boss.lua',
	'client/communation.lua',
	'client/duty.lua',
	'client/evidence.lua',
	'client/fingerprint.lua',
	'client/garage.lua',
	'client/gsr.lua',
	'client/props.lua',
	'client/radar.lua',
	'client/report.lua',
	'client/shop.lua',
}

server_scripts {
	'@oxmysql/lib/MySQL.lua',
	'server/*.lua'
}
ui_page 'html/index.html'
files {
	'html/index.html',
	'html/style.css',
	'html/images/*.png',
	'html/images/*.jpg',
	'html/images/*.webp',
	'html/images/*.svg',
	'html/fonts/*.ttf',	
	'html/fonts/*.otf',
	'html/*.js',	
	'html/*png',
	'html/*jpg',
	'html/*webp',
	'html/images/*.gif',
}

dependency '/assetpacks'

game "gta5"
this_is_a_map 'yes'

dependency '/assetpacks'

dependency '/assetpacks'
dependency '/assetpacks'
dependency '/assetpacks'
dependency '/assetpacks'
dependency '/assetpacks'
dependency '/assetpacks'
dependency '/assetpacks'
