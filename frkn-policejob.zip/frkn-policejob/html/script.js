stationIndex = 0
inventoryPath = "nui://qb-inventory/html/images/"
cloths = []
clothingData = []
nearby = []
myGrade = 0
perms = {}
gradeList = {}
currentMenu = ''
dutyBusy = false
myName = ''
myCid = ''
remotePage = false
saveEvidence = []

let shopState = { currency: "$", ui: {}, categories: [], items: [], currentCat: null };
let cart = {};

$(function () {
    function txt(sel, key) { $(sel).text(Lang.t(key)) }
    function ph(sel, key) { $(sel).attr('placeholder', Lang.t(key)) }
    function html(sel, key) { $(sel).html(Lang.t(key)) }

    txt('.report-header', 'report_title')
    $('.report-header + span, .report-header span').text(Lang.t('police_department'))
    txt('.report-desc', 'report_desc')
    ph('.report-name-input', 'enter_officer_name')
    ph('.report-job-input', 'enter_business_name')
    ph('.report-phone-input', 'enter_phone_number')
    txt('.report-text', 'report_details')
    ph('.report-textarea', 'write_complaint')
    txt('.anon-text', 'anon_name_sent')
    txt('.anon-desc', 'anon_name_sent')
    txt('.owner-signature', 'owner_signature_default')
    txt('.user-signature', 'send_report')

    $('.police-list .item').each(function () { $(this).html('<span style="color:#fff;font-weight:bold;">' + Lang.t('police_clothing') + '</span>') })
    // txt('.clothing-header', 'clothing_title')
    $('#cloth-header').html(Lang.t('clothing_title') + ' <span style="font-family: Monument Extended;background-color: white;color: black;padding: 0.5vh;">' + Lang.t('clothing_store') + '</span>')
    $('.text-desc').html(Lang.t('evidence_desc'))
    // $('.clothing-header span').text(Lang.t('clothing_store'))
    $('.car-desc').html(Lang.t('car_desc'))
    $('.text-xl').html(Lang.t('car_direction'))
    $('.front-plate .text').html(Lang.t('front_plate'))
    $('.back-plate .text').html(Lang.t('back_plate'))
    $('.fronttext').html(Lang.t('front_text'))
    $('.backtext').html(Lang.t('back_text'))
    txt('.clothing-desc', 'clothing_desc')
    $('.clothing-button-list .clothing-button').eq(0).text(Lang.t('police_uniform'))
    $('.clothing-button-list .clothing-button').eq(1).text(Lang.t('my_clothes'))
    $('.clothing-list .clothing-item').each(function () {
        $(this).find('.clothing-name').text(Lang.t('uniform_name'))
        $(this).find('.clothing-category').text(Lang.t('general'))
        $(this).find('.clothing-button').text(Lang.t('btn_select'))
    })
    ph('.save-input', 'scan_or_type')
    txt('.save-button', 'assign_new')

    txt('.vehicle-header', 'vehicle_helicopters_title')
    txt('.vehicle-desc', 'vehicle_desc')
    $('.vehicle-button-list .vehicle-button').eq(0).text(Lang.t('vehicle_category_patrol'))
    $('.vehicle-button-list .vehicle-button').eq(1).text(Lang.t('vehicle_category_helicopters'))
    $('.vehicle-button-list .vehicle-button').eq(2).html('<div class="locked"></div> ' + Lang.t('swat_vans'))
    $('.vehicle-list .vehicle-item').each(function () {
        $(this).find('.vehicle-name').text(Lang.t('general'))
        $(this).find('.vehicle-button').text(Lang.t('vehicle_btn_spawn'))
    })
    txt('.car-name', 'car_name')
    txt('.car-desc', 'car_desc')
    txt('.car-button', 'close')
    $('.car-text').eq(0).text(Lang.t('fuel'))
    $('.car-text').eq(1).text(Lang.t('top_speed'))
    $('.car-text').eq(2).text(Lang.t('damage'))

    $('.list-item').eq(0).find('.title').text(Lang.t('place_count_selection'))
    $('.list-item').eq(0).find('.description').text(Lang.t('place_count_selection_desc'))
    $('.list-item').eq(1).find('.title').text(Lang.t('place'))
    $('.list-item').eq(1).find('.description').text(Lang.t('place_desc'))
    $('.list-item').eq(2).find('.title').text(Lang.t('location'))
    $('.list-item').eq(2).find('.description').text(Lang.t('location_desc'))
    $('.list-item').eq(3).find('.title').text(Lang.t('up_down'))
    $('.list-item').eq(3).find('.description').text(Lang.t('up_down_desc'))
    $('.list-item').eq(4).find('.title').text(Lang.t('rotate_mode'))
    $('.list-item').eq(4).find('.description').text(Lang.t('rotate_mode_desc'))
    $('.mouse-item .title').text(Lang.t('mouse_label'))
    $('.mouse-item .description').text(Lang.t('mouse_desc'))

    $('.action-header .action-sub-header').text(Lang.t('action_department'))
    $('.action-list-item').removeClass('selected')
    $('.action-list-item').eq(0).attr('data-text', Lang.t('action_toggle_on_duty')).find('.action-item-text').text(Lang.t('action_toggle_on_duty'))
    $('.action-list-item').eq(1).attr('data-text', Lang.t('action_view_map')).find('.action-item-text').text(Lang.t('action_view_map'))
    $('.action-list-item').eq(2).attr('data-text', Lang.t('action_call_backup')).find('.action-item-text').text(Lang.t('action_call_backup'))
    $('.action-list-item').eq(3).attr('data-text', Lang.t('action_check_status')).find('.action-item-text').text(Lang.t('action_check_status'))
    $('.action-list-item').eq(4).attr('data-text', Lang.t('action_request_vehicle')).find('.action-item-text').text(Lang.t('action_request_vehicle'))
    $('.action-list-item').eq(5).attr('data-text', Lang.t('action_view_database')).find('.action-item-text').text(Lang.t('action_view_database'))
    $('.action-list-item').eq(6).attr('data-text', Lang.t('action_change_uniform')).find('.action-item-text').text(Lang.t('action_change_uniform'))
    $('.action-list-item').eq(7).attr('data-text', Lang.t('action_end_duty')).find('.action-item-text').text(Lang.t('action_end_duty'))

    txt('.shop-header', 'shop_title')
    $('.shop-system').text(Lang.t('shop_system'))
    txt('.shop-desc', 'shop_desc')
    $('.shop-category-list .shop-category-item').each(function (i) {
        $(this).find('.shop-category-text').text(Lang.t('tab_text', { id: i + 1 }))
    })
    txt('.shop-cart-header', 'your_cart')
    txt('.shop-cart-desc', 'your_cart_desc')
    txt('.shop-total-pay', 'total_pay')
    $('.shop-total-card').contents().filter(function () { return this.nodeType === 3 }).last().replaceWith(' ' + Lang.t('card'))
    $('.shop-total-cash').contents().filter(function () { return this.nodeType === 3 }).last().replaceWith(' ' + Lang.t('cash'))

    txt('.yes-no-box .info', 'yesno_title')
    txt('.yes-no-box .text', 'yesno_text')
    txt('.yes-no-box .yes', 'yes')
    txt('.yes-no-box .no', 'no')

    txt('.notify-header', 'notification')
    txt('.notify-desc', 'notify_purchased')

    txt('.boss-header', 'boss_header')
    txt('.boss-desc', 'boss_desc')
    txt('.boss-view', 'view_reports')
    txt('.boss-add', 'add_officer')
    $('.boss-box').eq(0).find('.boss-box-header').text(Lang.t('budget'))
    $('.boss-box').eq(1).find('.boss-box-header').text(Lang.t('on_duty'))
    $('.boss-box').eq(2).find('.boss-box-header').text(Lang.t('pending_reports'))
    $('.boss-button-list .boss-button').eq(0).text(Lang.t('online'))
    $('.boss-button-list .boss-button').eq(1).text(Lang.t('offline'))
    $('.boss-button-list .boss-button').eq(2).text(Lang.t('nearby_players'))
    $('.boss-action').eq(0).text(Lang.t('promote'))
    $('.boss-action').eq(1).text(Lang.t('demote'))
    $('.balance-desc').text(Lang.t('balance_desc'))
    $('.thead div').eq(0).text(Lang.t('table_name'))
    $('.thead div').eq(1).text(Lang.t('table_rank'))
    $('.thead div').eq(2).text(Lang.t('table_identifier'))
    $('.thead .status').text(Lang.t('table_status'))
    $('.roster-wrap .badge').text(Lang.t('badge_on_duty'))
    txt('.boss-cash', 'cash_register')
    txt('.cash-register-box .header', 'cash_register')
    txt('.balance-text', 'balance')
    $('.cash-register-box .balance-text').eq(1).text(Lang.t('fast_button'))
    $('.deposit-button').text(Lang.t('deposit'))
    $('.withdraw-button').text(Lang.t('withdraw'))
    txt('.perm-roles-box .header', 'permissions')
    $('.perm-list .perm-row').eq(0).find('span').text(Lang.t('hire_staff'))
    $('.perm-list .perm-row').eq(1).find('span').text(Lang.t('promote_demote_staff'))
    $('.perm-list .perm-row').eq(2).find('span').text(Lang.t('view_balance'))
    $('.perm-list .perm-row').eq(3).find('span').text(Lang.t('withdraw_from_register'))
    $('.perm-list .perm-row').eq(4).find('span').text(Lang.t('manage_evidence'))
    $('.perm-list .perm-row').eq(5).find('span').text(Lang.t('view_reports_perm'))
    txt('.boss-report-page .report-header', 'reports_messages')
    txt('.boss-report-page .report-desc', 'reports_messages_desc')
    $('.case-head div').eq(0).text(Lang.t('id'))
    $('.case-head div').eq(1).text(Lang.t('job'))
    $('.case-head div').eq(2).text(Lang.t('phone'))
    $('.case-head div').eq(3).text(Lang.t('report'))
    $('.case-head div').eq(4).text(Lang.t('anonymous_col'))
    $('.case-head .right').text(Lang.t('date_created'))

    txt('.badge-menu .comm-desc-header', 'description_header')
    txt('.badge-menu .comm-desc-text', 'desc_text')
    txt('.rank-box .header', 'rank')
    $('.rank-box').eq(1).find('.header').text(Lang.t('job_label'))
    txt('.current-date', 'current_date')

    txt('.duty-menu .header', 'duty_management')
    $('.status-text').text(Lang.t('off_duty'))
    txt('.duty-box', 'go_on_duty')
    txt('.worker-header', 'worker_list')
    txt('.worker-desc', 'worker_list_desc')
    $('.worker-button').eq(0).text(Lang.t('workers'))
    $('.worker-button').eq(1).text(Lang.t('history'))

    txt('.evidence-menu .header', 'dna_physical')
    txt('.evidence-menu .desc', 'dna_physical_desc')
    $('.button-box .button[data-page="home-page"]').text(Lang.t('home_page'))
    $('.arheader').text(Lang.t('archive').toUpperCase())
    $('.ardesc').text(Lang.t('archive') + ' list')
    $('.analyzing-text').text(Lang.t('analyzing'))
    $('.analyzing-desc').text(Lang.t('analyzing_desc'))
    ph('.search-input', 'search_archive')
    $('.result-button-box .result-button').eq(0).text(Lang.t('start_analysis'))
    $('.result-button-box .result-button').eq(1).text(Lang.t('open_archive'))
    $('#select-text').text(Lang.t('selected_item'))
    txt('.quick-box .header', 'evidence_bag_list')
    txt('.quick-box .desc', 'evidence_bag_desc')
    $('.result-box .header').text(Lang.t('analysis_result'))
    $('.result-box .desc').text(Lang.t('step_2_review'))
    $('.result-box .text').text(Lang.t('no_analysis_selected'))
    $('.scan-button').text(Lang.t('scan_new'))
    $('.searching-text').text(Lang.t('searching'))

    txt('.communication-menu .comm-header', 'communication')
    txt('.communication-menu .comm-desc', 'communication_desc')
    txt('.comm-box .comm-header', 'amount')
    ph('.duration-input', 'amount_placeholder')
    txt('.send-button', 'send')
    txt('.communication-menu .comm-desc-header', 'description_header')
    txt('.communication-menu .comm-desc-text', 'description_text')

    $('.evidencestash-menu .header').html(Lang.t('evidence_header_primary') + ' <span>' + Lang.t('evidence_header_secondary') + '</span>')
    $('.evidencestash-menu .desc').text(Lang.t('evidence_locker_desc'))
    // $('.evidencestash-menu .drawer .badge').each(function () {
    //     var t = $(this).text()
    //     var m = t.match(/#\s*(.*)$/)
    //     var idPart = m ? m[1].trim() : t
    //     $(this).text(Lang.t('evidence_drawer_id_prefix') + idPart)
    // })
    $('.evidencestash-menu .drawer .title').each(function (i) {
        var n = $(this).text().match(/\d+/)
        var idx = n ? n[0] : String(i + 1)
        $(this).text(Lang.t('evidence_drawer_title') + ' ' + idx)
    })
})





window.addEventListener("message", function (e) {
    e = e.data
    // remotePage = false
    switch (e.action) {
        case "openMenu":
            return openMenu(e);
        case "updateLogs":
            return renderLogs(e || []);
        case "shopOpen":
            inventoryPath = e.path
            myGrade = e.grade || 0;
            shopState.currency = e.currency || "$";
            shopState.ui = e.ui || {};
            shopState.categories = Array.isArray(e.categories) ? e.categories : [];
            shopState.items = Array.isArray(e.items) ? e.items : [];
            shopState.currentCat = shopState.categories.length ? shopState.categories[0].id : null;
            $('body, .shop').fadeIn(150).css('display', 'flex');
            cart = {};
            $('.shop-cart-list').empty();
            $('.shop-total-price').text(shopState.currency + '0.00');
            renderCategories();
            renderItemsShop();
            return;
        case "navigate":
            return handleNavigationKey(e.key);
        case "select":
            return handleSelect();
        case "back":
            return handleBack();
        case 'duty_update':
            d = e
            setHeader({ duty: d.duty }, { cid: d.cid, name: d.name })
            dutyState.workers = d.workers || dutyState.workers
            dutyState.history = d.history || dutyState.history
            const activeIsHistory = $('.worker-button.active').text().trim().toLowerCase() === 'history'
            if (activeIsHistory) renderHistoryData(dutyState.history)
            else renderWorkersData(dutyState.workers)
            dutyBusy = false
            return
        case "radar":
            return radarSystem(e);
        case "radar_visible":
            return e.state == true ? $('body, .radar-page').fadeIn(150) : $('body, .radar-page').fadeOut(150);
        case "toggleRemote":
            return toggleRemote();
        case "fingerPrint":
            return fingerPrint(e);
        case "fingerScan":
            return fingerScan(e);
        case "closeMenu":
            return $('body, .pages').fadeOut(150);
        case "closeAction":
            return $('.action-menu').fadeOut(150);
        case "playerLeftVehicle":
            return $('.radar-page , .remote-page').fadeOut(150);
        default:
            return;
    }
});


function openMenu(e) {
    $('body').fadeIn(150).css('display', 'flex')
    $('.' + e.menu).fadeIn(150).css('display', 'flex')
    currentMenu = e.menu
    stationIndex = e.index
    $('.boss-cash-list').empty()

    if (e.menu == 'report-menu') {
        $('.owner-signature').text(e.name || Lang.t('owner_signature_default'))
        $('.report-name-input').val('')
        $('.report-job-input').val('')
        $('.report-phone-input').val('')
        $('.report-textarea').val('')
    } else if (e.menu == 'clothing-menu') {
        cloths = e.cloths || []
        clothingData = e.clothingData || []
        $('.clothing-list').empty()
        $.each(e.cloths, function (index, cloth) {
            let label = cloth.outfitLabel || Lang.t('outfit_label_unknown')
            let data = cloth.outfitData || {}
            let category = Object.keys(data).length > 0 ? Lang.t('category_uniform') : Lang.t('category_general')
            $('.clothing-list').append(`
                <div class="clothing-item" data-index="${index}">
                    <img src="../html/images/clothing-uniform.png" alt="">
                    <div class="clothing-name">${label}</div>
                    <div class="clothing-category">${category}</div>
                    <hr>
                    <div class="clothing-button select-cloth">${Lang.t('btn_select')}</div>
                </div>
            `)
        })
    } else if (e.menu == 'vehicle-menu') {
        let el = $('.vehicle-menu')
        el.fadeIn(150).css('display', 'flex')
        $('.vehicle-button-list').css({ 'width': '100%', 'top': '32%' })
        $('.vehicle-list ,  .vehicle-in-menu hr  , .vehicle-desc').fadeIn(150).css('display', 'flex')
        $('.vehicle-list').css('display', 'grid')
        $('.vehicle-features , .tuning-list').css('display', 'none').fadeOut(150)

        let list = $('.vehicle-list').empty()
        let catsEl = $('.vehicle-button-list').empty()

        let grade = Number(e.grade || 0)
        let raw = e.vehicles || {}
        let items = []
        $.each(raw, function (model, v) {
            let cat = v.category || Lang.t('vehicle_category_patrol')
            let img = (v.customimg && v.customimg.trim() !== "")
                ? v.customimg
                : `https://raw.githubusercontent.com/MericcaN41/gta5carimages/refs/heads/main/images/${model}.png`
            items.push({
                model,
                label: v.label || model,
                ranks: v.ranks || [],
                price: v.price,
                category: cat,
                img: img
            })
        })

        let cats = [...new Set(items.map(i => i.category))]
        let selectedCat = cats[0] || Lang.t('vehicle_category_patrol')

        function renderCats() {
            catsEl.empty()
            $.each(cats, function (_, c) {
                let btn = $(`<div data-vehicle="car" class="vehicle-button">${c}</div>`)
                if (c === selectedCat) {
                    btn.addClass('active').css('opacity', 1)
                } else {
                    btn.css('opacity', 0.7)
                }
                btn.on('click', function () {
                    selectedCat = c
                    catsEl.find('.vehicle-button').removeClass('active').css('opacity', 0.7)
                    $(this).addClass('active').css('opacity', 1)
                    renderList()
                })
                catsEl.append(btn)
            })
        }

        function hasRank(ranks, g) {
            for (let i = 0; i < ranks.length; i++) {
                if (g >= Number(ranks[i])) return true
            }
            return false
        }

        function renderList() {
            list.empty()

            if (selectedCat === Lang.t('vehicle_category_my_cars')) {
                let myCars = e.myCars || [
                    { model: "adder", label: "Bugatti Adder", img: "https://raw.githubusercontent.com/MericcaN41/gta5carimages/refs/heads/main/images/adder.png" },
                    { model: "sultan", label: "Karin Sultan", img: "https://raw.githubusercontent.com/MericcaN41/gta5carimages/refs/heads/main/images/sultan.png" }
                ]
                $.each(myCars, function (_, i) {
                    let it = $(`
                        <div class="vehicle-item" data-model="${i.model}">
                            <img src="${i.img}" alt="">
                            <div class="vehicle-name">${i.label}</div>
                            <div data-vehicle="car" class="vehicle-button">${Lang.t('vehicle_btn_spawn')}</div>
                        </div>
                    `)
                    list.append(it)
                })
                return
            }

            $.each(items.filter(i => i.category === selectedCat), function (_, i) {
                let allowed = hasRank(i.ranks, grade)
                let it = $(`
                    <div class="vehicle-item" data-price="${i.price ?? 0}" data-model="${i.model}">
                        <img src="${i.img}" alt="">
                        <div class="vehicle-name">${i.label}</div>
                        <div data-vehicle="car" class="vehicle-button">${Lang.t('vehicle_btn_buy', { price: i.price ?? 0 })}</div>
                    </div>
                `)
                if (!allowed) {
                    it.addClass('locked-item').css('opacity', 0.5)
                    it.find('.vehicle-button').addClass('disabled')
                }
                list.append(it)
            })
        }

        renderCats()
        renderList()
    } else if (e.menu == 'extra-menu') {
        $('.vehicle-menu , .vehicle-features').fadeIn(150).css('display', 'flex')
        $('.vehicle-button-list').css({ 'width': '84%', 'top': '24%' })
        $('.vehicle-list ,  .vehicle-in-menu hr , .vehicle-desc').fadeIn(150).css('display', 'none')

        let f = e.features || {}
        $('.vehicle-features').fadeIn(150).css('display', 'block')
        if (f.img) $('.car-img').attr('src', f.img)
        $('.car-name').text(f.name || Lang.t('vehicle_label_vehicle'))
        $('.car-desc').text(f.desc || '')

        function setBar(i, val) {
            val = Math.max(0, Math.min(100, Number(val) || 0))
            $('.car-percent').eq(i).text('%' + val)
            $('.car-range').eq(i).find('.car-range-value').css('width', val + '%')
        }

        if (f.img) {
            $('.car-img').attr('src', f.img)
        } else if (f.model) {
            $('.car-img').attr('src', 'https://raw.githubusercontent.com/MericcaN41/gta5carimages/refs/heads/main/images/' + f.model.toLowerCase() + '.png')
        }

        setBar(0, f.fuel)
        setBar(1, f.speed)
        setBar(2, f.damage)

        let cats = e.extras || []
        let catWrap = $('.vehicle-button-list').empty()
        let list = $('.tuning-list').hide().empty()

        function isLocked(cat) {
            return !cat || !Array.isArray(cat.items) || cat.items.length === 0 || cat.locked === true
        }

        function renderCats() {
            $.each(cats, function (_, c) {
                let locked = isLocked(c)
                let btn = $('<div class="vehicle-button"></div>').attr('data-key', c.key).text(c.label || c.key.toUpperCase())
                if (locked) {
                    btn.css('opacity', 0.5)
                    btn.append('<div class="locked"><img src="../html/images/vehicle-lock-icon.svg" alt=""></div>')
                }
                catWrap.append(btn)
            })
        }

        function makeItemRow(name, extra) {
            let row = $('<div class="tuning-item"></div>')
            let nm = $('<div class="tuning-name"></div>').text(name)
            let actTxt = $('<div class="select-item"></div>').text(Lang.t('btn_select'))
            row.append(nm, actTxt)
            if (extra && extra.active) row.addClass('active')
            return row
        }

        function renderItems(catKey) {
            list.empty()
            let cat = (cats || []).find(v => v.key === catKey)
            if (!cat || isLocked(cat)) { list.hide(); return }

            $.each(cat.items || [], function (_, it) {
                if (cat.key === 'extras') {
                    let row = makeItemRow((it.label || ('Extra ' + it.id)), { active: !!it.state })
                    row.attr('data-type', 'extra').attr('data-id', it.id)
                    list.append(row)
                } else if (cat.key === 'liveries') {
                    let row = makeItemRow((it.label || ('Livery ' + it.index)), { active: !!it.current })
                    row.attr('data-type', 'livery').attr('data-index', it.index)
                    list.append(row)
                } else if (cat.key === 'engine') {
                    let row = makeItemRow((it.label || ('x' + it.value)), null)
                    row.attr('data-type', 'engine').attr('data-mult', it.value)
                    list.append(row)
                } else if (cat.key === 'quick') {
                    if (it.type === 'named_extra') {
                        let row = makeItemRow(it.label || it.name, { active: !!it.state })
                        row.attr('data-type', 'named_extra').attr('data-name', it.name).attr('data-id', it.id || '')
                        list.append(row)
                    } else if (it.type === 'siren') {
                        let opts = Array.isArray(it.options) && it.options.length ? it.options : ['toggle', 'on', 'off', 'mute']
                        $.each(opts, function (_, mode) {
                            let row = makeItemRow(Lang.t('siren_label', { mode: String(mode).toUpperCase() }), null)
                            row.attr('data-type', 'siren').attr('data-mode', mode)
                            list.append(row)
                        })
                    } else if (it.type === 'text') {
                        let row = $('<div class="tuning-item"></div>').append($('<div class="tuning-name"></div>').text(it.label || Lang.t('quick_text_info'))).append($('<div class="select-item"></div>').text('—'))
                        row.addClass('disabled')
                        list.append(row)
                    }
                } else if (cat.key === 'colors') {
                    let row = makeItemRow((it.label || it.key), null)
                    row.attr('data-type', 'colors').attr('data-primary', it.primary).attr('data-secondary', it.secondary)
                    list.append(row)
                } else {
                    let row = makeItemRow((it.label || 'Item'), null)
                    row.attr('data-type', 'generic')
                    list.append(row)
                }
            })
            list.fadeIn(150).css('display', 'block')
        }

        function firstSelectableKey() {
            for (let i = 0; i < cats.length; i++) { if (!isLocked(cats[i])) return cats[i].key }
            return null
        }

        renderCats()
        let currentKey = firstSelectableKey()
        if (currentKey) {
            catWrap.find('.vehicle-button[data-key="' + currentKey + '"]').addClass('active')
            renderItems(currentKey)
        } else {
            list.hide()
        }

        $(document).off('click.extraCats').on('click.extraCats', '.vehicle-button-list .vehicle-button', function () {
            if ($(this).find('.locked').length) return
            $('.vehicle-button-list .vehicle-button').removeClass('active')
            $(this).addClass('active')
            currentKey = $(this).data('key')
            renderItems(currentKey)
            if (currentKey === 'liveries') {
                $.post('https://frkn-policejob/camPreset', JSON.stringify({ mode: 'roof' }))
            } else {
                $.post('https://frkn-policejob/camPreset', JSON.stringify({ mode: 'front' }))
            }
        })
        $(document).off('click.extraItems').on('click.extraItems', '.tuning-list .tuning-item', function () {
            if ($(this).hasClass('disabled')) return
            let type = $(this).data('type')

            if (type !== 'livery') {
                $.post('https://frkn-policejob/camPreset', JSON.stringify({ mode: 'front' }))
            }

            if (type === 'extra') {
                let id = Number($(this).data('id'))
                $.post('https://frkn-policejob/toggleExtra', JSON.stringify({ id: id }), function (r) {
                    if (r && r.ok) { $('.tuning-item[data-type="extra"][data-id="' + id + '"]').toggleClass('active') }
                })
            } else if (type === 'named_extra') {
                let name = String($(this).data('name') || '')
                let id = $(this).data('id') !== '' ? Number($(this).data('id')) : null
                $.post('https://frkn-policejob/toggleNamedExtra', JSON.stringify({ name: name, id: id }), function (r) {
                    if (r && r.ok) { $('.tuning-item[data-type="named_extra"][data-name="' + name + '"]').toggleClass('active') }
                })
            } else if (type === 'livery') {
                let index = Number($(this).data('index'))
                $.post('https://frkn-policejob/setLivery', JSON.stringify({ index: index }), function (r) {
                    if (r && r.ok) {
                        $('.tuning-item[data-type="livery"]').removeClass('active')
                        $('.tuning-item[data-type="livery"][data-index="' + index + '"]').addClass('active')
                    }
                })
            } else if (type === 'siren') {
                let mode = String($(this).data('mode'))
                $.post('https://frkn-policejob/siren', JSON.stringify({ mode: mode }))
            } else if (type === 'engine') {
                let mult = Number($(this).data('mult'))
                $.post('https://frkn-policejob/engine', JSON.stringify({ mult: mult }))
            } else if (type === 'colors') {
                let primary = Number($(this).data('primary'))
                let secondary = Number($(this).data('secondary'))
                $.post('https://frkn-policejob/setColor', JSON.stringify({ primary: primary, secondary: secondary }), function (r) {
                    if (r && r.ok) {
                        $('.tuning-item[data-type="color"]').removeClass('active')
                        $('.tuning-item[data-type="color"][data-primary="' + primary + '"][data-secondary="' + secondary + '"]').addClass('active')
                    }
                })
            }
        })

    } else if (e.menu == 'boss-menu') {
        polices = e.polices
        gradeList = e.gradeList
        myCid = e.cid
        myName = e.name

        renderNearby()

        let { cash = 0, bank = 0 } = e.money || {}

        $("#moneyDisplay").html(
            `<span style="color:#fff;">${Lang.t('cash_label')}:</span> <span style="color:#C55728;">$${cash.toLocaleString()}</span> 
            <span style="color:#fff; margin-left:10px;">${Lang.t('bank_label')}:</span> <span style="color:#3498db;">$${bank.toLocaleString()}</span>`
        )

        const name = String(e.name || '').trim().replace(/\s+/g, ' ')
        const parts = name.split(' ')
        let html = ''
        if (parts.length === 2) {
            html = parts[0].toLocaleUpperCase('tr') + ' <span style="font-weight: lighter;">' + parts[1].toLocaleUpperCase('tr') + '</span>'
        } else {
            html = name
        }

        $('.boss-grade').html(e.gradeName)

        const active = (polices && polices.online ? polices.online.length : 0)
        const total = active + (polices && polices.offline ? polices.offline.length : 0)
        $('.police-count').text(`${active}/${total}`)
        $('.report-count').text(`${e && e.reports ? e.reports.length : 0}`)

        renderReports(e.reports || [])

        myGrade = Number(e.grade || 0)
        const grades = (e.grades || []).slice().sort((a, b) => a.grade - b.grade)
        const maxGrade = grades.length ? Number(grades[grades.length - 1].grade) : Number(myGrade)
        perms = Object.fromEntries((e.perms || []).map(p => [String(p.job_grade_id), p]))

        const $roleMenu = $('.role-menu , .hire-menu').empty()
        grades.forEach(g => {
            const dis = g.grade >= myGrade ? ' class="disabled"' : ''
            $roleMenu.append(`<li data-id="${g.id - 1}" data-role="${g.label}" data-grade="${g.grade}"${dis}>${String(g.label || '').toUpperCase()}</li>`)
        })

        let defaultId = grades.find(g => g.grade <= myGrade)?.id ?? (grades[0]?.id || null)
        $roleMenu.find(`li[data-id="${defaultId}"]`).addClass('active')
        $('.role-select .current , .hire-select .current').text($roleMenu.find('li.active').data('role') || '')

        function renderPermsFor(gradeId) {
            const p = perms[String(gradeId)] || {}
            const keys = ['can_hire', 'can_promote', 'can_view_balance', 'can_withdraw', 'can_manage_evidence', 'can_read_report']
            $('.perm-list .perm-row').each(function (i) {
                const v = p[keys[i]]
                const on = v === true || v === 1 || v === '1'
                const $t = $(this).find('.toggle')
                $t.toggleClass('on', on).attr('aria-pressed', on ? 'true' : 'false')
            })
        }

        renderPermsFor(defaultId)

        $(document).off('click.role').on('click.role', '.role-menu li', function () {
            if ($(this).hasClass('disabled')) {
                ShowNotify('BOSS MENU', Lang.t('error_higher_grade'))
                return
            }
            $('.role-menu li').removeClass('active')
            $(this).addClass('active')
            renderPermsFor($(this).data('id'))
            $('.boss-menu .role-menu').slideUp(120)
            $('.role-select .current').text($(this).data('role') || '')
        })

        $(document).off('click.perm').on('click.perm', '.perm-list .perm-row .toggle', function () {
            if ($(this).data('busy')) return

            const active = $('.role-menu li.active')
            const gradeId = Number(active.data('id'))
            const myPerm = perms && perms[String(myGrade)] && (perms[String(myGrade)].can_promote === true || perms[String(myGrade)].can_promote === 1 || perms[String(myGrade)].can_promote === '1')

            if (!myPerm) {
                ShowNotify('BOSS MENU', Lang.t('error_perm_change_denied'))
                return
            }
            if (Number(gradeId) > Number(myGrade)) {
                ShowNotify('BOSS MENU', Lang.t('error_higher_grade'))
                return
            }
        
            const idx = $(this).closest('.perm-row').index()
            const keys = ['can_hire', 'can_promote', 'can_view_balance', 'can_withdraw', 'can_manage_evidence', 'can_read_report']
            const key = keys[idx]
            const next = !$(this).hasClass('on')
            const payload = { job_grade_id: gradeId, key, value: next ? 1 : 0 }
            $(this).data('busy', true)
        
            $.post('https://frkn-policejob/updateGradePerm', JSON.stringify(payload), function (r) {
                if (!r || !r.ok) {
                    ShowNotify('BOSS MENU', Lang.t('error_perm_update_failed', { error: r && r.error ? r.error : Lang.t('error_unknown') }))
                    $('.perm-list .perm-row').each(function (i) {
                        const k = keys[i]
                        const v = perms[String(gradeId)] ? perms[String(gradeId)][k] : 0
                        const on = v === true || v === 1 || v === '1'
                        $(this).find('.toggle').toggleClass('on', on).attr('aria-pressed', on ? 'true' : 'false')
                    })
                } else {
                    perms[String(gradeId)] = r.perm || perms[String(gradeId)] || {}
                    perms[String(gradeId)][key] = payload.value
                    renderPermsFor(gradeId)
                }
                $('.perm-list .perm-row .toggle').data('busy', false)
            })
        })



        renderByPermission({
            selector: '.balance-value, #balance-value',
            perms,
            myGrade,
            permKey: 'can_view_balance',
            source: e.vault,
            matchKey: 'station',
            matchVal: e.index,
            take: 'vault',
            format: v => '$' + (v || 0),
            whenNoPerm: 'hide'
        })

        renderLogs(e)

        setTimeout(() => {
            loadRoster(polices)
        }, 500);


    } else if (e.menu == 'action-menu') {
        $('.boss-menu').css('display', 'none')
        myGrade = e.grade || 0;

        actionMenu(e.actionMenu)
    } else if (e.menu == 'prop-menu') {
        $('.prop-menu').fadeIn(150).css('display', 'flex')
    } else if (e.menu == 'badge-menu') {
        const d = new Date()
        const dd = String(d.getDate()).padStart(2, '0')
        const mm = String(d.getMonth() + 1).padStart(2, '0')
        const yyyy = d.getFullYear()
        $('#badge-date').text(`${dd}-${mm}-${yyyy}`)
        $('#badge-name').text(e.data.name)
        $('#badge-cid').text(e.data.cid)
        $('#badge-grade').text(e.data.grade)
        $('#badge-job').text(e.data.job)
        if (e.data.job == 'sheriff') {
            $('.badge-box img').attr('src', '../html/images/badge-sheriff.png')
            return
        }
        if (e.data.level == 0) {
            $('.badge-box img').attr('src', '../html/images/badge-0.png')
            $('.badge-box img').css({ 'height': '90%', 'top': '5%', 'width': '72%' })
        } else if (e.data.level >= 1) {
            $('.badge-box img').attr('src', '../html/images/badge-1.png')
            $('.badge-box img').css({ 'height': '100%', 'top': '0%', 'width': '72%' })
        } else if (e.data.level >= 4) {
            $('.badge-box img').attr('src', '../html/images/badge-2.png')
            $('.badge-box img').css({ 'height': '70%', 'top': '15%', 'width': '72%' })
        }

    } else if (e.menu == 'duty-menu') {
        d = e
        dutyState.workers = d.workers || { online: [], offline: [] }
        dutyState.history = d.history || { open: null, list: [] }
        startClock()
        setHeader({ duty: d.duty }, { cid: d.cid, name: d.name })
        setActiveTab('workers')
    } else if (e.menu == 'heli-menu') {
        let el = $('.vehicle-menu')

        el.fadeIn(150).css('display', 'flex')
        $('.vehicle-button-list').css({ 'width': '100%', 'top': '32%' })
        $('.vehicle-list ,  .vehicle-in-menu hr  , .vehicle-desc').fadeIn(150).css('display', 'flex')
        $('.vehicle-list').css('display', 'grid')
        $('.vehicle-features , .tuning-list').css('display', 'none').fadeOut(150)

        let list = $('.vehicle-list').empty()
        let catsEl = $('.vehicle-button-list').empty()

        let grade = Number(e.grade || 0)
        let raw = (e.type === 'heli') ? (e.helis || {}) : (e.vehicles || {})
        let items = []
        $.each(raw, function (model, v) {
            let cat = v.category || (e.type === 'heli' ? Lang.t('vehicle_category_helicopters') : Lang.t('vehicle_category_patrol'))
            let img = (v.customimg && v.customimg.trim() !== "")
                ? v.customimg
                : `https://raw.githubusercontent.com/MericcaN41/gta5carimages/refs/heads/main/images/${model}.png`
            items.push({
                model,
                label: v.label || model,
                ranks: v.ranks || [],
                price: v.price,
                category: cat,
                img: img
            })
        })



        let cats = [...new Set(items.map(i => i.category))]
        let selectedCat = cats[0] || (e.type === 'heli' ? Lang.t('vehicle_category_helicopters') : Lang.t('vehicle_category_patrol'))

        function renderCatsHeli() {
            catsEl.empty()
            $.each(cats, function (_, c) {
                let btn = $(`<div data-vehicle="heli" class="vehicle-button">${c}</div>`)
                if (c === selectedCat) {
                    btn.addClass('active').css('opacity', 1)
                } else {
                    btn.css('opacity', 0.7)
                }
                btn.on('click', function () {
                    selectedCat = c
                    catsEl.find('.vehicle-button').removeClass('active').css('opacity', 0.7)
                    $(this).addClass('active').css('opacity', 1)
                    renderList()
                })
                catsEl.append(btn)
            })
        }

        function hasRankHeli(ranks, g) {
            for (let i = 0; i < ranks.length; i++) {
                if (g >= Number(ranks[i])) return true
            }
            return false
        }

        function renderListHeli() {
            list.empty()

            if (selectedCat === Lang.t('vehicle_category_my_cars') || selectedCat === Lang.t('vehicle_category_my_helis')) {
                let myList = (e.type === 'heli')
                    ? (e.myHelis || [{ model: "polmav", label: "Police Maverick", img: "https://raw.githubusercontent.com/MericcaN41/gta5carimages/refs/heads/main/images/polmav.png" }])
                    : (e.myCars || [{ model: "adder", label: "Bugatti Adder", img: "https://raw.githubusercontent.com/MericcaN41/gta5carimages/refs/heads/main/images/adder.png" }])

                $.each(myList, function (_, i) {
                    let it = $(`
                        <div class="vehicle-item" data-model="${i.model}">
                            <img src="${i.img}" alt="">
                            <div class="vehicle-name">${i.label}</div>
                            <div data-vehicle="${e.type === 'heli' ? 'heli' : 'car'}" class="vehicle-button">${Lang.t('vehicle_btn_spawn')}</div>
                        </div>
                    `)
                    list.append(it)
                })
                return
            }

            $.each(items.filter(i => i.category === selectedCat), function (_, i) {
                let allowed = hasRankHeli(i.ranks, grade)
                let it = $(`
                    <div class="vehicle-item" data-price="${i.price ?? 0}" data-model="${i.model}">
                        <img src="${i.img}" alt="">
                        <div class="vehicle-name">${i.label}</div>
                        <div data-vehicle="${e.type === 'heli' ? 'heli' : 'car'}" class="vehicle-button">${Lang.t('vehicle_btn_spawn')}</div>
                    </div>
                `)
                if (!allowed) {
                    it.addClass('locked-item').css('opacity', 0.5)
                    it.find('.vehicle-button').addClass('disabled')
                }
                list.append(it)
            })
        }

        renderCatsHeli()
        renderListHeli()
    } else if (e.menu == 'evidence-menu') {
        var $list = $('.list-container').empty()
        var arr = Array.isArray(e.evidences) ? e.evidences : []
        saveEvidence = e.saveEvidence
        if (!arr.length) return

        $.each(arr, function (i, ev) {
            var t = String(ev.type || '').toLowerCase()
            if (t === 'gsr_impact' || t === 'gsr_shooter') t = 'gunpowder'
            var c = String(ev.container || '').toLowerCase()
            var cLabel = c === 'tube' ? Lang.t('container_tube') : Lang.t('container_bag')
            var typeText = t === 'blood' ? (Lang.t('evidence_blood') + ' ' + cLabel) : (Lang.t('evidence_gunpowder') + ' ' + cLabel)
            var tagText = t === 'blood' ? Lang.t('tag_dna') : Lang.t('tag_physical')

            var $item = $('<div  class="list-item' + (i === 0 ? ' active' : '') + '">' +
                '<div class="info-group">' +
                '<button class="match-button" data-id="' + (ev.evidence_id || '') + '" data-type="' + (t || '') + '">' + typeText + '</button>' +
                '</div>' +
                '<span class="item-type"><span style="color:white;font-size:1.5vh;">#' + (ev.evidence_id || '') + ' </span> ' + tagText + '</span>' +
                '</div>')

            $item.attr('data-id', ev.evidence_id || '')
            $item.attr('data-type', t || '')
            $item.attr('data-container', c)

            var baseMeta = {
                evidence_id: ev.evidence_id || '',
                type: t || '',
                container: c,
                street: ev.street || '',
                created: ev.created || 0
            }

            var meta = t === 'blood'
                ? Object.assign(baseMeta, { citizenid: ev.citizenid || '', victim: ev.victim || '' })
                : Object.assign(baseMeta, { shooter: ev.shooter || '', shot: ev.shot || '' })

            $item.data('meta', meta)
            $item.data('evidence', Object.assign({}, ev, { type: t, container: c }))
            $list.append($item)

            $('.button-box .button[data-page="home-page"]').trigger('click');
            $('.result-button[data-page="start"]').trigger('click');

        })
    } else if (e.menu == 'evidencestash-menu') {
        $('.drawer-wrap').empty()
        $.each(e.list, function (_, v) {
            $('.drawer-wrap').append(`
                <div class="drawer">
                  <div class="badge">#${v.id}</div>
                  <div class="title">${v.name}</div>
                </div>
            `)
        })
    }
}

function showMenu(selector) {
    const el = $(selector)
    el.addClass('active').css({
        display: 'flex',
        opacity: 0,
        transform: 'scale(0.95)'
    })
    setTimeout(() => {
        el.css({
            transition: 'opacity 0.25s ease, transform 0.25s ease',
            opacity: 1,
            transform: 'scale(1)'
        })
    }, 10)
}


let dutyState = { workers: { online: [], offline: [] }, history: { open: null, list: [] } }

function renderWorkersData(data) {
    const online = (data && data.online) || []
    const offline = (data && data.offline) || []
    const grid = $('.contact-grid').empty()

    online.forEach(function (x) {
        grid.append(
            `<div class="contact-item">
                <div class="avatar"><img src="../html/images/boss-avatar.png" alt=""></div>
                <div class="contact-info">
                    <div class="contact-name">${x.name || Lang.t('unknown_name')}</div>
                    <div class="contact-time"><span>●</span><span>${Lang.t('status_online')}</span></div>
                </div>
                <div class="status-icon online"><img src="../html/images/duty-phone.png" alt=""></div>
            </div>`
        )
    })

    offline.forEach(function (x) {
        grid.append(
            `<div class="contact-item">
                <div class="avatar"><img src="../html/images/boss-avatar.png" alt=""></div>
                <div class="contact-info">
                    <div class="contact-name">${x.name || Lang.t('unknown_name')}</div>
                    <div class="contact-time"><span>●</span><span>${Lang.t('status_offline')}</span></div>
                </div>
                <div class="status-icon"><img src="../html/images/duty-phone.png" alt=""></div>
            </div>`
        )
    })
}

function renderHistoryData(h) {
    const grid = $('.contact-grid').empty()
    const open = h.open
    const list = h.list || []

    if (open) {
        grid.append(
            `<div class="contact-item">
                <div class="avatar"><img src="../html/images/boss-avatar.png" alt=""></div>
                <div class="contact-info">
                    <div class="contact-name">${open.name || Lang.t('unknown_name')} • ${open.job || ''}</div>
                    <div class="contact-time"><span>●</span><span>${Lang.t('started_at', { time: open.start_str || '' })}</span></div>
                </div>
                <div class="status-icon online"><img src="../html/images/duty-phone.png" alt=""></div>
            </div>`
        )
    }

    list.forEach(function (s) {
        grid.append(
            `<div class="contact-item">
                <div class="avatar"><img src="../html/images/boss-avatar.png" alt=""></div>
                <div class="contact-info">
                    <div class="contact-name">${s.name || Lang.t('unknown_name')} • ${s.job || ''}</div>
                    <div class="contact-time"><span>${s.start_str || ''} → ${s.stop_str || ''} • ${Number(s.minutes || 0).toFixed(1)} ${Lang.t('minutes_short')}</span></div>
                </div>
                <div class="status-icon"><img src="../html/images/duty-phone.png" alt=""></div>
            </div>`
        )
    })
}

function setHeader(d, { cid, name }) {
    $('.duty-menu .player-name').text(name || Lang.t('unknown_name'))
    $('.duty-menu .cid').text(`#${cid || '-----'}`)
    const on = Number(d.duty) === 1
    $('.status-text').text(on ? Lang.t('status_on_duty') : Lang.t('status_off_duty'))
    $('.status-box img').attr('src', on ? '../html/images/green-dot.svg' : '../html/images/red-dot.svg')
    $('.duty-box').attr('data-duty', on ? 'on' : 'off').text(on ? Lang.t('btn_go_off_duty') : Lang.t('btn_go_on_duty'))
}

function writeTime() {
    const now = new Date()
    const h = String(now.getHours()).padStart(2, '0')
    const m = String(now.getMinutes()).padStart(2, '0')
    $('.duty-time').text(`${h}:${m}`)
}

function startClock() {
    writeTime()
    let body = $('body')
    clearInterval(body.data('dutyInterval'))
    clearTimeout(body.data('dutyKickoff'))
    const now = new Date()
    const ms = (60 - now.getSeconds()) * 1000 - now.getMilliseconds()
    const kickoff = setTimeout(function () {
        writeTime()
        const intv = setInterval(writeTime, 60000)
        body.data('dutyInterval', intv)
    }, ms)
    body.data('dutyKickoff', kickoff)
}

function setActiveTab(tab) {
    $('.worker-button').removeClass('active')
    if (tab === 'history') {
        $('.worker-button[data-tab="history"]').addClass('active')
        if (!$('.worker-button[data-tab="history"]').length) {
            $('.worker-button').filter(function () { return $(this).text().trim().toLowerCase() === Lang.t('tab_history').toLowerCase() }).addClass('active')
        }
        renderHistoryData(dutyState.history)
    } else {
        $('.worker-button[data-tab="workers"]').addClass('active')
        if (!$('.worker-button[data-tab="workers"]').length) {
            $('.worker-button').filter(function () { return $(this).text().trim().toLowerCase() === Lang.t('tab_workers').toLowerCase() }).addClass('active')
        }
        renderWorkersData(dutyState.workers)
    }
}

$(document).off('click.dutyTabs').on('click.dutyTabs', '.duty-menu .worker-button', function () {
    const t = $(this).data('tab') || $(this).text().trim().toLowerCase()
    setActiveTab(t === 'history' || t === Lang.t('tab_history').toLowerCase() ? 'history' : 'workers')
})

function renderByPermission(opts) {
    const permMap = opts.perms || {}
    const myGrade = Number(opts.myGrade || 0)
    const key = String(opts.permKey || '')
    const hasPerm = !!(permMap[String(myGrade)] && (permMap[String(myGrade)][key] === 1 || permMap[String(myGrade)][key] === '1' || permMap[String(myGrade)][key] === true))

    const el = $(opts.selector)
    const placeholder = (opts.placeholder != null) ? String(opts.placeholder) : '-'

    if (!hasPerm) {
        el.show()
        if (opts.disableWhenNoPerm) el.prop('disabled', true).addClass('disabled')
        if (el.is('input,textarea,select')) el.val(placeholder)
        else el.html(placeholder)
        return
    }

    el.show().prop('disabled', false).removeClass('disabled')

    let val = opts.value
    if (val === undefined && Array.isArray(opts.source) && opts.take) {
        const mk = opts.matchKey || 'id'
        const mv = opts.matchVal
        for (let i = 0; i < opts.source.length; i++) {
            const it = opts.source[i] || {}
            if (String(it[mk]) === String(mv)) { val = it[opts.take]; break }
        }
    }

    const out = typeof opts.format === 'function' ? opts.format(val) : val
    if (typeof opts.apply === 'function') {
        opts.apply(el, val, out)
    } else if (out !== undefined) {
        if (el.is('input,textarea,select')) el.val(out)
        else el.html(out)
    }
}




function renderLogs(data) {
    let { cash = 0, bank = 0 } = data.money || {}
    $("#moneyDisplay").html(
        `<span style="color:#fff;">${Lang.t('cash_label')}:</span> <span style="color:#C55728;">$${cash.toLocaleString()}</span> 
         <span style="color:#fff; margin-left:10px;">${Lang.t('bank_label')}:</span> <span style="color:#3498db;">$${bank.toLocaleString()}</span>`
    )
    const $list = $('.boss-cash-list').empty()
    $.each(data.logs || [], function (i, v) {
        $list.append(`
            <div class="boss-cash-list-item">
                <div class="name">${v.name || ''}</div>
                <div class="action">${v.action || ''}</div>
                <div class="count">${fmtAmount(v.amount)}</div>
                <div class="date">${fmtTRDate(v.update_date)}</div>
            </div>
        `)
    })
}

function pad(n){ return String(n).padStart(2,'0') }

function parseTs(ts){
    if (ts == null) return null
    if (ts instanceof Date) return ts
    if (typeof ts === 'number'){
        if (ts > 1e12) return new Date(ts)
        if (ts > 1e9)  return new Date(ts*1000)
    }
    if (typeof ts === 'string'){
        const s = ts.trim()
        const n = Number(s)
        if (!Number.isNaN(n) && s.replace(/\D/g,'').length >= 10){
            if (n > 1e12) return new Date(n)
            if (n > 1e9)  return new Date(n*1000)
        }
        const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/)
        if (m){
            return new Date(+m[1], +m[2]-1, +m[3], +m[4], +m[5], +(m[6]||0))
        }
        const d = new Date(s)
        if (!Number.isNaN(d.getTime())) return d
    }
    return null
}

function fmtDate(ts){
    const d = parseTs(ts) || new Date(0)
    return `<b>${pad(d.getHours())}:${pad(d.getMinutes())}</b> ${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} <img src="../html/images/boss-calendar.svg" alt="">`
}


function renderReports(reports) {
    function esc(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;') }
    const list = $('.case-list').empty()
    $.each(reports || [], function (_, r) {
        const anon = (r.anonymous === 1 || r.anonymous === '1' || r.anonymous === true) ? Lang.t('anonymous') : (r.anonymous || '-')
        const row = $(`
            <div class="case-row" data-message="${esc(r.report) || ''}">
                <div class="id"><span>${r.id ?? '-'}</span></div>
                <div class="job">${esc(r.job)}</div>
                <div class="phone">${esc(r.phone)}</div>
                <div class="report">${esc(r.report)}</div>
                <div class="anon">${esc(anon)}</div>
                <div class="date">${fmtDate(r.created_at)}</div>
            </div>
        `)
        const detail = $(`<div class="case-detail"><div class="msg"></div></div>`)
        list.append(row, detail)
    })
}

$(document).on("mouseenter", ".case-row", function () {
    const row = $(this)
    if (row.find(".delete-btn").length === 0) {
        row.append('<div class="delete-btn">' + Lang.t('delete') + '</div>')
    }
    row.find(".delete-btn").show()
})

$(document).on("mouseleave", ".case-row", function () {
    $(this).find(".delete-btn").hide()
})

$(document).on("click", ".delete-btn", function (e) {
    e.stopPropagation()
    const row = $(this).closest(".case-row")
    const id = row.find(".id span").text().trim()
    showYesNo(Lang.t('confirm_delete_title'), Lang.t('confirm_delete_info', { id: id }), function (ok) {
        if (ok) {
            $.post("https://frkn-policejob/deleteReport", JSON.stringify({ id: id }))
            row.next(".case-detail").remove()
            row.remove()
        }
    })
})

let policeData = { online: [], offline: [] }

function renderRoster(list, mode) {
    const table = $('.roster-wrap .table')
    table.find('.tr').remove()
    $.each(list || [], function (_, v) {
        const name = v.name || '-'
        const rank = v.rank || v.grade || 0
        const callsign = v.identifier || '-'
        let status
        if (mode === 'online') {
            status = (Number(v.onDuty) === 1) ? Lang.t('status_on_duty') : Lang.t('status_off_duty')
        } else {
            status = Lang.t('status_offline')
        }
        table.append(
            `<div class="tr" data-id="${v.identifier || ''}">
                <div class="td name">${name}</div>
                <div class="td rank">${rank}</div>
                <div class="td callsign">${callsign}</div>
                <div class="td status"><span class="badge">${status}</span></div>
            </div>`
        )
    })
}

function loadRoster(polices) {
    policeData = polices || { online: [], offline: [] }
    renderRoster(policeData.online, 'online')
}

function renderNearby() {
    $.post('https://frkn-policejob/getNearbyPlayers', JSON.stringify({}), function (response) {
        if (response && response.ok) {
            let nearby = response.players || []
            const table = $('.roster-wrap .table')
            table.find('.tr').remove()
            $.each(nearby, function (_, v) {
                const name = v.name || '-'
                const rank = (v.rank || v.grade || '-')
                const callsign = v.identifier || '-'
                const status = Lang.t('status_nearby')
                table.append(
                    `<div class="tr" data-id="${v.identifier || ''}">
                        <div class="td name">${name}</div>
                        <div class="td rank">${rank}</div>
                        <div class="td callsign">${callsign}</div>
                        <div class="td status"><span class="badge">${status}</span></div>
                    </div>`
                )
            })
        }
    })
}

let remote = { open: false, frontOn: true, rearOn: true, lockFront: false, lockRear: false, fast: false }

function postOp(op, extra) {
    $.post(`https://frkn-policejob/remote`, JSON.stringify(Object.assign({ op }, extra || {})))
}

function applyRemoteUI() {
    let bFront = $('.grid-layout [data-op="radaron"]')
    let bRear = $('.grid-layout [data-op="radaroff"]')
    let bLF = $('.grid-layout [data-op="lockboth"]')
    let bLR = $('.grid-layout [data-op="unlockboth"]')
    let bFast = $('.grid-layout [data-op="fastmode"]')
    bFront.text(remote.frontOn ? Lang.t('btn_front_on') : Lang.t('btn_front_off')).toggleClass('orange-active', remote.frontOn)
    bRear.text(remote.rearOn ? Lang.t('btn_rear_on') : Lang.t('btn_rear_off')).toggleClass('orange-active', remote.rearOn)
    bLF.text(remote.lockFront ? Lang.t('btn_unlock') : Lang.t('btn_lock')).toggleClass('orange-active', remote.lockFront)
    bLR.text(remote.lockRear ? Lang.t('btn_unlock') : Lang.t('btn_lock')).toggleClass('orange-active', remote.lockRear)
    bFast.text(remote.fast ? Lang.t('fast_mode_on') : Lang.t('fast_mode_off')).toggleClass('orange-active', remote.fast)
}

function initRemote() {
    $('.grid-layout [data-op="radaron"]').off('click').on('click', function () {
        remote.frontOn = !remote.frontOn
        applyRemoteUI()
        postOp(remote.frontOn ? 'front_on' : 'front_off')
    })
    $('.grid-layout [data-op="radaroff"]').off('click').on('click', function () {
        remote.rearOn = !remote.rearOn
        applyRemoteUI()
        postOp(remote.rearOn ? 'rear_on' : 'rear_off')
    })
    $('.grid-layout [data-op="lockboth"]').off('click').on('click', function () {
        remote.lockFront = !remote.lockFront
        applyRemoteUI()
        postOp(remote.lockFront ? 'lockfront' : 'unlockfront')
    })
    $('.grid-layout [data-op="unlockboth"]').off('click').on('click', function () {
        remote.lockRear = !remote.lockRear
        applyRemoteUI()
        postOp(remote.lockRear ? 'lockrear' : 'unlockrear')
    })
    $('.grid-layout [data-op="fastmode"]').off('click').on('click', function () {
        remote.fast = !remote.fast
        applyRemoteUI()
        postOp('fastmode')
    })
    $('.grid-layout [data-op="test"]').off('click').on('click', function () { postOp('test') })
    applyRemoteUI()
}

function toggleRemote() {
    if (!remote.open) {
        if ($('.radar-page').css('display') === 'block') {
            initRemote();
            $('.remote-page, body').css('display', 'flex').hide().fadeIn(150);
            remote.open = true;
            remotePage = true;
        } else {
            $.post('https://frkn-policejob/radarError', JSON.stringify({}));
        }
    } else {
        $.post('https://frkn-policejob/nuiClose', JSON.stringify({}));
        $('.remote-page').fadeOut(150, function() {
            $('.remote-page').hide();
        });
        remote.open = false;
        remotePage = false;
    }
}
window.remote = window.remote || { frontOn: true, rearOn: true }

function radarSystem(data) {
    if (data.menu_visible) {
        $('.radar-page , body').fadeIn(150).css('display', 'flex')
    }
    if (!data) return

    function pad(n) { n = parseInt(n || 0); if (isNaN(n) || n < 0) n = 0; return String(n).padStart(3, '0') }
    function setNum(el, val) {
        val = pad(val)
        el.attr('data-value', val)
        el.find('.overlay').text(val)
        let nodes = el.contents()
        let last = nodes[nodes.length - 1]
        if (!last || last.nodeType !== 3) el.append(document.createTextNode(val))
        else last.nodeValue = val
    }

    let fLive = (data.front && data.front.live) || 0
    let fFast = (data.front && data.front.fast) || 0
    let bLive = (data.back && data.back.live) || 0
    let bFast = (data.back && data.back.fast) || 0
    let patrol = data.patrol || Math.max(fLive, bLive, fFast, bFast)

    let frontPlate = (data.front && (data.front.livePlate || data.front.fastPlate)) || '—'
    let backPlate = (data.back && (data.back.livePlate || data.back.fastPlate)) || '—'
    $('.front-plate .plate-text').text(remote.frontOn ? frontPlate : '—')
    $('.back-plate .plate-text').text(remote.rearOn ? backPlate : '—')

    let slots = { FRONT: 0, BACK: 0 }
    $('.gauge-grid .unit').each(function () {
        let side = $(this).find('.side').text().trim().toUpperCase()
        let num = $(this).find('.number')
        let val = 0
        if (side === 'FRONT') {
            if (!remote.frontOn) val = 0
            else if (slots.FRONT++ === 0) val = fFast
            else val = fLive
        } else if (side === 'BACK') {
            if (!remote.rearOn) val = 0
            else if (slots.BACK++ === 0) val = bFast
            else val = bLive
        }
        setNum(num, val)
    })

    setNum($('.patrol-unit .patrol'), patrol)
}

let baseSize = { w: 35, h: 23 }
let curSize = { w: baseSize.w, h: baseSize.h }

function clampRadar() {
    if (radPos.left < 0) radPos.left = 0
    if (radPos.bottom < 0) radPos.bottom = 0
    if (radPos.left > 100 - curSize.w) radPos.left = 100 - curSize.w
    if (radPos.bottom > 100 - curSize.h) radPos.bottom = 100 - curSize.h
    $('.radar-page').css({ left: radPos.left + '%', bottom: radPos.bottom + '%', width: curSize.w + '%', height: curSize.h + '%' })
}

let radPos = { left: 63, bottom: 4 }

function applyRadarPos() {
    $('.radar-page').css({ left: radPos.left + '%', bottom: radPos.bottom + '%' })
}

$(function () {
    $('#dirRight').off('click').on('click', function () { radPos.left = 55; applyRadarPos() })
    $('#dirDown').off('click').on('click', function () { radPos.bottom = 4; applyRadarPos() })
    $('#dirLeft').off('click').on('click', function () { radPos.left = 2; applyRadarPos() })
    $('#dirUp').off('click').on('click', function () { radPos.bottom = 72; applyRadarPos() })
    applyRadarPos()

    function applySize(v) {
        let p = (v / 100)
        let f = 0.75 + 0.5 * p
        curSize.w = baseSize.w * f
        curSize.h = baseSize.h * f
        clampRadar()
    }

    function fill(el) {
        let min = +el.attr('min') || 0, max = +el.attr('max') || 100, val = +el.val() || 0
        let p = ((val - min) / (max - min)) * 100 + '%'
        el.css('--p', p)
        applySize(val)
    }

    $('.nice-range').each(function () { fill($(this)) })
    $(document).on('input change', '.nice-range', function () { fill($(this)) })

    clampRadar()
})

$(document).on('click', '.fix-size', function () {
    $('.radar-page').css({ width: '35%', height: '25%' })
})

$(document).on('click', '.remote-close-img', function () {
    $('.remote-page').fadeOut(150)
    remote.open = false
    $.post('https://frkn-policejob/close', JSON.stringify({ currentMenu: remotePage }))
})

$(document).on('click', '.roster-wrap .table .tr', function () {
    $('.roster-wrap .table .tr').removeClass('active')
    $(this).addClass('active')
})

$(document).on('click', '.duty-box', function () {
    if (dutyBusy) return
    dutyBusy = true
    $.post('https://frkn-policejob/duty_toggle', JSON.stringify({ toggle: true }))
})

$(document).on('click', '.list-container .list-item', function () {
    $('.list-container .list-item').removeClass('active')
    $(this).addClass('active')
    $('#select-text').html(Lang.t('selected_item_prefix') + ' #' + $(this).attr('data-id'))
})

$(document).on('click', '.button-box .button', function () {
    $('.button-box .button').removeClass('active')
    $(this).addClass('active')
    const page = $(this).data('page')
    if (page == 'home-page') {
        $('.search-input , .upload-box, .result-box .text , .result-box .text-desc , .result-box .scan-button , .result-box img').css({ display: 'grid' })
        $(' .confidence-card , #arch-list, .evidence-card, .button-action-box  , .button-result-box , .analyzing').fadeOut(200)
        $('.result-box').css('display', 'grid !important')
        $('.searching-text').fadeOut(200)
        $('.analyzing-text , .analyzing-desc , .analyzing-img').fadeOut(200)
    }
})

$(document).on("click", ".drawer", function () {
    let drawerId = $(this).find(".badge").text().trim()
    let drawerTitle = $(this).find(".title").text().trim()
    $(".drawer").removeClass("active")
    $(this).addClass("active")
    $('.evidencestash-menu').fadeOut(200)
    $.post("https://frkn-policejob/selectDrawer", JSON.stringify({ id: drawerId, title: drawerTitle }))
})

$(document).on('click', '.scan-button', function () {
    var li = $('.list-container .list-item.active')
    if (!li.length) {
        ShowNotify('EVIDENCE', Lang.t('select_item_first'), 2500, 'error')
        return
    }
    var id = li.data('id') || String(li.find('.item-type span:first').text()).replace('#', '').trim()
    var type = li.data('type') || 'unknown'
    var container = li.data('container') || ''
    var meta = li.data('meta'); if (typeof meta === 'string' && meta.length) { try { meta = JSON.parse(meta) } catch (e) { } }
    var ev = li.data('evidence') || {}
    if (!ev.id && id) ev.id = id
    if (!ev.type && type) ev.type = type
    if (!ev.container && container) ev.container = container
    if (meta && typeof meta === 'object') { for (var k in meta) { if (!(k in ev)) ev[k] = meta[k] } }

    function pad2(n) { return (n < 10 ? '0' : '') + n }
    var created = Number(ev.created) ? new Date(Number(ev.created) * 1000) : new Date()
    var dateStr = pad2(created.getDate()) + '/' + pad2(created.getMonth() + 1) + '/' + created.getFullYear()

    function setField(label, val) {
        $('.evidence-card .ev-row').filter(function () {
            return $(this).find('.ev-label').text().trim() === label
        }).find('.ev-value').text(val || '')
    }

    setField('Evidence ID', '#' + (ev.evidence_id || ''))
    setField('Name', ev.citizenid || ev.victim || '')
    setField('Street', ev.street || '')
    setField('SEX', ev.type || '')
    setField('Nationality', ev.container || '')
    setField('Date', dateStr)

    $('#arch-list , .result-button-box , .upload-box , .search-input , .result-box .text , .result-box .text-desc , .result-box .scan-button , .result-box img').css({ display: 'none' })
    $('.ardesc').html('<span class="working-text">' + Lang.t('working') + '</span>')
    $('.searching-text , .analyzing-text , .analyzing-desc , .analyzing-img').fadeIn(200)
    $('.analyzing-img').addClass('scan-anim')

    let target = $('.searching-text')
    clearInterval(target.data('dotTimer')); clearTimeout(target.data('stopTimer'))
    let base = Lang.t('searching_base'), i = 0
    target.text(base).addClass('animating')
    let t = setInterval(function () {
        i = (i + 1) % 4
        target.text(base + (i ? '.'.repeat(i) : ''))
    }, 400)
    target.data('dotTimer', t)

    let wTarget = $('.working-text')
    clearInterval(wTarget.data('dotTimer')); clearTimeout(wTarget.data('stopTimer'))
    let wbase = Lang.t('working_base'), wi = 0
    wTarget.text(wbase).addClass('animating')
    let wt = setInterval(function () {
        wi = (wi + 1) % 4
        wTarget.text(wbase + (wi ? '.'.repeat(wi) : ''))
    }, 400)
    wTarget.data('dotTimer', wt)

    let stop = setTimeout(function () {
        clearInterval(target.data('dotTimer'))
        clearInterval(wTarget.data('dotTimer'))
        target.removeClass('animating').text(Lang.t('searching_done'))
        wTarget.removeClass('animating').text(Lang.t('working_done'))
        $('.analyzing-img').removeClass('scan-anim')
        $(document).trigger('evidence:search:done')
    }, 4000)
    target.data('stopTimer', stop)
    wTarget.data('stopTimer', stop)

    $('.result-button[data-page="start"]').trigger('click');

})

$(document).on('evidence:search:done', function () {
    $('.searching-text , .list-container .searching-text , .analyzing-text , .analyzing-desc , .analyzing-img').fadeOut(200)
    $('.ardesc').html('<span class="working-text">' + Lang.t('step_1_of_2') + '</span>')

    $('.result-button-box , .search-input  , .result-box , .lastresult , .confidence-card , .evidence-card, .button-action-box  , .button-result-box , .analyzing').fadeIn(200)
    $('.search-input').attr('placeholder', Lang.t('scan_or_type')).val('').fadeIn(200)

    var li = $('.list-container .list-item.active')
    if (!li.length) return

    var meta = li.data('meta') || {}
    if (typeof meta === 'string' && meta.length) { try { meta = JSON.parse(meta) } catch (e) { } }


    $('.upload-box').fadeIn(200)

    t = meta.type

    if (t === 'gsr_impact' || t === 'gsr_shooter') t = 'gunpowder'

    var payload = {
        evidence: {
            evidence_id: meta.evidence_id || '',
            type: t,
            container: String(meta.container || li.data('container') || '').toLowerCase(),
            street: meta.street || '',
            created: Number(meta.created || 0) || 0,
            citizenid: meta.citizenid || '',
            victim: meta.victim || '',
            shooter: meta.shooter || '',
            shot: meta.shot || '',
            memo: $('.cc-memo').val() || ''
        }
    }

    $.post('https://frkn-policejob/saveEvidenceScan', JSON.stringify(payload), function (res) {
        if (!res) return
        if (Array.isArray(res.saveEvidence)) { saveEvidence = res.saveEvidence } else { saveEvidence = [] }
        if (res.ok) {
            $('.ardesc .working-text').text(Lang.t('step_2_of_2'))
            ShowNotify('EVIDENCE', res.msg || Lang.t('saved'), 2000, 'success')
            $('.button-result-box .button-result').prop('disabled', false)
        } else {
            ShowNotify('EVIDENCE', res.msg || Lang.t('error_generic'), 2500, 'error')
            if ((res.code || '').toString() === 'already_scanned') {
                $('.button-result-box .button-result').prop('disabled', true)
            }
        }
    })
})

$(document).on('click', '.button-result', function () {
    var action = $(this).text().trim()
    var li = $('.list-container .list-item.active')
    if (!li.length) {
        ShowNotify('EVIDENCE', Lang.t('select_item_first'), 2500, 'error')
        return
    }

    var meta = li.data('meta') || {}
    if (typeof meta === 'string' && meta.length) { try { meta = JSON.parse(meta) } catch (e) { } }

    var evidence = {
        evidence_id: li.data('id') || meta.evidence_id || '',
        type: meta.type || li.data('type') || '',
        container: meta.container || li.data('container') || '',
        street: meta.street || '',
        created: Number(meta.created || 0) || 0,
        citizenid: meta.citizenid || '',
        victim: meta.victim || '',
        shooter: meta.shooter || '',
        shot: meta.shot || '',
        memo: $('.cc-memo').val() || ''
    }

    if (action === Lang.t('btn_save_evidence')) {
        $.post('https://frkn-policejob/saveEvidenceScan', JSON.stringify(evidence), function (res) {
            if (!res) return
            if (Array.isArray(res.saveEvidence)) { saveEvidence = res.saveEvidence } else { saveEvidence = [] }
            if (res.ok) {
                $('.ardesc .working-text').text(Lang.t('step_2_of_2'))
                ShowNotify('EVIDENCE', res.msg || Lang.t('saved'), 2000, 'success')
                $('.button-result-box .button-result').prop('disabled', false)
            } else {
                ShowNotify('EVIDENCE', res.msg || Lang.t('error_generic'), 2500, 'error')
                if ((res.code || '').toString() === 'already_scanned') {
                    $('.button-result-box .button-result').prop('disabled', true)
                }
            }
        })
    } else if (action === Lang.t('btn_update_analysis')) {
        $.post('https://frkn-policejob/updateEvidenceScan', JSON.stringify({ evidence }), function (res) {
            if (!res) return
            if (Array.isArray(res.saveEvidence)) { saveEvidence = res.saveEvidence } else { saveEvidence = [] }
            if (res.ok) {
                ShowNotify('EVIDENCE', res.msg || Lang.t('updated'), 2000, 'success')
            } else {
                ShowNotify('EVIDENCE', res.msg || Lang.t('error_generic'), 2500, 'error')
            }
        })
    }
})

$(document).on('click', '.result-button', function () {
    const page = $(this).data('page')
    if (page == 'archive') {
        $('#arch-list').css('display', 'grid')
        $('.upload-box').css('display', 'none')
        $('#arch-list').empty()
        $.each(saveEvidence, function (i, v) {
            var item = $('<div class="list-item">' +
                '<div class="info-group">' +
                '<button class="match-button" data-id="' + (v.id || '') + '" data-type="' + (v.type || '') + '">' + Lang.t('match') + '</button>' +
                '<span class="item-id">#' + (v.id || '') + '</span>' +
                '<span class="item-type">' + (v.type || '').toUpperCase() + '</span>' +
                '</div>' +
                '<div class="score-group">' +
                '<span class="item-score">' + (v.street || '') + '</span>' +
                '<span class="arrow-icon">&gt;</span>' +
                '</div>' +
                '</div>')
            item.attr('data-id', v.evidence_id || '')
            item.attr('data-type', v.type || '')
            item.attr('data-container', v.container || '')
            item.data('meta', v)
            $('#arch-list').append(item)
        })
    } else {
        $('#arch-list').css('display', 'none')
        // $('.upload-box').css('display', 'grid')
    }
})

$(document).on('click', '#arch-list .list-item', function () {
    $('.result-box').hide()
    $(this).addClass('active')

    var evidId = $(this).attr('data-id') || ''
    var dataRow = null

    $.each(saveEvidence, function (i, v) {
        if (String(v.evidence_id) === String(evidId) || String(v.id) === String(evidId)) { dataRow = v; return false }
    })
    if (!dataRow) return

    var t = String(dataRow.type || '').toLowerCase()
    if (t === 'gsr_impact' || t === 'gsr_shooter') t = 'gunpowder'
    var c = String(dataRow.container || '').toLowerCase()

    function pad2(n) { return (n < 10 ? '0' : '') + n }
    var ts = Number(dataRow.created) || (Number(dataRow.inserted_at) ? Number(dataRow.inserted_at) / 1000 : 0)
    var d = ts ? new Date(ts * 1000) : new Date()
    var dateStr = pad2(d.getDate()) + '/' + pad2(d.getMonth() + 1) + '/' + d.getFullYear()

    function setFieldByLabel(label, val) {
        var target = null
        $('.evidence-card .ev-row').each(function () {
            var lab = $(this).find('.ev-label').text().replace(/\s+/g, ' ').trim().toLowerCase()
            if (lab === String(label).toLowerCase()) { target = $(this); return false }
        })
        if (target) target.find('.ev-value').text(val || '')
    }

    var nameVal = dataRow.name || dataRow.victim || dataRow.citizenid || dataRow.shooter || dataRow.source_identifier || ''

    setFieldByLabel('Evidence ID', '#' + (dataRow.id || ''))
    setFieldByLabel('Name', nameVal)
    setFieldByLabel('Street', (dataRow.street || '').toUpperCase())
    setFieldByLabel('TYPE', t.toUpperCase())
    setFieldByLabel('CONTAINER', c.toUpperCase())
    setFieldByLabel('Date', dateStr)

    $('.cc-memo').val(dataRow.memo || '')

    $('.searching-text, .analyzing-text, .analyzing-desc, .analyzing-img , .search-evidence , .result-box .text , .result-box .text-desc , .result-box .scan-button').hide()
    $('.result-button-box, .search-input, .lastresult, .confidence-card, .evidence-card, .button-action-box, .button-result-box , .result-box').fadeIn(200)
    $('.upload-box').hide()
    $('.ardesc').html('<span class="working-text">' + Lang.t('step_1_of_2') + '</span>')
    $('.result-button-box .result-button').removeClass('active')
})

function formatMoney(n) { return '$' + new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(Number(n) || 0) }

$(document).off('click.vault').on('click.vault', '.deposit-button, .withdraw-button', function () {
    if ($(this).data('busy')) return
    const type = $(this).hasClass('deposit-button') ? 'deposit' : 'withdraw'
    const amount = getSelectedAmount()
    if (!amount || amount <= 0) { ShowNotify('VAULT', Lang.t('select_valid_amount')); return }

    const msg = (type === 'deposit' ? Lang.t('deposit_prefix') : Lang.t('withdraw_prefix')) + formatMoney(amount) + ' ?'
    const info = Lang.t('station_prefix') + (stationIndex || 1)

    showYesNo(msg, info, function (ok) {
        if (!ok) return
        $('.deposit-button, .withdraw-button').data('busy', true)
        $.post('https://frkn-policejob/vaultTransfer', JSON.stringify({ type, amount, stationIndex }), function (res) {
            if (res && res.ok) {
                if (Number(res.station) === stationIndex) {
                    renderByPermission({
                        selector: '.balance-value, #balance-value',
                        perms, myGrade,
                        permKey: 'can_view_balance',
                        value: res.balance,
                        format: v => formatMoney(v),
                        whenNoPerm: 'hide'
                    })
                }
                $('.money-btn').removeClass('active')
                ShowNotify('VAULT', res.message || Lang.t('tx_completed'))
            } else {
                ShowNotify('VAULT', (res && res.message) || Lang.t('tx_failed'))
            }
            $('.deposit-button, .withdraw-button').data('busy', false)
        })
    })
})

$(document).off('click.money').on('click.money', '.money-btn', function () {
    $('.money-btn').removeClass('active')
    $(this).addClass('active')
})

function getSelectedAmount() {
    const activeBtn = $('.money-btn.active')
    if (activeBtn.length) {
        return Number(activeBtn.text().replace(/[^\d]/g, ''))
    }
    return 0
}

function buildHireUI(gradeList, myGrade, mode) {
    if (mode === 'offline') return ''
    const grades = Object.keys(gradeList || {}).map(k => ({ grade: Number(k), name: String((gradeList[k] && gradeList[k].name) || k).toUpperCase() })).sort((a, b) => a.grade - b.grade)
    const firstAllowed = grades.find(g => g.grade <= Number(myGrade)) || grades[0] || { grade: 0, name: Lang.t('unknown_upper') }
    const items = grades.map(g => {
        const dis = g.grade > Number(myGrade) ? ' class="disabled"' : ''
        const act = g.grade === firstAllowed.grade ? ' active' : ''
        return `<li data-role="${g.name}" data-grade="${g.grade}"${dis}${act}>${g.name}</li>`
    }).join('')
    const head = `
        <div class="hire-select">
            <div class="current">${firstAllowed.name}</div>
            <div class="arrow"></div>
        </div>
        <ul class="hire-menu">${items}</ul>
    `
    if (mode === 'nearby') return head + `<div class="boss-action">${Lang.t('btn_hire')}</div>`
    return head + `
        <div class="boss-action">${Lang.t('btn_rank_update')}</div>
        <div class="boss-action">${Lang.t('btn_fire')}</div>
    `
}

$(document).on('click', '.boss-button-list .boss-button', function () {
    $('.boss-button-list .boss-button').removeClass('active')
    $(this).addClass('active')
    const idx = $(this).index()
    const actionBox = $('.boss-action-list').empty()
    if (idx === 0) {
        renderRoster(policeData.online, 'online')
        actionBox.append(buildHireUI(gradeList, myGrade, 'online'))
    } else if (idx === 1) {
        renderRoster(policeData.offline, 'offline')
        actionBox.empty()
    } else if (idx === 2) {
        renderNearby()
        actionBox.append(buildHireUI(gradeList, myGrade, 'nearby'))
    }
})

$(document).on('click', '.boss-action', function () {
    const action = $(this).text().trim().toUpperCase()
    const tabIdx = $('.boss-button-list .boss-button.active').index()
    if (tabIdx === 1) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('offline_list_block')); return }
    if (tabIdx === 2 && action !== 'HIRE') { ShowNotify(Lang.t('boss_menu_title'), Lang.t('nearby_only_hire')); return }

    const activeEl = $('.hire-menu li.active')
    const targetGrade = Number(activeEl.data('grade') || 0)
    const targetRole = activeEl.data('role') || ''
    const row = $('.roster-wrap .table .tr.active')
    const targetId = row.data('id')
    if (!targetId) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('select_player_first_msg')); return }

    const currentTargetGrade =
        Number(row.data('grade')) ||
        Number((row.find('.td.rank').data('grade'))) ||
        Number((row.find('.td.rank').text() || '').replace(/\D+/g, '')) || 0

    const permsForMe = perms[String(myGrade)] || {}
    const canPromote = permsForMe.can_promote == 1
    const canHire = permsForMe.can_hire == 1

    function refreshRoster() {
        $.post('https://frkn-policejob/getPolices', JSON.stringify({}), function (res) {
            const polices = (res && res.polices) || res || {}
            loadRoster(polices)
            $('.boss-button-list .boss-button').removeClass('active').eq(0).addClass('active')
            $('.boss-action-list').empty().append(buildHireUI(gradeList, myGrade, 'online'))
            $('.boss-menu .hire-menu, .boss-menu .role-menu').slideUp(120)
            $('.roster-wrap .table .tr').removeClass('active')
        })
    }

    if (action === 'RANK UPDATE') {
        if (myCid === targetId) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('cannot_change_own_rank')); return }
        if (!canPromote) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('no_perm_update_ranks')); return }
        if (currentTargetGrade > myGrade) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('cannot_promote_above')); return }
        const payload = { playerId: targetId, grade: targetGrade, role: targetRole }
        $.post('https://frkn-policejob/updatePlayerGrade', JSON.stringify(payload), function (res) {
            if (res && res.ok) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('rank_updated', { role: targetRole })); refreshRoster() }
            else { ShowNotify(Lang.t('boss_menu_title'), Lang.t('failed_update_rank')) }
        })

    } else if (action === 'HIRE') {
        if (myCid === targetId) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('cannot_hire_self')); return }
        if (!canHire) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('no_perm_hire')); return }
        if (targetGrade > myGrade) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('cannot_hire_above')); return }

        const payload = { playerId: targetId, grade: targetGrade, role: targetRole }
        $.post('https://frkn-policejob/hirePlayer', JSON.stringify(payload), function (res) {
            if (res && res.ok) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('player_hired_as', { role: targetRole })); refreshRoster() }
            else { ShowNotify(Lang.t('boss_menu_title'), Lang.t('failed_hire')) }
        })

    } else if (action === 'FIRE') {
        if (myCid === targetId) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('cannot_fire_self')); return }
        if (!canHire) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('no_perm_fire')); return }
        if (currentTargetGrade > myGrade) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('cannot_fire_above')); return }

        const payload = { playerId: targetId }
        $.post('https://frkn-policejob/firePlayer', JSON.stringify(payload), function (res) {
            if (res && res.ok) { ShowNotify(Lang.t('boss_menu_title'), Lang.t('player_fired')); refreshRoster() }
            else { ShowNotify(Lang.t('boss_menu_title'), Lang.t('failed_fire')) }
        })
    }
})


$(document).on('click', '.evidence-menu .close-box , .evidencestash-menu .close-box , .duty-menu .close-box , .boss-close', function () {
    $('.evidence-menu , .evidencestash-menu , .duty-menu , .boss-menu').fadeOut(150);
    close()
})

$(document).on('click', '.vehicle-item .vehicle-button', function () {
    let item = $(this).closest('.vehicle-item');
    let category = $(this).data('vehicle');
    if (item.hasClass('locked-item')) return;
    let model = item.data('model');
    $.post('https://frkn-policejob/buyVehicle', JSON.stringify({ model, price: item.data('price'), category }), function (response) {
        if (response.ok) {
            $('.vehicle-menu').hide();
            close();
        }
    });
});

$(document).on('click', '.one', function () {
    if ($(this).attr('src') === '../html/images/report-icon-notclick.svg') {
        $(this).attr('src', '../html/images/report-icon-click.svg')
        $('.two').attr('src', '../html/images/report-icon-notclick.svg')
        $('.anon-text').text(Lang.t('anon_name_sent'))
    }
})

$(document).on('click', '.two', function () {
    if ($(this).attr('src') === '../html/images/report-icon-notclick.svg') {
        $(this).attr('src', '../html/images/report-icon-click.svg')
        $('.one').attr('src', '../html/images/report-icon-notclick.svg')
        $('.anon-text').text(Lang.t('anonymous_upper_text'))
    }
})

$(document).on('click', '.boss-button', function () {
    $('.boss-button').removeClass('active')
    $(this).addClass('active')
})
$(document).on('click', '.result-button', function () {
    $('.result-button').removeClass('active')
    $(this).addClass('active')
})

$(document).on('click', '.selectcategory', function () {
    $('.selectcategory').removeClass('active')
    $(this).addClass('active')

    if ($(this).data('page') === 'my-clothes') {
        $('.clothing-list').empty()
        clothingData.forEach((item) => {
            $('.clothing-menu .clothing-list').append(`
                <div class="clothing-item" data-index="${item.id}">
                    <img src="../html/images/clothing-uniform.png" alt="">
                    <div class="clothing-name">${item.name}</div>
                    <div class="clothing-category">${Lang.t('category_daily')}</div>
                    <hr>
                    <div class="clothing-button select-cloth">${Lang.t('btn_select')}</div>
                </div>
            `);
        });
    } else if ($(this).data('page') === 'police-uniform') {
        $('.clothing-list').empty()
        cloths.forEach((item, index) => {
            $('.clothing-menu .clothing-list').append(`
                <div class="clothing-item" data-index="${index}">
                    <img src="../html/images/clothing-uniform.png" alt="">
                    <div class="clothing-name">${item.outfitLabel}</div>
                    <div class="clothing-category">${item.category || Lang.t('category_uniform')}</div>
                    <hr>
                    <div class="clothing-button select-cloth">${Lang.t('btn_select')}</div>
                </div>
            `);
        });
    }
})

$(document).on('click', '.select-cloth', function () {
    $('.select-cloth').removeClass('active')
    $(this).addClass('active')

    let index = $(this).closest('.clothing-item').data('index');
    let cloth = cloths[index];

    let activePage = $('.clothing-button.selectcategory.active').data('page');

    if (activePage === 'police-uniform') {
        $.post(`https://frkn-policejob/applyPoliceUniform`, JSON.stringify({
            outfitData: cloth.outfitData,
            outfitLabel: cloth.outfitLabel
        }));
    } else if (activePage === 'my-clothes') {
        let item = clothingData.find(c => c.id === index);
        if (!item) return;

        $.post(`https://frkn-policejob/applyMyClothes`, JSON.stringify({
            id: index,
            name: item.name,
            data: item.data
        }));
    }
});

$(document).on('click', '.vehicle-button', function () {
    $('.vehicle-button').removeClass('active')
    $(this).addClass('active')
})

$(document).on('click', '.vehicle-features .car-button', function () {
    $('.vehicle-menu').fadeOut(150);
    close()
})

function startScroll() {
    let list = $('.clothing-menu .police-list')
    let first = list.find('.item:first')
    first.animate(
        { marginTop: "-=200px" },
        25,
        "linear",
        function () {
            let mt = parseInt($(this).css('marginTop'))
            if (mt < -200) {
                $(this).appendTo(list).css('marginTop', "300%")
            }
            startScroll()
        }
    )
}

$(document).ready(function () {
    startScroll()
})

function isSubmenu(it) { return (it && (it.type === 'submenu' || (Array.isArray(it.items) && it.items.length > 0) || it.dynamic)) }

let selectedIndex = 0
let menuStack = []

let unselectedArrowUrl = '../html/images/action-arrow-notselect.svg'
let selectedArrowUrl = '../html/images/action-arrow-select.svg'
function actionMenu(data) {
    menuStack = [{ title: 'Main', items: data }]
    renderActionList(data)
}

let lastKeyTime = 0;
const FAST_KEY_THRESHOLD = 100;
let scrollAnimation = null;

function handleNavigationKey(key) {
    const rows = $('.action-list-item');
    if (!rows.length) return;
    const currentTime = Date.now();
    const isFastKey = currentTime - lastKeyTime < FAST_KEY_THRESHOLD;
    lastKeyTime = currentTime;
    if (key === 'ArrowDown') {
        navigateDown(rows, isFastKey);
    } else if (key === 'ArrowUp') {
        navigateUp(rows, isFastKey);
    }
}

function navigateDown(rows) {
    const lastIndex = rows.length - 1;
    const wasAtEnd = selectedIndex === lastIndex;
    rows.eq(selectedIndex).removeClass('selected');
    selectedIndex = selectedIndex === lastIndex ? 0 : selectedIndex + 1;
    rows.eq(selectedIndex).addClass('selected');
    updateArrows();
    if (wasAtEnd && selectedIndex === 0) {
        $('.action-list-wrapper').scrollTop(0);
    } else {
        ensureVisibleSmart();
    }
}

function navigateUp(rows, isFastKey) {
    const wasAtStart = selectedIndex === 0
    rows.eq(selectedIndex).removeClass('selected')
    selectedIndex = selectedIndex === 0 ? rows.length - 1 : selectedIndex - 1
    rows.eq(selectedIndex).addClass('selected')
    updateArrows()
    if (wasAtStart && selectedIndex === rows.length - 1) {
        const c = $('.action-list-wrapper')
        const max = Math.max(0, c[0].scrollHeight - c.innerHeight())
        if (isFastKey) c.scrollTop(max)
        else smoothScrollTo(c, max)
    } else {
        ensureVisibleSmart(isFastKey)
    }
}

function ensureVisibleSmart(isFastKey = false) {
    const container = $('.action-list-wrapper');
    const item = $('.action-list-item').eq(selectedIndex);
    if (!container.length || !item.length) return;
    const containerHeight = container.innerHeight();
    const itemHeight = item.outerHeight(true);
    const scrollTop = container.scrollTop();
    const itemPosition = item.position();
    const itemTop = itemPosition.top;
    const itemBottom = itemTop + itemHeight;
    const margin = itemHeight * 0.5;
    let targetScroll;
    if (itemTop < 0) {
        targetScroll = Math.max(0, scrollTop + itemTop - margin);
    } else {
        targetScroll = scrollTop + (itemBottom - containerHeight) + margin;
    }
    if (isFastKey) {
        container.scrollTop(targetScroll);
    } else {
        smoothScrollTo(container, targetScroll);
    }
}

function smoothScrollTo(container, targetScroll) {
    if (scrollAnimation) {
        cancelAnimationFrame(scrollAnimation);
        scrollAnimation = null;
    }
    const startScroll = container.scrollTop();
    const distance = targetScroll - startScroll;
    const duration = 150;
    const startTime = Date.now();
    function animate() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeOut = 1 - Math.pow(1 - progress, 2);
        const currentScroll = startScroll + (distance * easeOut);
        container.scrollTop(currentScroll);
        if (progress < 1) {
            scrollAnimation = requestAnimationFrame(animate);
        } else {
            scrollAnimation = null;
        }
    }
    scrollAnimation = requestAnimationFrame(animate);
}

function updateArrows() {
    $('.action-list-item').each(function () {
        const isSelected = $(this).hasClass('selected');
        const img = isSelected ? selectedArrowUrl : unselectedArrowUrl;
        $(this).find('.action-arrow').html(`<img src="${img}" />`);
    });
}
function renderActionList(items, keepIndex) {
    const wrap = $(`<div class="action-list-wrapper"></div>`);
    $.each(items, function (i, it) {
        const isSelected = (keepIndex ? i === selectedIndex : i === 0);
        const sel = isSelected ? 'selected' : '';
        const arrowUrl = isSelected ? selectedArrowUrl : unselectedArrowUrl;
        const allowed = !(Array.isArray(it.grade)) || it.grade.indexOf(myGrade) !== -1;

        const row = $(`
            <div class="action-list-item ${sel}" data-key="${it.key || ''}" data-type="${it.type || 'item'}">
                <span class="action-item-text">${it.label}</span>
                <span class="action-arrow"><img src="${arrowUrl}" /></span>
            </div>
        `);

        row.data('event', it.event || null);
        row.data('items', it.items || null);
        row.data('dynamic', it.dynamic || '');
        row.data('disabled', !allowed);

        if (!allowed) {
            row.addClass('disabled').css({ opacity: 0.35, pointerEvents: 'none' });
        }

        wrap.append(row);
    });
    $('#main-content').html(wrap);
    if (!keepIndex) {
        selectedIndex = 0;
    }
    $('.action-list-wrapper').scrollTop(0);
}

function ensureVisibleSimple() {
    const container = $('.action-list-wrapper');
    const item = $('.action-list-item').eq(selectedIndex);
    if (!container.length || !item.length) return;
    if (selectedIndex < 5) {
        return;
    }
    const containerHeight = container.innerHeight();
    const itemHeight = item.outerHeight(true);
    const itemTop = item.position().top;
    const itemBottom = itemTop + itemHeight;
    if (itemBottom > containerHeight - itemHeight) {
        container.scrollTop(container.scrollTop() + itemHeight);
    } else if (itemTop < 0) {
        container.scrollTop(container.scrollTop() + itemTop);
    }
}

let _lastEnterTs = 0

function close() {
    $('body , .pages').fadeOut(150)
    $(document).off('keydown.actionmenu')
    remote.open = false
    // Fermer la caméra du vestiaire
    $.post('https://frkn-policejob/closeClothingCam', JSON.stringify({}))
    $.post('https://frkn-policejob/close', JSON.stringify({ currentMenu: currentMenu }))
    $('.action-list-item').removeClass('selected')
    selectedIndex = 0
    _lastEnterTs = 0
    menuStack = []
    scrollAnimation = null;
    lastKeyTime = 0;
    currentMenu = null;
}

function rowHasSubmenu(row) {
    const t = String(row.data('type') || '').toLowerCase()
    if (t === 'submenu') return true
    let its = row.data('items')
    if (typeof its === 'string') { try { its = JSON.parse(its) } catch (_) { } }
    if (Array.isArray(its)) return its.length > 0
    if (its && typeof its === 'object') return Object.keys(its).length > 0
    return false
}


function handleSelect() {
    const rows = $('.action-list-item');
    if (!rows.length) return;
    const row = rows.eq(selectedIndex);
    if (Date.now() - _lastEnterTs < 120) return;
    _lastEnterTs = Date.now();

    if (row.data('disabled')) {
        const msg = (typeof Lang !== 'undefined' && Lang.t) ? Lang.t('not_permission') : 'You do not have permission.';
        ShowNotify('ACTION MENU', msg);
        return;
    }

    const dynamic = row.data('dynamic');
    if (dynamic === 'props_remove') {
        $.post('https://frkn-policejob/menu:select', JSON.stringify({ dynamic: 'props_remove' }));
        $('.action-menu').css('display', 'none');
        return;
    }

    if (rowHasSubmenu(row)) {
        let items = row.data('items');
        if (typeof items === 'string') { try { items = JSON.parse(items) } catch (_) {} }
        menuStack.push({ title: row.find('.action-item-text').text(), items });
        selectedIndex = 0;
        renderActionList(items);
        $('.action-list-wrapper').scrollTop(0);
        return;
    }

    const ev = row.data('event') || {};
    $.post('https://frkn-policejob/menu:select', JSON.stringify({ event: ev }));
    $('.action-menu').css('display', 'none');
}


function handleBack() {
    if (menuStack.length > 1) {
        menuStack.pop()
        selectedIndex = 0
        renderActionList(menuStack[menuStack.length - 1].items)
    } else {
        $('.action-menu').css('display', 'none')
        $.post('https://frkn-policejob/closeAction', JSON.stringify())
    }
}

$('.shop-category-list').on('wheel mousewheel DOMMouseScroll', function (e) {
    e.preventDefault();
    let oe = e.originalEvent;
    let delta = oe.deltaY !== undefined ? oe.deltaY : (oe.wheelDelta !== undefined ? -oe.wheelDelta : oe.detail);
    if (oe.deltaMode === 1) delta *= 16;
    if (oe.deltaMode === 2) delta *= this.clientHeight;
    let speed = 40;
    this.scrollLeft += delta * speed / 100;
});

function keyOf(n, c) { return n + '|' + c }
function toNumber(t) { return parseFloat(String(t).replace(/[^0-9.]/g, '')) || 0 }
function format(n) { return '$' + n.toFixed(2) }

function renderCart() {
    const list = $('.shop-cart-list');
    list.empty();
    Object.values(cart).forEach(it => {
        const subtotal = it.qty * it.price;
        const el = $(`
        <div class="shop-cart-item" data-key="${it.key}">
          <div class="shop-count">${it.qty}x</div>
          <div class="shop-price">${format(subtotal)}</div>
          <div class="shop-name">${it.name} <span style="color: rgba(255, 255, 255, 0.35); font-weight: lighter;font-size:1vh;"> (${it.category})</span></div>
          <div class="shop-plus">+</div>
          <div class="shop-minus">-</div>
          <div class="shop-delete">x</div>
        </div>
      `);
        list.append(el);
    });
    toggleCartScroll();
    updateTotalBox();
}

$(document).on("click", ".send-button", function () {
    let val = $(".duration-input").val().trim();
    if (val === "" || isNaN(val)) return;
    $('.communication-menu').hide()
    close();
    $.post("https://frkn-policejob/communication", JSON.stringify({
        amount: parseInt(val)
    }));
});

$(document).on('click', '.shop-item-select', function () {
    const box = $(this).closest('.shop-item');
    const itemname = box.data('itemname');
    const name = box.find('.shop-item-name').text().trim();
    const category = box.find('.shop-item-category').text().trim();
    const price = toNumber(box.find('.shop-item-price').text());
    const key = keyOf(name, category);
    if (cart[key]) cart[key].qty += 1;
    else cart[key] = { key, name, category, price, qty: 1, itemname };
    renderCart();
    updateTotalBox();
});

$(document).on('click', '.shop-cart-list .shop-plus, .shop-cart-list .shop-minus, .shop-cart-list .shop-delete', function () {
    const item = $(this).closest('.shop-cart-item');
    const key = item.data('key');
    if (!cart[key]) return;
    if ($(this).hasClass('shop-plus')) cart[key].qty += 1;
    else if ($(this).hasClass('shop-minus')) {
        cart[key].qty -= 1;
        if (cart[key].qty <= 0) delete cart[key];
    } else if ($(this).hasClass('shop-delete')) {
        delete cart[key];
    }
    renderCart();
    updateTotalBox();
});

$(document).on('click', '.shop-category-item', function () {
    const id = $(this).data('id');
    shopState.currentCat = id;
    $('.shop-category-item').removeClass('active');
    $(this).addClass('active');
    renderItemsShop();
});

$(document).on('click', '.shop-close', function () {
    $('.shop').fadeOut(150);
    close()
});

function renderCategories() {
    const box = $('.shop-category-list');
    box.empty();
    $.each(shopState.categories, function (_, c) {
        const el = $(`<div class="shop-category-item" data-id="${c.id}"><div class="shop-category-text">${c.label}</div></div>`);
        if (c.id === shopState.currentCat) el.addClass('active');
        box.append(el);
    });
}

function renderItemsShop() {
    const list = $('.shop-item-list');
    list.empty();
    const data = shopState.currentCat
        ? shopState.items.filter(x => x.category === shopState.currentCat)
        : shopState.items;
    $.each(data, function (_, v) {
        let imgSrc = v.image && v.image !== ""
            ? `../html/images/${v.image}`
            : inventoryPath + (v.itemName || 'default') + '.png';
        let isDisabled = v.grade > myGrade ? 'disabled' : '';
        const el = $(`
          <div class="shop-item ${isDisabled}" data-itemName="${v.itemName}" data-id="${v.id}">
            <div class="shop-item-img">
                <img src="${imgSrc}" alt="">
            </div>
            <div class="shop-item-name">${v.name}</div>
            <div class="shop-item-category">${(shopState.categories.find(c => c.id === v.category) || {}).label || v.category}</div>
            <div class="shop-item-price">${shopState.currency}${Number(v.price).toFixed(2)}</div>
            <div class="shop-item-desc">${v.desc || ''}</div>
            <div class="shop-item-select">${Lang.t('btn_select')}</div>
          </div>
        `);
        list.append(el);
    });
}

function updateTotalBox() {
    let total = 0;
    $('.shop-cart-item').each(function () {
        let priceText = $(this).find('.shop-price').text();
        let price = parseFloat(priceText.replace(/[^0-9.]/g, '')) || 0;
        total += price;
    });
    $('.shop-total-price').text(total.toLocaleString(undefined, { minimumFractionDigits: 2 }) + '$');
}

$(document).on('mouseenter', '.shop-total-card:not(.disabled)', function () {
    $(this).find('img').attr('src', '../html/images/shop-card-active.svg');
    $(this).css({
        color: '#C55728',
        background: 'rgba(217, 217, 217, 0.09)'
    });
}).on('mouseleave', '.shop-total-card:not(.disabled)', function () {
    $(this).find('img').attr('src', '../html/images/shop-card.svg');
    $(this).css({
        color: '',
        background: ''
    });
});

$(document).on('mouseenter', '.shop-total-cash:not(.disabled)', function () {
    $(this).find('img').attr('src', '../html/images/shop-cash-active.svg');
    $(this).css({
        color: '#C55728',
        background: 'rgba(217, 217, 217, 0.09)'
    });
}).on('mouseleave', '.shop-total-cash:not(.disabled)', function () {
    $(this).find('img').attr('src', '../html/images/shop-cash.svg');
    $(this).css({
        color: '',
        background: ''
    });
});

function toggleCartScroll() {
    let cartEl = $('.shop-cart-list');
    if (cartEl.children('.shop-cart-item').length === 0) {
        cartEl.css('overflow', 'hidden');
    } else {
        cartEl.css('overflow', 'hidden scroll');
    }
}

toggleCartScroll();

$(document).on('DOMSubtreeModified', '.shop-cart-list', function () {
    toggleCartScroll();
});

function getCartData() {
    let items = [];
    let total = 0;
    Object.values(cart).forEach(it => {
        let subtotal = it.qty * it.price;
        total += subtotal;
        items.push({
            id: it.key,
            itemName: it.itemname,
            name: it.name,
            category: it.category,
            price: it.price,
            qty: it.qty,
            subtotal: subtotal
        });
    });
    return { items: items, total: total };
}

$(document).on('click', '.shop-total-card:not(.disabled)', function () {
    let cartData = getCartData();
    $.post('https://frkn-policejob/payWithCard', JSON.stringify(cartData), function (response) {
        if (response.ok) {
            ShowNotify(Lang.t('notify_title_success'), response.message || Lang.t('notify_default_success'));
        } else {
            ShowNotify(Lang.t('notify_title_error'), response.message || Lang.t('notify_default_error'));
        }
    });
});

$(document).on('click', '.shop-total-cash:not(.disabled)', function () {
    let cartData = getCartData();
    $.post('https://frkn-policejob/payWithCash', JSON.stringify(cartData), function (response) {
        if (response.ok) {
            ShowNotify(Lang.t('notify_title_success'), response.message || Lang.t('notify_default_success'));
        } else {
            ShowNotify(Lang.t('notify_title_error'), response.message || Lang.t('notify_default_error'));
        }
    });
});

function notify(type, customMessage) {
    let title = '';
    let message = customMessage || '';
    switch (type) {
        case 'success':
            title = Lang.t('notify_title_success');
            if (!message) message = Lang.t('notify_default_success');
            break;
        case 'error':
            title = Lang.t('notify_title_error');
            if (!message) message = Lang.t('notify_default_error');
            break;
        case 'info':
            title = Lang.t('notify_title_info');
            if (!message) message = Lang.t('notify_default_info');
            break;
        default:
            title = Lang.t('notify_title_info');
            if (!message) message = Lang.t('notify_default_generic');
            break;
    }
    const notifyHtml = `
    <div class="notify ${type}">
      <div class="notify-title">${title}</div>
      <div class="notify-message">${message}</div>
    </div>
  `;
    const notifyEl = $(notifyHtml);
    $('.notify-container').append(notifyEl);
    notifyEl.on('click', function () {
        $(this).remove();
    });
    setTimeout(function () {
        notifyEl.remove();
    }, 5000);
}

$(document).on('click', '.user-signature', function () {
    let name = $('.report-name-input').val().trim();
    let job = $('.report-job-input').val().trim();
    let phone = $('.report-phone-input').val().trim();
    let report = $('.report-textarea').val().trim();
    let requiredFields = [
        { el: $('.report-name-input'), val: name },
        { el: $('.report-job-input'), val: job },
        { el: $('.report-phone-input'), val: phone },
        { el: $('.report-textarea'), val: report }
    ];
    let hasEmpty = false;
    requiredFields.forEach(field => {
        if (!field.val) {
            hasEmpty = true;
            field.el.addClass('shake');
            setTimeout(() => field.el.removeClass('shake'), 300);
        }
    });
    if (hasEmpty) return;
    let anonymous = $('.two').attr('src').includes('report-icon-click');
    let data = {
        name: name,
        job: job,
        phone: phone,
        report: report,
        anonymous: anonymous
    };
    $('.report-menu').hide()
    $.post(`https://frkn-policejob/reportSubmit`, JSON.stringify(data));
    ShowNotify(Lang.t('report_title'), Lang.t('report_submitted_success'), 2000);
    setTimeout(() => {
        close();
    }, 2000);
});

$(document).on('click', '.clothing-menu .save-button', function () {
    let input = $('.clothing-menu .save-input');
    let val = input.val().trim();
    if (val === "") {
        input.addClass('shake');
        setTimeout(() => input.removeClass('shake'), 300);
        return;
    }
    $.post('https://frkn-policejob/saveClothing', JSON.stringify({ name: val }), function (response) {
        if (response.ok) {
            clothingData = response.clothing;
            input.val('');
            ShowNotify(Lang.t('clothing_title'), Lang.t('clothing_saved_success'), 1500);
            let activePage = $('.clothing-button.selectcategory.active').data('page');
            if (activePage === 'my-clothes') {
                $('.clothing-menu .clothing-list').empty();
                $.each(response.clothing, function (_, cloth) {
                    let label = cloth.name || Lang.t('outfit_label_unknown');
                    let category = cloth.outfitData ? Lang.t('category_uniform') : Lang.t('category_general');
                    $('.clothing-list').append(`
                        <div class="clothing-item" data-index="${cloth.id}">
                            <img src="../html/images/clothing-uniform.png" alt="">
                            <div class="clothing-name">${label}</div>
                            <div class="clothing-category">${category}</div>
                            <hr>
                            <div class="clothing-button select-cloth">${Lang.t('btn_select')}</div>
                        </div>
                    `);
                });
            }
        } else {
            notify('error', response.message);
        }
    });
});

$(document).off('contextmenu.cloth').on('contextmenu.cloth', '.clothing-item', function (e) {
    e.preventDefault()
    if ($('.selectcategory.active').data('page') !== 'my-clothes') return
    $('.cloth-menu').remove()
    let id = Number($(this).data('index'))
    let menu = $(`
        <div class="cloth-menu" data-id="${id}">
            <div class="cloth-delete">${Lang.t('delete')}</div>
        </div>
    `)
    $('body').append(menu)
    menu.css({
        position: 'absolute',
        left: e.pageX,
        top: e.pageY,
        zIndex: 9999,
        padding: '8px 10px',
        borderRadius: '8px',
        background: 'rgba(0,0,0,0.85)',
        color: '#fff',
        boxShadow: '0 6px 18px rgba(0,0,0,0.35)',
        fontSize: '12px',
        userSelect: 'none'
    })
    menu.find('.cloth-delete').css({ cursor: 'pointer', padding: '6px 10px' }).hover(
        function () { $(this).css({ background: 'rgba(255,255,255,0.08)' }) },
        function () { $(this).css({ background: 'transparent' }) }
    )
})

$(document).off('click.clothmenu').on('click.clothmenu', function (e) {
    if (!$(e.target).closest('.cloth-menu').length) $('.cloth-menu').remove()
})

$(window).off('scroll.clothmenu').on('scroll.clothmenu', function () {
    $('.cloth-menu').remove()
})

$(document).off('keydown.clothmenu').on('keydown.clothmenu', function (e) {
    if (e.key === 'Escape') $('.cloth-menu').remove()
})

$(document).off('click.clothdelete').on('click.clothdelete', '.cloth-menu .cloth-delete', function (e) {
    e.stopPropagation()
    let menu = $(this).closest('.cloth-menu')
    let id = Number(menu.data('id'))
    menu.remove()
    $.post('https://frkn-policejob/deleteClothing', JSON.stringify({ id }), function (res) {
        if (res && res.ok) {
            if (Array.isArray(res.clothing)) clothingData = res.clothing
            $(`.clothing-item[data-index="${id}"]`).remove()
            ShowNotify(Lang.t('clothing_title'), Lang.t('clothing_deleted_success'), 1200)
        } else {
            ShowNotify(Lang.t('clothing_title'), (res && res.message) || Lang.t('clothing_delete_failed'), 2000)
        }
    })
})

$(document).on('click', '.boss-menu .role-select', function () {
    $('.boss-menu .role-menu').slideToggle(120)
})

$(document).on('click', '.boss-menu .role-menu li', function () {
    $('.boss-menu .role-menu li').removeClass('active')
    $(this).addClass('active')
    $('.boss-menu .role-select .current').text($(this).data('role'))
    $('.boss-menu .role-menu').slideUp(120)
})

$(document).on('click', function (e) {
    if (!$(e.target).closest('.boss-menu .role-select, .boss-menu .role-menu').length) {
        $('.boss-menu .role-menu').slideUp(120)
    }
})

$(document).on('click', '.boss-menu .hire-select', function () {
    $('.boss-menu .hire-menu').slideToggle(120)
})

$(document).on('click', '.boss-menu .hire-menu li', function () {
    $('.boss-menu .hire-menu li').removeClass('active')
    $(this).addClass('active')
    $('.boss-menu .hire-select .current').text($(this).data('role'))
    $('.boss-menu .hire-menu').slideUp(120)
})

$(document).on('click', function (e) {
    if (!$(e.target).closest('.boss-menu .role-select, .boss-menu .role-menu').length) {
        $('.boss-menu .role-menu').slideUp(120)
    }
    if (!$(e.target).closest('.boss-menu .hire-select, .boss-menu .hire-menu').length) {
        $('.boss-menu .hire-menu').slideUp(120)
    }
})

$(document).on('click', '.boss-menu .case-row', function () {
    const row = $(this)
    const next = row.next('.case-detail')
    $('.boss-menu .case-row').not(row).removeClass('active')
    $('.boss-menu .case-detail').not(next).slideUp(140)
    row.toggleClass('active')
    next.find('.msg').text(row.data('message') || '')
    next.stop(true, true).slideToggle(140)
})

$(document).off('click.bossView').on('click.bossView', '.boss-menu .boss-view', function () {
    const action = String($(this).data('action') || '')
    if (action === 'view_reports') {
        const g = Number(myGrade || 0)
        const map = perms && perms[String(g)]
        const ok = !!(map && (map.can_read_report === 1 || map.can_read_report === '1' || map.can_read_report === true))
        if (!ok) { ShowNotify(Lang.t('reports_title'), Lang.t('no_perm_view_page')); return }
    }
    $('.boss-menu .boss-view, .boss-menu .boss-add').removeClass('active')
    $(this).addClass('active')
    $('.boss-menu .boss-main-page').hide()
    $('.boss-menu .boss-report-page').show()
})

$(document).on('click', '.boss-menu .boss-add', function () {
    $('.boss-menu .boss-view, .boss-menu .boss-add').removeClass('active')
    $(this).addClass('active')
    $('.boss-menu .boss-report-page').hide()
    $('.boss-menu .boss-main-page').show()
})

$(document).on('click', '.selection-box .off-button', function (e) {
    e.preventDefault(); e.stopPropagation()
    let btn = $(this), box = btn.closest('.selection-box')
    let txt = btn.prev('.off-text')
    let val = (btn.data('val') || txt.text().trim().toLowerCase())
    let col = txt.css('color')
    box.find('.off-button').removeClass('active')
    box.find('.off-text').removeClass('active')
    btn.addClass('active').css('--c', col)
    txt.addClass('active')
    box.data('value', val)
    $(document).trigger('selection:changed', { value: val, color: col })
})

function ShowNotify(header, desc, duration = 2000) {
    // Önce var olan bildirimi kapat
    if ($('.notify-box').length > 0) {
        $('.notify-box').stop(true, true).remove()
    }

    const box = $(`
      <div class="notify-box" style="top:-21%; display:none;">
        <div class="top-colored"></div>
        <img src="../html/images/report-top-bg.svg" class="top-bg" alt="">
        <img src="../html/images/notify-megaphone.svg" class="megaphone" alt="">
        <div class="notify-range"><div class="range"></div></div>
        <div class="notify-header">${header}</div>
        <div class="notify-desc">${desc}</div>
      </div>
    `)

    $('body').append(box)

    box.fadeIn(200).css('display', 'flex')
    box.animate({ top: '0%' }, 400, 'swing')

    box.find('.range').css({ width: '100%' }).animate(
        { width: '0%' },
        {
            duration: duration,
            easing: 'linear',
            complete: function () {
                box.fadeOut(400, function () {
                    $(this).remove()
                })
            }
        }
    )
}


function showYesNo(message, info, cb) {
    $('.yes-no-box').remove()
    const box = $(`
    <div class="yes-no-box">
      <div class="yesno">
        <img src="../html/images/yesno-top.svg" alt="">
        <div class="info">${info || ''}</div>
        <div class="text">${message || ''}</div>
        <div class="yes">${Lang.t('yes')}</div>
        <div class="no">${Lang.t('no')}</div>
      </div>
    </div>
  `).appendTo('body')
    box.fadeIn(200).css('display', 'flex')
    box.find('.yes').on('click', function () { cb(true); box.fadeOut(200, () => box.remove()) })
    box.find('.no').on('click', function () { cb(false); box.fadeOut(200, () => box.remove()) })
}

function fmtTRDate(d) {
    if (d == null) return ''
    if (typeof d === 'number') {
        if (d < 1e12) d = d * 1000
        return new Intl.DateTimeFormat('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(d))
    }
    const s = String(d).trim()
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
        const [y, m, day] = s.split('-').map(Number)
        return new Intl.DateTimeFormat('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(y, m - 1, day))
    }
    const n = Number(s)
    if (!Number.isNaN(n)) return fmtTRDate(n)
    const dt = new Date(s)
    return Number.isNaN(dt.getTime()) ? s : new Intl.DateTimeFormat('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(dt)
}

function fmtAmount(n) {
    const x = Number(String(n).replace(/[^\d-]/g, '')) || 0
    return new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(x)
}

$(document).on('keydown', function (e) {
    if (e.key === "Escape" || e.keyCode === 27) {
        if ($('.remote-page').css('display') === 'flex') return
        if (remotePage) remotePage = false
        close()
    }
})

$(document).on('keydown', function (e) {
    if (currentMenu == 'clothing-menu') {
        switch (e.key) {
            case "ArrowLeft": $.post(`https://frkn-policejob/cameraRotate`, JSON.stringify({ direction: "left" })); break
            case "ArrowRight": $.post(`https://frkn-policejob/cameraRotate`, JSON.stringify({ direction: "right" })); break
            case "ArrowUp": $.post(`https://frkn-policejob/cameraHeight`, JSON.stringify({ direction: "up" })); break
            case "ArrowDown": $.post(`https://frkn-policejob/cameraHeight`, JSON.stringify({ direction: "down" })); break
            default: break
        }
    }
})

var _rafFinger = null, _rafScan = null

function runFingerBoxScan() {
    var box = $('.fingerscan-box')
    var line = box.find('.fingerscan-line')
    var glow = box.find('.scan-glow')
    var svg = box.find('svg')
    var overlay = svg.find('path[fill^="url("]')
    if (!box.length || !line.length || !glow.length || !svg.length || !overlay.length) { return }
    var h = box.height()
    if (!h) { setTimeout(runFingerBoxScan, 50); return }
    var topMin = 0.06 * h
    var topMax = 0.88 * h
    var y = topMin
    var dir = 1
    var speed = 0.3
    cancelAnimationFrame(_rafFinger)
    function step() {
        var curH = box.height()
        if (curH && curH !== h) {
            h = curH
            topMin = 0.06 * h
            topMax = 0.88 * h
            if (y < topMin) y = topMin
            if (y > topMax) y = topMax
        }
        y += dir * speed
        if (y >= topMax) { y = topMax; dir = -1 }
        if (y <= topMin) { y = topMin; dir = 1 }
        var t = (y - topMin) / (topMax - topMin)
        var op = 0.13 + (1.0 - 0.13) * t
        line.css('top', y + 'px')
        glow.css({ top: (y - glow.height() / 2) + 'px', opacity: 0.4 + 0.4 * t })
        overlay.attr('fill-opacity', op.toFixed(3))
        _rafFinger = requestAnimationFrame(step)
    }
    _rafFinger = requestAnimationFrame(step)
}

function runSimpleScan() {
    var box = $('.scan-box')
    var line = box.find('.scan-line')
    var svg = box.find('svg')
    var overlay = svg.find('rect[fill^="url("]')
    if (!box.length || !line.length || !svg.length || !overlay.length) { return }
    var h = box.height()
    if (!h) { setTimeout(runSimpleScan, 50); return }
    var topMin = 0.06 * h
    var topMax = 0.88 * h
    var y = topMin
    var dir = 1
    var speed = 0.3
    cancelAnimationFrame(_rafScan)
    function step() {
        var curH = box.height()
        if (curH && curH !== h) {
            h = curH
            topMin = 0.06 * h
            topMax = 0.88 * h
            if (y < topMin) y = topMin
            if (y > topMax) y = topMax
        }
        y += dir * speed
        if (y >= topMax) { y = topMax; dir = -1 }
        if (y <= topMin) { y = topMin; dir = 1 }
        var t = (y - topMin) / (topMax - topMin)
        var op = 0.13 + (1.0 - 0.13) * t
        line.css('top', y + 'px')
        overlay.attr('fill-opacity', op.toFixed(3))
        _rafScan = requestAnimationFrame(step)
    }
    _rafScan = requestAnimationFrame(step)
}

function stopScans() { cancelAnimationFrame(_rafFinger); cancelAnimationFrame(_rafScan) }

$(function () {
    $('.back-button img').on('mouseenter', function () {
        let src = $(this).attr('src')
        if (!src.includes('-hover')) {
            let n = src.replace('.svg', '-hover.svg')
            $(this).attr('src', n)
        }
    }).on('mouseleave', function () {
        let src = $(this).attr('src')
        let n = src.replace('-hover.svg', '.svg')
        $(this).attr('src', n)
    })
})

$(document).on('click', '#finger-report-list', function () {
    $('.finger-report-detail').fadeOut(250)
    $('.finger-history-page').fadeIn(250).css('display', 'flex')
})

$(document).on('click', '#finger-history-back', function () {
    $('.finger-history-page').fadeOut(250)
    $('.finger-main-page').fadeIn(250).css('display', 'flex')
})

$(document).on('click', '#open-history', function () {
    $('.finger-main-page').fadeOut(250)
    $('.finger-history-page').fadeIn(250).css('display', 'flex')
})

$(document).on('click', '.view', function () {
    $('.finger-history-page').fadeOut(250)
    $('.finger-report-detail').fadeIn(250).css('display', 'flex')
})

$(document).on('click', '#new-scan', function () {
    $.post('https://frkn-policejob/startFingerScan', JSON.stringify({}), function (response) {
        if (response == false) { ShowNotify(Lang.t('fingerprint_title'), Lang.t('no_scanner'), 2500); return }
        stopScans()
        $('.finger-main-page').fadeOut(250)
        $('.finger-scan-page').fadeIn(250).css('display', 'flex')
        var p = (Array.isArray(response) ? response[1] : response) || {}
        var nm = String(p.name || '').trim().split(/\s+/)
        var first = nm[0] || ''
        var last = nm.slice(1).join(' ') || ''
        var list = $('.fingerprint-history-list')
        list.find('.finger-history-item:eq(0) span').text(p.identifier || '')
        list.find('.finger-history-item:eq(1) span').text(first)
        list.find('.finger-history-item:eq(2) span').text(last)
        list.find('.finger-history-item:eq(3) span').text(p.job || '')
        addScanRecord({ identifier: p.identifier || '', name: p.name || '', job: p.job || '', id: p.id || p.serverId || '' })
        $('body, .fingerprint-page, .finger-scan-page').css('display', 'flex').hide().fadeIn(250, function () {
            if ($(this).hasClass('finger-scan-page')) {
                setTimeout(function () { runFingerBoxScan(); runSimpleScan() }, 10)
                setTimeout(function () {
                    stopScans()
                    setScanReportData(p)
                    $('.finger-main-page, .finger-history-page, .finger-scan-page, .finger-report-detail').css('display', 'none')
                    $('.finger-report-detail').fadeIn(250).css('display', 'flex')
                }, 5000)
            }
        })
    })
})

function setScanReportData(p) {
    var nm = String(p.name || '').trim().split(/\s+/)
    var first = nm[0] || ''
    var last = nm.slice(1).join(' ') || ''
    var list = $('.finger-report-detail .fingerprint-history-list')
    list.empty()

    const rows = [
        { label: "Identifier", value: p.identifier || '' },
        { label: "First Name", value: first },
        { label: "Last Name", value: last },
        { label: "Job Name", value: p.job || '' },
    ]

    rows.forEach(function (r) {
        var item = $(
            `<div class="finger-history-item">
                <div class="name">${r.label} : <span>${r.value}</span></div>
             </div>`
        )
        list.append(item)
    })
}


$(document).on('click', '#home-page', function () {
    $('.finger-main-page').fadeIn(250).css('display', 'flex')
    $('.finger-history-page').fadeOut(250)
    $('.finger-report-detail').fadeOut(250)
    $('.finger-scan-page').fadeOut(250)
})

function fingerScan(data, duration, callback) {
    stopScans()
    $('.finger-main-page, .finger-history-page, .finger-scan-page, .finger-report-detail').css('display', 'none')
    $('body, .fingerprint-page, .finger-scan-page').css('display', 'flex').hide().fadeIn(250, function () {
    $('.finger-scan-page .back-button').fadeOut(250)

        if ($(this).hasClass('finger-scan-page')) {
            setTimeout(function () { runFingerBoxScan(); runSimpleScan() }, 10)
            _stopTimer = setTimeout(function () {
                stopScans()
                $('.fingerprint-page').fadeOut(250)
                $('.finger-scan-page .back-button').fadeOut(250)
                if (typeof callback === 'function') callback()
            }, duration || 5000)
        }
    })
}

function fingerPrint(data) {
    stopScans()
    setScanReportData(data || {})
    $('.finger-main-page, .finger-history-page, .finger-scan-page, .finger-report-detail').css('display', 'none')
    $('body, .fingerprint-page, .finger-main-page').css('display', 'flex').hide().fadeIn(150)
    $('.finger-scan-page .back-button').fadeIn(250)
}

const FINGER_HISTORY_KEY = "fingerHistory"

function getHistory() {
    let data = localStorage.getItem(FINGER_HISTORY_KEY)
    try { return data ? JSON.parse(data) : [] } catch (e) { return [] }
}

function saveHistory(list) {
    localStorage.setItem(FINGER_HISTORY_KEY, JSON.stringify(list))
}

function addScanRecord(player) {
    let list = getHistory()
    list.push(player)
    saveHistory(list)
    renderHistory()
}

function renderHistory() {
    let list = getHistory()
    let box = $('.finger-history-page .fingerprint-history-list')
    box.empty()
    list.forEach(function (p, i) {
        var item = $(`
      <div class="finger-history-item" data-index="${i}">
        <div class="name">${p.name || p.identifier || Lang.t('unknown_name')}</div>
        <div class="view">${Lang.t('view_label')}</div>
      </div>
    `)
        box.append(item)
    })
}

$(document).on('click', '.finger-history-item', function () {
    selectedIndex = $(this).data('index')
    $('.finger-history-item').removeClass('active')
    $(this).addClass('active')
})

$(document).on('click', '.back-button img[alt=""] , .back-button img[src*="fingerprint-trash.svg"]', function () {
    if (selectedIndex === null) {
        ShowNotify(Lang.t('fingerprint_title'), Lang.t('no_selection') || 'No item selected!', 2000)
        return
    }

    let list = getHistory()
    if (list[selectedIndex]) {
        list.splice(selectedIndex, 1)
        saveHistory(list)
        renderHistory()
        selectedIndex = null
    }
})


$(document).on('click', '.finger-history-item .view', function () {
    var index = $(this).closest('.finger-history-item').data('index')
    let list = getHistory()
    var player = list[index]
    if (!player) return
    var nm = String(player.name || '').trim().split(/\s+/)
    var first = nm[0] || ''
    var last = nm.slice(1).join(' ') || ''
    var detail = $('.finger-report-detail .fingerprint-history-list')
    detail.find('.finger-history-item:eq(0) span').text(player.identifier || '')
    detail.find('.finger-history-item:eq(1) span').text(first)
    detail.find('.finger-history-item:eq(2) span').text(last)
    detail.find('.finger-history-item:eq(3) span').text(player.job || '')
    $('.finger-main-page, .finger-history-page, .finger-scan-page, .finger-report-detail').hide()
    $('.finger-report-detail').fadeIn(250).css('display', 'flex')
    $('.finger-history-item').removeClass('selected')
    $(`.finger-history-item[data-index="${index}"]`).addClass('selected')
})

$(document).on('click', '.finger-history-page .back-button img[alt=""]', function () {
    var selected = $('.finger-history-item.selected')
    var idx = selected.data('index')
    if (typeof idx !== 'undefined') {
        let list = getHistory()
        list.splice(idx, 1)
        saveHistory(list)
        renderHistory()
    }
})

$(function () { renderHistory() })
