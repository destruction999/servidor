

local Translations = {
    error = {
        not_enough_bank = "Solde bancaire insuffisant pour effectuer cette action !",
        not_enough_cash = "Pas assez d'argent liquide pour effectuer cette action !",
        not_permission = "Vous n'avez pas la permission d'effectuer cette action !",
        not_found = "La ressource demandée n'a pas été trouvée !",
        self_update = "Vous ne pouvez pas modifier votre propre grade !",
        setjob_failed = "Échec de l'attribution du métier !",
        target_offline = "Le joueur ciblé est hors ligne !",

        vehicle_tint = "Le véhicule a des vitres teintées.",
        not_in_vehicle = "Vous ne pouvez pas effectuer cette opération dans le véhicule !",
        not_car_distance = "Aucune voiture trouvée à proximité !",

        restricted_weapon = "Vous ne pouvez pas braquer avec cette arme !",
        need_weapon = "Vous devez avoir une arme en main.",
        target_not_ready = "La personne doit avoir les mains en l'air ou être morte.",
        none_nearby = "Personne à proximité.",
        canceled = "Action annulée.",
        not_cuffed_dead = "La personne doit être menottée ou morte.",
        not_cuffed = "La personne doit être menottée.",
        cant_cut = "Vous ne pouvez pas couper.",
        break_out = "Vous vous êtes libéré des menottes.",
        where_looking = "Où regardez-vous ?",
        already_cuffed = "La personne est déjà menottée.",
        notitem_cuff = "Vous n'avez pas de menottes.",
        notitem_uncuff = "Vous n'avez pas de clé pour déverrouiller les menottes.",
        vehicle_cuff = "Vous ne pouvez pas menotter quelqu'un dans un véhicule.",
        target_not_cuffed = "La personne n'est pas menottée.",
        target_already_cuffed = "La personne est déjà menottée.",
        none_nearby_gsr = "Personne à proximité pour tester.",
        none_nearby_community = "Personne à proximité pour communiquer.",
        only_police = "Cette commande ne peut être utilisée que par les forces de l'ordre.",
        cancel_wash = "Vous avez quitté l'eau trop tôt et n'avez pas lavé les résidus de poudre.",
        gsr_negative = "Négatif : Aucun résidu de poudre trouvé sur cette personne.",

        no_player = "Aucun joueur trouvé.",
        communityservice_max = "Le service communautaire maximum est de %{value}. Vous ne pouvez pas entrer plus.",
        community_empty = "Veuillez entrer une valeur valide.",
        garage = "Vous ne pouvez pas modifier cette voiture.",
        communation_warning = "Vous ne pouvez pas vous échapper. Votre service communautaire a été prolongé.",
        report_cooldown = "Vous pourrez soumettre un nouveau rapport dans %{minutes} minutes.",
        vehicle_already_owned = "Vous possédez déjà ce véhicule.",

        front_no_data = "Aucune donnée avant.",
        rear_no_data = "Aucune donnée arrière.",

        already_scanned = "Cette preuve a déjà été scannée !",
        invalid_data = "Données de preuve invalides !",
        db_insert_failed = "Erreur de base de données lors de la sauvegarde de la preuve !",

        need_evidence_tube = "Vous avez besoin d'un tube à preuves vide pour collecter le sang.",
        need_evidence_bag = "Vous avez besoin d'un sachet à preuves vide pour collecter cette preuve.",

        not_in_police_vehicle = "Vous devez être dans un véhicule de police pour utiliser cette fonction.",

        invalid_id = "Vous avez entré un ID invalide",

        db_update_failed = "Échec de la mise à jour des données !",

        radar_not_active = "Vous devez d'abord allumer le radar.",

        not_authorized = "Vous n'êtes pas autorisé à utiliser ce menu.",

        spawn_occupied = "Il n'y a pas de place disponible pour faire apparaître le véhicule.",

        not_on_duty = "Vous devez être en service pour utiliser cette fonction.",
        not_in_community = "Le joueur n'est pas en service communautaire.",

        cuff_position = "Vous ne pouvez pas déverrouiller les menottes de quelqu'un dans cette position.",
        heli_pad_occupied = "L'héliport est actuellement plein.",

    },
    success = {
        paid_cash = "Paiement en espèces effectué avec succès !",
        paid_card = "Paiement par carte effectué avec succès !",
        vehicle_buy = "Véhicule acheté avec succès !",
        vault = "Transaction du coffre réussie !",

        vehicle_tint = "Il n'y a pas de vitres teintées sur le véhicule.",
        vehicle_tint_removed = "Film des vitres retiré.",
        vehicle_locked_success = "La serrure du véhicule a été déverrouillée.",

        robbery_success = "Vous avez fouillé la personne avec succès.",
        robbing = "Quelqu'un vous fouille",
        parking_violation = "Vous avez violé le règlement de stationnement.",
        pd_impound = "Le véhicule a été mis en fourrière.",
        uncuffed = "Vous avez été démenotté.",
        cuffed_player = "Vous avez menotté le joueur.",

        wash_gsr = "Vous avez lavé tous les résidus de poudre dans l'eau.",
        gsr_positive = "Positif : Des résidus de poudre ont été trouvés sur cette personne.",

        engine_power_set = "Puissance du moteur réglée à %{mult}x.",
        vehicle_rented = "Le véhicule a été loué.",

        front_locked = "Vitesse avant verrouillée.",
        front_unlocked = "Verrouillage avant libéré.",
        rear_locked = "Vitesse arrière verrouillée.",
        rear_unlocked = "Verrouillage arrière libéré.",
        fast_on = "Mode rapide activé.",
        fast_off = "Mode rapide désactivé.",

        scan_saved = "Le scan de preuve a été sauvegardé avec succès !",
        scan_updated = "L'analyse de preuve a été mise à jour !",

        picked_blood = "Échantillon de sang collecté.",
        picked_evidence = "Preuve collectée.",

        community_finished_self = "Vous avez terminé votre service communautaire.",
        community_finished_other = "Service communautaire terminé pour %{name}.",
        no_alcohol_detected = "Aucun alcool détecté chez le joueur.",

    },
    general = {
        report_interact = "Ouvrir le menu des rapports",
        armory_interact = "Ouvrir l'armurerie",
        clothes_interact = "Changer de vêtements",
        garage_interact = "Ouvrir le garage",
        extrasmenu_interact = "Ouvrir le menu des extras",
        boss_interact = "Accéder au menu patron",
        duty_interact = "Prendre/Quitter le service",
        heli_interact = "Prendre l'hélicoptère",
        heli_return = "Rendre l'hélicoptère",
        evidence_interact = "Ouvrir le menu des preuves",
        evidencestash_interact = "Ouvrir le stockage des preuves",
        personstash_interact = "Ouvrir le stockage personnel",
        vehCategory_quick = "Rapide",
        vehCategory_extras = "Extras",
        vehCategory_liveries = "Livrées",
        vehCategory_tuning = "Moteur",
        vehCategory_colors = "Couleurs",
        transaction_cancelled = "Transaction annulée",

        vehicle_tint_control = "Contrôler les vitres teintées",
        vehicle_tint_remove = "Retirer le film des vitres",
        vehicle_doorlock = "Forcer la serrure",

        robbing = "La fouille a commencé...",
        progbar_impound = "Mise en fourrière en cours...",
        progbar_tuning = "Tuning du véhicule...",

        tuning_status = "Moteur : %{engine} | Carrosserie : %{body} | Turbo : %{turbo} | Freins : %{brakes} | Transmission : %{transmission} | Suspension : %{suspension}",
        turbo_on = "Installé",
        turbo_off = "Non installé",
        mod_upgraded = "Amélioré",
        mod_stock = "D'origine",

        wash_gsr = "Lavage des résidus de poudre...",
        gsr_checking = "Test GSR en cours...",

        liqour_progress = "Boire de l'alcool...",
        alcohol = "Sent l'alcool",
        heavy_alcohol = "Sent fortement l'alcool",

        community_remaining = "Service communautaire restant : ~g~%{count} ~s~",
        community_prompt = "[E] Nettoyer",
        community_completed = "Vous avez terminé votre service communautaire",
        community_progress_cleaning = "Nettoyage en cours...",
        community_progress_gardening = "Jardinage en cours...",

        remote_open = "Télécommande ouverte.",
        radar_off = "Radar éteint.",

        community_ended = "Le service communautaire est terminé.",

        community_started = "Vous avez commencé un service communautaire et reçu %{count} pénalités.",
        cuffed_walk = "Vous êtes menotté.",
        cuff = "Vous êtes menotté.",

        take_blood = "~r~E~s~ Prendre le sang (Tube)",
        take_fragment = "~b~E~s~ Prendre le fragment (Sachet)",
        take_gsr = "~y~E~s~ Prendre GSR (Sachet)",

    }
}

Lang = Lang or Locale:new({
    phrases = Translations,
    warnOnMissing = true
})

