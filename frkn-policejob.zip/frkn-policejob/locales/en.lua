

local Translations = {
    error = {
        not_enough_bank = "Not enough bank balance to complete this action!",
        not_enough_cash = "Not enough cash to complete this action!",
        not_permission = "You do not have permission to perform this action!",
        not_found = "The requested resource was not found!",
        self_update = "You cannot update your own grade!",
        setjob_failed = "Failed to set job!",
        target_offline = "Target player is offline!",

        vehicle_tint = "The vehicle has window tinting.",
        not_in_vehicle = "You cannot perform this operation in the vehicle!",
        not_car_distance = "No car found nearby!",

        restricted_weapon = "You cannot rob with this weapon!",
        need_weapon = "You must have a weapon in your hand.",
        target_not_ready = "The person must have their hands up or be dead.",
        none_nearby = "No one nearby.",
        canceled = "Action canceled.",
        not_cuffed_dead = "The person must be handcuffed or dead.",
        not_cuffed = "The person must be handcuffed.",
        cant_cut = "You cannot cut.",
        break_out = "You got out of handcuffs.",
        where_looking = "Where are you looking?",
        already_cuffed = "The person is already handcuffed.",
        notitem_cuff = "You do not have a handcuff item.",
        notitem_uncuff = "You do not have a key to unlock handcuffs.",
        vehicle_cuff = "You cannot handcuff someone in a vehicle.",
        target_not_cuffed = "The person is not handcuffed.",
        target_already_cuffed = "The person is already handcuffed.",
        none_nearby_gsr = "No one nearby to test.",
        none_nearby_community = "No one nearby to communicate with.",
        only_police = "This command can only be used by law enforcement.",
        cancel_wash = "You left the water too early and did not wash off the gunshot residue.",
        gsr_negative = "Negative: No gunshot residue found on this person.",

        canceled = "Action canceled.",
        no_player ="No such player was found.",
        communityservice_max = "Maximum community service is %{value}. You cannot enter more than this.",
        community_empty = "Please enter a valid value.",
        garage = "You cannot modify this car..",
        communation_warning = "You can't escape. Your community service has been extended.",
        report_cooldown = "You can submit a report again in %{minutes} minutes.",
        vehicle_already_owned = "You already own this vehicle.",

        front_no_data = "No front data.",
        rear_no_data = "No rear data.",

        already_scanned = "This evidence has already been scanned!",
        invalid_data = "Invalid evidence data!",
        db_insert_failed = "Database error while saving evidence!",

        need_evidence_tube = "You need an empty evidence tube to collect blood.",
        need_evidence_bag  = "You need an empty evidence bag to collect this evidence.",

        not_in_police_vehicle = "You must be in a police vehicle to use this feature.",

        invalid_id = "You entered an invalid ID",

        db_update_failed = "Failed to update the data!",

        radar_not_active = "You must turn on the radar first.",

        not_authorized = "You are not authorized to use this menu.",

        spawn_occupied = "There is no available space to spawn the vehicle.",

        not_on_duty = "You must be on duty to use this feature.",
        not_in_community = "The player is not in community service.",

        cuff_position = "You can't unlock someone's handcuffs in this position.",
        heli_pad_occupied = "The helipad is currently full.",

    },
    success = {
        paid_cash = "Paid with cash successfully!",
        paid_card = "Paid with card successfully!",
        vehicle_buy = "Vehicle purchased successfully!",
        vault = "Vault transaction successful!",

        vehicle_tint = "There is no window tinting on the vehicle.",
        vehicle_tint_removed = "Window film removed.",
        vehicle_locked_success = "The vehicle lock has been unlocked.",

        robbery_success = "You successfully search the person.",
        robbing = "Someone is searching you",
        parking_violation = "You have violated parking regulations.",
        pd_impound = "The vehicle has been impounded.",
        uncuffed = "You have been uncuffed.",
        cuffed_player = "You have cuffed the player.",

        wash_gsr = "You washed off all the gunshot residue in the water.",
        gsr_positive = "Positive: Gunshot residue was found on this person.",

        engine_power_set = "Engine power set to %{mult}x.",
        vehicle_rented = "The vehicle has been rented.",

        front_locked = "Front speed locked.",
        front_unlocked = "Front lock released.",
        rear_locked = "Rear speed locked.",
        rear_unlocked = "Rear lock released.",
        fast_on = "Fast Mode enabled.",
        fast_off = "Fast Mode disabled.",

        scan_saved = "Evidence scan has been successfully saved!",
        scan_updated = "Evidence analysis has been updated!",

        picked_blood    = "Blood sample collected.",
        picked_evidence = "Evidence collected.",

        community_finished_self = "You have finished your community service.",
        community_finished_other = "Community service finished for %{name}.",
        no_alcohol_detected = "No alcohol was found in the player.", 

    },
    general = {
        report_interact       = "Open Report Menu",
        armory_interact       = "Open Armory",
        clothes_interact      = "Change Clothes",
        garage_interact       = "Open Garage",
        extrasmenu_interact   = "Open Extras Menu",
        boss_interact         = "Access Boss Menu",
        duty_interact         = "Toggle Duty",
        heli_interact         = "Get Helicopter",
        heli_return           = "Return Helicopter",
        evidence_interact     = "Open Evidence Menu",
        evidencestash_interact= "Open Evidence Storage",
        personstash_interact  = "Open Personal Storage",
        vehCategory_quick = "Quick",
        vehCategory_extras = "Extras",
        vehCategory_liveries = "Liveries",
        vehCategory_tuning = "Engine",
        vehCategory_colors = "Colors",
        transaction_cancelled = "Transaction canceled",

        vehicle_tint_control = "Control window tinting",
        vehicle_tint_remove = "Window film removal",
        vehicle_doorlock = "The door lock is breaking",

        robbing = "The search for the superior began...",
        progbar_impound = "Impounding vehicle...",
        progbar_tuning = "Tuning vehicle...",

        tuning_status = "Engine: %{engine} | Body: %{body} | Turbo: %{turbo} | Brakes: %{brakes} | Transmission: %{transmission} | Suspension: %{suspension}",
        turbo_on = "Installed",
        turbo_off = "Not Installed",
        mod_upgraded = "Upgraded",
        mod_stock = "Stock",

        wash_gsr = "Washing off GSR...",
        gsr_checking = "Performing GSR Test...",

        liqour_progress = "Drinking liquor...",
        alcohol = 'Smells like alcohol',
        heavy_alcohol = 'Smells very much like alcohol',

        community_remaining = "Remaining community service: ~g~%{count} ~s~",
        community_prompt = "[E] Clean",
        community_completed = "You have completed your community service",
        community_progress_cleaning = "Cleaning...",
        community_progress_gardening = "Working on gardening...",

        remote_open = "Remote Control opened.",
        radar_off = "Radar turned off.",

        community_ended = "Community service has ended.",

        community_started = "You started a community service and received %{count} penalties.",
        cuffed_walk = "You are handcuffed.",
        cuff = "You are handcuffed.",

            take_blood = "~r~E~s~ Take Blood (Tube)",
    take_fragment = "~b~E~s~ Take Fragment (Bag)",
    take_gsr = "~y~E~s~ Take GSR (Bag)",
 
    }
}

Lang = Lang or Locale:new({
    phrases = Translations,
    warnOnMissing = true
})

