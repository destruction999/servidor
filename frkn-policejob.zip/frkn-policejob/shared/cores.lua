-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Cores = {
    {
        Name = "ESX",
        ResourceName = "es_extended",
        GetFramework = function() return exports.es_extended:getSharedObject() end
    },
    {
        Name = "QBCore",
        ResourceName = "qb-core",
        GetFramework = function() return exports['qb-core']:GetCoreObject() end
    },
    {
        Name = "QBX",
        ResourceName = "qbx_core",
        GetFramework = function() return exports.qbx_core end
    }
}
