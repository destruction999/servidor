-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

FRKN = {
	ServerCallbacks = {},

    language = "en", 

    Interaction = {
        Target = 'ox_target', 
    },

    BotToken = "", -- (opcional) token de bot de Discord

    Inventory = "ox_inventory", 

    VehicleTableName = "owned_vehicles", 

    Coords = {
        Report = {
            {
                name = "report_pd_1",
                coords = vector4(486.02, -1005.98, 21.95, 116.22),
                jobs = {},
                distance = 1.5,
                icon = "fas fa-clipboard-list",
                marker = { enabled = true, type = 2, scale = 0.7, z = 0.5, color = { r = 255, g = 255, b = 0, a = 180 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 180.0 }
            },
        },
        Armory = {
            {
                name = "armory_pd_1",
                coords = vector4(462.59, -999.81, 30.59, 280.01),
                jobs = { "police" },
                distance = 1.5,
                icon = "fas fa-warehouse",
                marker = { enabled = false, type = 1, scale = 0.6, z = 0.5, color = { r = 0, g = 180, b = 255, a = 180 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 90.0 }
            },
        },
        Clothes = {
            {
                name = "clothes_pd_1",
                coords = vector4(453.34, -999.69, 29.30, 355.1),
                jobs = { "police" },
                distance = 2.0,
                icon = "fas fa-tshirt",
                marker = { enabled = true, type = 1, scale = 0.6, z = 0.5, color = { r = 180, g = 255, b = 180, a = 180 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 270.0 }
            },
        },
        Garage = {
            {
                name = "garage_pd_1",
                coords = vector4(457.68, -981.85, 21.93, 90.70),
                jobs = { "police"},
                spawnCoords = vector4(439.9452, -1019.5364, 28.7177, 93.5490),
                distance = 4.0,
                icon = "fas fa-car",
                marker = { enabled = true, type = 36, scale = 0.9, z = 0.5, color = { r = 255, g = 120, b = 120, a = 180 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 180.0 }
            },
            {
                name = "garage_pd_2",
                coords = vector4(444.8105, -1015.2521, 28.5985, 256.4282),
                jobs = { "police", "ambulance" },
                spawnCoords = vector4(447.6108, -1024.0791, 28.6043, 210.7899),
                distance = 3.0,
                icon = "fas fa-car",
                marker = { enabled = false, type = 36, scale = 0.9, z = 0.5, color = { r = 255, g = 120, b = 120, a = 180 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 180.0 }
            },
        },
        ExtrasMenu = {
            {
                name = "extras_pd_1",
                coords = vector4(431.4452, -1026.2278, 28.9135, 33.7235),
                jobs = { "police" },
                distance = 2.0,
                icon = "fas fa-tools",
                marker = { enabled = false, type = 27, scale = 0.6, z = 0.5, color = { r = 255, g = 140, b = 0, a = 180 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 0.0 }
            },
        },
        BossMenu = {
            {
                name = "boss_pd_1",
                coords = vector4(455.55, -998.96, 35.17, 2.83),
                jobs = { "police" },
                distance = 2.0,
                icon = "fas fa-crown",
                marker = { enabled = true, type = 25, scale = 0.6, z = 0.5, color = { r = 200, g = 120, b = 255, a = 180 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 45.0 }
            },
        },
        DutySystem = {
            {
                name = "duty_pd_1",
                coords = vector4(449.327484, -981.599976, 30.695190, 90.708656),
                jobs = { "police" },
                distance = 2.0,
                icon = "fas fa-id-badge",
                marker = { enabled = true, type = 29, scale = 0.55, z = 0.5, color = { r = 120, g = 255, b = 255, a = 180 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 135.0 }
            },
        },
        Heli = {
            {
                name = "heli_pd_1",
                coords = vector4(474.883514, -1003.279114, 47.814698, 291.968506),
                coords = vector4(446.887908, -990.395630, 48.808838, 99.212594),
                jobs = { "police" },
                spawnCoords = vector4(441.059326, -995.525268, 48.808838, 178.582688),
                distance = 4.0,
                icon = "fas fa-helicopter",
                marker = { enabled = true, type = 34, scale = 1.0, z = 0.5, color = { r = 100, g = 200, b = 255, a = 200 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = -1.0, heading = 90.0 }
            },
        },
        Evidence = {
            {
                name = "evidence_pd_1",
                coords = vector4(484.338470, -1007.617554, 21.950196, 189.921264),
                jobs = { "police" },
                distance = 2.0,
                icon = "fas fa-vials",
                marker = { enabled = true, type = 20, scale = 0.55, z = 0.5, color = { r = 255, g = 255, b = 255, a = 170 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 270.0 }
            },
        },
        EvidenceStash = {
            {
                name = "evidence_stash_pd_1",
                coords = vector4(467.986816, -1009.120850, 21.933350, 93.543304),
                jobs = { "police" },
                distance = 2.0,
                icon = "fas fa-vials",
                marker = { enabled = true, type = 20, scale = 0.55, z = 0.5, color = { r = 255, g = 255, b = 255, a = 170 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 270.0 }
            }
        },
        PersonStash = {
            {
                name = "personal_stash_pd_1",
                coords = vector4(462.474732, -1001.274720, 22.506226, 11.338582),
                jobs = { "police" },
                distance = 2.0,
                icon = "fas fa-box-open",
                marker = { enabled = true, type = 21, scale = 0.55, z = 0.5, color = { r = 255, g = 255, b = 255, a = 170 } },
                npc = { enabled = false, model = `s_m_y_cop_01`, z = 0.0, heading = 270.0 }
            }
        }
    },

    Radar = {
        frontOffset = 3.5,   
        backOffset = 3.5,    
        height = 0.5,        
        radius = 3.2,        
        plateDistance = {
            front = 70.0,    
            back = 70.0      
        }
    },

    ReportCooldownMinutes = 10, 

    BossOpenGrade = {3,4}, 

    BadgeTime = 4000, 

    Evidence = {
       
        DecayMinutes = 30,
        DropCooldownMs = 250,
        BloodDrop = { enabled = true },
        GSRDrop = { enabled = true },

        Labels = {
          blood = "Collect Blood Sample",
          gsr_shooter = "Collect GSR (Shooter)",
          gsr_impact = "Collect GSR (Impact)"
        },

        FlashlightMarker = {
          maxDistance = 18.0,
          scale = 0.18
        },
    },

    EvidenceStashSettings = {
        maxWeight = 1000000, 
        slots = 48
    },

    EvidenceStashList = { 
        { id = 25121, name = "Drawer 1" },
        { id = 25122, name = "Drawer 2" },
        { id = 25123, name = "Drawer 3" },
        { id = 25124, name = "Drawer 4" },
        { id = 25125, name = "Drawer 5" },
        { id = 25126, name = "Drawer 6" },
        { id = 25127, name = "Drawer 7" },
        { id = 25128, name = "Drawer 8" },
        { id = 25129, name = "Drawer 9" },
        { id = 25130, name = "Drawer 10" },
    },

    Departments = {
        [1] = {
            job = "police",
            label = "LSPD",
            type = "leo",
            defaultDuty = true,
            offDutyPay = false,
            grades = {
                ['0'] = { name = "Recruit", payment = 50 },
                ['1'] = { name = "Officer", payment = 75 },
                ['2'] = { name = "Sergeant", payment = 100 },
                ['3'] = { name = "Lieutenant", payment = 125 },
                ['4'] = { name = "Chief", isboss = true, payment = 150 },
            },
            blip = { label = "LSPD", coords = vector3(430.931885, -981.019775, 30.69519), sprite = 60, color = 38, scale = 0.9, shortRange = true }
        }
    },

    Duty = {
        On = function(job, cid, name)
            print(("[Duty] %s (%s) Prise de service."):format(name, job))
        end,

        Off = function(job, cid, name)
            print(("[Duty] %s (%s) Fin de service."):format(name, job))
        end
    },

    alcohol = { 
        ['whiskey'] = math.random(20, 30),
        ['beer'] = math.random(30, 40),
        ['vodka'] = math.random(20, 40),
    },

	Currency = "$",

    Categories = {
        { id = "weapons",    label = "Weapons",    order = 1 },
        { id = "ammo",       label = "Ammunition", order = 2 },
        { id = "equipment",  label = "Equipment",  order = 3 },
        { id = "protection", label = "Protection", order = 4 },
        { id = "utility",    label = "Utility",    order = 5 }
    },

    InventoryImagePath = "nui://ox_inventory/web/images/", 

    Items = {

        { id = "pistol",   name = "Pistol",   category = "weapons", grade = 0, price = 10.00, image = "",    desc = "Sidearm.", itemName = "weapon_pistol", stack = 1, maxPerCart = 1 },
        { id = "smg",      name = "SMG",      category = "weapons", grade = 2, price = 10.00, image = "",       desc = "SMG.", itemName = "weapon_smg", stack = 1, maxPerCart = 1 },
        { id = "carbine",  name = "Rifle",    category = "weapons", grade = 3, price = 10.00, image = "",   desc = "Rifle.", itemName = "weapon_carbinerifle", stack = 1, maxPerCart = 1 },
        { id = "shotgun",  name = "Shotgun",  category = "weapons", grade = 3, price = 10.00, image = "",   desc = "Shotgun.", itemName = "weapon_pumpshotgun", stack = 1, maxPerCart = 1 },
        { id = "flashbang",name = "Flash",    category = "weapons", grade = 4, price = 10.00, image = "", desc = "Flash.", itemName = "weapon_flashlight", stack = 2, maxPerCart = 5 },

        { id = "pistol_ammo",  name = "Pistol Ammo",  category = "ammo", grade = 0, price = 10.00, image = "", desc = "Ammo.", itemName = "pistol_ammo", stack = 30, maxPerCart = 200 },
        { id = "smg_ammo",     name = "SMG Ammo",     category = "ammo", grade = 2, price = 10.00, image = "",    desc = "Ammo.", itemName = "smg_ammo", stack = 30, maxPerCart = 200 },
        { id = "rifle_ammo",   name = "Rifle Ammo",   category = "ammo", grade = 3, price = 10.00, image = "",  desc = "Ammo.", itemName = "rifle_ammo", stack = 30, maxPerCart = 200 },
        { id = "shotgun_ammo", name = "Shotgun Ammo", category = "ammo", grade = 3, price = 10.00, image = "", desc = "Ammo.", itemName = "shotgun_ammo", stack = 10, maxPerCart = 50 },

        { id = "cuffs",     name = "Cuffs",    category = "equipment", grade = 0, price = 10.00, image = "", desc = "Cuffs.", itemName = "handcuffs", stack = 1, maxPerCart = 5 },
        { id = "taser",     name = "Taser",    category = "equipment", grade = 1, price = 10.00, image = "",     desc = "Taser.", itemName = "weapon_stungun", stack = 1, maxPerCart = 1 },
        { id = "flashlight",name = "Light",    category = "equipment", grade = 0, price = 10.00, image = "", desc = "Light.", itemName = "weapon_flashlight", stack = 1, maxPerCart = 1 },
        { id = "radio",     name = "Radio",    category = "equipment", grade = 0, price = 10.00, image = "",      desc = "Radio.", itemName = "radio", stack = 1, maxPerCart = 1 },

        { id = "armor_light", name = "L-Armor", category = "protection", grade = 0, price = 10.00, image = "", desc = "Light armor.", itemName = "armor", stack = 1, maxPerCart = 2 },
        { id = "armor_heavy", name = "H-Armor", category = "protection", grade = 2, price = 10.00, image = "", desc = "Heavy armor.", itemName = "heavyarmor", stack = 1, maxPerCart = 2 },
        { id = "shield",      name = "Shield",  category = "protection", grade = 4, price = 10.00, image = "", desc = "Shield.", itemName = "police_stormram", stack = 1, maxPerCart = 1 },

        { id = "spikes",   name = "Spikes",   category = "utility", grade = 2, price = 10.00, image = "", desc = "Spikes.", itemName = "police_spikestrip", stack = 1, maxPerCart = 5 },
        { id = "breach",   name = "Breach",   category = "utility", grade = 3, price = 10.00, image = "", desc = "Breach kit.", itemName = "police_breachkit", stack = 1, maxPerCart = 2 },
        { id = "bodycam",  name = "Bodycam",  category = "utility", grade = 0, price = 10.00, image = "", desc = "Bodycam.", itemName = "police_bodycam", stack = 1, maxPerCart = 1 },
   
        { id = "gps_tracker", name = "GPS Tracker", category = "equipment", grade = 1, price = 10.00, image = "gps_tracker.png", desc = "A device for tracking players.", itemName = "gps_tracker", stack = 1, maxPerCart = 2 },
            
        { id = "evidence_bag", name = "Evidence Bag", category = "evidence", grade = 0, price = 0.00, image = "evidence_bag.png", desc = "An empty bag for collecting evidence.", itemName = "evidence_bag", stack = 5, maxPerCart = 20 },
        { id = "evidence_bag_full", name = "Evidence Bag (Full)", category = "evidence", grade = 0, price = 0.00, image = "evidence_bag_full.png", desc = "A sealed bag containing evidence.", itemName = "evidence_bag_full", stack = 1, maxPerCart = 10 },
        { id = "evidence_tube", name = "Evidence Tube", category = "evidence", grade = 0, price = 0.00, image = "evidence_tube.png", desc = "An empty tube for blood samples.", itemName = "evidence_tube", stack = 5, maxPerCart = 20 },
        { id = "evidence_tube_full", name = "Evidence Tube (Full)", category = "evidence", grade = 0, price = 0.00, image = "evidence_tube_full.png", desc = "A sealed tube with a blood sample.", itemName = "evidence_tube_full", stack = 1, maxPerCart = 10 },
            
        { id = "body_cam", name = "Bodycam", category = "utility", grade = 0, price = 10.00, image = "bodycam.png", desc = "A body camera used by police officers.", itemName = "body_cam", stack = 1, maxPerCart = 1 },
        { id = "bodycam_dashboard", name = "Bodycam Dashboard", category = "utility", grade = 1, price = 10.00, image = "bodycam_dashboard.png", desc = "Dashboard to view bodycams.", itemName = "bodycam_dashboard", stack = 1, maxPerCart = 1 },
        { id = "dispatch_tablet", name = "Dispatch Tablet", category = "utility", grade = 2, price = 10.00, image = "dispatch_tablet.png", desc = "Dispatch control tablet.", itemName = "dispatch_tablet", stack = 1, maxPerCart = 1 },

    },

    VehicleColor = 0 , 
    GarageName = "police",

    GiveKey = function(plate)
        if plate and plate ~= '' then
            TriggerEvent('vehiclekeys:client:SetOwner', plate)
        end
    end,

    Heli = {
        [1] = {
            ["polmav"]   = {label = "Police Maverick",   ranks = {2,3,4}, livery = 1, price = 25, customimg = ""},
            ["buzzard2"] = {label = "Police Buzzard",    ranks = {3,4},   livery = 1, price = 30, customimg = ""},
            ["frogger"]  = {label = "Sheriff Frogger",   ranks = {3,4},   livery = 1, price = 28, customimg = ""},
        },
        [2] = {
            ["polmav"]   = {label = "Sheriff Maverick",  ranks = {2,3,4}, livery = 1, price = 25, customimg = ""},
            ["frogger"]  = {label = "Sheriff Frogger",   ranks = {3,4},   livery = 1, price = 28, customimg = ""},
        },
        [3] = {
            ["polmav"]   = {label = "Air Support Maverick", ranks = {3,4}, livery = 1, price = 25, customimg = ""},
        }
    },

    ExtrasCarList = { 
        'police',
        'sheriff',
        'fbi',
        'npolvic'
    },

    Garage = {
        [1] = {
            ["xtzpn"]   = {label = "Moto Police",   ranks = {1,2}, livery = 1, price = 10, customimg = ""},
            ["police2"]  = {label = "Interceptor",      ranks = {1,2}, livery = 1, price = 10, customimg = ""},
            ["police3"]  = {label = "Marked Charger",   ranks = {2,3}, livery = 1, price = 10, customimg = ""},
            ["police4"]  = {label = "Marked CVPI",      ranks = {2,3}, livery = 1, price = 10, customimg = ""},
            ["policeb"]  = {label = "Police Bike",      ranks = {3,4}, livery = 1, price = 10, customimg = ""},
            ["policet"]  = {label = "Transport Van",    ranks = {3,4}, livery = 1, price = nil, customimg = ""},
            ["riot"]     = {label = "Riot Van",         ranks = {4},   livery = 0, price = nil, customimg = ""},
        },
        [2] = {
            ["police"]   = {label = "Patrol Buffalo",   ranks = {1,2}, livery = 1, price = 10, customimg = ""},
            ["police2"]  = {label = "Interceptor",      ranks = {1,2}, livery = 1, price = 10, customimg = ""},
            ["police3"]  = {label = "Marked Charger",   ranks = {2,3}, livery = 1, price = 10, customimg = ""},
            ["police4"]  = {label = "Marked CVPI",      ranks = {2,3}, livery = 1, price = 10, customimg = ""},
            ["policeb"]  = {label = "Police Bike",      ranks = {3,4}, livery = 1, price = 10, customimg = ""},
        },
        [3] = {
            ["police"]   = {label = "Patrol Buffalo",   ranks = {1,2}, livery = 1, price = 10, customimg = ""},
            ["police2"]  = {label = "Interceptor",      ranks = {1,2}, livery = 1, price = 10, customimg = ""},
            ["police3"]  = {label = "Marked Charger",   ranks = {2,3}, livery = 1, price = 10, customimg = ""},
            ["police4"]  = {label = "Marked CVPI",      ranks = {2,3}, livery = 1, price = 10, customimg = ""},
            ["policeb"]  = {label = "Police Bike",      ranks = {3,4}, livery = 1, price = 10, customimg = ""},
        },
    },

    ExtraMenu = { 
        quick    = true,
        extras   = true,
        liveries = true,
        engine   = true,
        colors   = true
    },

    VehicleColors = {
        { key = "black",        label = "Black",        primary = 0,   secondary = 0   },
        { key = "white",        label = "White",        primary = 111, secondary = 111 },
        { key = "red",          label = "Red",          primary = 27,  secondary = 27  },
        { key = "blue",         label = "Blue",         primary = 64,  secondary = 64  },
        { key = "green",        label = "Green",        primary = 55,  secondary = 55  },
        { key = "yellow",       label = "Yellow",       primary = 88,  secondary = 88  },
        { key = "orange",       label = "Orange",       primary = 38,  secondary = 38  },
        { key = "pink",         label = "Pink",         primary = 135, secondary = 135 },
        { key = "purple",       label = "Purple",       primary = 145, secondary = 145 },
        { key = "silver",       label = "Silver",       primary = 4,   secondary = 4   },
        { key = "grey",         label = "Grey",         primary = 13,  secondary = 13  },
        { key = "gold",         label = "Gold",         primary = 37,  secondary = 37  },
        { key = "lime",         label = "Lime",         primary = 92,  secondary = 92  },
        { key = "cyan",         label = "Cyan",         primary = 70,  secondary = 70  },
        { key = "turquoise",    label = "Turquoise",    primary = 71,  secondary = 71  },
        { key = "bronze",       label = "Bronze",       primary = 90,  secondary = 90  },
        { key = "midnightblue", label = "Midnight Blue",primary = 141, secondary = 141 },
        { key = "cream",        label = "Cream",        primary = 107, secondary = 107 }
    },

    Progressbar = { 
        TintControl = 6000,
        BreakLock = 5000,
        Impound = 7000,
        Tuning = 4000,
        GsrCheck = 3000, 
        Alcohol = 2000,
    },
    
    GSRCleanInterval = 60000, 

    HandCuffItem = 'handcuffs',
    
    CuffKeyItem = "cuffkeys",

    ActionMenu = {
        { 
        key = "citizen", label = "Transactions Citoyen", type = "submenu", grade = {0,1,2,3,4},
        items = {
            { key = "search_person", label = "Palpation de sécurité", grade = {0,1,3,4}, event = { side = "client", name = "frkn:police:searchPerson", args = {} } },
            { key = "handcuff", label = "Menotter", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:client:cuffplayer", args = false } },
            { key = "handcuff_hard", label = "Menotter (Serré)", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:client:cuffplayer", args = true } },
            { key = "uncuff", label = "Démenotter", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:client:UnCuffPlayer", args = { item = "cuffkeys", menu = "main" } } },
            { key = "transport_cuffed", label = "Escorter la personne", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:client:EscortPlayer", args = {} } },
            { key = "carry", label = "Porter la personne", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:police:carry", args = {} } },
            { key = "put_in_vehicle", label = "Placer l'individu dans le véhicule", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:client:PutPlayerInVehicle", args = {} } },
            { key = "take_out_vehicle", label = "Sortir l'individu du véhicule", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:client:SetPlayerOutVehicle", args = {} } },
            { key = "send_public", label = "Remettre aux autorités", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:police:sendPublic", args = {} } },
            { key = "send_jail", label = "Envoyer en prison", grade = {0,1,2,3,4}, event = { side = "command", name = "jailmenu", args = {} } },
            { key = "gsr", label = "Effectuer un test GSR", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:cl:gsr_check", args = {} } },
            { key = "alcohol", label = "Effectuer un test d'alcoolémie", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:alcoholtest", args = {} } },
        }
        },
        { 
            key = "vehicle", label = "Contrôles du véhicule", type = "submenu", grade = {0,1,2,3,4},
            items = {
                { key = "check_tuning", label = "Vérifier l'état du tuning", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:vehicle:checkTuning", args = {} } },
                { key = "check_tint", label = "Vérifier la teinte des vitres", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:vehicle:checkTint", args = {} } },
                { key = "remove_tint", label = "Retirer le film teinté", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:vehicle:removeTint", args = {} } },
                { key = "vehicle_scuff", label = "Remorquage du véhicule", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:client:VehicleScuff", args = {} } },
                { key = "break_lock", label = "Forcer la serrure du véhicule", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:vehicle:breakLock", args = {} } }
            }
        },
        {
            key = "objects",
            label = "Actions d'objets",
            type = "submenu",
            grade = {0,1,2,3,4},
            items = {
                { key = "place_barrier",   label = "Placer une barrière", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:props:place", args = { prop = "prop_barrier_work06a", freeze = true,  count = 1, spacing = 1.5, grade = 0 } } },
                { key = "place_spike",     label = "Poser une herse", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:props:place", args = { prop = "P_ld_stinger_s",     freeze = false, count = 1, spacing = 3.5, grade = 2 } } },
                { key = "place_cone",      label = "Placer un cône", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:props:place", args = { prop = "prop_roadcone02a",   freeze = false, count = 1, spacing = 1.5, grade = 0 } } },
                { key = "place_tent",      label = "Installer une tente", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:props:place", args = { prop = "prop_gazebo_03",    freeze = true,  count = 1, spacing = 1.5, grade = 2 } } },
                { key = "place_light",     label = "Installer un éclairage", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:props:place", args = { prop = "prop_worklight_03b", freeze = true,  count = 1, spacing = 1.5, grade = 0 } } },
                { key = "place_stand",     label = "Poser un pupitre de police", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:props:place", args = { prop = "p_amb_cop_stand",   freeze = true,  count = 1, spacing = 1.5, grade = 1 } } },
                { key = "place_barrier_2", label = "Placer une barrière métallique", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:props:place", args = { prop = "prop_barrier_02a",  freeze = true,  count = 1, spacing = 1.5, grade = 1 } } },
                { key = "place_bollard",   label = "Placer un Vegiblock en béton", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn:props:place", args = { prop = "pshul_vigibloc", freeze = true,  count = 1, spacing = 1.5, grade = 2 } } },
            }
        },

        { 
            key = "policeops", label = "Opérations de police Nationale", type = "submenu", grade = {0,1,2,3,4},
            items = {
                { key = "show_badge", label = "Présenter l'insigne", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:showBadge", args = {} } },
                { key = "vehicle_radar_on", label = "Radar embarqué", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:radarOn", args = {} } },
                { key = "vehicle_remote_opn", label = "Télécommande radar", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:radarRemote", args = {} } },
                { key = "finger", label = "Empreinte digitale", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-policejob:openFingerPrint", args = {} } },
                { key = "k9", label = "Menu Cynophile", grade = {0,1,2,3,4}, event = { side = "client", name = "frkn-k9:open", args = {} } },
            }
        },
    },

    PoliceSearch = {

        SearchTime = 8000, 

        weapons = {  

            [GetHashKey("WEAPON_FLASHLIGHT")] = true,
            [GetHashKey("WEAPON_FIREEXTINGUISHER")] = true,
            [GetHashKey("WEAPON_NIGHTSTICK")] = true
        },

        handsupAnim = {
            dict = "missfbi5ig_22",
            name = "hands_up_anxious_scientist",
            animcontrol = false,
        },

        deadAnim = {
            dict = "missexile3",
            name = "ex03_dingy_search_case_base_michael",
            animcontrol = false,
        },

        robAnim = {
            dict = "random@shop_robbery",
            name = "robbery_action_b",
        }

    },

    PropsSettings = {
        maxDistance = 6.0,
        zLimit = 0.3
    },

    ServiceExtensionOnEscape = 5, 

    ServiceLocation = vector3(170.0552, -989.230, 30.091), 
    
    ServiceLocations = {
    	{ type = "cleaning", coords = vector3(172.3472, -1005.82, 29.337) },
    	{ type = "cleaning", coords = vector3(176.5671, -1004.31, 29.333) },
    	{ type = "cleaning", coords = vector3(198.6010, -1013.68, 29.303) },
    	{ type = "cleaning", coords = vector3(195.5679, -1016.82, 29.359) },
    	{ type = "cleaning", coords = vector3(191.2855, -1009.08, 29.311) },
    	{ type = "cleaning", coords = vector3(185.9871, -1010.50, 29.319) },
    	{ type = "cleaning", coords = vector3(177.5478, -1006.31, 29.331) },
    	{ type = "cleaning", coords = vector3(185.8083, -1008.28, 29.320) },
    	{ type = "gardening", coords = vector3(190.5050, -1003.26, 29.291) },
    	{ type = "gardening", coords = vector3(199.2376, -1007.25, 29.291) },
    	{ type = "gardening", coords = vector3(189.8262, -1004.42, 29.291) },
    	{ type = "gardening", coords = vector3(186.8539, -997.449, 29.289) },
    	{ type = "gardening", coords = vector3(181.3150, -997.791, 29.291) }
    },

    CommunicationService = {
        Command = "communityend",
        Grade = {0,1,2,3,4},
        MaxCommunity = 100,
    },
    
    Outfits = { 
        enabled = false, 
        male = {
            mask = { item = 0, texture = 0 },
            arms = { item = 17, texture = 0 },
            shirt = { item = 15, texture = 0 },
            jacket = { item = 243, texture = 18 },
            pants = { item = 27, texture = 3 },
            shoes = { item = 51, texture = 0 },
            accessories = { item = 0, texture = 0 },
        },
        female = {
            mask = { item = 0, texture = 0 },
            arms = { item = 4, texture = 0 },
            shirt = { item = 2, texture = 0 },
            jacket = { item = 229, texture = 0 },
            pants = { item = 3, texture = 15 },
            shoes = { item = 72, texture = 0 },
            accessories = { item = 0, texture = 0 },
        },
    },

    Cloths = {
        ['male'] = {
             [1] = {
                    
                    outfitLabel = 'Short Sleeve',
                    outfitData = {
                        ['pants'] = {texture = 0, item = 24, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 19, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 58, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 55, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 51, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['bag'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = -1, texture = -1, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
                [2] = {
                    outfitLabel = 'Trooper Tan',
                    outfitData = {
                        ['pants'] = {item = 24, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 20, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 58, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 317, texture = 3, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 51, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['bag'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = 58, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
                [3] = {
                    outfitLabel = 'Long Sleeve',
                    outfitData = {
                        ['pants'] = {item = 24, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 20, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 58, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 317, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 51, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['bag'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = -1, texture = -1, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
                [4] = {
                    outfitLabel = 'Trooper Black',
                    outfitData = {
                        ['pants'] = {item = 24, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 20, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 58, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 317, texture = 8, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 51, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['bag'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = 58, texture = 3, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
                [5] = {
                    outfitLabel = 'SWAT',
                    outfitData = {
                        ['pants'] = {item = 130, texture = 1, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 172, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 15, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 15, texture = 2, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 336, texture = 3, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 24, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 133, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = 150, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 52, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
        },
        ['female'] = {
            [1] = {
                    outfitLabel = 'Short Sleeve',
                    outfitData = {
                        ['pants'] = {item = 133, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 31, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 35, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 34, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 48, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 52, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['bag'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
                [2] = {
                    outfitLabel = 'Trooper Tan',
                    outfitData = {
                        ['pants'] = {item = 133, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 31, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 35, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 34, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 327, texture = 3, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 52, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['bag'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
                [3] = {
                    outfitLabel = 'Long Sleeve',
                    outfitData = {
                        ['pants'] = {item = 133, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 31, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 35, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 34, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 327, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 52, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['bag'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
                [4] = {
                    outfitLabel = 'Trooper Black',
                    outfitData = {
                        ['pants'] = {item = 133, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 31, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 35, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 34, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 327, texture = 8, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 52, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['bag'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
                [5] = {
                    outfitLabel = 'Swat',
                    outfitData = {
                        ['pants'] = {item = 135, texture = 1, defaultItem = 0, defaultTexture = 0}, 
                        ['arms'] = {item = 213, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['t-shirt'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['vest'] = {item = 17, texture = 2, defaultItem = 0, defaultTexture = 0}, 
                        ['torso2'] = {item = 327, texture = 8, defaultItem = 0, defaultTexture = 0}, 
                        ['shoes'] = {item = 52, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['accessory'] = {item = 102, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['bag'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['hat'] = {item = 149, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['glass'] = {item = 0, texture = 0, defaultItem = 0, defaultTexture = 0}, 
                        ['mask'] = {item = 35, texture = 0, defaultItem = 0, defaultTexture = 0} 
                    }
                },
        },
    },
}

