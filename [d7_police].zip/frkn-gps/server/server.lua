-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

local channels = {}
local playerData = {}
local playerSettings = {}

RegisterServerEvent("frkn-gps:server:connectToChannel", function(channel)
    local source = source
    if not channels[channel] then
        channels[channel] = {}
    end
    local alreadyConnected = false
    for _, playerId in ipairs(channels[channel]) do
        if playerId == source then
            alreadyConnected = true
            break
        end
    end
    if not alreadyConnected then
        table.insert(channels[channel], source)
    end
    local playersInChannel = {}
    for _, playerId in ipairs(channels[channel]) do
        if playerData[playerId] then
            table.insert(playersInChannel, playerData[playerId])
        end
    end
    TriggerClientEvent("frkn-gps:client:connectToChannel", source, channel, playersInChannel)
end)

RegisterServerEvent("frkn-gps:server:disconnectFromChannel", function(channel)
    local source = source
    if channels[channel] then
        for i, playerId in ipairs(channels[channel]) do
            if playerId == source then
                table.remove(channels[channel], i)
                break
            end
        end
        for _, playerId in ipairs(channels[channel]) do
            TriggerClientEvent("frkn-gps:client:playerDisconnected", playerId, channel, source)
        end
    end
    TriggerClientEvent("frkn-gps:client:disconnectFromChannel", source, channel)
end)

RegisterServerEvent("frkn-gps:client:updateGpsSettings", function(settings)
    local source = source
    if settings then
        playerSettings[source] = settings
        if playerData[source] then
            playerData[source].color = settings.color
            playerData[source].gpsCode = settings.gpsCode
        end
    end
end)

RegisterServerEvent("frkn-gps:client:updateVehicleData", function(vehicleData)
    local source = source
    local ped = GetPlayerPed(source)
    local coords = GetEntityCoords(ped)
    if not playerData[source] then
        playerData[source] = {}
    end
    playerData[source].src = source
    playerData[source].coords = coords
    playerData[source].vehicle = vehicleData
    playerData[source].name = GetPlayerName(source)
    if playerSettings[source] then
        playerData[source].color = playerSettings[source].color
        playerData[source].gpsCode = playerSettings[source].gpsCode
    end
    for channel, players in pairs(channels) do
        local isInChannel = false
        for _, playerId in ipairs(players) do
            if playerId == source then
                isInChannel = true
                break
            end
        end
        if isInChannel then
            local playersInChannel = {}
            for _, playerId in ipairs(players) do
                if playerData[playerId] then
                    table.insert(playersInChannel, playerData[playerId])
                end
            end
            for _, playerId in ipairs(players) do
                TriggerClientEvent("frkn-gps:client:updateChannelPlayers", playerId, channel, playersInChannel)
            end
        end
    end
end)

RegisterServerEvent("frkn-gps:server:settingsUpdated", function()
    local source = source
end)

RegisterServerEvent("frkn-gps:server:requestChannelRefresh", function(channel)
    local source = source
    if channels[channel] then
        local playersInChannel = {}
        for _, playerId in ipairs(channels[channel]) do
            if playerData[playerId] then
                table.insert(playersInChannel, playerData[playerId])
            end
        end
        TriggerClientEvent("frkn-gps:client:updateChannelPlayers", source, channel, playersInChannel)
    end
end)

AddEventHandler("playerDropped", function(reason)
    local source = source
    playerData[source] = nil
    playerSettings[source] = nil
    for channel, players in pairs(channels) do
        for i, playerId in ipairs(players) do
            if playerId == source then
                table.remove(players, i)
                for _, remainingPlayerId in ipairs(players) do
                    TriggerClientEvent("frkn-gps:client:playerDisconnected", remainingPlayerId, channel, source)
                end
                break
            end
        end
    end
end)

