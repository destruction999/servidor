-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Core = nil
CoreName = nil
CoreReady = false

Citizen.CreateThread(function()
    for k, v in pairs(Cores) do
        if GetResourceState(v.ResourceName) == "starting" or GetResourceState(v.ResourceName) == "started" then
            CoreName = v.ResourceName
            Core = v.GetFramework()
            CoreReady = true
        end
    end
end)

function GetPlayer(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        return Core.Functions.GetPlayer(source)
    elseif CoreName == "es_extended" then
        return Core.GetPlayerFromId(source)
    end
    return nil
end

function GetPlayerIdentifier(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        if player then
            return player.PlayerData.citizenid
        end
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        if player then
            return player.identifier
        end
    end
    return nil
end

function GetPlayerName(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        if player then
            return player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
        end
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        if player then
            return player.getName()
        end
    end
    return nil
end

function GetPlayerJob(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        if player then
            return player.PlayerData.job.name, player.PlayerData.job.grade.level
        end
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        if player then
            return player.job.name, player.job.grade
        end
    end
    return nil, nil
end

RegisterServerEvent('frkn-policejob:server:triggerCallback', function(name, ...)
    local source = source
    if name == "frkn-policejob:characterDetail" then
        local args = {...}
        local targetId = args[1]
        local targetName = GetPlayerName(targetId)
        local targetJob = GetPlayerJob(targetId)
        local targetIdentifier = GetPlayerIdentifier(targetId)
        TriggerClientEvent('frkn-policejob:client:triggerCallback', source, name, {
            name = targetName,
            job = targetJob,
            identifier = targetIdentifier
        })
    end
end)

