-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

isTrackerUIOpen = false
trackerProp = nil
connectedChannels = {}
playerBlips = {}
playerCoordinates = {}

local function hexToBlipColor(hex)
    if not hex then
        return 2
    end
    hex = hex:gsub("#", "")
    local colorMap = {
        ["147c6a"] = 2,
        ["1d5ea8"] = 3,
        ["2c65b0"] = 3,
        ["6e1a5e"] = 8,
        ["7b1d74"] = 8,
        ["ff8a00"] = 5,
        ["6b6f76"] = 0,
        ["ff0000"] = 1,
        ["ffff00"] = 5,
        ["00ff00"] = 2,
        ["0000ff"] = 3,
        ["ff00ff"] = 8,
        ["00ffff"] = 6,
        ["ffffff"] = 0,
        ["000000"] = 0
    }
    local color = colorMap[hex:lower()]
    if not color then
        color = 2
    end
    return color
end

function LoadAnimDic(animDict)
    if not HasAnimDictLoaded(animDict) then
        RequestAnimDict(animDict)
        while true do
            if HasAnimDictLoaded(animDict) then
                break
            end
            Wait(0)
        end
    end
end

function ToggleTrackerUI(state)
    isTrackerUIOpen = state
    LoadAnimDic("cellphone@")
    if state then
        TriggerEvent("attachItemRadio", "radio01")
        TaskPlayAnim(PlayerPedId(), "cellphone@", "cellphone_text_read_base", 2.0, 3.0, -1, 49, 0, false, false, false)
        trackerProp = CreateObject(-1964402432, 1.0, 1.0, 1.0, true, true, false)
        AttachEntityToEntity(trackerProp, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 57005), 0.14, 0.01, -0.02, 110.0, 120.0, -15.0, true, false, false, false, 2, true)
    else
        StopAnimTask(PlayerPedId(), "cellphone@", "cellphone_text_read_base", 1.0)
        ClearPedTasks(PlayerPedId())
        if 0 ~= trackerProp then
            DeleteObject(trackerProp)
            trackerProp = 0
        end
    end
end

RegisterNetEvent("frkn-gps:client:openGps", function()
    isTrackerUIOpen = true
    SetNuiFocus(true, true)
    local job, grade = GetPlayerJob()
    local vehicleData = GetVehicleDataForGPS()
    local channels = {}
    for channel, connected in pairs(connectedChannels) do
        if connected then
            channels[channel] = true
        end
    end
    local kvpSettings = GetResourceKvpString("frkn_gps_settings_key")
    if kvpSettings then
        local settings = json.decode(kvpSettings)
        if settings then
            if settings.cid == GetPlayerCID() then
                TriggerServerEvent("frkn-gps:client:updateGpsSettings", settings)
            end
        end
    end
    SendNUIMessage({
        action = "openGps",
        defaultChannels = FRKN.defaultChannels,
        vehicleData = vehicleData,
        connectedChannels = channels,
        job = job
    })
    ToggleTrackerUI(true)
end)

RegisterNuiCallback("closeGps", function()
    isTrackerUIOpen = false
    SetNuiFocus(false, false)
    ToggleTrackerUI(false)
end)

RegisterNuiCallback("panicButton", function()
    local job = GetPlayerJob()
    if job ~= FRKN.policeJobName then
        if job ~= FRKN.ambulanceJobName then
            Notify(Locale.error.panicButton, "error", 5000)
            return
        end
    end
    FRKN.panicExport()
    Notify(Locale.success.panicButton, "success", 5000)
end)

local function calculateDistance(pos1, pos2)
    local dx = pos1.x - pos2.x
    local dy = pos1.y - pos2.y
    local dz = pos1.z - pos2.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

local function isPlayerInRange(playerData, maxDistance)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local distance = calculateDistance(coords, playerData.coords)
    return maxDistance >= distance
end

local function createBlip(data)
    local scale = 1.0
    local sprite = data.blipType
    if data.vehicle then
        if data.vehicle.model then
            local model = data.vehicle.model
            local vehClass = data.vehicle.class
            if vehClass then
                if 8 == vehClass then
                    sprite = FRKN.sprite.motorcycle
                elseif 9 == vehClass or 14 == vehClass then
                    sprite = FRKN.sprite.boat
                elseif 15 == vehClass then
                    sprite = FRKN.sprite.heli
                elseif 16 == vehClass then
                    sprite = FRKN.sprite.plane
                elseif 18 == vehClass then
                    if data.vehicle.sirenOn then
                        sprite = 42
                        scale = 0.6
                    else
                        sprite = 41
                        scale = 0.6
                    end
                else
                    sprite = FRKN.sprite.vehicle
                end
            else
                if IsThisModelAHeli(model) then
                    sprite = FRKN.sprite.heli
                elseif IsThisModelAPlane(model) then
                    sprite = FRKN.sprite.plane
                else
                    sprite = FRKN.sprite.vehicle
                end
            end
        end
    end
    local color = 2
    local blipName = data.name
    if not blipName then
        blipName = GetPlayerName()
    end
    if data.gpsCode then
        blipName = tostring(data.gpsCode)
    end
    if data.color then
        color = hexToBlipColor(data.color)
    end
    local blip = AddBlipForCoord(data.coords.x, data.coords.y, data.coords.z)
    SetBlipSprite(blip, sprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, scale)
    SetBlipColour(blip, color)
    SetBlipAsShortRange(blip, true)
    if data.vehicle then
        if sprite == FRKN.sprite.heli then
            blipName = blipName .. " (Helicopter)"
        elseif sprite == FRKN.sprite.plane then
            blipName = blipName .. " (Plane)"
        elseif sprite == FRKN.sprite.vehicle then
            blipName = blipName .. " (Vehicle)"
        elseif sprite == FRKN.sprite.motorcycle then
            blipName = blipName .. " (Motorcycle)"
        elseif sprite == FRKN.sprite.boat then
            blipName = blipName .. " (Boat)"
        else
            blipName = blipName .. " (Vehicle)"
        end
    else
        blipName = blipName .. " (Walking)"
    end
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentSubstringPlayerName(blipName)
    EndTextCommandSetBlipName(blip)
    return blip
end

local function updateBlip(playerId, data)
    local scale = 1.0
    if playerBlips[playerId] then
        SetBlipCoords(playerBlips[playerId], data.coords.x, data.coords.y, data.coords.z)
        local sprite = data.blipType
        if data.vehicle then
            if data.vehicle.model then
                local model = data.vehicle.model
                local vehClass = data.vehicle.class
                if vehClass then
                    if 8 == vehClass then
                        sprite = FRKN.sprite.motorcycle
                    elseif 9 == vehClass or 14 == vehClass then
                        sprite = FRKN.sprite.boat
                    elseif 15 == vehClass then
                        sprite = FRKN.sprite.heli
                    elseif 16 == vehClass then
                        sprite = FRKN.sprite.plane
                    elseif 18 == vehClass then
                        if data.vehicle.sirenOn then
                            sprite = 42
                            scale = 0.6
                        else
                            sprite = 41
                            scale = 0.6
                        end
                    else
                        sprite = FRKN.sprite.vehicle
                    end
                else
                    if IsThisModelAHeli(model) then
                        sprite = FRKN.sprite.heli
                    elseif IsThisModelAPlane(model) then
                        sprite = FRKN.sprite.plane
                    else
                        sprite = FRKN.sprite.vehicle
                    end
                end
            end
        end
        local currentSprite = GetBlipSprite(playerBlips[playerId])
        local currentColor = GetBlipColour(playerBlips[playerId])
        local blipName = data.name
        if not blipName then
            blipName = GetPlayerName()
        end
        local color = 2
        if data.gpsCode then
            blipName = tostring(data.gpsCode)
        end
        if data.color then
            color = hexToBlipColor(data.color)
        end
        if data.vehicle then
            if sprite == FRKN.sprite.heli then
                blipName = blipName .. " (Helicopter)"
            elseif sprite == FRKN.sprite.plane then
                blipName = blipName .. " (Plane)"
            elseif sprite == FRKN.sprite.vehicle then
                blipName = blipName .. " (Vehicle)"
            elseif sprite == FRKN.sprite.motorcycle then
                blipName = blipName .. " (Motorcycle)"
            elseif sprite == FRKN.sprite.boat then
                blipName = blipName .. " (Boat)"
            else
                blipName = blipName .. " (Vehicle)"
            end
        else
            blipName = blipName .. " (Walking)"
        end
        SetBlipSprite(playerBlips[playerId], sprite)
        SetBlipScale(playerBlips[playerId], scale)
        SetBlipColour(playerBlips[playerId], color)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentSubstringPlayerName(blipName)
        EndTextCommandSetBlipName(playerBlips[playerId])
    end
end

local function removeBlip(playerId)
    if playerBlips[playerId] then
        RemoveBlip(playerBlips[playerId])
        playerBlips[playerId] = nil
    end
end

local function removeAllBlips()
    for _, blip in pairs(playerBlips) do
        RemoveBlip(blip)
    end
    playerBlips = {}
end

RegisterNuiCallback("connectToChannel", function(data)
    local channel = data.channel
    local job, grade = GetPlayerJob()
    local allowed = false
    local channelConfig = nil
    for _, cfg in ipairs(FRKN.defaultChannels) do
        if cfg.frequency == channel then
            channelConfig = cfg
            break
        end
    end
    if channelConfig then
        for _, allowedJob in ipairs(channelConfig.allowedJobs) do
            if allowedJob == job then
                allowed = true
                break
            end
        end
    else
        allowed = true
    end
    if allowed then
        local kvpSettings = GetResourceKvpString("frkn_gps_settings_key")
        if kvpSettings then
            local settings = json.decode(kvpSettings)
            if settings then
                if settings.cid == GetPlayerCID() then
                    TriggerServerEvent("frkn-gps:client:updateGpsSettings", settings)
                end
            end
        end
        TriggerServerEvent("frkn-gps:server:connectToChannel", channel)
        connectedChannels[channel] = true
    end
end)

function DisconnectFromAllChannels()
    for channel, connected in pairs(connectedChannels) do
        if connected then
            TriggerServerEvent("frkn-gps:server:disconnectFromChannel", channel)
            connectedChannels[channel] = false
        end
    end
    removeAllBlips()
    playerCoordinates = {}
end

RegisterNuiCallback("disconnectFromChannel", function(data)
    local channel = data.channel
    TriggerServerEvent("frkn-gps:server:disconnectFromChannel", channel)
    connectedChannels[channel] = false
    removeAllBlips()
    playerCoordinates = {}
    Notify(Locale.success.disconnectFromChannel, "success", 5000)
end)

RegisterNetEvent("frkn-gps:client:connectToChannel")
AddEventHandler("frkn-gps:client:connectToChannel", function(channel, players)
    local kvpSettings = GetResourceKvpString("frkn_gps_settings_key")
    local maxDistance = 100
    if kvpSettings then
        local settings = json.decode(kvpSettings)
        if settings then
            if settings.cid == GetPlayerCID() then
                if settings.distance then
                    maxDistance = settings.distance
                end
            end
        end
    end
    for _, playerData in pairs(players) do
        if isPlayerInRange(playerData, maxDistance) then
            playerBlips[playerData.src] = createBlip(playerData)
        end
    end
end)

RegisterNetEvent("frkn-gps:client:disconnectFromChannel")
AddEventHandler("frkn-gps:client:disconnectFromChannel", function(channel)
    removeAllBlips()
    playerCoordinates = {}
end)

RegisterNetEvent("frkn-gps:client:updateChannelPlayers")
AddEventHandler("frkn-gps:client:updateChannelPlayers", function(channel, players)
    if not connectedChannels[channel] then
        return
    end
    local kvpSettings = GetResourceKvpString("frkn_gps_settings_key")
    local maxDistance = 100
    if kvpSettings then
        local settings = json.decode(kvpSettings)
        if settings then
            if settings.cid == GetPlayerCID() then
                if settings.distance then
                    maxDistance = settings.distance
                end
            end
        end
    end
    if players then
        if type(players) == "table" then
            for _, playerData in pairs(players) do
                if playerData then
                    if isPlayerInRange(playerData, maxDistance) then
                        if playerBlips[playerData.src] then
                            updateBlip(playerData.src, playerData)
                            local blip = playerBlips[playerData.src]
                            if blip then
                                local blipName = nil
                                if playerData.gpsCode then
                                    blipName = tostring(playerData.gpsCode)
                                else
                                    blipName = playerData.name or blipName
                                    if not playerData.name then
                                        blipName = GetPlayerName()
                                    end
                                end
                                if playerData.vehicle then
                                    local sprite = GetBlipSprite(blip)
                                    if sprite == FRKN.sprite.heli then
                                        blipName = blipName .. " (Helicopter)"
                                    elseif sprite == FRKN.sprite.plane then
                                        blipName = blipName .. " (Plane)"
                                    elseif sprite == FRKN.sprite.vehicle then
                                        blipName = blipName .. " (Vehicle)"
                                    elseif sprite == FRKN.sprite.motorcycle then
                                        blipName = blipName .. " (Motorcycle)"
                                    elseif sprite == FRKN.sprite.boat then
                                        blipName = blipName .. " (Boat)"
                                    elseif 41 == sprite or 42 == sprite then
                                        blipName = blipName .. " (Emergency)"
                                    else
                                        blipName = blipName .. " (Vehicle)"
                                    end
                                else
                                    blipName = blipName .. " (Walking)"
                                end
                                BeginTextCommandSetBlipName("STRING")
                                AddTextComponentSubstringPlayerName(blipName)
                                EndTextCommandSetBlipName(blip)
                            end
                        else
                            playerBlips[playerData.src] = createBlip(playerData)
                        end
                    else
                        removeBlip(playerData.src)
                    end
                end
            end
            playerCoordinates = {}
            for _, playerData in pairs(players) do
                if playerData then
                    if playerData.src then
                        playerCoordinates[playerData.src] = playerData
                    end
                end
            end
        end
    else
        playerCoordinates = {}
    end
    local vehicleList = {}
    if players then
        if type(players) == "table" then
            for _, playerData in pairs(players) do
                if playerData then
                    if playerData.vehicle then
                        if isPlayerInRange(playerData, maxDistance) then
                            local vehicleInfo = {}
                            local plate = playerData.vehicle.plate
                            if not plate then
                                plate = "Unknown"
                            end
                            vehicleInfo.plate = plate
                            vehicleInfo.coords = playerData.coords
                            vehicleInfo.street = GetStreetNameFromCoords(playerData.coords)
                            table.insert(vehicleList, vehicleInfo)
                        end
                    end
                end
            end
        end
    end
    SendNUIMessage({
        action = "refreshVehicleList",
        vehicleData = vehicleList
    })
end)

RegisterNetEvent("frkn-gps:client:playerDisconnected")
AddEventHandler("frkn-gps:client:playerDisconnected", function(channel, playerId)
    removeBlip(playerId)
end)

RegisterNetEvent("frkn-gps:client:connectionError")
AddEventHandler("frkn-gps:client:connectionError", function(message)
    Notify(message, "error", 5000)
end)

function getVehiclePlate(vehicle)
    local plate = GetVehicleNumberPlateText(vehicle)
    if not plate then
        plate = "UNKNOWN"
    end
    return plate
end

function GetVehicleDataForGPS()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle and 0 ~= vehicle then
        local vehClass = GetVehicleClass(vehicle)
        local model = GetEntityModel(vehicle)
        local sirenOn = IsVehicleSirenOn(vehicle)
        return {
            plate = GetVehicleNumberPlateText(vehicle),
            model = model,
            class = vehClass,
            sirenOn = sirenOn
        }
    end
    return nil
end

function GetStreetNameFromCoords(coords)
    local streetHash, crossingHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local streetName = GetStreetNameFromHashKey(streetHash)
    if 0 ~= crossingHash then
        local crossingName = GetStreetNameFromHashKey(crossingHash)
        streetName = streetName .. " & " .. crossingName
    end
    return streetName
end

function SetWaypointToCoords(coords)
    if coords then
        if coords.x then
            if coords.y then
                SetNewWaypoint(coords.x, coords.y)
                return true
            end
        end
    end
    return false
end

RegisterNetEvent("frkn-gps:client:getVehicleData")
AddEventHandler("frkn-gps:client:getVehicleData", function(cb)
    local vehicleData = GetVehicleDataForGPS()
    cb(vehicleData)
end)

RegisterNuiCallback("saveSettings", function(data, cb)
    local settings = {}
    settings.cid = GetPlayerCID()
    settings.color = data.color
    settings.distance = data.distance
    settings.gpsCode = data.gpsCode
    SetResourceKvp("frkn_gps_settings_key", json.encode(settings))
    TriggerServerEvent("frkn-gps:client:updateGpsSettings", settings)
    local hasConnectedChannel = false
    for channel, connected in pairs(connectedChannels) do
        if connected then
            hasConnectedChannel = true
            break
        end
    end
    if hasConnectedChannel then
        for playerId, blip in pairs(playerBlips) do
            local coordData = playerCoordinates[playerId]
            if coordData then
                local color = 2
                if coordData.color then
                    color = hexToBlipColor(coordData.color)
                end
                SetBlipColour(blip, color)
                local blipName = nil
                if coordData.gpsCode then
                    blipName = tostring(coordData.gpsCode)
                else
                    blipName = coordData.name or blipName
                    if not coordData.name then
                        blipName = GetPlayerName()
                    end
                end
                if coordData.vehicle then
                    local sprite = GetBlipSprite(blip)
                    if sprite == FRKN.sprite.heli then
                        blipName = blipName .. " (Helicopter)"
                    elseif sprite == FRKN.sprite.plane then
                        blipName = blipName .. " (Plane)"
                    elseif sprite == FRKN.sprite.vehicle then
                        blipName = blipName .. " (Vehicle)"
                    elseif sprite == FRKN.sprite.motorcycle then
                        blipName = blipName .. " (Motorcycle)"
                    elseif sprite == FRKN.sprite.boat then
                        blipName = blipName .. " (Boat)"
                    elseif 41 == sprite or 42 == sprite then
                        blipName = blipName .. " (Emergency)"
                    else
                        blipName = blipName .. " (Vehicle)"
                    end
                else
                    blipName = blipName .. " (Walking)"
                end
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentSubstringPlayerName(blipName)
                EndTextCommandSetBlipName(blip)
            end
        end
    end
    if data.distance then
        local newDistance = data.distance
        removeAllBlips()
        local hasConnected = false
        for channel, connected in pairs(connectedChannels) do
            if connected then
                hasConnected = true
                break
            end
        end
        if hasConnected then
            for playerId, coordData in pairs(playerCoordinates) do
                local myServerId = GetPlayerServerId(PlayerId())
                if playerId ~= myServerId then
                    if isPlayerInRange(coordData, newDistance) then
                        playerBlips[playerId] = createBlip(coordData)
                    end
                end
            end
        end
    end
    TriggerServerEvent("frkn-gps:server:settingsUpdated")
    Citizen.Wait(100)
    for channel, connected in pairs(connectedChannels) do
        if connected then
            TriggerServerEvent("frkn-gps:server:requestChannelRefresh", channel)
        end
    end
    cb({})
end)

RegisterNuiCallback("getSettings", function(data, cb)
    local kvpSettings = GetResourceKvpString("frkn_gps_settings_key")
    if kvpSettings then
        local settings = json.decode(kvpSettings)
        if settings.cid == GetPlayerCID() then
            cb(settings)
        else
            cb({})
        end
    else
        cb({})
    end
end)

RegisterNuiCallback("setWaypoint", function(data, cb)
    if data.coords then
        local success = SetWaypointToCoords(data.coords)
        cb({ success = success })
    else
        cb({ success = false })
    end
end)

RegisterNuiCallback("getVehicleGPSData", function(data, cb)
    local vehicleList = {}
    local kvpSettings = GetResourceKvpString("frkn_gps_settings_key")
    local maxDistance = 100
    if kvpSettings then
        local settings = json.decode(kvpSettings)
        if settings then
            if settings.cid == GetPlayerCID() then
                if settings.distance then
                    maxDistance = settings.distance
                end
            end
        end
    end
    for _, playerData in pairs(playerCoordinates) do
        if playerData then
            if playerData.vehicle then
                if isPlayerInRange(playerData, maxDistance) then
                    local vehicleInfo = {}
                    local plate = playerData.vehicle.plate
                    if not plate then
                        plate = "Unknown"
                    end
                    vehicleInfo.plate = plate
                    vehicleInfo.coords = playerData.coords
                    vehicleInfo.street = GetStreetNameFromCoords(playerData.coords)
                    table.insert(vehicleList, vehicleInfo)
                end
            end
        end
    end
    cb(vehicleList)
end)

CreateThread(function()
    Wait(5000)
    local kvpSettings = GetResourceKvpString("frkn_gps_settings_key")
    if kvpSettings then
        local settings = json.decode(kvpSettings)
        if settings then
            if settings.cid == GetPlayerCID() then
                TriggerServerEvent("frkn-gps:client:updateGpsSettings", settings)
            end
        end
    end
    while true do
        Wait(FRKN.blipRefreshTime)
        local vehicleData = GetVehicleDataForGPS()
        TriggerServerEvent("frkn-gps:client:updateVehicleData", vehicleData)
    end
end)

CreateThread(function()
    while true do
        Wait(FRKN.blipRefreshTime)
        local hasConnectedChannel = false
        for channel, connected in pairs(connectedChannels) do
            if connected then
                hasConnectedChannel = true
                break
            end
        end
        if hasConnectedChannel then
            local kvpSettings = GetResourceKvpString("frkn_gps_settings_key")
            local maxDistance = 100
            if kvpSettings then
                local settings = json.decode(kvpSettings)
                if settings then
                    if settings.cid == GetPlayerCID() then
                        if settings.distance then
                            maxDistance = settings.distance
                        end
                    end
                end
            end
            for playerId, blip in pairs(playerBlips) do
                local coordData = playerCoordinates[playerId]
                if coordData then
                    if not isPlayerInRange(coordData, maxDistance) then
                        removeBlip(playerId)
                    end
                else
                    removeBlip(playerId)
                end
            end
            for playerId, coordData in pairs(playerCoordinates) do
                if not playerBlips[playerId] then
                    if isPlayerInRange(coordData, maxDistance) then
                        playerBlips[playerId] = createBlip(coordData)
                    end
                end
            end
        end
    end
end)

function CheckGpsTracker()
    while true do
        Wait(1000)
        local hasItem = HasItem(FRKN.gpsTracker)
        local hasConnectedChannel = false
        for channel, connected in pairs(connectedChannels) do
            if connected then
                hasConnectedChannel = true
                break
            end
        end
        if hasConnectedChannel and 0 == hasItem then
            DisconnectFromAllChannels()
            Notify(Locale.error.noGpsTracker, "error", 5000)
        end
    end
end

CheckGpsTracker()

