let cachedVehicleData = null;
let lastVehicleDataHash = null;
let myJob = null;

window.addEventListener("message", function (e) {
    e = e.data
    switch (e.action) {
        case "openGps":
            return openGps(e);
        case "closeGps":
            return closeGps();
        case "refreshVehicleList":
            return updateVehicleGPSList(e.vehicleData);
        default:
            return;
    }
});

function openGps(e) {
    myJob = e.job;
    $('.gps-menu').css('display', 'flex');
    preConfiguredChannels(e.defaultChannels)
    loadSettings();

    window.currentVehicleData = e.vehicleData;
    window.connectedChannels = e.connectedChannels || {};

    clearVehicleCache();
    updateVehicleGPSList();
    updateChannelListDisplay();
    updateConnectPageState();
}

function closeGps() {
    $('.gps-menu').css('display', 'none');
    $.post(`https://frkn-gps/closeGps`, JSON.stringify({}));
}


function preConfiguredChannels(data) {
    const defaultChannelsList = $('.gpschannel-list');
    defaultChannelsList.empty();

    data.forEach((item, index) => {
        const isConnected = window.connectedChannels && window.connectedChannels[item.frequency];
        const channelItem = `
      <div class="gpschannel-item">
        <div class="number">${item.frequency}</div>
        <div class="name">${item.name}'s GPS</div>
        <img src="../html/images/gps-link.svg" class="gps-link" alt="" onclick="connectToChannel(${item.frequency})" data-job="${(item.allowedJobs || []).join(',')}" style="cursor: pointer;">
      </div>
    `;
        defaultChannelsList.append(channelItem);
    });
}

function updateChannelListDisplay() {
    const defaultChannelsList = $('.gpschannel-list');
    defaultChannelsList.find('.gpschannel-item').each(function () {
        const $item = $(this);
        const channelNumber = $item.find('.number').text();
        const jobs = $item.data('job');
        const isConnected = window.connectedChannels && window.connectedChannels[channelNumber];

        if (isConnected) {
            $item.addClass('connected');
            $item.find('.gps-link')
                .attr('src', '../html/images/gps-link-hover.svg')
                .css('cursor', 'not-allowed')
                .attr('onclick', '');
        } else {
            $item.removeClass('connected');
            $item.find('.gps-link')
                .attr('src', '../html/images/gps-link.svg')
                .css('cursor', 'pointer')
                .attr('data-job', jobs)
                .attr('onclick', `connectToChannel(${channelNumber}, this)`);
        }
    });

    updateConnectPageState();
}

function updateConnectPageState() {
    const isConnected = Object.keys(window.connectedChannels || {}).length > 0;
    const $connectBtn = $('.connect-btn');
    const $mhzInput = $('.mhz-input');
    const $leftIcon = $('.left-icon');
    const $rightIcon = $('.right-icon');

    if (isConnected) {
        let connectedChannel = null;
        for (let channel in window.connectedChannels) {
            if (window.connectedChannels[channel]) {
                connectedChannel = channel;
                break;
            }
        }

        $connectBtn.removeClass('disconnect').addClass('disconnect');
        $connectBtn.text('DISCONNECT');

        if (connectedChannel) {
            $mhzInput.val(connectedChannel);
        }
        $mhzInput.prop('disabled', true);
        $mhzInput.css('opacity', '0.5');

        $leftIcon.css('pointer-events', 'none').css('opacity', '0.5');
        $rightIcon.css('pointer-events', 'none').css('opacity', '0.5');
    } else {
        $connectBtn.removeClass('disconnect');
        $connectBtn.text('CONNECT');

        $mhzInput.prop('disabled', false);
        $mhzInput.css('opacity', '1');

        $leftIcon.css('pointer-events', 'auto').css('opacity', '1');
        $rightIcon.css('pointer-events', 'auto').css('opacity', '1');
    }
}


function connectToChannel(channel, el) {
    const raw = $(el).attr('data-job') || ''
    const allowed = raw.split(',').map(s => s.trim().toLowerCase()).filter(Boolean)

    const userJob = String(myJob || '').toLowerCase()



    if (allowed.length && !allowed.includes(userJob)) {
        $('.vehicle-gps-list , .default-channels , .settings-page').css('display', 'none');
        $('.connect-page').css('display', 'flex');
        setTimeout(() => {
            $('.notify-list').prepend(`
                <div class="notify">
                  <img src="../html/images/gps-notify-error-icon.svg" alt="">
                  <div class="header">ERROR</div>
                  <div class="desc">You are not allowed to join this channel</div>
                </div>
            `)
        }, 500);
        return
    }

    let isAlreadyConnected = false
    for (let k in window.connectedChannels) {
        if (window.connectedChannels[k]) { isAlreadyConnected = true; break }
    }
    if (isAlreadyConnected) {
        $('.vehicle-gps-list , .default-channels , .settings-page').css('display', 'none');
        $('.connect-page').css('display', 'flex');
        setTimeout(() => {
            $('.notify-list').prepend(`
                <div class="notify">
                  <img src="../html/images/gps-notify-error-icon.svg" alt="">
                  <div class="header">ERROR</div>
                  <div class="desc">You must disconnect from current channel first</div>
                </div>
            `)
        }, 500);
        return
    }

    if (window.connectedChannels && window.connectedChannels[channel]) {
        $('.vehicle-gps-list , .default-channels , .settings-page').css('display', 'none');
        $('.connect-page').css('display', 'flex');
        setTimeout(() => {
            $('.notify-list').prepend(`
                    <div class="notify">
                        <img src="../html/images/gps-notify-error-icon.svg" alt="">
                        <div class="header">ERROR</div>
                        <div class="desc">You are already connected to this channel</div>
                    </div>
                `)
        }, 500);
        return
    }

    $.post(`https://frkn-gps/connectToChannel`, JSON.stringify({ channel }))
    window.connectedChannels[channel] = true
    updateVehicleGPSList()
    updateChannelListDisplay()
    updateConnectPageState()
    $('.notify-list').prepend(`
        <div class="notify">
          <img src="../html/images/gps-notify-success-icon.svg" alt="">
          <div class="header">SUCCESS</div>
          <div class="desc">YOU HAVE CONNECTED TO ${channel}</div>
        </div>
    `)
}


function panicButton() {
    $.post(`https://frkn-gps/panicButton`, JSON.stringify({}));

}

$(document).ready(function () {
    $('.gps-menu').css('display', 'none');

    setInterval(function () {
        if ($('.gps-menu').is(':visible') && Object.keys(window.connectedChannels || {}).length > 0) {
            updateVehicleGPSList();
        }
    }, 5000);
});

$(document).on('keydown', function (event) {
    if (event.key === 'Escape') {
        closeGps();
    }
});

$(document).on('mouseenter', '.left-icon', function () {
    $(this).attr('src', '../html/images/gps-mhz-select-2.svg');
    $(this).css({
        'width': '25%',
        'height': '25%',
        'top': '34%',
        'left': '20%'
    })
});

$(document).on('mouseleave', '.left-icon', function () {
    $(this).attr('src', '../html/images/gps-mhz-notselect-2.svg');
    $(this).css({
        'width': '11%',
        'height': '11%',
        'top': '41%',
        'left': '25%'
    });
});
$(document).on('mouseenter', '.right-icon', function () {
    $(this).attr('src', '../html/images/gps-mhz-select.svg');
    $(this).css({
        'width': '25%',
        'height': '25%',
        'top': '34%',
        'right': '20%'
    })
});

$(document).on('mouseleave', '.right-icon', function () {
    $(this).attr('src', '../html/images/gps-mhz-notselect.svg');
    $(this).css({
        'width': '11%',
        'height': '11%',
        'top': '41%',
        'right': '25%'
    });
});


$(document).on('click', '.right-icon', function () {
    let input = $('.mhz-input');
    let val = parseInt(input.val()) || 0;
    input.val(val + 1);
});

$(document).on('click', '.left-icon', function () {
    let input = $('.mhz-input');
    let val = parseInt(input.val()) || 0;
    input.val(val - 1);
});


$(document).on('mouseenter', '.app-list .item img', function () {
    let $img = $(this);
    let src = $img.attr('src');
    if (!src.includes('-hover')) {
        let extIndex = src.lastIndexOf('.');
        let newSrc = src.substring(0, extIndex) + '-hover' + src.substring(extIndex);

        $img.stop(true, true).fadeOut(50, function () {
            $img.attr('src', newSrc).fadeIn(50);
        });
    }
});

$(document).on('mouseleave', '.app-list .item img', function () {
    let $img = $(this);
    if ($img.closest('.item').hasClass('active')) return;

    let src = $img.attr('src');
    if (src.includes('-hover')) {
        let newSrc = src.replace('-hover', '');

        $img.stop(true, true).fadeOut(50, function () {
            $img.attr('src', newSrc).fadeIn(50);
        });
    }
});

$(document).on('click', '.color-bar .swatch', function () {
    $('.color-bar .swatch').removeClass('selected')
    $(this).addClass('selected')
    saveSettings();
})


let interval;

function startChanging($input, step) {
    clearInterval(interval);
    interval = setInterval(() => {
        let val = parseInt($input.val()) || 0;
        $input.val(val + step);
    }, 100);
}

function stopChanging() {
    clearInterval(interval);
}

$(document).on('mousedown', '.up', function () {
    let $input = $('.distance-input');
    startChanging($input, +1);
});

$(document).on('mousedown', '.down', function () {
    let $input = $('.distance-input');
    startChanging($input, -1);
});

$(document).on('mouseup mouseleave', '.up, .down', function () {
    stopChanging();
    saveSettings();
});

$(document).on('mouseenter', '.gpsvehicle-item img', function () {
    let src = $(this).attr('src');
    if (!src.includes('-hover')) {
        let extIndex = src.lastIndexOf('.');
        let newSrc = src.substring(0, extIndex) + '-hover' + src.substring(extIndex);
        $(this).attr('src', newSrc);
    }
});

$(document).on('mouseleave', '.gpsvehicle-item img', function () {
    let src = $(this).attr('src');
    if (src.includes('-hover')) {
        $(this).attr('src', src.replace('-hover', ''));
    }
});

$(document).on('input change', '.distance-input', function () {
    saveSettings();
});

$(document).on('input change', '.gps-code-input', function () {
    saveSettings();
});



$(document).on('click', '.app-list .item img', function () {
    $('.app-list .item').removeClass('active');
    $('.app-list .item img').each(function () {
        let src = $(this).attr('src');
        if (src.includes('-hover')) {
            $(this).attr('src', src.replace('-hover', ''));
        }
    });

    let $item = $(this).closest('.item');
    $item.addClass('active');

    let $img = $(this);
    let src = $img.attr('src');
    if (!src.includes('-hover')) {
        let extIndex = src.lastIndexOf('.');
        let newSrc = src.substring(0, extIndex) + '-hover' + src.substring(extIndex);
        $img.attr('src', newSrc);
    }
});


$(document).on('click', '.app-list .item', function () {
    let targetPage = $(this).data('page');

    $('.connect-page, .vehicle-gps-list , .default-channels , .settings-page').css('display', 'none');

    $('.' + targetPage).css('display', 'flex');
});

$(document).on('click', '.connect-btn', function () {
    let $btn = $(this);
    if ($btn.hasClass('disconnect')) {
        $btn.removeClass('disconnect');
        $btn.text('CONNECT');

        $.post(`https://frkn-gps/disconnectFromChannel`, JSON.stringify({
            channel: $('.mhz-input').val()
        }));

        delete window.connectedChannels[$('.mhz-input').val()];
        clearVehicleCache(); // Clear cache when disconnecting
        updateVehicleGPSList();
        updateChannelListDisplay();
        updateConnectPageState();

        $('.notify-list').prepend(`
          <div class="notify">
            <img src="../html/images/gps-notify-error-icon.svg" alt="">
            <div class="header">SUCCESS</div>
            <div class="desc">YOU HAVE DISCONNECTED FROM ${$('.mhz-input').val()}</div>
          </div>
        `);
    } else {
        let isAlreadyConnected = false;
        for (let connectedChannel in window.connectedChannels) {
            if (window.connectedChannels[connectedChannel]) {
                isAlreadyConnected = true;
                break;
            }
        }

        if (isAlreadyConnected) {
            $('.notify-list').prepend(`
                <div class="notify">
                  <img src="../html/images/gps-notify-error-icon.svg" alt="">
                  <div class="header">ERROR</div>
                  <div class="desc">You must disconnect from current channel first</div>
                </div>
              `);
            return;
        }

        $btn.addClass('disconnect');
        $btn.text('DISCONNECT');
        $.post(`https://frkn-gps/connectToChannel`, JSON.stringify({
            channel: $('.mhz-input').val()
        }));


        window.connectedChannels[$('.mhz-input').val()] = true;
        clearVehicleCache(); // Clear cache when connecting to get fresh data
        updateVehicleGPSList();
        updateChannelListDisplay();
        updateConnectPageState();

        $('.notify-list').prepend(`
          <div class="notify">
            <img src="../html/images/gps-notify-success-icon.svg" alt="">
            <div class="header">SUCCESS</div>
            <div class="desc">YOU HAVE CONNECTED TO ${$('.mhz-input').val()}</div>
          </div>
        `);
    }
});

function saveSettings() {
    const selectedColor = $('.color-bar .swatch.selected').data('color') || '#147c6a';
    const distance = $('.distance-input').val() || 100;
    const gpsCode = $('.gps-code-input').val() || 'FRKN(101)';
    $.post(`https://frkn-gps/saveSettings`, JSON.stringify({
        color: selectedColor,
        distance: parseInt(distance),
        gpsCode: gpsCode
    }));
}

function loadSettings() {
    $.post(`https://frkn-gps/getSettings`, JSON.stringify({}), function (settings) {
        if (settings && Object.keys(settings).length > 0) {
            if (settings.color) {
                $('.color-bar .swatch').removeClass('selected');
                $(`.color-bar .swatch[data-color="${settings.color}"]`).addClass('selected');
            }

            if (settings.distance) {
                $('.distance-input').val(settings.distance);
            }

            if (settings.gpsCode) {
                $('.gps-code-input').val(settings.gpsCode);
            }
        } else {
            $('.color-bar .swatch').removeClass('selected');
            $('.color-bar .swatch[data-color="#147c6a"]').addClass('selected');
        }
    }).fail(function (xhr, status, error) {
        console.error('Error loading settings:', error);
        $('.color-bar .swatch').removeClass('selected');
        $('.color-bar .swatch[data-color="#147c6a"]').addClass('selected');
    });
}


function updateVehicleGPSList(vehicleData) {
    const hasConnectedChannels = Object.keys(window.connectedChannels).length > 0;
    if (!hasConnectedChannels) {
        $('.gpsvehicle-list').html('<div class="no-vehicles">No vehicles found. Connect to a channel to see vehicle GPS data.</div>');
        return;
    }

    if (vehicleData) {
        const currentHash = JSON.stringify(vehicleData);
        if (currentHash === lastVehicleDataHash && cachedVehicleData !== null) return;
        cachedVehicleData = vehicleData;
        lastVehicleDataHash = currentHash;
        renderVehicleList(vehicleData);
        return;
    }

    $.post(`https://frkn-gps/getVehicleGPSData`, JSON.stringify({}), function (res) {
        const currentHash = JSON.stringify(res);
        if (currentHash === lastVehicleDataHash && cachedVehicleData !== null) return;
        cachedVehicleData = res;
        lastVehicleDataHash = currentHash;
        renderVehicleList(res);
    }).fail(function () {
        $('.gpsvehicle-list').html('<div class="no-vehicles">Error loading vehicle data.</div>');
    });
}

function setWaypoint(x, y, z) {
    $.post(`https://frkn-gps/setWaypoint`, JSON.stringify({
        coords: { x: x, y: y, z: z }
    }), function (data) {
        if (data && data.success) {
            $('.notify-list').append(`
                <div class="notify">
                    <img src="../html/images/gps-notify-success-icon.svg" alt="">
                    <div class="header">SUCCESS</div>
                    <div class="desc">Waypoint set successfully</div>
                </div>
            `);
        } else {
            $('.notify-list').append(`
                <div class="notify">
                    <img src="../html/images/gps-notify-error-icon.svg" alt="">
                    <div class="header">ERROR</div>
                    <div class="desc">Failed to set waypoint</div>
                </div>
            `);
        }
    }).fail(function (xhr, status, error) {
        console.error('Error setting waypoint:', error);
        $('.notify-list').append(`
            <div class="notify">
                <img src="../html/images/gps-notify-error-icon.svg" alt="">
                <div class="header">ERROR</div>
                <div class="desc">Failed to set waypoint</div>
            </div>
        `);
    });
}


function renderVehicleList(vehicleData) {
    const vehicleList = $('.gpsvehicle-list');
    vehicleList.empty();

    if (vehicleData && vehicleData.length > 0) {
        vehicleData.forEach(vehicle => {
            if (vehicle && vehicle.coords && vehicle.coords.x !== null && vehicle.coords.y !== null && vehicle.coords.z !== null) {
                const vehicleItem = `
                    <div class="gpsvehicle-item" data-coords='${JSON.stringify(vehicle.coords)}'>
                        <img src="../html/images/gps-vehicle-icon.svg" class="gps-vehicle-icon" alt="">
                        <div class="vehicle-plate">${vehicle.plate || 'Unknown'}</div>
                        <div class="street">${vehicle.street || 'Unknown location'}</div>
                        <img src="../html/images/gps-map.svg" class="gps-map" alt="" onclick="setWaypoint(${vehicle.coords.x}, ${vehicle.coords.y}, ${vehicle.coords.z})">
                        <img src="../html/images/gps-link.svg" class="gps-link" alt="" onclick="setWaypoint(${vehicle.coords.x}, ${vehicle.coords.y}, ${vehicle.coords.z})">
                    </div>
                `;
                vehicleList.append(vehicleItem);
            }
        });
    } else {
        vehicleList.html('<div class="no-vehicles">No vehicles found in connected channels.</div>');
    }
}

function clearVehicleCache() {
    cachedVehicleData = null;
    lastVehicleDataHash = null;
}