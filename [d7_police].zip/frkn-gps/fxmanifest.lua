-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts
-- Join our Discord : https://discord.com/invite/R9KgyCkXJp

fx_version 'cerulean'
game 'gta5'

client_scripts {
	'client/core.lua',
	'client/client.lua'
}

server_scripts {
	'@oxmysql/lib/MySQL.lua',
	'server/core.lua',
	'server/server.lua'
}

ui_page 'html/index.html'

files {
	'html/index.html',
	'html/style.css',
	'html/images/*.png',
	'html/images/*.jpg',
	'html/images/*.webp',
	'html/images/*.svg',
	'html/fonts/*.ttf',
	'html/fonts/*.otf',
	'html/script.js',
	'html/*png',
	'html/*jpg',
	'html/*webp',
	'html/images/*.gif',
}

lua54 'yes'

