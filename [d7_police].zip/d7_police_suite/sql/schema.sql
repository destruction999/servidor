-- D7 Police Suite: esquema SEGURO (solo crea lo que falta; nunca borra datos)
-- ;;
CREATE TABLE IF NOT EXISTS `bodycam_recordings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` varchar(50) NOT NULL,
  `recording` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cid` (`cid`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_dispatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  `map_data` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_dispatch_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Unit` varchar(100) NOT NULL,
  `unitdata` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `profession` varchar(50) DEFAULT 'police',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_dispatch_drawing_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `officer_id` varchar(50) NOT NULL,
  `officer_name` varchar(100) NOT NULL,
  `permission` tinyint(1) NOT NULL DEFAULT 0,
  `granted_by` varchar(100) NOT NULL,
  `granted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `officer_profession` varchar(50) DEFAULT 'police',
  `granted_by_profession` varchar(50) DEFAULT 'police',
  PRIMARY KEY (`id`),
  UNIQUE KEY `officer_id` (`officer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_evidence_scans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `evidence_id` varchar(32) NOT NULL,
  `type` varchar(32) NOT NULL,
  `container` varchar(16) NOT NULL,
  `street` varchar(120) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `citizenid` varchar(64) DEFAULT '',
  `victim` varchar(64) DEFAULT '',
  `shooter` varchar(64) DEFAULT '',
  `shot` varchar(64) DEFAULT '',
  `memo` text DEFAULT NULL,
  `source_identifier` varchar(64) DEFAULT '',
  `inserted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_pd_cloth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `data` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_pd_job_grades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_name` varchar(64) NOT NULL,
  `grade` int(10) unsigned NOT NULL,
  `label` varchar(64) NOT NULL,
  `payment` int(11) NOT NULL DEFAULT 0,
  `is_boss` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_job_grade` (`job_name`,`grade`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_pd_job_grade_perms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_grade_id` int(10) unsigned NOT NULL,
  `can_hire` tinyint(1) NOT NULL DEFAULT 0,
  `can_promote` tinyint(1) NOT NULL DEFAULT 0,
  `can_view_balance` tinyint(1) NOT NULL DEFAULT 0,
  `can_withdraw` tinyint(1) NOT NULL DEFAULT 0,
  `can_manage_evidence` tinyint(1) NOT NULL DEFAULT 0,
  `can_read_report` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_grade` (`job_grade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_pd_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `report` text DEFAULT NULL,
  `anonymous` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_pd_vaults` (
  `id` int(11) DEFAULT NULL,
  `station` int(11) DEFAULT NULL,
  `vault` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_pd_vaults_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `station` int(11) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_radio_channels` (
  `channel_id` varchar(50) NOT NULL,
  `password` varchar(100) DEFAULT '',
  PRIMARY KEY (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_radio_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel_id` varchar(50) NOT NULL,
  `identifier` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `avatar` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `channel_id` (`channel_id`),
  CONSTRAINT `frkn_radio_chat_ibfk_1` FOREIGN KEY (`channel_id`) REFERENCES `frkn_radio_channels` (`channel_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- ;;
CREATE TABLE IF NOT EXISTS `frkn_radio_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel_id` varchar(50) NOT NULL,
  `identifier` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `channel_id` (`channel_id`),
  CONSTRAINT `frkn_radio_members_ibfk_1` FOREIGN KEY (`channel_id`) REFERENCES `frkn_radio_channels` (`channel_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
-- ;;
INSERT IGNORE INTO `frkn_pd_job_grades` (`id`,`job_name`,`grade`,`label`,`payment`,`is_boss`) VALUES (1,'police',0,'Recruit',50,0),(2,'police',1,'Officer',75,0),(3,'police',2,'Sergeant',100,0),(4,'police',3,'Lieutenant',125,0),(5,'police',4,'Chief',150,1);
-- ;;
INSERT IGNORE INTO `frkn_pd_job_grade_perms` (`id`,`job_grade_id`,`can_hire`,`can_promote`,`can_view_balance`,`can_withdraw`,`can_manage_evidence`,`can_read_report`) VALUES (1,0,1,0,0,0,0,0),(2,1,1,1,1,1,1,1),(3,2,0,1,0,0,0,1),(4,3,1,1,1,1,1,1),(5,4,1,1,1,1,1,1);
-- ;;
