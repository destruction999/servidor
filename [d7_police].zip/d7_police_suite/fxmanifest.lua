fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Distrito 7RP'
description 'D7 Police Suite - instala y configura solo: PoliceJob + GPS + Radio + Bodycam + BossMenu + PoliceSimulatorV'
version '1.0.0'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'config.lua',
    'server.lua'
}
