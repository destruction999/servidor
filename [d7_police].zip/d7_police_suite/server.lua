local RESOURCE = GetCurrentResourceName()
local results = {}

local function say(msg)  print('^5[D7 Police Suite]^7 ' .. msg) end
local function warn(msg) print('^5[D7 Police Suite]^7 ^3' .. msg .. '^7') end
local function fail(msg) print('^5[D7 Police Suite]^7 ^1' .. msg .. '^7') end

local function state(name) return GetResourceState(name) end

local function waitFor(name, seconds)
    local waited = 0
    while state(name) ~= 'started' do
        if state(name) == 'missing' then return false end
        if waited >= seconds * 1000 then return false end
        Wait(500)
        waited = waited + 500
    end
    return true
end

local function detectFramework(seconds)
    local waited = 0
    while waited <= seconds * 1000 do
        if state('qbx_core') == 'started' then return 'qbox' end
        if state('qb-core') == 'started' then return 'qbcore' end
        if state('es_extended') == 'started' then return 'esx' end
        Wait(500)
        waited = waited + 500
    end
    return nil
end

local function trim(s) return (s:gsub('^%s+', ''):gsub('%s+$', '')) end

-- 1) Base de datos: crea solo lo que falta, nunca borra nada
local function runSchema()
    local sql = LoadResourceFile(RESOURCE, 'sql/schema.sql')
    if not sql then fail('No encuentro sql/schema.sql') return end
    local good, bad = 0, 0
    for statement in (sql .. '\n-- ;;'):gmatch('(.-)\n%-%- ;;') do
        statement = trim(statement)
        if #statement > 20 and not statement:match('^%-%-') then
            local ok, err = pcall(function() return MySQL.query.await(statement) end)
            if ok then good = good + 1 else bad = bad + 1; fail('SQL fallo: ' .. tostring(err)) end
        end
    end
    say(('Base de datos lista (%d sentencias OK, %d con error).'):format(good, bad))
end

-- 2) Ajusta la tabla de vehiculos de frkn-policejob segun tu framework (ESX o QB/Qbox)
local function patchVehicleTable(framework)
    local res, path = 'frkn-policejob', 'shared/config.lua'
    if state(res) == 'missing' then return false end
    local content = LoadResourceFile(res, path)
    if not content then return false end
    local wanted = (framework == 'esx') and 'owned_vehicles' or 'player_vehicles'
    local current = content:match('VehicleTableName%s*=%s*"([%w_]+)"')
    if current == wanted then return false end
    local updated, n = content:gsub('(VehicleTableName%s*=%s*")[%w_]+(")', '%1' .. wanted .. '%2', 1)
    if n == 1 and SaveResourceFile(res, path, updated, -1) then
        say(('Tabla de vehiculos de frkn-policejob ajustada a "%s" (framework: %s).'):format(wanted, framework))
        return true
    end
    return false
end

-- 3) Evita choques con el policia viejo
local function stopConflicts()
    if not Config.StopConflicting then return end
    for _, name in ipairs(Config.ConflictingResources) do
        local s = state(name)
        if s == 'started' or s == 'starting' then
            ExecuteCommand('stop ' .. name)
            warn(('"%s" estaba encendido y choca con frkn-policejob: lo apague.'):format(name))
        end
    end
end

-- 4) Inicia cada modulo en orden, esperando sus dependencias
local function startModule(mod)
    if not mod.enabled then return 'apagado' end
    if state(mod.name) == 'missing' then
        warn(('%s: no encontre la carpeta, lo salto.'):format(mod.name))
        return 'no encontrado'
    end
    for _, dep in ipairs(mod.needs or {}) do
        if not waitFor(dep, Config.WaitSeconds) then
            warn(('%s: necesita "%s" y no esta iniciado, lo salto.'):format(mod.name, dep))
            return 'falta ' .. dep
        end
    end
    if state(mod.name) ~= 'started' then
        ExecuteCommand('ensure ' .. mod.name)
        if not waitFor(mod.name, 25) then return 'ERROR al iniciar' end
    end
    return 'OK'
end

local function printStatus()
    say('--------- Estado ---------')
    for _, mod in ipairs(Config.Modules) do
        local r = results[mod.name] or 'pendiente'
        local color = (r == 'OK') and '^2' or ((r == 'apagado') and '^7' or '^3')
        print(('   %s%-22s %s^7 (%s)'):format(color, mod.name, r, state(mod.name)))
    end
    say('---------------------------')
end

CreateThread(function()
    say('Iniciando instalacion automatica...')

    if not waitFor('oxmysql', Config.WaitSeconds) then
        fail('oxmysql no esta iniciado. Ponlo ANTES de d7_police_suite en tu server.cfg.')
        return
    end
    local framework = detectFramework(Config.WaitSeconds)
    if not framework then
        fail('No detecte framework (es_extended / qb-core / qbx_core). Pon d7_police_suite DESPUES de tu framework.')
        return
    end
    say('Framework detectado: ' .. framework)

    runSchema()
    stopConflicts()

    local changed = patchVehicleTable(framework)
    if changed and state('frkn-policejob') == 'started' then
        ExecuteCommand('restart frkn-policejob')
        Wait(2000)
    end

    for _, mod in ipairs(Config.Modules) do
        results[mod.name] = startModule(mod)
    end

    printStatus()

    -- segunda pasada: por si tu server.cfg o un script reinicia el policia viejo mas tarde
    Wait(30000)
    stopConflicts()
end)

-- Desde la consola del servidor: d7police
RegisterCommand('d7police', function(source)
    if source ~= 0 then return end
    printStatus()
end, true)
