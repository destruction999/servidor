Config = {}

-- Segundos maximos que espera a que arranquen las dependencias (ox_target, ox_inventory, etc.)
Config.WaitSeconds = 90

-- Para y evita choques con el trabajo de policia viejo (dos policias a la vez se pelean)
Config.StopConflicting = true
Config.ConflictingResources = { 'esx_policejob', 'PoliceJobUpdated' }

-- Modulos que se inician solos, en este orden. Pon enabled = false para apagar uno.
Config.Modules = {
    { name = 'BabloBossMenu',       enabled = true, needs = { 'ox_lib', 'oxmysql' } },
    { name = 'frkn-policejob',      enabled = true, needs = { 'ox_lib', 'oxmysql', 'ox_inventory', 'ox_target' } },
    { name = 'frkn-gps',            enabled = true, needs = { 'oxmysql' } },
    { name = 'frkn-radio',          enabled = true, needs = { 'ox_lib', 'oxmysql', 'pma-voice' } },
    { name = 'frkn-bodycam',        enabled = true, needs = { 'oxmysql' } },
    { name = 'frkn-bodycam-render', enabled = true, needs = {} },
    { name = 'PoliceSimulatorV',    enabled = true, needs = {} },  -- solo actua si un jugador usa /forceduty
}
