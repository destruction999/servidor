-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts
-- Join our Discord : https://discord.com/invite/R9KgyCkXJp

fx_version 'cerulean'
game 'gta5'

client_scripts {
    'client.lua',
    'config.lua'
}

server_scripts {
    'server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html'
}

lua54 'yes'

