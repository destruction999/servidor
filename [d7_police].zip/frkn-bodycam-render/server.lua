-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

local bodycamStates = {}

RegisterNetEvent("frkn-bodycam:server:setBodycamState", function(state)
    local source = source
    bodycamStates[source] = state
end)

AddEventHandler("playerDropped", function()
    local source = source
    bodycamStates[source] = nil
end)

exports("getBodycamState", function(playerId)
    return bodycamStates[playerId] or false
end)

exports("getActiveBodycams", function()
    local active = {}
    for playerId, state in pairs(bodycamStates) do
        if state then
            active[#active + 1] = playerId
        end
    end
    return active
end)

