-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

local mediaService = "fm"
local services = {
    fm = {
        apiUrl = "https://fmapi.net/api/v2/video",
        apiKey = "PON_AQUI_TU_API_KEY",
        headers = { "Authorization" }
    },
    fivemerr = {
        apiUrl = "https://api.fivemerr.com/v1/media/videos",
        apiKey = "YOUR_FIVEMERR_API_KEY",
        headers = { "Authorization" }
    },
    discord = {
        webhookUrl = "YOUR_DISCORD_WEBHOOK_URL",
        maxFileSize = 26214400,
        username = "Bodycam System",
        avatarUrl = nil
    }
}

local apiKey = (services[mediaService] and services[mediaService].apiKey) or "PON_AQUI_TU_API_KEY"
local uploadResult = nil
local isProcessing = false
local processingCounter = 0

local function updateConfig()
    SendNUIMessage({
        action = "updateConfig",
        config = {
            mediaService = mediaService,
            services = services
        }
    })
end

updateConfig()

local function startCapture()
    TriggerServerEvent("frkn-bodycam:server:setBodycamState", true)
    SendNUIMessage({
        action = "startCapture"
    })
end

local function stopCapture()
    TriggerServerEvent("frkn-bodycam:server:setBodycamState", false)
    isProcessing = true
    uploadResult = nil
    processingCounter = 0
    TriggerEvent("frkn-bodycam:client:notify", "Processing video... Please wait.", "info", 5000)
    SendNUIMessage({
        action = "stopCapture"
    })
    local intervalHandle = SetInterval(function()
        if isProcessing then
            processingCounter = processingCounter + 1
            if processingCounter == 40 then
                TriggerEvent("frkn-bodycam:client:notify", "Uploading video... Estimated time: 2-3 minutes", "info", 5000)
            elseif processingCounter == 100 then
                TriggerEvent("frkn-bodycam:client:notify", "Uploading video... Estimated time: 1-2 minutes", "info", 5000)
            elseif processingCounter == 150 then
                TriggerEvent("frkn-bodycam:client:notify", "Uploading video... Estimated time: 30-60 seconds", "info",
                    5000)
            end
        end
    end, 100)
    while isProcessing do
        Wait(100)
    end
    ClearInterval(intervalHandle)
    return uploadResult
end

RegisterNUICallback("recordingComplete", function(data, cb)
    if data.success then
        local videoUrl = data.videoUrl or nil
        uploadResult = {
            success = true,
            videoUrl = videoUrl
        }
        TriggerEvent("frkn-bodycam:client:notify", "Video uploaded successfully!", "success", 5000)
    else
        uploadResult = {
            success = false,
            error = data.error
        }
        TriggerEvent("frkn-bodycam:client:notify", "Upload failed: " .. (data.error or "Unknown error"), "error", 5000)
    end
    isProcessing = false
    cb("ok")
end)

if not SetInterval then
    function SetInterval(callback, interval)
        local handle = { active = true }
        Citizen.CreateThread(function()
            while handle.active do
                callback()
                Citizen.Wait(interval)
            end
        end)
        return handle
    end
end

if not ClearInterval then
    function ClearInterval(handle)
        if handle then
            handle.active = false
        end
    end
end

exports("startCapture", startCapture)
exports("stopCapture", stopCapture)
