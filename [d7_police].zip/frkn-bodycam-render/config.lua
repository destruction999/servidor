-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Config = {}

Config.MediaService = 'fm'

Config.Services = {
    fm = {
        apiUrl = 'https://fmapi.net/api/v2/video',
        apiKey = 'PON_AQUI_TU_API_KEY',
        headers = {
            'Authorization'
        }
    },
    
    fivemerr = {
        apiUrl = 'https://api.fivemerr.com/v1/media/videos',
        apiKey = 'YOUR_FIVEMERR_API_KEY',
        headers = {
            'Authorization'
        }
    },
    
    discord = {
        webhookUrl = 'YOUR_DISCORD_WEBHOOK_URL', 
        maxFileSize = 25 * 1024 * 1024,
        username = 'Bodycam System',
        avatarUrl = nil
    }
}

Config.MediaServiceKey = Config.Services[Config.MediaService] and Config.Services[Config.MediaService].apiKey or 'PON_AQUI_TU_API_KEY'
