-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Core = nil
CoreName = nil
CoreReady = false

Citizen.CreateThread(function()
    for k, v in pairs(Cores) do
        if GetResourceState(v.ResourceName) == "starting" or GetResourceState(v.ResourceName) == "started" then
            CoreName = v.ResourceName
            Core = v.GetFramework()
            CoreReady = true
        end
    end
end)

local channels = {}
local playerChannels = {}

function GetPlayerIdentifierBySource(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        return player and player.PlayerData.citizenid or nil
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        return player and player.identifier or nil
    end
    return nil
end

function GetPlayerNameBySource(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        if player and player.PlayerData.charinfo then
            return player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
        end
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        return player and player.getName() or GetPlayerName(source)
    end
    return GetPlayerName(source)
end

RegisterServerEvent('frkn-radio:server:triggerCallback', function(name, ...)
    local src = source
    if FRKN.ServerCallbacks and FRKN.ServerCallbacks[name] then
        FRKN.ServerCallbacks[name](src, function(...)
            TriggerClientEvent('frkn-radio:client:triggerCallback', src, name, ...)
        end, ...)
    end
end)

FRKN.ServerCallbacks = FRKN.ServerCallbacks or {}

FRKN.ServerCallbacks["frkn-radio:getImg"] = function(source, cb)
    local identifier = GetPlayerIdentifierBySource(source)
    local avatar = nil
    cb(avatar)
end

FRKN.ServerCallbacks["frkn-radio:leftChannel"] = function(source, cb, mhz)
    local identifier = GetPlayerIdentifierBySource(source)
    if not identifier or not mhz then
        cb(false)
        return
    end
    
    local channel = channels[mhz]
    if not channel then
        cb(false)
        return
    end
    
    for i, member in ipairs(channel.members or {}) do
        if member.identifier == identifier then
            table.remove(channel.members, i)
            break
        end
    end
    
    if #channel.members == 0 then
        channels[mhz] = nil
    end
    
    playerChannels[identifier] = nil
    
    TriggerClientEvent("frkn-radio:updateChannel", -1, channels, "allmemberupdate")
    cb(true)
end

FRKN.ServerCallbacks["frkn-radio:createChannel"] = function(source, cb, mhz, password)
    local identifier = GetPlayerIdentifierBySource(source)
    if not identifier or not mhz then
        cb({
            success = false,
            message = "Invalid channel.",
            type = "error"
        })
        return
    end
    
    if channels[mhz] then
        cb({
            success = false,
            message = "Channel already exists.",
            type = "error"
        })
        return
    end
    
    channels[mhz] = {
        password = password or "",
        members = {},
        chat = {}
    }
    
    cb({
        success = true,
        message = "Channel created successfully.",
        type = "success"
    })
end

FRKN.ServerCallbacks["frkn-radio:getChannels"] = function(source, cb)
    local result = {}
    for mhz, channel in pairs(channels) do
        result[mhz] = {
            memberCount = #(channel.members or {}),
            hasPassword = channel.password and channel.password ~= ""
        }
    end
    cb(result)
end

FRKN.ServerCallbacks["frkn-radio:joinChannel"] = function(source, cb, channel)
    local identifier = GetPlayerIdentifierBySource(source)
    local playerName = GetPlayerNameBySource(source)
    
    if not identifier or not channel then
        cb(nil)
        return
    end
    
    if not channels[channel] then
        channels[channel] = {
            password = "",
            members = {},
            chat = {}
        }
    end
    
    local channelData = channels[channel]
    
    if channelData.password and channelData.password ~= "" then
        cb({ password = true })
        return
    end
    
    if playerChannels[identifier] and playerChannels[identifier] ~= channel then
        local oldChannel = playerChannels[identifier]
        if channels[oldChannel] then
            for i, member in ipairs(channels[oldChannel].members or {}) do
                if member.identifier == identifier then
                    table.remove(channels[oldChannel].members, i)
                    break
                end
            end
            if #channels[oldChannel].members == 0 then
                channels[oldChannel] = nil
            end
        end
    end
    
    local alreadyMember = false
    for _, member in ipairs(channelData.members or {}) do
        if member.identifier == identifier then
            alreadyMember = true
            break
        end
    end
    
    if not alreadyMember then
        table.insert(channelData.members, {
            identifier = identifier,
            name = playerName
        })
    end
    
    playerChannels[identifier] = channel
    
    TriggerClientEvent("frkn-radio:updateChannel", -1, channels, "memberupdate")
    
    cb({ connected = true })
end

FRKN.ServerCallbacks["frkn-radio:addMember"] = function(source, cb, mhz)
    local identifier = GetPlayerIdentifierBySource(source)
    local playerName = GetPlayerNameBySource(source)
    
    if not identifier or not mhz then
        cb(nil)
        return
    end
    
    if not channels[mhz] then
        cb(nil)
        return
    end
    
    local channelData = channels[mhz]
    
    if playerChannels[identifier] and playerChannels[identifier] ~= mhz then
        local oldChannel = playerChannels[identifier]
        if channels[oldChannel] then
            for i, member in ipairs(channels[oldChannel].members or {}) do
                if member.identifier == identifier then
                    table.remove(channels[oldChannel].members, i)
                    break
                end
            end
            if #channels[oldChannel].members == 0 then
                channels[oldChannel] = nil
            end
        end
    end
    
    local alreadyMember = false
    for _, member in ipairs(channelData.members or {}) do
        if member.identifier == identifier then
            alreadyMember = true
            break
        end
    end
    
    if not alreadyMember then
        table.insert(channelData.members, {
            identifier = identifier,
            name = playerName
        })
    end
    
    playerChannels[identifier] = mhz
    
    TriggerClientEvent("frkn-radio:updateChannel", -1, channels, "memberupdate")
    
    cb(channelData)
end

RegisterServerEvent("frkn-radio:sendChatMessage", function(channel, message)
    local src = source
    local identifier = GetPlayerIdentifierBySource(src)
    local playerName = GetPlayerNameBySource(src)
    
    if not channel or not channels[channel] then
        return
    end
    
    local chatMessage = {
        identifier = identifier,
        name = playerName,
        message = message,
        time = os.date("%H:%M")
    }
    
    table.insert(channels[channel].chat, chatMessage)
    
    if #channels[channel].chat > 50 then
        table.remove(channels[channel].chat, 1)
    end
    
    for _, member in ipairs(channels[channel].members or {}) do
        local targetPlayer = GetPlayerByIdentifier(member.identifier)
        if targetPlayer then
            TriggerClientEvent("frkn-radio:receiveChatMessage", targetPlayer, chatMessage)
        end
    end
end)

RegisterServerEvent("frkn-radio:dataPostClient", function()
    local src = source
    local identifier = GetPlayerIdentifierBySource(src)
    
    if not identifier then
        return
    end
    
    if playerChannels[identifier] then
        TriggerClientEvent("frkn-radio:setClient", src, channels)
    end
end)

RegisterServerEvent("frkn-radio:toggleTalking", function(isTalking)
    local src = source
    local identifier = GetPlayerIdentifierBySource(src)
    
    if not identifier then
        return
    end
    
    local playerChannel = playerChannels[identifier]
    if not playerChannel or not channels[playerChannel] then
        return
    end
    
    for _, member in ipairs(channels[playerChannel].members or {}) do
        local targetPlayer = GetPlayerByIdentifier(member.identifier)
        if targetPlayer then
            TriggerClientEvent("frkn-radio:updateSpeaking", targetPlayer, identifier, isTalking)
        end
    end
end)

function GetPlayerByIdentifier(identifier)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerByCitizenId(identifier)
        return player and player.PlayerData.source or nil
    elseif CoreName == "es_extended" then
        local xPlayers = Core.GetExtendedPlayers()
        for _, xPlayer in pairs(xPlayers) do
            if xPlayer.identifier == identifier then
                return xPlayer.source
            end
        end
    end
    return nil
end

AddEventHandler("playerDropped", function(reason)
    local src = source
    local identifier = GetPlayerIdentifierBySource(src)
    
    if not identifier then
        return
    end
    
    local playerChannel = playerChannels[identifier]
    if playerChannel and channels[playerChannel] then
        for i, member in ipairs(channels[playerChannel].members or {}) do
            if member.identifier == identifier then
                table.remove(channels[playerChannel].members, i)
                break
            end
        end
        
        if #channels[playerChannel].members == 0 then
            channels[playerChannel] = nil
        end
        
        TriggerClientEvent("frkn-radio:updateChannel", -1, channels, "allmemberupdate")
    end
    
    playerChannels[identifier] = nil
end)

