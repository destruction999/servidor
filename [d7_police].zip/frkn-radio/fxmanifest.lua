-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts
-- Join our Discord : https://discord.com/invite/R9KgyCkXJp

fx_version 'cerulean'
game 'gta5'
lua54 'yes'

escrow_ignore {
    'client/core.lua',
    'client/callback.lua',
    'server/core.lua',
    'shared/*.lua',
    'locales/*.lua',
}

shared_scripts {
    "@ox_lib/init.lua",
    'shared/locale.lua',
    'locales/en.lua',
    'locales/*.lua',
    'shared/cores.lua',
    'shared/config.lua'
}

client_scripts {
    'client/*.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/*.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/images/*.png',
    'html/images/*.jpg',
    'html/images/*.webp',
    'html/images/*.svg',
    'html/images/*.gif',
    'html/fonts/*.ttf',
    'html/fonts/*.otf',
    'html/script.js',
}

