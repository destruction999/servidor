

local Translations = {
    error = {
        unauthorized_access = "Vous n’avez pas la permission d’accéder à ce canal.",
        already_connected   = "Vous êtes déjà connecté à ce canal.",
        invalid_frequency   = "La fréquence est invalide ou hors plage.",
        not_on_duty         = "Vous devez être en service pour accéder à ce canal.",
        job_not_allowed     = "Votre métier n’a pas accès à ce canal.",
        radio_kicked_job_change = "Vous avez été retiré de la radio suite à un changement de métier.",
        radio_kicked_duty_change = "Vous avez été retiré de la radio car vous n’êtes plus en service."
    },
    success = {
        auto_connected_header  = "Connexion automatique.",
        auto_connected_message = "Vous avez été automatiquement connecté au canal : {channel}.",
    },
    general = {
        connecting = "Connexion au canal...",
        disconnect = "Déconnecté du canal."
    }
}

Lang = Lang or Locale:new({
    phrases = Translations,
    warnOnMissing = true
})

