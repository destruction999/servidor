let dragEnabled = false;
let passwordOpened = false;
let currentPage = 'home-page';
let currentPassword = null;
let currentMhz = null;
let light = false;
let identifier = null;
let avatar = null;

let currentChannel = null;

let configChannels = []


window.addEventListener("message", function (event) {
  const e = event.data;

  if (e.action === "openRadio") {
    avatar = e.avatar;
    currentMhz = e.mhz;
    currentPassword = e.password;
    identifier = e.identifier;
    currentChannel = e.channelData;
    $('.mhzvalue').text(currentMhz + ' MHz');
    $('.power-input , #connect-mhz').val(currentMhz);
    configChannels = e.configChannels;
    openRadio(e);
  }

  if (e.action === "closeRadio") {
    $('.radio').fadeOut(300);
  }

  if (e.action == "closeRadioUI") {
    $('.member-list').fadeOut(300);
    $('.cmembers-list').html('');
    $('.length-box').text('0');
  }

  if (e.action === "radioSpeak") {
    const targetDiv = $(`.cmembers-list .name[data-identifier="${e.identifier}"]`).siblings('.mic');

    if (e.speaking) {
      targetDiv.attr('src', '../html/images/member-mic-open2.svg');
      targetDiv.css({'width':'4vh','height':'4vh','top':'-21%','left':'83.3%' });
    } else {
      targetDiv.attr('src', '../html/images/member-mic-close.svg');
      targetDiv.css({'width':'53%','height':'53%','top':'20%','left':'63%' });
    }
  }


  if (e.action === "autoConnect") {
    currentMhz = e.mhz;
    currentPassword = e.password;
    identifier = e.identifier;

    $('.chat-area').html('');

    $('.home-page , .settings-page , .chat-page , .favorites-page').fadeOut(300);
    $('.chat-page').fadeIn(300);

    currentChannel = e.channelData;

    currentChannel.chat.forEach(chatMsg => {
      const memberData = currentChannel.members.find(m => m.identifier === chatMsg.identifier);
      const name = memberData?.name || "Unknown";

      if (chatMsg.identifier === identifier) {
        $('.chat-area').append(`
                <div class="chat-message right">
                    <div class="player-name-text">Player Name</div>
                    <div class="player-name">${name}</div>
                    <div class="message-content">
                        <div class="message-text">${chatMsg.message}</div>
                    </div>
                    <img src="${chatMsg.avatar}" class="avatar">
                </div>
            `);
      } else {
        $('.chat-area').append(`
                <div class="chat-message left">
                    <div style="left:3%;" class="player-name-text">Player Name</div>
                    <div style="left:2%;" class="player-name">${name}</div>
                    <img src="${chatMsg.avatar}" class="avatar">
                    <div class="message-content">
                        <div class="message-text">${chatMsg.message}</div>
                    </div>
                </div>
            `);
      }
    });

    $('.mhzvalue').text(currentMhz + ' MHz');
    $('.power-input , #connect-mhz').val(currentMhz);

    $('.cmembers-list , .members-list').html('');

    currentChannel.members.forEach(member => {
      $('.cmembers-list').append(`
              <div class="member">
                  <div data-identifier="${member.identifier}" class="name">${member.name}</div>
                  <img src="../html/images/member-mic-close.svg" class="mic" alt="">
              </div>
          `);

      $('.members-list').append(`
              <div class="member"><div class="name">${member.name}</div> <img src="../html/images/micopen.svg" alt=""> </div>
          `);

      $('.length-box').text(currentChannel.members.length);
    });

    if (e.notify) {
      showNotify(e.notifyMessage.header, e.notifyMessage.message);
    }

  }

  if (e.action === 'updateMembersOnly') {
    $('.cmembers-list').html('');
    $('.members-list').html('');

    e.members.forEach(member => {
      $('.cmembers-list').append(`
      <div class="member">
          <div data-identifier="${member.identifier}" class="name">${member.name}</div>
          <img src="../html/images/member-mic-close.svg" class="mic" alt="">
      </div>
    `);

      $('.members-list').append(`
      <div class="member">
          <div class="name">${member.name}</div> 
          <img src="../html/images/micopen.svg" alt="">
      </div>
    `);
    });

    $('.length-box').text(e.members.length);
  }


  if (e.action === "newChatMessage") {
    var data = e;
    $('.chat-area').html('');
    data.chat.forEach(chatMsg => {
      const memberData = data.members.find(m => m.identifier === chatMsg.identifier);
      const name = memberData?.name || "Unknown";
      if (chatMsg.identifier === data.identifier) {
        $('.chat-area').append(`
                <div class="chat-message right">
                    <div class="player-name-text">Player Name</div>
                    <div class="player-name">${name}</div>
                    <div class="message-content">
                        <div class="message-text">${chatMsg.message}</div>
                    </div>
                    <img src="${chatMsg.avatar}" class="avatar">
                </div>
            `);
      } else {
        $('.chat-area').append(`
                <div class="chat-message left">
                    <div style="left:3%;" class="player-name-text">Player Name</div>
                    <div style="left:2%;" class="player-name">${name}</div>
                    <img src="${chatMsg.avatar}" class="avatar">
                    <div class="message-content">
                        <div class="message-text">${chatMsg.message}</div>
                    </div>
                </div>
            `);
      }
    });

    scrollToBottom();
  }
});


function openRadio(e) {
  identifier = e.identifier;

  $('.home-page , .settings-page , .chat-page , .favorites-page').fadeOut(300);
  $('.home-page , .radio').fadeIn(300);
  $('body').fadeIn(300);
}

function updateVolumeUI(level) {
  const all = $('.sound-box .sound');
  const total = all.length;
  all.removeClass('active');

  const start = total - level;
  all.each(function (i) {
    if (i >= start) $(this).addClass('active');
  });

  const scaledVolume = Math.floor((level / total) * 100);

  $.post(`https://${GetParentResourceName()}/setVolume`, JSON.stringify({
    volume: scaledVolume
  }));
}


$(document).on('click', '.sound-box .sound', function () {
  const index = $(this).index();
  const total = $('.sound-box .sound').length;
  const volume = total - index;
  updateVolumeUI(volume);
});

$(document).on('click', '.arti-box', function () {
  const current = $('.sound-box .sound.active').length;
  const max = $('.sound-box .sound').length;
  if (current < max) updateVolumeUI(current + 1);
});

$(document).on('click', '.eksi-box', function () {
  const current = $('.sound-box .sound.active').length;
  if (current > 0) updateVolumeUI(current - 1);
});



$(document).on('click', '.members-box', function () {
  $('.members-box').addClass('active');
  $('.channels-box').removeClass('active');
  $('.page-list').css('display', 'none');
  $('.members-list').css('display', 'block');
});

$(document).on('click', '.channels-box', function () {
  $('.channels-box').addClass('active');
  $('.members-box').removeClass('active');
  $('.page-list').css('display', 'flex');
  $('.members-list').css('display', 'none');
});

let createChannel = true;
$(document).on('click', '.alt-box .box', function () {
  page = $(this).data('page');

  if (page == 'create-channel') {
    createChannel = !createChannel;
    if (createChannel) {
      $('.mhz-popup').css('display', 'none');
      $('.create-radio').css('display', 'block');

      setTimeout(() => {
        $('.create-radio .blur').css('filter', 'blur(0.4vh)');
      }, 100);

      setTimeout(() => {
        $('.create-radio').css({
          'pointer-events': 'all',
          'top': '100%',
          'opacity': '0'
        });
      }, 150);
    } else {
      $('.mhz-popup').css('display', 'none');
      $('.create-radio').css('display', 'block');

      setTimeout(() => {
        $('.create-radio .blur').css('filter', 'blur(0.4vh)');
      }, 100);

      setTimeout(() => {
        $('.create-radio').css({
          'pointer-events': 'all',
          'top': '7%',
          'opacity': '1'
        });
      }, 150);
    }
  } else if (page == 'message-channel') {

    setTimeout(() => {
      $('.page-list .page[data-page="chat-page"]').trigger('click');
    }, 500);


  } else if (page == 'light') {
    light = !light;
    $.post('https://frkn-radio/flash', JSON.stringify({
      flash: light
    }));
    $('#light-img').attr('src', light ? '../html/images/light.svg' : '../html/images/flashlight-2.svg');
  }
});

$(document).on('click', '.page-list .page', function () {
  const page = $(this).data('page');
  $('.home-page , .settings-page , .chat-page').fadeOut(300);
  $('.' + page).fadeIn(300);

  currentPage = page;

  const colorBox = $('.radio .color-box');

  colorBox.css({
    display: 'flex',
    opacity: 0
  }).animate({
    top: '0%'
  }, 500);
  if (page == 'channel-page') {
    $('.favorites-page').fadeIn(300);
    $('.favorites-page .star').css('display', 'none');
    $('.favorites-page .page-header').text('Listed Radios').css({ 'color': '#98D8FF', 'text-shadow': '0px 0px 9.9px rgba(152, 216, 255, 0.64)', 'left': '5%' });

    console.log(JSON.stringify(configChannels))
    $('.favorites-list').html('');

    $.each(configChannels, function (i, cfg) {
      var mhz = (cfg && cfg.mhz != null) ? cfg.mhz : (i + 1);
      var jobs = cfg && cfg.jobs ? Object.keys(cfg.jobs) : [];
      var gangs = cfg && cfg.gangs ? Object.keys(cfg.gangs) : [];
      var tags = [];
      if (jobs.length) tags.push('Jobs: ' + jobs.join(', '));
      if (gangs.length) tags.push('Gangs: ' + gangs.join(', '));
      var info = tags.length ? `<div class="restr">${tags.join(' | ')}</div>` : '';

      $('.favorites-list').append(`
    <div class="fav" data-mhz="${String(mhz)}">
      <div class="radio-img"><img src="../html/images/radio2.png" alt=""></div>
      <div class="mhz-address">${mhz} MHz</div>
      <div class="members-length">0 Members</div>
      <img src="../html/images/members.svg" class="members" alt="">
      <div class="fav-connect">
        <img src="../html/images/connect.svg" class="connect-icon" alt="">
        <div class="text">Connect</div>
      </div>
    </div>
  `);
    });


    $.post('https://frkn-radio/getChannels', JSON.stringify({}), function (channels) {

      Object.entries(channels).forEach(([mhz, channel]) => {
        const membersCount = channel.members ? channel.members.length : 0;

        $('.favorites-list').append(`
                <div class="fav">
                    <div class="radio-img">
                        <img src="../html/images/radio2.png" alt="">
                    </div>
                    <div class="mhz-address">${mhz} MHz</div>
                    <div class="members-length">${membersCount} Members</div>
                    <img src="../html/images/members.svg" class="members" alt="">
                    <div class="fav-connect">
                        <img src="../html/images/connect.svg" class="connect-icon" alt="">
                        <div class="text">Connect</div>
                    </div>
                </div>
            `);
      });
    });




  } else if (page == 'favorites-page') {
    $('.favorites-page .star').css('display', 'block');
    $('.favorites-page .page-header').text('FAVORITES TAB').css({ 'color': '#FFFC9A', 'text-shadow': '0px 0px 9.9px rgba(255, 252, 154, 0.64)', 'left': '15%' });
  } else if (page == 'chat-page') {
    if (currentChannel && typeof currentChannel === 'object' && Array.isArray(currentChannel.members) && currentChannel.members.length > 0) {
      $('.chat-area').html('');
      currentChannel.chat.forEach(chatMsg => {
        const memberData = currentChannel.members.find(m => m.identifier === chatMsg.identifier);
        const name = memberData?.name || "Unknown";

        if (chatMsg.identifier === identifier) {
          $('.chat-area').append(`
                <div class="chat-message right">
                    <div class="player-name-text">Player Name</div>
                    <div class="player-name">${name}</div>
                    <div class="message-content">
                        <div class="message-text">${chatMsg.message}</div>
                    </div>
                    <img src="${chatMsg.avatar}" class="avatar">
                </div>
            `);
        } else {
          $('.chat-area').append(`
                <div class="chat-message left">
                    <div style="left:3%;" class="player-name-text">Player Name</div>
                    <div style="left:2%;" class="player-name">${name}</div>
                    <img src="${chatMsg.avatar}" class="avatar">
                    <div class="message-content">
                        <div class="message-text">${chatMsg.message}</div>
                    </div>
                </div>
            `);
        }
      });

      // $('.chat-page .mhzvalue').text(currentChannel.mhz + ' MHz');
      // $('.chat-page .length-box').text(currentChannel.members.length);
      // $('.chat-page .members-list').html(''); 

      currentChannel.members.forEach(member => {
        $('.chat-page .members-list').append(`
          <div class="member">
            <div class="name">${member.name}</div>
            <img src="../html/images/micopen.svg" alt="">
          </div>
        `);
      });
      $('.chat-page').fadeIn(300, function () {
        scrollToBottom();
      });
    } else {
      $('.chat-page').fadeOut(300);
      $('.home-page').fadeIn(300);
      showNotify('Error', 'No channel connected. Please connect to a channel first.');
    }


  } else if (page == 'settings-page') {
    openColorBox(colorBox);
  }

})

$(document).on('click', '.home-button', function () {
  homePage()
})

$(document).on('click', '.left-button', function () {
  $('.radio').fadeOut()
  $.post('https://frkn-radio/closeRadio', JSON.stringify({}), function (response) { });
})
$(document).on('click', '.right-button', function () {

  $('.mhz-popup').css('display', 'block');

  setTimeout(() => {
    $('.mhz-popup .blur').css('filter', 'blur(0.4vh)');
  }, 100);

  setTimeout(() => {
    $('.mhz-popup').css({
      'pointer-events': 'all',
      'top': '7%',
      'opacity': '1'
    });
  }, 150);

})

$(document).on('keydown', function (e) {
  if (e.key === 'Escape') {
    $('.radio').fadeOut();
    $.post('https://frkn-radio/closeRadio', JSON.stringify({}));
  }
});

$(document).on('click', '.power-on', function () {
  $('.mhz-popup').css('display', 'block');

  setTimeout(() => {
    $('.mhz-popup .blur').css('filter', 'blur(0.4vh)');
  }, 100);

  setTimeout(() => {
    $('.mhz-popup').css({
      'pointer-events': 'all',
      'top': '7%',
      'opacity': '1'
    });
  }, 150);

});

$(document).on('click', '.fav-connect', function () {
  const mhzText = $(this).closest('.fav').find('.mhz-address').text();
  const mhzValue = parseFloat(mhzText);
  currentMhz = mhzValue;

  $.post('https://frkn-radio/connect', JSON.stringify({ mhz: mhzValue }), function (res) {
    if (typeof res === 'string') { try { res = JSON.parse(res) } catch (_) { } }

    if (res === 'notchannel') { showNotify('Error', 'This channel does not exist.'); return; }
    if (res === false) { showNotify('Error', 'Connection failed.'); return; }

    if (res && (res.password || res.requirePassword)) {
      currentPassword = res.password || '';
      $('.password').fadeIn(300).css({ 'display': 'flex', 'top': '0%', 'left': '0%' });
      setTimeout(() => { passwordOpened = true; }, 300);
      return;
    }

    if (res && res.error) { showNotify('Error', res.error); return; }
    if (res && res.connected) { showNotify('Success', 'Connected to ' + mhzValue + ' MHz'); return; }

    showNotify('Error', 'Unexpected response.');
  }, 'json').fail(function () {
    showNotify('Error', 'Connection failed.');
  });
});



$(document).on('click', '#connect', function () {
  const mhzValue = $('#connect-mhz').val();
  currentMhz = mhzValue;
  $.post('https://frkn-radio/connect', JSON.stringify({
    mhz: mhzValue
  }), function (response) {
    if (response == 'notchannel') {
      showNotify('Error', 'This channel does not exist.');
      return;
    }

    if (response.error) {
      showNotify('Error', response.error);
    }

    if (response.connected) {
      showNotify('Success', 'Connected to the channel successfully.');
    }

    if (response.password) {
      currentPassword = response.password;
      $('.password').fadeIn(300).css('display', 'flex');
      setTimeout(() => { passwordOpened = true; }, 300);
    } else {
      $('.mhz-popup , .create-radio').css({
        'opacity': '0',
        'pointer-events': 'none',
        'top': '100%'
      });

      setTimeout(() => {
        $('.mhz-popup .blur').css('filter', 'blur(0)');
      }, 300);

      setTimeout(() => {
        $('.mhz-popup , .create-radio').css('display', 'none');
      }, 400);
    }
  });
});

$(document).on('click', function (e) {
  if (passwordOpened && !$(e.target).closest('.password-input').length) {
    $('.password').fadeOut(300, function () {
      $(this).css('display', 'none');
      passwordOpened = false;
    });
  }
});


$(document).on('keydown', '.password-input', function (e) {
  if (e.key === 'Enter') {
    const enteredPassword = $(this).val();

    if (enteredPassword === currentPassword) {

      $.post('https://frkn-radio/confirm', JSON.stringify({
        mhz: currentMhz,
        success: true
      }), function (channels) {

        $('.home-page , .settings-page , .chat-page , .favorites-page').fadeOut(300);
        $('.chat-page').fadeIn(300);

        currentChannel = channels.channelData;

        $('.chat-area').html('');

        currentChannel.chat.forEach(chatMsg => {
          const memberData = currentChannel.members.find(m => m.identifier === chatMsg.identifier);
          const name = memberData?.name || "Unknown";

          if (chatMsg.identifier === identifier) {
            $('.chat-area').append(`
                  <div class="chat-message right">
                      <div class="player-name-text">Player Name</div>
                      <div class="player-name">${name}</div>
                      <div class="message-content">
                          <div class="message-text">${chatMsg.message}</div>
                      </div>
                      <img src="${chatMsg.avatar}" class="avatar">
                  </div>
              `);
          } else {
            $('.chat-area').append(`
                  <div class="chat-message left">
                      <div style="left:3%;" class="player-name-text">Player Name</div>
                      <div style="left:2%;" class="player-name">${name}</div>
                      <img src="${chatMsg.avatar}" class="avatar">
                      <div class="message-content">
                          <div class="message-text">${chatMsg.message}</div>
                      </div>
                  </div>
              `);
          }
        });

        showNotify('Success', 'Connected to the channel successfully.');

        $('.mhzvalue').text(currentMhz + ' MHz');

        $('.cmembers-list , .members-list').html('');

        if (channels.success && channels.channelData && channels.channelData.members) {
          channels.channelData.members.forEach(member => {
            $('.cmembers-list').append(`
                    <div class="member">
                        <div class="name">${member.name}</div>
                        <img src="../html/images/member-mic-close.svg" class="mic" alt="">
                    </div>
                `);

            $('.members-list').append(`
                  <div class="member"><div class="name">${member.name}</div> <img src="../html/images/micopen.svg" alt=""> </div>
                `);

            $('.length-box').text(channels.channelData.members.length);
          });
        }
      });

      $('.password').fadeOut(300, function () {
        $(this).css('display', 'none');
        passwordOpened = false;
      });

      $('.mhz-popup , .create-radio').css({
        'opacity': '0',
        'pointer-events': 'none',
        'top': '100%'
      });

      setTimeout(() => {
        $('.mhz-popup .blur').css('filter', 'blur(0)');
      }, 300);

      setTimeout(() => {
        $('.mhz-popup , .create-radio').css('display', 'none');
      }, 400);

      $('.power-input , #connect-mhz').val(currentMhz);

    } else {
      $.post('https://frkn-radio/confirm', JSON.stringify({
        mhz: currentMhz,
        success: false
      }));

      $('.password-input').val('');

      $('.password-input').addClass('shake');

      setTimeout(() => {
        $('.password-input').removeClass('shake');
      }, 500);

      showNotify('Error', 'Incorrect password. Please try again.');
    }
  }
});

$(document).on('click', '#create-channel', function () {
  const channelName = $('#channel-name').val();
  const channelPassword = $('#channel-password').val();

  if (!channelName || !channelPassword) {
    showNotify('Error', 'Please fill in all fields.');
    return;
  }

  $.post('https://frkn-radio/createChannel', JSON.stringify({
    mhz: channelName,
    password: channelPassword,
  }), function (response) {
    if (response.success) {
      showNotify('Success', response.message || 'Channel created successfully.');

      $('.mhz-popup , .create-radio').css({
        'opacity': '0',
        'pointer-events': 'none',
        'top': '100%'
      });

      setTimeout(() => {
        $('.mhz-popup .blur').css('filter', 'blur(0)');
      }, 300);

      setTimeout(() => {
        $('.mhz-popup , .create-radio').css('display', 'none');
      }, 400);
    } else {
      showNotify('Error', response.message || 'Failed to create channel.');
    }
  });

})

$(document).on('input', '.mhz-input-2', function () {
  const name = $(this).val();
  if (name) {
    $('.connect-box .header').text(name + ' mhz');
  } else {
    $('.connect-box .header').text('0 mhz');
  }
});



$(document).on('click', '.blur', function () {
  $('.mhz-popup').css({
    'opacity': '0',
    'pointer-events': 'none',
    'top': '100%'
  });

  setTimeout(() => {
    $('.mhz-popup .blur').css('filter', 'blur(0)');
  }, 300);

  setTimeout(() => {
    $('.mhz-popup').css('display', 'none');
  }, 400);
  $('.create-radio').css({
    'opacity': '0',
    'pointer-events': 'none',
    'top': '100%'
  });
  setTimeout(() => {
    $('.create-radio .blur').css('filter', 'blur(0)');
  }, 300);
});


$(document).on('input', '#myRange', function () {
  var min = $(this).attr('min');
  var max = $(this).attr('max');
  var val = ($(this).val() - min) / (max - min);
  $(this).css('background', 'linear-gradient(to right, #98D8FF ' + (val * 100) + '%, #333 ' + (val * 100) + '%)');
  var currentValue = parseInt($(this).val());
  var displayValue = (currentValue / 100).toFixed(2) + "x";
  $('#sizeValue').text(displayValue);
  var sizeMultiplier = currentValue / 124;
  var baseWidth = 19;
  var baseHeight = 61.3;
  var newWidth = (baseWidth * sizeMultiplier) + '%';
  var newHeight = (baseHeight * sizeMultiplier) + '%';
  $('.radio').css({ width: newWidth, height: newHeight });
});

let isDragging = false;
let offsetX, offsetY;

let isDraggingRadio = false;
let isDraggingMemberList = false;

$(document).on('mousedown', '.radio', function (e) {
  if (!dragEnabled) return;
  isDraggingRadio = true;
  offsetX = e.clientX - $(this).offset().left;
  offsetY = e.clientY - $(this).offset().top;
});

$(document).on('mousedown', '.member-list', function (e) {
  if (!dragEnabled) return;
  isDraggingMemberList = true;
  offsetX = e.clientX - $(this).offset().left;
  offsetY = e.clientY - $(this).offset().top;
});

$(document).on('mousemove', function (e) {
  if (!dragEnabled) return;

  if (isDraggingRadio) {
    const newLeft = (e.clientX - offsetX) + 'px';
    const newTop = (e.clientY - offsetY) + 'px';

    $('.radio').css({
      left: newLeft,
      top: newTop
    });
  }

  if (isDraggingMemberList) {
    const newLeft = (e.clientX - offsetX) + 'px';
    const newTop = (e.clientY - offsetY) + 'px';

    $('.member-list').css({
      left: newLeft,
      top: newTop
    });
  }
});

$(document).on('mouseup', function () {
  if (!dragEnabled) return;
  isDraggingRadio = false;
  isDraggingMemberList = false;
});

$(document).on('dragstart', '.radio, .member-list', function (e) {
  e.preventDefault();
});


// chatMessages.forEach(data => {
//   if (data.sender === "me") {
//       $('.chat-area').append(`
//           <div class="chat-message right">
//               <div class="player-name-text">Player Name</div>
//               <div class="player-name">${data.playerName}</div>
//               <div class="message-content">
//                   <div class="message-text">${data.message}</div>
//               </div>
//               <img src="${data.avatar}" class="avatar">
//           </div>
//       `);
//   } else {
//       $('.chat-area').append(`
//           <div class="chat-message left">
//               <div style="left:3%;" class="player-name-text">Player Name</div>
//               <div style="left:2%;width:100%;right:0%;" class="player-name">${data.playerName}</div>
//               <img src="${data.avatar}" class="avatar">
//               <div class="message-content">
//                   <div class="message-text">${data.message}</div>
//               </div>
//           </div>
//       `);
//   }

//   scrollToBottom();
// });

$(document).on('input', '.search-input', function () {
  var searchText = $(this).val().toLowerCase();

  if ($('.members-box').hasClass('active')) {
    $('.members-list .member').each(function () {
      var memberName = $(this).find('.name').text().toLowerCase();
      if (memberName.includes(searchText)) {
        $(this).show();
      } else {
        $(this).hide();
      }
    });
  } else if ($('.channels-box').hasClass('active')) {
    $('.page-list .page').each(function () {
      var headerText = $(this).find('.header').text().toLowerCase();
      var descText = $(this).find('.desc').text().toLowerCase();

      if (headerText.includes(searchText) || descText.includes(searchText)) {
        $(this).show();
      } else {
        $(this).hide();
      }
    });
  }
});

$(document).on('mouseenter', '.settings', function () {
  const img = $(this).find('.icon');
  const src = img.attr('src');

  if (!src.includes('-open')) {
    const newSrc = src.replace('.svg', '-open.svg');
    img.attr('src', newSrc);
  }

  img.css({
    width: '60%',
    height: '60%',
    top: '-5%'
  });
});

$(document).on('mouseleave', '.settings', function () {
  const img = $(this).find('.icon');
  const src = img.attr('src');

  if (!$(this).hasClass('active')) {
    if (src.includes('-open')) {
      const originalSrc = src.replace('-open.svg', '.svg');
      img.attr('src', originalSrc);
    }

    img.css({
      width: '',
      height: '',
      top: ''
    });
  } else {
    img.css({
      width: '60%',
      height: '60%',
      top: '-5%'
    });
  }
});



$(document).on('click', '.popupclick-button', function () {
  let toggled = $(this).data('toggled') || false;
  let mode = $(this).closest('.settings').data('mode') || 'normal';
  const settings = $(this).closest('.settings');
  const popupText = settings.find('.popup-text');
  const icon = settings.find('.icon');

  if (!toggled) {
    $(this).animate({ left: '55%' }, 300).css('background', '#98D8FF');
    settings.addClass('active');
    popupText.text('ON');

    const src = icon.attr('src');
    if (!src.includes('-open')) {
      icon.attr('src', src.replace('.svg', '-open.svg'));
    }

    icon.css({
      width: '60%',
      height: '60%',
      top: '-5%'
    });
  } else {
    $(this).animate({ left: '10%' }, 300).css('background', '#D9D9D9');
    settings.removeClass('active');
    popupText.text('OFF');

    const src = icon.attr('src');
    if (src.includes('-open')) {
      icon.attr('src', src.replace('-open.svg', '.svg'));
    }

    icon.css({
      width: '',
      height: '',
      top: ''
    });
  }

  $(this).data('toggled', !toggled);

  if (mode === 'drag') {
    dragEnabled = !toggled;
  } else if (mode === 'member') {
    memberListEnabled = !toggled;
    $('.member-list').css('display', toggled ? 'none' : 'flex');
  } else if (mode === 'flash') {
    flashEnabled = !toggled;
    $.post('https://frkn-radio/flash', JSON.stringify({
      flash: flashEnabled
    }));
    $('#light-img').attr('src', flashEnabled ? '../html/images/light.svg' : '../html/images/flashlight-2.svg');
  }
});

$(document).on('click', '.disconnect', function () {
  $.post('https://frkn-radio/leftChannel', JSON.stringify({
    mhz: currentMhz
  }), function (response) {
    if (response.success) {
      showNotify('Success', 'You have left the channel successfully.');
      $('.home-page , .settings-page , .chat-page , .favorites-page').fadeOut(300);
      $('.home-page').fadeIn(300);
      currentChannel = null;
      currentMhz = null;
      currentPassword = null;
      $('.mhzvalue').text('0 MHz');
      $('.power-input , #connect-mhz').val('0');
      $('.cmembers-list , .members-list').html('');
      $('.length-box').text('0');
      $('.chat-area').html('');
    } else {
      showNotify('Error', response.error || 'An error occurred while leaving the channel.');
    }
  });
})


$(document).on('click', '.edit', function () {

  let action = $(this).data('action');

  if (action == 'left') {
    $.post('https://frkn-radio/leftChannel', JSON.stringify({
      mhz: currentMhz
    }), function (response) {
      if (response.success) {
        showNotify('Success', 'You have left the channel successfully.');
        $('.home-page , .settings-page , .chat-page , .favorites-page').fadeOut(300);
        $('.home-page').fadeIn(300);
        currentChannel = null;
        currentMhz = null;
        currentPassword = null;
        $('.mhzvalue').text('0 MHz');
        $('.power-input , #connect-mhz').val('0');
        $('.cmembers-list , .members-list').html('');
        $('.length-box').text('0');
        $('.chat-area').html('');
      } else {
        showNotify('Error', response.error || 'An error occurred while leaving the channel.');
      }
    });
  } else if (action == 'home') {
    homePage();
  } else if (action == 'edit') {
    const colorBox = $('.radio .color-box');
    if (colorBox.css('display') === 'none') {
      openColorBox(colorBox);
    } else {
      closeColorBox(colorBox);
    }
  }
})

$(document).on('click', '.color', function () {
  $('.color').css('opacity', '0.5').css('border-radius', '0vh');
  $(this).css('opacity', '1').css('border-radius', '0.4vh');

  const index = $(this).index();
  const backgrounds = [
    '../html/images/radio-bg.png',
    '../html/images/radio-bg-2.png',
    '../html/images/radio-bg-3.png'
  ];

  $('.radio-bg').attr('src', backgrounds[index]);

  showNotify('Success', 'Background changed successfully.');
});

$(document).on('click', '.sent-box', function () {
  sendMessage();
});

$(document).on('keypress', '.chat-input', function (e) {
  if (e.which == 13) {
    sendMessage();
  }
});

$(document).on('dragstart', '.radio', function (e) {
  e.preventDefault();
});

function scrollToBottom() {
  var chatArea = $('.chat-area');
  chatArea.scrollTop(chatArea[0].scrollHeight);
}

function sendMessage() {
  var messageText = $('.chat-input').val().trim();

  if (messageText !== '') {
    $.post(`https://frkn-radio/sendChatMessage`, JSON.stringify({
      message: messageText
    }));

    $('.chat-area').append(`
      <div class="chat-message right">
        <div class="player-name-text">Player Name</div>
        <div class="player-name"></div>
        <div class="message-content">
          <div class="message-text">${messageText}</div>
        </div>
        <img src="${avatar}" class="avatar">
      </div>
    `);

    $('.chat-input').val('');
    scrollToBottom();
  }
}


// function sendMessage() {
//   var messageText = $('.chat-input').val().trim();

//   if (messageText !== '') {
//       $('.chat-area').append(`
//           <div class="chat-message right">
//               <div class="player-name-text">Player Name</div>
//               <div class="player-name">FURKAN</div>
//               <div class="message-content">
//                   <div class="message-text">${messageText}</div>
//               </div>
//               <img src="https://randomuser.me/api/portraits/men/32.jpg" class="avatar">
//           </div>
//       `);

//       $('.chat-input').val('');
//       scrollToBottom();
//   }
// }

function homePage() {
  $('.home-page , .settings-page , .chat-page , .favorites-page , .create-radio').fadeOut(300);
  $('.home-page').fadeIn(300);
  closeColorBox($('.radio .color-box'));
}


function updateTime() {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  $('.time').text(`${hours}:${minutes}`);
}

updateTime();

setInterval(updateTime, 10000);

function showNotify(headerText, altText) {
  const notify = $('.notify');

  notify.find('.header').text(headerText);
  notify.find('.alt').text(altText);

  notify.css({
    top: '-25%',
    opacity: 1,
    display: 'flex'
  }).animate({
    top: '0%'
  }, 500, function () {
    setTimeout(function () {
      notify.animate({
        top: '-25%'
      }, 500, function () {
        notify.css('display', 'none');
      });
    }, 3000);
  });
}

// showNotify('Success', 'Your data has been saved successfully.');


function openColorBox(colorBox) {

  colorBox.css({
    display: 'flex',
    opacity: 1
  }).animate({
    top: '-18%'
  }, 500);
}

function closeColorBox(colorBox) {
  colorBox.animate({
    top: '0%'
  }, 500, function () {
    colorBox.css({
      display: 'none',
      opacity: 0
    });
  });
}
