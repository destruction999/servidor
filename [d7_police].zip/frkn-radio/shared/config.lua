-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

FRKN = {
	ServerCallbacks = {},

	RadioAnimation = {
        Enable = false,
        Dict = "cellphone@",
        Animation = "cellphone_text_read_base"
    },

    MaxFrequency = 999.99,

    Notify = false, 

    BotToken = "",

    SpeakKey = 306 , 

	ItemCheckLoop = true,
	RadioItem = "radio",
    VoiceSystem = "pma-voice", 
    RestrictedChannels = {
        [1] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            },
            ["gangs"] = { 
                ballas = true
            }
        },
        [2] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            }
        },
        [3] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            }
        },
        [4] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            }
        },
        [5] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            }
        },
        [6] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            }
        },
        [7] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            }
        },
        [8] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            }
        },
        [9] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            }
        },
        [10] = {
            ["jobs"] = {
                police = true,
                ambulance = true
            }
        }
    },
}
