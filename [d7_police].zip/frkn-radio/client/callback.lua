

local voice = FRKN.VoiceSystem

RegisterNetEvent('QBCore:Client:OnJobUpdate', function(job)
    CheckRadioChannelAccess()
end)

RegisterNetEvent('esx:setJob', function(job)
    CheckRadioChannelAccess()
end)

function CheckRadioChannelAccess()
    local currentChannel = RadioChannel
    if currentChannel == 0 or not FRKN.RestrictedChannels[currentChannel] then return end

    local jobName = GetPlayerJob()
    local gang = GetPlayerGang()
    local player = GetPlayerData()

    local jobAllowed = FRKN.RestrictedChannels[currentChannel].jobs and FRKN.RestrictedChannels[currentChannel].jobs[jobName]
    local gangAllowed = FRKN.RestrictedChannels[currentChannel].gangs and gang and FRKN.RestrictedChannels[currentChannel].gangs[gang.name]
    local onDuty = player and player.job and player.job.onduty == true

    if not jobAllowed and not gangAllowed then
        if voice == "pma-voice" then
            exports["pma-voice"]:setRadioChannel(0)
        elseif voice == "saltychat" then
            exports.saltychat:SetRadioChannel('', true)
        end
        RadioChannel = 0
        onRadio = false
        Notify(Lang:t("error.radio_kicked_job_change"), "error")

    elseif jobAllowed and not onDuty then
        if voice == "pma-voice" then
            exports["pma-voice"]:setRadioChannel(0)
        elseif voice == "saltychat" then
            exports.saltychat:SetRadioChannel('', true)
        end
        RadioChannel = 0
        onRadio = false
        Notify(Lang:t("error.radio_kicked_duty_change"), "error")
    end
end

RegisterNUICallback('connect', function(data, cb)
    local rchannel = tonumber(data.mhz)
    globalMhz = rchannel
    if rchannel == nil or rchannel == 0 then
        Notify(Lang:t("error.invalid_frequency"), 'error')
        PlaySound(-1, "Place_Prop_Fail", "DLC_Dmod_Prop_Editor_Sounds", 0, 0, 1)
        cb({ connected = false, error = Lang:t("error.invalid_frequency") })
        return
    end

    if rchannel == RadioChannel then
        Notify(Lang:t("error.already_connected"), 'error')
        PlaySound(-1, "Place_Prop_Fail", "DLC_Dmod_Prop_Editor_Sounds", 0, 0, 1)
        cb({ connected = false, error = Lang:t("error.already_connected") })
        return
    end

    local restrict = FRKN.RestrictedChannels[rchannel]
    if restrict then
        local jobName, jobGrade = GetPlayerJob()
        local gang = GetPlayerGang()

        if CoreName == "qb-core" or CoreName == "qbx_core" then
            local player = Core.Functions.GetPlayerData()
            local onDuty = player and player.job and player.job.onduty == true
            local jobAllowed = restrict.jobs and restrict.jobs[jobName] == true
            local gangAllowed = restrict.gangs and gang and restrict.gangs[gang.name] == true

            if jobAllowed then
                if not onDuty then
                    Notify(Lang:t("error.not_on_duty"), 'error')
                    PlaySound(-1, "Place_Prop_Fail", "DLC_Dmod_Prop_Editor_Sounds", 0, 0, 1)
                    cb({ connected = false, error = Lang:t("error.not_on_duty") })
                    return
                end
                connectToRadio(rchannel, function(response)
                    PlaySound(-1, "CLICK_BACK", "WEB_NAVIGATION_SOUNDS_PHONE", 0, 0, 1)
                    cb(response)
                end)
                return
            end

            if gangAllowed then
                connectToRadio(rchannel, function(response)
                    PlaySound(-1, "CLICK_BACK", "WEB_NAVIGATION_SOUNDS_PHONE", 0, 0, 1)
                    cb(response)
                end)
                return
            end

            Notify(Lang:t("error.job_not_allowed"), 'error')
            PlaySound(-1, "Place_Prop_Fail", "DLC_Dmod_Prop_Editor_SOUNDS_PHONE", 0, 0, 1)
            cb({ connected = false, error = Lang:t("error.job_not_allowed") })
            return
        elseif CoreName == "es_extended" then
            local jobAllowed = restrict.jobs and restrict.jobs[jobName] == true
            if jobAllowed then
                connectToRadio(rchannel, function(response)
                    PlaySound(-1, "CLICK_BACK", "WEB_NAVIGATION_SOUNDS_PHONE", 0, 0, 1)
                    cb(response)
                end)
                return
            end

            Notify(Lang:t("error.job_not_allowed"), 'error')
            PlaySound(-1, "Place_Prop_Fail", "DLC_Dmod_Prop_Editor_SOUNDS_PHONE", 0, 0, 1)
            cb({ connected = false, error = Lang:t("error.job_not_allowed") })
            return
        end
    else
        connectToRadio(rchannel, function(response)
            PlaySound(-1, "CLICK_BACK", "WEB_NAVIGATION_SOUNDS_PHONE", 0, 0, 1)
            cb(response)
        end)
        return
    end

    Notify(Lang:t("error.unauthorized_access"), 'error')
    PlaySound(-1, "Place_Prop_Fail", "DLC_Dmod_Prop_Editor_Sounds", 0, 0, 1)
    cb({ connected = false, error = Lang:t("error.unauthorized_access") })
end)

function leaveRadio()

    TriggerCallback('frkn-radio:leftChannel', function(success)
        if success then
            globalMhz = nil
            closeEvent()
            RadioChannel = 0
            onRadio = false

            if voice == "pma-voice" then
                exports["pma-voice"]:removePlayerFromRadio()
                exports["pma-voice"]:setVoiceProperty("radioEnabled", false)

            elseif voice == "saltychat" then
                local current = exports.saltychat:GetRadioChannel(true)
                if current and current ~= '' then
                    exports.saltychat:SetRadioChannel('', true)
                end
            end

            Notify("You left the channel.", 'error')   
        else
            Notify("Failed to leave the channel.", 'error')
        end
    end, globalMhz)

end

RegisterNUICallback("setVolume", function(data, cb)
    local volume = tonumber(data.volume)
    if not volume then return end

    local clamped = math.max(0, math.min(100, volume))
    if voice == "pma-voice" then
        exports["pma-voice"]:setRadioVolume(clamped)
    elseif voice == "saltychat" then
        local volumeLevel = clamped / 100.0
        volumeLevel = volumeLevel * 10.0
        exports.saltychat:SetRadioVolume(volumeLevel)
    end

    cb("ok")
end)

function connectToRadio(channel, cb)
    if channel <= 0 then 
        Notify('You cannot connect to this channel.', 'error') 
        cb(false)
        return
    end

    if FRKN.RestrictedChannels[channel] ~= nil then
        local jobName, jobGrade = GetPlayerJob()

        if CoreName == "qb-core" or CoreName == "qbx_core" then
            local player = Core.Functions.GetPlayerData()

            if not (FRKN.RestrictedChannels[channel]["jobs"]
                and FRKN.RestrictedChannels[channel]["jobs"][jobName]
                and player.job.onduty) then

                Notify('You cannot connect to this channel.', 'error')
                cb(false)
                return
            end
        elseif CoreName == "es_extended" then
            if not (FRKN.RestrictedChannels[channel]["jobs"]
                and FRKN.RestrictedChannels[channel]["jobs"][jobName]) then

                Notify('You cannot connect to this channel.', 'error')
                cb(false)
                return
            end
        end
    end

    TriggerCallback('frkn-radio:joinChannel', function(response)
        if response == nil then
            Notify('You cannot connect to this channel.', 'error')
            cb('notchannel')
            return
        end

        if response.password then
            Notify('This channel requires a password.', 'error')
            cb({ password = response.password })
            return
        end

        if response.connected then
            RadioChannel = channel

            if onRadio then
                if voice == "pma-voice" then
                    exports["pma-voice"]:setRadioChannel(0)
                elseif voice == "saltychat" then
                    exports.saltychat:SetRadioChannel('', true)
                end
            else
                onRadio = true
                if voice == "pma-voice" then
                    exports["pma-voice"]:setVoiceProperty("radioEnabled", true)
                end
            end

            if voice == "pma-voice" then
                exports["pma-voice"]:setRadioChannel(tonumber(channel))
                exports["pma-voice"]:setRadioVolume(1.0)
            elseif voice == "saltychat" then
                local current = exports.saltychat:GetRadioChannel(true)
                if current and current ~= '' then
                    exports.saltychat:SetRadioChannel('', true)
                end
                exports.saltychat:SetRadioChannel(channel, true)
                exports.saltychat:SetRadioVolume(1.0)
            end

            if SplitStr(tostring(channel), ".")[2] ~= nil and SplitStr(tostring(channel), ".")[2] ~= "" then
                Notify('You have joined ' .. channel .. ' MHz', 'success')
            else
                Notify('You have joined ' .. channel .. '.00 MHz', 'success')
            end

            cb({ connected = true })
        else
            Notify('You cannot connect to this channel.', 'error')
            cb('notchannel')
        end
    end, channel)
end

RegisterNUICallback('confirm', function(data, cb)
    local rchannel = tonumber(data.mhz)
    globalMhz = rchannel
    if not rchannel then
        cb({ success = false, message = "Invalid channel." })
        return
    end

    if data.success then
        TriggerCallback('frkn-radio:addMember', function(channelData)
            if channelData then
                RadioChannel = rchannel

                if onRadio then
                    if voice == "pma-voice" then
                        exports["pma-voice"]:setRadioChannel(0)
                    elseif voice == "saltychat" then
                        exports.saltychat:SetRadioChannel('', true)
                    end
                else
                    onRadio = true
                    if voice == "pma-voice" then
                        exports["pma-voice"]:setVoiceProperty("radioEnabled", true)
                    end
                end

                if voice == "pma-voice" then
                    exports["pma-voice"]:setRadioChannel(rchannel)
                elseif voice == "saltychat" then
                    local current = exports.saltychat:GetRadioChannel(true)
                    if current and current ~= '' then
                        exports.saltychat:SetRadioChannel('', true)
                    end
                    exports.saltychat:SetRadioChannel(rchannel, true)
                end

                if SplitStr(tostring(rchannel), ".")[2] ~= nil and SplitStr(tostring(rchannel), ".")[2] ~= "" then
                    Notify('You have joined ' .. rchannel .. ' MHz', 'success')
                else
                    Notify('You have joined ' .. rchannel .. '.00 MHz', 'success')
                end

                cb({ success = true, channelData = channelData })
            else
                cb({ success = false, message = "Failed to join channel." })
            end
        end, rchannel)
    else
        Notify('Wrong password, cannot connect.', 'error')
        cb({ success = false, message = "Wrong password." })
    end
end)

