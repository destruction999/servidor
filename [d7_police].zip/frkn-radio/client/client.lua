-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

local radioFlashActive = false
RadioChannel = 0
RadioVolume = 100
radioMenu = false
radioProp = nil
channellist = {}
playerData = {}
globalMhz = nil
onRadio = false

function Round(num)
    return math.floor(num + 0.5)
end

function toggleRadioAnimation(state)
    RequestAnimDict(FRKN.RadioAnimation.Dict)
    while not HasAnimDictLoaded(FRKN.RadioAnimation.Dict) do
        Wait(0)
    end
    if state then
        TaskPlayAnim(PlayerPedId(), FRKN.RadioAnimation.Dict, FRKN.RadioAnimation.Animation, 2.0, 3.0, -1, 49, 0, 0, 0, 0)
        radioProp = CreateObject(-1964402432, 1.0, 1.0, 1.0, 1, 1, 0)
        AttachEntityToEntity(radioProp, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 57005), 0.14, 0.01, -0.02, 110.0, 120.0, -15.0, 1, 0, 0, 0, 2, 1)
    else
        stopRadioFlash()
        StopAnimTask(PlayerPedId(), FRKN.RadioAnimation.Dict, FRKN.RadioAnimation.Animation, 1.0)
        ClearPedTasks(PlayerPedId())
        if DoesEntityExist(radioProp) then
            DeleteObject(radioProp)
            DeleteEntity(radioProp)
            radioProp = nil
        end
    end
end

function toggleRadio(state)
    radioMenu = state
    SetNuiFocus(radioMenu, radioMenu)
    local identifier = GetPlayerIdentifier()
    if radioMenu then
        if FRKN.RadioAnimation.Enable then
            toggleRadioAnimation(true)
        end
        TriggerCallback("frkn-radio:getImg", function(avatar)
            local currentMhz = nil
            local currentChannel = nil
            for mhz, channel in pairs(channellist) do
                for _, member in ipairs(channel.members or {}) do
                    if member.identifier == identifier then
                        currentMhz = mhz
                        currentChannel = channel
                        break
                    end
                end
                if currentMhz then
                    break
                end
            end
            globalMhz = currentMhz
            SendNUIMessage({
                action = "openRadio",
                volume = RadioVolume,
                max = FRKN.MaxFrequency,
                identifier = identifier,
                avatar = avatar or "https://cdn.discordapp.com/embed/avatars/0.png",
                mhz = currentMhz,
                password = (currentChannel and currentChannel.password) or "",
                channelData = currentChannel or {},
                configChannels = FRKN.RestrictedChannels
            })
        end)
    else
        if FRKN.RadioAnimation.Enable then
            toggleRadioAnimation(false)
        end
        SendNUIMessage({
            action = "closeRadio"
        })
    end
end

RegisterNUICallback("closeRadio", function(data, cb)
    toggleRadio(false)
    cb("ok")
end)

function startRadioFlash()
    if radioFlashActive then
        return
    end
    radioFlashActive = true
    CreateThread(function()
        while radioFlashActive and radioProp and DoesEntityExist(radioProp) do
            local propCoords = GetEntityCoords(radioProp)
            local ped = PlayerPedId()
            local forward = GetEntityForwardVector(ped)
            local right = vector3(-forward.y, forward.x, 0.0)
            local lightPos = vector3(
                propCoords.x + forward.x * 2.0 + right.x * -0.5,
                propCoords.y + forward.y * 2.0 + right.y * -0.5,
                propCoords.z + 0.2
            )
            DrawLightWithRange(lightPos.x, lightPos.y, lightPos.z, 255, 255, 255, 2.5, 7.0)
            Wait(0)
        end
    end)
end

function stopRadioFlash()
    radioFlashActive = false
end

RegisterNUICallback("leftChannel", function(data, cb)
    local mhz = data.mhz
    if not mhz then
        cb({
            success = false,
            message = "Invalid channel."
        })
        return
    end
    TriggerCallback("frkn-radio:leftChannel", function(success)
        if success then
            leaveRadio()
            cb({
                success = true
            })
        else
            cb({
                success = false,
                message = "Failed to leave channel."
            })
        end
    end, mhz)
end)

RegisterNUICallback("sendChatMessage", function(data, cb)
    local message = data.message
    TriggerServerEvent("frkn-radio:sendChatMessage", RadioChannel, message)
    cb("ok")
end)

RegisterNetEvent("frkn-radio:receiveChatMessage", function(messageData)
    SendNUIMessage({
        action = "newChatMessage",
        data = messageData
    })
end)

RegisterNUICallback("flash", function(data, cb)
    if data.flash then
        startRadioFlash()
    elseif data.flash == false then
        stopRadioFlash()
    end
    cb({
        success = true
    })
end)

RegisterNUICallback("createChannel", function(data, cb)
    local mhz = tonumber(data.mhz)
    local password = data.password or ""
    if not mhz then
        cb({
            success = false,
            message = "Invalid channel.",
            type = "error"
        })
        return
    end
    TriggerCallback("frkn-radio:createChannel", function(response)
        if response.success then
            cb({
                success = response.success,
                message = response.message,
                type = response.type
            })
            connectToRadio(tonumber(mhz), function(connectResponse)
                if connectResponse.connected then
                    globalMhz = mhz
                    SendNUIMessage({
                        action = "autoConnect",
                        mhz = mhz,
                        password = password,
                        identifier = GetPlayerIdentifier(),
                        channelData = {
                            password = password,
                            members = {
                                {
                                    identifier = GetPlayerIdentifier(),
                                    name = GetPlayerName(PlayerId())
                                }
                            },
                            chat = {}
                        },
                        notify = false
                    })
                end
            end)
        else
            cb({
                success = false,
                message = response.message,
                type = response.type
            })
        end
    end, mhz, password)
end)

RegisterNUICallback("getChannels", function(data, cb)
    TriggerCallback("frkn-radio:getChannels", function(channels)
        cb(channels)
    end)
end)

function SplitStr(str, sep)
    if sep == nil then
        sep = "%s"
    end
    local result = {}
    for match in string.gmatch(str, "([^" .. sep .. "]+)") do
        result[#result + 1] = match
    end
    return result
end

function closeEvent()
    TriggerEvent("InteractSound_CL:PlayOnOne", "click", 0.6)
end

AddEventHandler("onResourceStop", function(resourceName)
    if GetCurrentResourceName() == resourceName then
        if RadioChannel ~= 0 then
            leaveRadio()
            toggleRadio(false)
        end
    end
end)

RegisterNetEvent("frkn-radio:use:client", function()
    toggleRadio(not radioMenu)
end)

RegisterNetEvent("qb-radio:onRadioDrop", function()
    if RadioChannel ~= 0 then
        leaveRadio()
    end
end)

function IsRadioOn()
    return onRadio
end

exports("IsRadioOn", IsRadioOn)

RegisterNetEvent("QBCore:Client:OnPlayerLoaded", function()
    PlayerData = GetPlayerData()
    TriggerServerEvent("frkn-radio:dataPostClient")
    DoRadioCheck()
end)

RegisterNetEvent("esx:playerLoaded", function()
    PlayerData = GetPlayerData()
    DoRadioCheck()
    TriggerServerEvent("frkn-radio:dataPostClient")
end)

RegisterNetEvent("QBCore:Client:OnPlayerUnload", function()
    DoRadioCheck()
    PlayerData = {}
    leaveradio()
end)

RegisterNetEvent("QBCore:Client:OnPlayerLoaded", function()
    PlayerData = GetPlayerData()
    DoRadioCheck()
end)

RegisterNetEvent("QBCore:Player:SetPlayerData", function(data)
    PlayerData = data
    DoRadioCheck()
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1500)
        if NetworkIsPlayerActive(PlayerId()) then
            playerData = GetPlayerData()
            TriggerServerEvent("frkn-radio:dataPostClient")
            break
        end
    end
end)

AddEventHandler("onResourceStart", function(resourceName)
    if GetCurrentResourceName() == resourceName then
        while not CoreReady do
            Citizen.Wait(0)
        end
        PlayerData = GetPlayerData()
        DoRadioCheck()
    end
end)

RegisterNetEvent("qb-radio:use", function()
    toggleRadio(not radioMenu)
end)

RegisterNetEvent("baseevents:onPlayerDied", function()
    if RadioChannel ~= 0 then
        leaveRadio()
        toggleRadio(false)
    end
end)

RegisterNetEvent("baseevents:onPlayerKilled", function()
    if RadioChannel ~= 0 then
        leaveRadio()
        toggleRadio(false)
    end
end)

RegisterNetEvent("hospital:client:Respawned", function()
    if RadioChannel ~= 0 then
        leaveRadio()
        toggleRadio(false)
    end
end)

RegisterNetEvent("esx:onPlayerDeath", function()
    if RadioChannel ~= 0 then
        leaveRadio()
        toggleRadio(false)
    end
end)

RegisterNetEvent("esx:onPlayerSpawn", function()
    if RadioChannel ~= 0 then
        leaveRadio()
        toggleRadio(false)
    end
end)

local isTalking = false
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlPressed(0, FRKN.SpeakKey) then
            if not isTalking then
                isTalking = true
                TriggerServerEvent("frkn-radio:toggleTalking", true)
            end
        elseif IsControlJustReleased(0, FRKN.SpeakKey) then
            if isTalking then
                isTalking = false
                TriggerServerEvent("frkn-radio:toggleTalking", false)
            end
        end
    end
end)

RegisterNetEvent("frkn-radio:updateSpeaking")
AddEventHandler("frkn-radio:updateSpeaking", function(identifier, speaking)
    SendNUIMessage({
        action = "radioSpeak",
        identifier = identifier,
        speaking = speaking
    })
end)

RegisterNetEvent("frkn-radio:updateChannel")
AddEventHandler("frkn-radio:updateChannel", function(channels, updateType)
    channellist = channels
    local identifier = GetPlayerIdentifier()
    local currentMhz = nil
    for mhz, channel in pairs(channellist) do
        for _, member in ipairs(channel.members or {}) do
            if member.identifier == identifier then
                currentMhz = mhz
                break
            end
        end
        if currentMhz then
            break
        end
    end
    if updateType == "allmemberupdate" then
        if currentMhz then
            SendNUIMessage({
                action = "newChatMessage",
                identifier = identifier,
                channel = currentMhz,
                members = channellist[currentMhz].members or {},
                chat = channellist[currentMhz].chat or {}
            })
            SendNUIMessage({
                action = "updateMembersOnly",
                identifier = identifier,
                channel = currentMhz,
                members = channellist[currentMhz].members or {}
            })
        else
            SendNUIMessage({
                action = "closeRadioUI",
                identifier = identifier
            })
        end
        return
    end
    if not currentMhz then
        return
    end
    if updateType == "updateChat" then
        SendNUIMessage({
            action = "newChatMessage",
            identifier = identifier,
            channel = currentMhz,
            members = channellist[currentMhz].members or {},
            chat = channellist[currentMhz].chat or {}
        })
    elseif updateType == "memberupdate" then
        SendNUIMessage({
            action = "updateMembersOnly",
            identifier = identifier,
            channel = currentMhz,
            members = channellist[currentMhz].members or {}
        })
    end
end)

RegisterNetEvent("frkn-radio:setClient", function(channels)
    channellist = channels
    local src = source
    local identifier = GetPlayerIdentifier()
    for mhz, channel in pairs(channellist) do
        for _, member in ipairs(channel.members or {}) do
            if member.identifier == identifier then
                connectToRadio(tonumber(mhz), function(response)
                    globalMhz = mhz
                    if type(response) == "table" and response.connected then
                        local message = Lang:t("success.auto_connected_message")
                        message = message:gsub("{channel}", tostring(mhz))
                        SendNUIMessage({
                            action = "autoConnect",
                            mhz = mhz,
                            password = channel.password,
                            identifier = identifier,
                            channelData = channel,
                            notify = true,
                            notifyMessage = {
                                header = Lang:t("success.auto_connected_header"),
                                message = message
                            }
                        })
                    end
                end)
                return
            end
        end
    end
end)

RegisterCommand("radio", function()
    toggleRadio(not radioMenu)
end, false)

