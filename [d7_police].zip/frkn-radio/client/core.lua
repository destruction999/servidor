-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Core = nil
CoreName = nil
CoreReady = false
Citizen.CreateThread(function()
    for k, v in pairs(Cores) do
        if GetResourceState(v.ResourceName) == "starting" or GetResourceState(v.ResourceName) == "started" then
            CoreName = v.ResourceName
            Core = v.GetFramework()
            CoreReady = true
            PlayerData = GetPlayerData()
        end
    end
end)

function TriggerCallback(name, cb, ...)
    FRKN.ServerCallbacks[name] = cb
    TriggerServerEvent('frkn-radio:server:triggerCallback', name, ...)
end

RegisterNetEvent('frkn-radio:client:triggerCallback', function(name, ...)
    if FRKN.ServerCallbacks[name] then
        FRKN.ServerCallbacks[name](...)
        FRKN.ServerCallbacks[name] = nil
    end
end)

function Notify(text, type, length)
    if not FRKN.Notify  then return end
    length = length or 5000
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        Core.Functions.Notify(text, type, length)
    elseif CoreName == "es_extended" then
        Core.ShowNotification(text)
    end
end

function GetPlayerGang()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player.gang
    end
end

function GetPlayerJob()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player.job.name, player.job.grade.level
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerData(source)
        return player.job.name, player.job.grade
    end
end

function GetPlayerData()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerData()
        return player
    end
end

function GetPlayerName()
    local playerData

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        playerData = Core.Functions.GetPlayerData()
        return playerData and playerData.charinfo and playerData.charinfo.firstname .. " " .. playerData.charinfo.lastname or nil
    elseif CoreName == "es_extended" then
        playerData = Core.GetPlayerData()
        return playerData and playerData.name
    end

    return nil
end

function GetPlayerMoney()
    local playerData

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        playerData = Core.Functions.GetPlayerData()
        return playerData and playerData.money["cash"] or nil
    elseif CoreName == "es_extended" then
        playerData = Core.GetPlayerData()
        return playerData and playerData.getMoney() or nil
    end

    return nil
end

function GetPlayerJob(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player.job.name
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerData(source)
        return player.job.name
    end
end

function GetPlayerIdentifier()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player.citizenid
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerData()
        return player.identifier
    end
end

function getVehiclePlate(vehicle)
    return GetVehicleNumberPlateText(vehicle) or "UNKNOWN"
end

RegisterNetEvent('hospital:client:DeathStatus', function(isDead)
    if isDead and onRadio and RadioChannel ~= 0 then
        leaveRadio()
    end
end)

AddEventHandler('esx:onPlayerDeath', function()
    if onRadio and RadioChannel ~= 0 then
        leaveRadio()
    end
end)

Citizen.CreateThread(function()
	local volumeData = GetResourceKvpString('volume-frkn-radio')
    if volumeData then RadioVolume = Round(tonumber(volumeData)) end
    while not CoreReady do Citizen.Wait(0) end
    if FRKN.ItemCheckLoop then
        while true do
            Citizen.Wait(1000)
            if onRadio then
                if CoreName == "qb-core" or CoreName == "qbx_core" then
                    if not DoRadioCheck() or PlayerData.metadata.isdead or PlayerData.metadata.inlaststand then
                        if RadioChannel ~= 0 then
                            leaveRadio()
                        end
                    end
                else
                    if not DoRadioCheck() then
                        if RadioChannel ~= 0 then
                            leaveRadio()
                        end
                    end
                end
            end
        end
    end
end)

function DoRadioCheck()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local PlayerData = Core.Functions.GetPlayerData() or {}
        while not next(PlayerData) do
            Citizen.Wait(0)
            PlayerData = Core.Functions.GetPlayerData() or {}
        end

        local hasOX = GetResourceState('ox_inventory') == 'started'
        if hasOX then
            local ok, oxItems = pcall(function() return exports.ox_inventory:GetPlayerItems() end)
            if ok then
                for _, item in pairs(oxItems or {}) do
                    if item and item.name == FRKN.RadioItem then
                        return true
                    end
                end
            end
        end

        for _, item in pairs(PlayerData.items or {}) do
            if item and item.name == FRKN.RadioItem then
                return true
            end
        end

        return false

    elseif CoreName == "es_extended" then
        local hasOX = GetResourceState('ox_inventory') == 'started'
        if hasOX then
            local ok, oxItems = pcall(function() return exports.ox_inventory:GetPlayerItems() end)
            if ok then
                for _, item in pairs(oxItems or {}) do
                    if item and item.name == FRKN.RadioItem then
                        return true
                    end
                end
            end
        end

        local ESX = exports["es_extended"]:getSharedObject()
        local playerData = (ESX and ESX.GetPlayerData()) or {}
        for _, item in pairs((playerData and playerData.inventory) or {}) do
            if item and item.name == FRKN.RadioItem and item.count and item.count > 0 then
                return true
            end
        end

        return false

    elseif GetResourceState('inventory') == 'started' then 
        local src = source
        local inv = exports['inventory']:getInventory(src) or {}
        for _, item in pairs(inv) do
            if item and item.name == FRKN.RadioItem and (item.count or item.amount or 0) > 0 then
                return true
            end
        end
        return false
    end
end

