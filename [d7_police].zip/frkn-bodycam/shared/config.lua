-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

FRKN = {
	ServerCallbacks = {},
    policeJobName = 'police',
	minRankToOpenDashboard = 1,
	bodycam = 'body_cam',
	customPoliceCars = {'POLICE' , 'POLICE2' , 'POLBIKE', 'IGNUS'} 
}
