-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

RegisterNetEvent("frkn-bodycam:client:openDashboard", function()
    local jobName, gradeLevel, gradeName = GetPlayerJob()
    if jobName == FRKN.policeJobName then
        if gradeLevel >= FRKN.minRankToOpenDashboard then
            SetNuiFocus(true, true)
            SendNUIMessage({ action = "openDashboard" })
        end
    else
        Notify("You are not a police officer or you are not high enough rank to open the dashboard", "error", 5000)
    end
end)

RegisterNuiCallback("getAllRecordings", function(data, cb)
    TriggerCallback("frkn-bodycam-render:getAllRecordings", function(recordings)
        cb(recordings)
    end)
end)

RegisterNetEvent("frkn-bodycam:client:setBodycamState", function()
    SendNUIMessage({ action = "setBodycamState" })
end)

RegisterNuiCallback("getBodyCamData", function(data, cb)
    TriggerCallback("frkn-bodycam:server:getOfficers", function(officers)
        cb(officers)
    end)
end)

RegisterNetEvent("frkn-bodycam:client:refreshDashCamData", function()
    SendNUIMessage({ action = "refreshDashCamData" })
end)

