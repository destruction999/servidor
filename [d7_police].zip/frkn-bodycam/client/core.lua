-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Core = nil
CoreName = nil
CoreReady = false
Citizen.CreateThread(function()
    for k, v in pairs(Cores) do
        if GetResourceState(v.ResourceName) == "starting" or GetResourceState(v.ResourceName) == "started" then
            CoreName = v.ResourceName
            Core = v.GetFramework()
            CoreReady = true
            PlayerData = GetPlayerData()
        end
    end
end)

function TriggerCallback(name, cb, ...)
    FRKN.ServerCallbacks[name] = cb
    TriggerServerEvent('frkn-bodycam:server:triggerCallback', name, ...)
end

RegisterNetEvent('frkn-bodycam:client:triggerCallback', function(name, ...)
    if FRKN.ServerCallbacks[name] then
        FRKN.ServerCallbacks[name](...)
        FRKN.ServerCallbacks[name] = nil
    end
end)

exports('bodyCam',function()
    TriggerEvent('frkn-bodycam:client:openBodyCam')            
end)

exports('bodycam_dashboard',function()
    TriggerEvent('frkn-bodycam:client:openDashboard')            
end)

function Notify(text, type, length)
    length = length or 5000
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        Core.Functions.Notify(text, type, length)
    elseif CoreName == "es_extended" then
        Core.ShowNotification(text)
    end
end

RegisterNetEvent('frkn-bodycam:client:notify', function(text, type, length)
    Notify(text, type, length)
end)

function GetPlayerData()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerData()
        return player
    end
end

function GetPlayerName()
    local playerData

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        playerData = Core.Functions.GetPlayerData()
        return playerData and playerData.charinfo and playerData.charinfo.firstname .. " " .. playerData.charinfo.lastname or nil
    elseif CoreName == "es_extended" then
        playerData = Core.GetPlayerData()
        return playerData and playerData.firstName and playerData.lastName and (playerData.firstName .. " " .. playerData.lastName) or nil
    end

    return nil
end

function GetPlayerMoney()
    local playerData

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        playerData = Core.Functions.GetPlayerData()
        return playerData and playerData.money["cash"] or nil
    elseif CoreName == "es_extended" then
        playerData = Core.GetPlayerData()
        return playerData and playerData.getMoney() or nil
    end

    return nil
end

function GetPlayerJob()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = GetPlayerData()
        if player and player.job then
            return player.job.name, player.job.grade.level, player.job.grade.name
        end
    elseif CoreName == "es_extended" then
        local player = GetPlayerData()
        if player and player.job then
            return player.job.name, player.job.grade, player.job.grade_label
        end
    end
    return nil, nil, nil
end

function GetPlayerIdentifier()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player.citizenid
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerData()
        return player.identifier
    end
end

function GetNearbyPlayers(radius, cb)
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local nearbyPlayers = {}
    local activePlayers = GetActivePlayers()
    local totalToCheck = 0
    local completed = 0

    for _, playerId in ipairs(activePlayers) do
        local targetPed = GetPlayerPed(playerId)
        local targetCoords = GetEntityCoords(targetPed)
        local distance = Vdist(playerCoords.x, playerCoords.y, playerCoords.z, targetCoords.x, targetCoords.y, targetCoords.z)

        if distance <= radius and playerId ~= PlayerId() then
            local serverId = GetPlayerServerId(playerId)
            totalToCheck = totalToCheck + 1

            TriggerCallback("frkn-policejob:characterDetail", function(data)
                
                table.insert(nearbyPlayers, {
                    id = serverId,
                    name = data.name or "Unknown",
                    job = data.job or "Unknown",
                    identifier = data.identifier or "Unknown",
                    
                })

                completed = completed + 1
                if completed == totalToCheck then
                    cb(nearbyPlayers)
                end
            end, serverId)
        end
    end

    if totalToCheck == 0 then
        cb({})
    end
end

function getVehiclePlate(vehicle)
    return GetVehicleNumberPlateText(vehicle) or "UNKNOWN"
end

local inventorySystem
local codemInv   = 'codem-inventory'
local oxInv      = 'ox_inventory'
local qsProInv   = 'qs-inventory-pro'
local origenInv  = 'origen_inventory'

if GetResourceState(codemInv) == 'started' then
    inventorySystem = 'codem'
elseif GetResourceState(oxInv) == 'started' then
    inventorySystem = 'ox'
elseif GetResourceState(qsProInv) == 'started' then
    inventorySystem = 'qs-pro'
elseif GetResourceState(origenInv) == 'started' then
    inventorySystem = 'origen'
end

HasItem = function()
    if inventorySystem == 'codem' then
        return function(items)
            local playerInventory = exports[codemInv]:getUserInventory()
            local result = {}
            if type(items) == 'table' then
                for k in pairs(items) do result[k] = 0 end
                for _, itemData in pairs(playerInventory) do
                    local name = tostring(itemData.name)
                    if items[name] then
                        result[name] = result[name] + (itemData.amount or 0)
                    end
                end
                return result
            else
                local count = 0
                for _, itemData in pairs(playerInventory) do
                    if tostring(itemData.name) == items then
                        count = count + (itemData.amount or 0)
                    end
                end
                return count
            end
        end

    elseif inventorySystem == 'ox' then
        return function(items)
            if type(items) == 'table' then
                local keys, result = {}, {}
                for k in pairs(items) do keys[#keys+1] = k; result[k] = 0 end
                local returned = exports[oxInv]:Search('count', keys)
                for k in pairs(items) do
                    result[k] = returned[k] or 0
                end
                return result
            else
                return exports[oxInv]:Search('count', items)
            end
        end

    elseif inventorySystem == 'qs-pro' then
        return function(items)
            local playerInventory = exports[qsProInv]:getUserInventory()
            if type(items) == 'table' then
                local result = {}
                for k in pairs(items) do result[k] = 0 end
                for _, itemData in pairs(playerInventory) do
                    local name = tostring(itemData.name)
                    if items[name] then
                        result[name] = result[name] + (itemData.count or itemData.amount or 0)
                    end
                end
                return result
            else
                local total = 0
                for _, itemData in pairs(playerInventory) do
                    if tostring(itemData.name) == items then
                        total = total + (itemData.count or itemData.amount or 0)
                    end
                end
                return total
            end
        end

    elseif inventorySystem == 'origen' then
        return function(items)
            local playerInventory = exports[origenInv]:GetInventory()
            local result, count = {}, 0
            if type(items) == 'table' then
                for k in pairs(items) do result[k] = 0 end
                for _, itemData in pairs(playerInventory) do
                    local name = tostring(itemData.name)
                    if items[name] then
                        result[name] = result[name] + (itemData.amount or 0)
                    end
                end
                return result
            else
                for _, itemData in pairs(playerInventory) do
                    if tostring(itemData.name) == items then
                        count = count + (itemData.amount or 0)
                    end
                end
                return count
            end
        end

    elseif CoreName == 'es_extended' then
        return function(items)
            local pd = Core.GetPlayerData() or {}
            local inv = pd.inventory or {}
            local result, count = {}, 0
            if type(items) == 'table' then
                for k in pairs(items) do result[k] = 0 end
                for _, itemData in pairs(inv) do
                    if items[itemData.name] then
                        result[itemData.name] = (itemData.count or itemData.amount)
                    end
                end
                return result
            else
                for _, itemData in pairs(inv) do
                    if itemData.name == items then
                        return itemData.count or itemData.amount
                    end
                end
                return 0
            end
        end

    elseif CoreName == 'qb-core' or CoreName == 'qbx_core' then
        return function(items)
            local pd = Core.Functions.GetPlayerData() or {}
            local inv = pd.items or {}
            if type(items) == 'table' then
                local result = {}
                for k in pairs(items) do result[k] = 0 end
                for _, itm in ipairs(inv) do
                    if items[itm.name] then
                        result[itm.name] = itm.amount or itm.count
                    end
                end
                return result
            else
                for _, itm in ipairs(inv) do
                    if itm.name == items then
                        return itm.amount or itm.count
                    end
                end
                return 0
            end
        end

    else
        return function() return 0 end
    end
end

CreateThread(function()
    while not inventorySystem do Wait(100) end 
    HasItem = HasItem()
end)

