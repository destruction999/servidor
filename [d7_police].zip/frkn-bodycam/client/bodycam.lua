-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

local isWatching = false
local activeCam = nil
local targetPed = nil
local targetServerId = nil
local originalPosition = nil
local wasInVehicle = false

local function IsPoliceVehicle(vehicle)
    if vehicle and DoesEntityExist(vehicle) then
        if GetVehicleClass(vehicle) == 18 then
            return true
        end
        local model = GetEntityModel(vehicle)
        local displayName = GetDisplayNameFromVehicleModel(model)
        for _, carName in ipairs(FRKN.customPoliceCars) do
            if displayName == carName then
                return true
            end
        end
    end
    return false
end

RegisterNetEvent("frkn-bodycam:client:openBodyCam", function()
    local jobName, gradeLevel, gradeName = GetPlayerJob()
    if jobName ~= FRKN.policeJobName then
        Notify(Lang:t("error.not_officer"), "error", 5000)
        return
    end
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local streetHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local streetName = GetStreetNameFromHashKey(streetHash)
    local zoneName = GetLabelText(GetNameOfZone(coords.x, coords.y, coords.z))
    SendNUIMessage({
        action = "openBodyCam",
        data = {
            street = streetName,
            zone = zoneName,
            rank = gradeName,
            name = GetPlayerName()
        }
    })
    SetNuiFocus(true, true)
end)

RegisterNuiCallback("streetNames", function(data, cb)
    local coords = GetEntityCoords(PlayerPedId())
    if data.targetPlayer then
        coords = GetEntityCoords(data.targetPlayer)
    end
    local streetHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local streetName = GetStreetNameFromHashKey(streetHash)
    local zoneName = GetLabelText(GetNameOfZone(coords.x, coords.y, coords.z))
    cb({
        street = streetName,
        zone = zoneName
    })
end)

RegisterNuiCallback("closeUI", function()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "closeUI" })
    TriggerEvent("frkn-bodycam:client:closeBodyScreen")
end)

RegisterNuiCallback("setBodycamStateOn", function()
    TriggerServerEvent("frkn-bodycam:server:setBodycamState", true)
end)

RegisterNuiCallback("setBodycamStateOff", function()
    TriggerServerEvent("frkn-bodycam:server:setBodycamState", false)
end)

RegisterNuiCallback("startCapture", function()
    exports["frkn-bodycam-render"]:startCapture()
end)

RegisterNuiCallback("stopCapture", function()
    local result = exports["frkn-bodycam-render"]:stopCapture()
    if result.success then
        TriggerServerEvent("frkn-bodycam-render:saveRecording", result)
    end
end)

RegisterNuiCallback("getBodyCamRecording", function(data, cb)
    TriggerCallback("frkn-bodycam-render:getBodyCamRecording", function(recordings)
        cb(recordings)
    end)
end)

RegisterNuiCallback("validateAndShowBodyCam", function(data, cb)
    if not data.playerSrc then
        Notify(Lang:t("error.invalid_id"), "error", 5000)
        cb({ success = false, error = Lang:t("error.invalid_id") })
        return
    end
    TriggerCallback("frkn-bodycam:server:validatePlayer", function(result)
        if result.success then
            TriggerEvent("frkn-bodycam:client:showBodyCam", result.data)
            cb({ success = true })
        else
            Notify(result.error, "error", 5000)
            cb({ success = false, error = result.error })
        end
    end, data.playerSrc)
end)

RegisterNuiCallback("validateAndShowDashCam", function(data, cb)
    if not data.playerSrc then
        Notify(Lang:t("error.invalid_id"), "error", 5000)
        cb({ success = false, error = Lang:t("error.invalid_id") })
        return
    end
    TriggerCallback("frkn-bodycam:server:validatePlayerInVehicle", function(result)
        if result.success then
            TriggerEvent("frkn-bodycam:client:showDashCam", result.data)
            cb({ success = true })
        else
            Notify(result.error, "error", 5000)
            cb({ success = false, error = result.error })
        end
    end, data.playerSrc)
end)

RegisterNetEvent("frkn-bodycam:client:showBodyCam", function(data)
    local myServerId = GetPlayerServerId(PlayerId())
    local targetSrc = tonumber(data.playerSrc)
    if targetSrc == myServerId then
        Notify(Lang:t("error.cannot_yourself"), "error", 5000)
        return
    end
    local myCoords = GetEntityCoords(PlayerPedId())
    local myHeading = GetEntityHeading(PlayerPedId())
    originalPosition = vector4(myCoords.x, myCoords.y, myCoords.z, myHeading)
    TriggerCallback("frkn-bodycam:server:getPedCoords", function(targetCoords)
        if not targetCoords then
            Notify(Lang:t("error.target_not_online"), "error", 5000)
            return
        end
        targetServerId = tonumber(data.playerSrc)
        DoScreenFadeOut(1000)
        while not IsScreenFadedOut() do
            Wait(100)
        end
        FreezeEntityPosition(PlayerPedId(), true)
        SetEntityVisible(PlayerPedId(), false)
        SetEntityCollision(PlayerPedId(), false, false)
        SetEntityInvincible(PlayerPedId(), true)
        NetworkSetEntityInvisibleToNetwork(PlayerPedId(), true)
        SetEntityCoords(PlayerPedId(), targetCoords.x, targetCoords.y, targetCoords.z - 100.0, false, false, false, true)
        Wait(500)
        local playerId = GetPlayerFromServerId(targetServerId)
        targetPed = GetPlayerPed(playerId)
        if not DoesEntityExist(targetPed) then
            Notify(Lang:t("error.target_not_found"), "error", 5000)
            TriggerEvent("frkn-bodycam:client:closeBodyScreen")
            return
        end
        local vehicle = GetVehiclePedIsIn(targetPed, false)
        if vehicle and IsPoliceVehicle(vehicle) then
            TriggerEvent("frkn-bodycam:client:showDashCam", data)
            return
        end
        local pedCoords = GetEntityCoords(targetPed)
        local streetHash = GetStreetNameAtCoord(pedCoords.x, pedCoords.y, pedCoords.z)
        local streetName = GetStreetNameFromHashKey(streetHash)
        local zoneName = GetLabelText(GetNameOfZone(pedCoords.x, pedCoords.y, pedCoords.z))
        SetNuiFocus(false, false)
        SendNUIMessage({ action = "closeUI" })
        SetNuiFocus(true, true)
        SendNUIMessage({
            action = "openOtherPlayerBodyCam",
            data = {
                name = data.name,
                rank = data.rank,
                callsign = data.callsign,
                street = streetName,
                zone = zoneName,
                dashcam = false,
                targetPlayer = targetPed
            }
        })
        TriggerServerEvent("frkn-bodycam:server:startWatching", data.playerSrc)
        activeCam = CreateCam("DEFAULT_SCRIPTED_FLY_CAMERA", true)
        AttachCamToPedBone(activeCam, targetPed, 46240, 0.1, 0.025, 0.1, true)
        SetCamFov(activeCam, 100.0)
        local heading = GetEntityHeading(targetPed)
        SetCamRot(activeCam, 0.0, 0.0, heading, 2)
        RenderScriptCams(true, false, 0, 1, 0)
        ShakeCam(activeCam, "HAND_SHAKE", 1.0)
        SetCamShakeAmplitude(activeCam, 2.0)
        SetTimecycleModifierStrength(0.5)
        isWatching = true
        CreateThread(function()
            while isWatching and DoesEntityExist(targetPed) do
                Wait(1)
                local pedHeading = GetEntityHeading(targetPed)
                SetCamRot(activeCam, 0.0, 0.0, pedHeading, 2)
                if not IsCamActive(activeCam) then
                    AttachCamToPedBone(activeCam, targetPed, 46240, 0.1, 0.025, 0.1, true)
                end
            end
        end)
        CreateThread(function()
            while isWatching do
                local myPos = GetEntityCoords(PlayerPedId())
                if DoesEntityExist(targetPed) then
                    local targetPos = GetEntityCoords(targetPed)
                    local distance = #(myPos - targetPos)
                    if distance > 150 then
                        SetEntityCoords(PlayerPedId(), targetPos.x, targetPos.y, targetPos.z - 100.0, false, false, false, true)
                    end
                else
                    TriggerEvent("frkn-bodycam:client:closeBodyScreen")
                    break
                end
                Wait(2500)
            end
        end)
        DoScreenFadeIn(1000)
    end, tonumber(data.playerSrc))
end)

RegisterNetEvent("frkn-bodycam:client:showDashCam", function(data)
    local myServerId = GetPlayerServerId(PlayerId())
    local targetSrc = tonumber(data.playerSrc)
    if targetSrc == myServerId then
        Notify(Lang:t("error.cannot_own_vehicle"), "error", 5000)
        return
    end
    if not originalPosition then
        local myCoords = GetEntityCoords(PlayerPedId())
        local myHeading = GetEntityHeading(PlayerPedId())
        originalPosition = vector4(myCoords.x, myCoords.y, myCoords.z, myHeading)
    end
    TriggerCallback("frkn-bodycam:server:getCarCoords", function(carCoords)
        if not carCoords then
            TriggerEvent("frkn-bodycam:client:closeBodyScreen")
            Notify(Lang:t("error.vehicle_not_found"), "error", 5000)
            return
        end
        targetServerId = tonumber(data.playerSrc)
        if not IsScreenFadedOut() then
            DoScreenFadeOut(1000)
            while not IsScreenFadedOut() do
                Wait(100)
            end
        end
        FreezeEntityPosition(PlayerPedId(), true)
        SetEntityVisible(PlayerPedId(), false)
        SetEntityCollision(PlayerPedId(), false, false)
        SetEntityInvincible(PlayerPedId(), true)
        NetworkSetEntityInvisibleToNetwork(PlayerPedId(), true)
        SetEntityCoords(PlayerPedId(), carCoords.x, carCoords.y, carCoords.z - 100.0, false, false, false, true)
        Wait(500)
        local ped = GetPlayerPed(GetPlayerFromServerId(targetServerId))
        local vehicle = GetVehiclePedIsIn(ped, false)
        if not vehicle or not DoesEntityExist(vehicle) then
            TriggerEvent("frkn-bodycam:client:closeBodyScreen")
            Notify(Lang:t("error.not_vehicle"), "error", 5000)
            return
        end
        if not IsPoliceVehicle(vehicle) then
            TriggerEvent("frkn-bodycam:client:closeBodyScreen")
            Notify(Lang:t("error.not_police_vehicle"), "error", 5000)
            return
        end
        local pedCoords = GetEntityCoords(ped)
        local streetHash = GetStreetNameAtCoord(pedCoords.x, pedCoords.y, pedCoords.z)
        local streetName = GetStreetNameFromHashKey(streetHash)
        local zoneName = GetLabelText(GetNameOfZone(pedCoords.x, pedCoords.y, pedCoords.z))
        SetNuiFocus(false, false)
        SendNUIMessage({ action = "closeUI" })
        SetNuiFocus(true, true)
        SendNUIMessage({
            action = "openOtherPlayerBodyCam",
            data = {
                name = data.name,
                rank = data.rank,
                callsign = data.callsign,
                street = streetName,
                zone = zoneName,
                dashcam = true,
                targetPlayer = ped
            }
        })
        TriggerServerEvent("frkn-bodycam:server:startWatching", data.playerSrc)
        activeCam = CreateCam("DEFAULT_SCRIPTED_FLY_CAMERA", true)
        SetCamFov(activeCam, 80.0)
        local boneIndex = GetEntityBoneIndexByName(vehicle, "windscreen")
        if boneIndex == -1 then
            boneIndex = GetEntityBoneIndexByName(vehicle, "chassis")
        end
        if boneIndex ~= -1 then
            AttachCamToVehicleBone(activeCam, vehicle, boneIndex, true, 0.0, 0.0, 0.0, 0.0, 0.35, 0.79, true)
        else
            AttachCamToEntity(activeCam, vehicle, 0.0, 0.0, 0.0, true)
        end
        RenderScriptCams(true, false, 0, 1, 0)
        isWatching = true
        ShakeCam(activeCam, "HAND_SHAKE", 0.3)
        SetCamShakeAmplitude(activeCam, 0.8)
        SetTimecycleModifierStrength(1.0)
        CreateThread(function()
            while isWatching do
                local myPos = GetEntityCoords(PlayerPedId())
                if DoesEntityExist(vehicle) then
                    local vehiclePos = GetEntityCoords(vehicle)
                    local distance = #(myPos - vehiclePos)
                    if distance > 150 then
                        SetEntityCoords(PlayerPedId(), vehiclePos.x, vehiclePos.y, vehiclePos.z - 100.0, false, false, false, true)
                    end
                else
                    TriggerEvent("frkn-bodycam:client:closeBodyScreen")
                    break
                end
                Wait(2500)
            end
        end)
        CreateThread(function()
            while isWatching and DoesEntityExist(vehicle) do
                Wait(0)
                if not IsCamActive(activeCam) then
                    local bone = GetEntityBoneIndexByName(vehicle, "windscreen")
                    if bone == -1 then
                        bone = GetEntityBoneIndexByName(vehicle, "chassis")
                    end
                    if bone ~= -1 then
                        AttachCamToVehicleBone(activeCam, vehicle, bone, true, 0.0, 0.0, 0.0, 0.0, 0.35, 0.79, true)
                    else
                        AttachCamToEntity(activeCam, vehicle, 0.0, 0.0, 0.0, true)
                    end
                end
            end
        end)
        DoScreenFadeIn(1000)
    end, tonumber(data.playerSrc))
end)

RegisterNuiCallback("showBodyCam", function(data, cb)
    TriggerCallback("frkn-bodycam:server:validatePlayer", function(result)
        if result.success then
            TriggerEvent("frkn-bodycam:client:showBodyCam", result.data)
            cb({ success = true })
        else
            Notify(result.error, "error", 5000)
            cb({ success = false, error = result.error })
        end
    end, data.playerSrc)
end)

RegisterNuiCallback("showDashCam", function(data, cb)
    TriggerCallback("frkn-bodycam:server:validatePlayerInVehicle", function(result)
        if result.success then
            TriggerEvent("frkn-bodycam:client:showBodyCam", result.data)
            cb({ success = true })
        else
            Notify(result.error, "error", 5000)
            cb({ success = false, error = result.error })
        end
    end, data.playerSrc)
end)

RegisterNuiCallback("closeBodyScreen", function(data, cb)
    TriggerEvent("frkn-bodycam:client:closeBodyScreen", data)
end)

RegisterNetEvent("frkn-bodycam:client:closeBodyScreen", function()
    TriggerServerEvent("frkn-bodycam:server:stopWatching")
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "closeUI" })
    if isWatching then
        DoScreenFadeOut(1000)
        while not IsScreenFadedOut() do
            Wait(100)
        end
        if activeCam then
            RenderScriptCams(false, false, 0, 1, 0)
            DestroyCam(activeCam, false)
            activeCam = nil
        end
        FreezeEntityPosition(PlayerPedId(), false)
        SetEntityVisible(PlayerPedId(), true)
        SetEntityCollision(PlayerPedId(), true, true)
        SetEntityInvincible(PlayerPedId(), false)
        NetworkSetEntityInvisibleToNetwork(PlayerPedId(), false)
        if originalPosition then
            SetEntityCoords(PlayerPedId(), originalPosition.x, originalPosition.y, originalPosition.z, false, false, false, true)
            SetEntityHeading(PlayerPedId(), originalPosition.w)
            originalPosition = nil
        end
        isWatching = false
        targetServerId = nil
        targetPed = nil
        ClearTimecycleModifier()
        DoScreenFadeIn(1000)
    end
    if PlyInSelfCam then
        DoScreenFadeOut(1000)
        while not IsScreenFadedOut() do
            Wait(100)
        end
        if activeCam then
            RenderScriptCams(false, false, 0, 1, 0)
            DestroyCam(activeCam, false)
            activeCam = nil
        end
        FreezeEntityPosition(PlayerPedId(), false)
        PlyInSelfCam = false
        targetServerId = nil
        targetPed = nil
        ClearTimecycleModifier()
        DoScreenFadeIn(1000)
    end
end)

RegisterNetEvent("frkn-bodycam:client:closeDashcamView", function()
    TriggerServerEvent("frkn-bodycam:server:stopWatching")
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "closeUI" })
    if isWatching then
        DoScreenFadeOut(1000)
        while not IsScreenFadedOut() do
            Wait(100)
        end
        if activeCam then
            RenderScriptCams(false, false, 0, 1, 0)
            DestroyCam(activeCam, false)
            activeCam = nil
        end
        FreezeEntityPosition(PlayerPedId(), false)
        SetEntityVisible(PlayerPedId(), true)
        SetEntityCollision(PlayerPedId(), true, true)
        SetEntityInvincible(PlayerPedId(), false)
        NetworkSetEntityInvisibleToNetwork(PlayerPedId(), false)
        if originalPosition then
            SetEntityCoords(PlayerPedId(), originalPosition.x, originalPosition.y, originalPosition.z, false, false, false, true)
            SetEntityHeading(PlayerPedId(), originalPosition.w)
            originalPosition = nil
        end
        isWatching = false
        targetServerId = nil
        targetPed = nil
        ClearTimecycleModifier()
        DoScreenFadeIn(1000)
    end
    Notify(Lang:t("general.closed_dashcam"), "info", 5000)
end)

CreateThread(function()
    while true do
        Wait(1000)
        local jobName = GetPlayerJob()
        if jobName ~= "police" then
            return
        end
        if IsPedInAnyVehicle(PlayerPedId(), false) then
            local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
            if IsPoliceVehicle(vehicle) then
                if not wasInVehicle then
                    TriggerServerEvent("frkn-bodycam:server:refreshDashCamData")
                end
                local networkId = NetworkGetNetworkIdFromEntity(vehicle)
                TriggerServerEvent("frkn-bodycam:server:playerEnteredVehicle", { networkId = networkId })
                Wait(1000)
                wasInVehicle = true
            end
        else
            TriggerServerEvent("frkn-bodycam:server:playerExitedVehicle")
            if wasInVehicle then
                TriggerServerEvent("frkn-bodycam:server:refreshDashCamData")
                wasInVehicle = false
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(3000)
        if isWatching and targetServerId then
            local playerId = GetPlayerFromServerId(targetServerId)
            if playerId == -1 or playerId == nil then
                TriggerEvent("frkn-bodycam:client:closeBodyScreen")
                Notify(Lang:t("general.disconnected"), "info", 5000)
            else
                local ped = GetPlayerPed(playerId)
                if not DoesEntityExist(ped) then
                    TriggerEvent("frkn-bodycam:client:closeBodyScreen")
                    Notify(Lang:t("general.entity_not_found"), "info", 5000)
                else
                    local vehicle = GetVehiclePedIsIn(ped, false)
                    if isWatching and not vehicle and not PlyInSelfCam then
                        TriggerEvent("frkn-bodycam:client:closeDashcamView")
                    end
                end
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(2000)
        if isWatching and targetServerId then
            local playerId = GetPlayerFromServerId(targetServerId)
            if playerId ~= -1 and playerId ~= nil then
                local ped = GetPlayerPed(playerId)
                if DoesEntityExist(ped) then
                    local coords = GetEntityCoords(ped)
                    local streetHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
                    local streetName = GetStreetNameFromHashKey(streetHash)
                    local zoneName = GetLabelText(GetNameOfZone(coords.x, coords.y, coords.z))
                    SendNUIMessage({
                        action = "updateLocation",
                        data = {
                            street = streetName,
                            zone = zoneName
                        }
                    })
                end
            end
        end
    end
end)

function CheckBodycam()
    while true do
        Wait(1000)
        local itemCount = HasItem(FRKN.bodycam)
        if itemCount == 0 then
            SendNUIMessage({ action = "stopBodycam" })
            TriggerServerEvent("frkn-bodycam:server:setBodycamState", false)
        end
    end
end

CheckBodycam()

