let recordings = [];
let currentView = 'cameras'; 
let currentCameraType = 'body'; 
let playerData = {};
let dashboardData = {
    dashCameras: [],
    bodyCameras: [],
    savedRecordings: []
};

window.addEventListener("message", function (e) {
    e = e.data
    switch (e.action) {
    case "openBodyCam":
        return openBodyCam(e.data);
    case "closeUI":
        return closeUI();
    case "openDashboard":
        return openDashboard();
    case "openOtherPlayerBodyCam":
        return openOtherPlayerBodyCam(e.data);
    case "setBodycamState":
        return refreshDashboardData();
    case "refreshDashCamData":
        return refreshDashboardData();
    case "stopBodycam":
        return stopBodycam();
    default:
    return;
    }
});

$(document).ready(function() {
    $('.bodycam-menu').css('display', 'none');
    $('.dashboard').css('display', 'none');
    $('.body-screen').css('display', 'none');
});

function stopBodycam() {
    $('.record-bg').css('display', 'none');
    $('#start-bodycam').text('START BODYCAM');
}

function openOtherPlayerBodyCam(data) {
    $('.body-screen').css('display', 'flex');
    $('.body-screen .rank-box .rank').text(data.rank);
    $('.body-screen .rank-box .name').text(data.name);
    $('.body-screen .screen-street').text(data.street + ", " + data.zone);
    if (data.dashcam) {
        $('#bodycam-title').text('DASH CAMERA');
    } else {
        $('#bodycam-title').text('BODY CAMERA');
    }
    
    if (window.bodycamIntervalId) {
        clearInterval(window.bodycamIntervalId);
    }
    
    $.post(`https://${GetParentResourceName()}/streetNames`, JSON.stringify({
        targetPlayer: data.targetPlayer
    }), function(data) {
        $('.body-screen .screen-street').text(data.street + ", " + data.zone);
    }, 'json').fail(function(error) {
        console.error('Error fetching street names:', error);
    });
    
    const intervalId = setInterval(() => {
        $.post(`https://${GetParentResourceName()}/streetNames`, JSON.stringify({
            targetPlayer: data.targetPlayer
        }), function(data) {
            $('.body-screen .screen-street').text(data.street + ", " + data.zone);
        }, 'json').fail(function(error) {
            console.error('Error fetching street names:', error);
        });
    }, 1000);
    
    window.bodycamIntervalId = intervalId;
}


function openBodyCam(data) {
    $('.bodycam-menu').css('display', 'flex');
    $('#street-bodycam').text(data.street + ", " + data.zone);
    playerData = data
    $.post(`https://${GetParentResourceName()}/getBodyCamRecording`, JSON.stringify({}), function(recordings) {
        populateRecordingsList(recordings);
    }, 'json').fail(function(error) {
        console.error('Error fetching recordings:', error);
    });
}

function populateRecordingsList(recordings) {
    
    const listWrapper = $('.list-wrapper');
    listWrapper.empty();
    
    if (recordings && recordings.length > 0) {
        recordings.forEach((recording, index) => {
            
            let videoUrl = '';
            try {
                if (recording.recording) {
                    const parsedRecording = JSON.parse(recording.recording);
                    videoUrl = parsedRecording || '';
                }
            } catch (e) {
                console.error('Error parsing recording data:', e);
            }
            
            const listItem = $('<div>')
                .addClass('list-item')
                .text(recording.created_at)
                .attr('data-video-url', videoUrl);
            
            if (index === 0) {
                listItem.addClass('active');
                if (videoUrl) {
                    playVideo(videoUrl);
                }
            }
            
            listWrapper.append(listItem);
        });
    } else {
        listWrapper.append('<div class="list-item">No recordings found</div>');
    }
}

function closeUI() {
    $('.bodycam-menu').css('display', 'none');
    $('.dashboard').css('display', 'none');
    $('.body-screen').css('display', 'none');
    
    const video = document.getElementById('bodycam-video');
    if (video) {
        video.pause();
        video.currentTime = 0;
    }
    showDefaultImage();
}

function playVideo(videoUrl) {
    
    const video = document.getElementById('bodycam-video');
    const defaultAvatar = document.getElementById('default-avatar');
    
    if (video && defaultAvatar) {
        defaultAvatar.style.display = 'none';
        video.style.display = 'block';
        
        video.src = videoUrl;
        video.load();
        video.play()
    } else {
        console.error('Video or avatar element not found');
    }
}

function showDefaultImage() {
    const video = document.getElementById('bodycam-video');
    const defaultAvatar = document.getElementById('default-avatar');
    
    if (video && defaultAvatar) {
        video.pause();
        video.currentTime = 0;
        video.style.display = 'none';
        
        defaultAvatar.style.display = 'block';
    }
}

function openDashboard() {
    $('.dashboard').css('display', 'block');
    loadDashboardData();
}

function refreshDashboardData() {
    loadDashboardData();
}

function loadDashboardData() {
    $.post(`https://${GetParentResourceName()}/getBodyCamData`, JSON.stringify({}), function(cacheData) {
        dashboardData.dashCameras = cacheData.filter(item => item.isInVehicle === 1);
        dashboardData.bodyCameras = cacheData.filter(item => item.isInVehicle === 0);
        $('#dash-cameras-count').text(dashboardData.dashCameras.length);
        $('#body-cameras-count').text(dashboardData.bodyCameras.length);
        
        restoreCurrentView();
    });
    
    $.post(`https://${GetParentResourceName()}/getAllRecordings`, JSON.stringify({}), function(allRecordings) {
        const savedRecordings = allRecordings || [];
        $('#saved-recordings-count').text(savedRecordings.length);
        dashboardData.savedRecordings = savedRecordings;
        
        if (currentView === 'saved') {
            populateCamerasGrid(dashboardData.savedRecordings, 'Recording');
        }
    });
}

function showDashCameras() {
    currentView = 'dash';
    populateCamerasGrid(dashboardData.dashCameras, 'Dash Camera');
}

function showBodyCameras() {
    currentView = 'body';
    populateCamerasGrid(dashboardData.bodyCameras, 'Body Camera');
}

function showSavedRecordings() {
    currentView = 'saved';
    populateCamerasGrid(dashboardData.savedRecordings, 'Recording');
}

function restoreCurrentView() {
    if (!currentView || currentView === 'cameras') {
        currentView = 'body';
    }
    
    switch (currentView) {
        case 'dash':
            populateCamerasGrid(dashboardData.dashCameras, 'Dash Camera');
            break;
        case 'body':
            populateCamerasGrid(dashboardData.bodyCameras, 'Body Camera');
            break;
        case 'saved':
            break;
        default:
            currentView = 'body';
            populateCamerasGrid(dashboardData.bodyCameras, 'Body Camera');
            break;
    }
}

function populateCamerasGrid(recordings, type) {
    const camerasGrid = $('.cameras-grid');
    camerasGrid.empty();
    
    if (recordings && recordings.length > 0) {
        recordings.forEach((recording, index) => {
            let videoUrl = '';
            let displayName = '';
            let displayRole = '';
            let displayId = '';
            
            if (type === 'Recording') {
                try {
                    if (recording.recording) {
                        const parsedRecording = JSON.parse(recording.recording);
                        videoUrl = parsedRecording || '';
                    }
                } catch (e) {
                    console.error('Error parsing recording data:', e);
                }
                displayName = `${type} ${recording.id}`;
                displayRole = `● ${recording.cid || 'Unknown'}`;
                displayId = recording.created_at || 'Unknown Date';
            } else {
                displayName = recording.name || 'Unknown Officer';
                displayRole = `● ${recording.rank || 'Unknown Rank'}`;
                displayId = `Callsign: ${recording.callsign || 'N/A'}`;
            }
            
            const videoCard = $(`
                <div class="camera-card" data-video-url="${videoUrl}" data-recording-id="${recording.id || recording.playerSrc}">
                    <div class="camera-avatar">
                        <img src="../html/images/player-img-2.png" alt="">
                    </div>
                    <div class="camera-name">${displayName}</div>
                    <div class="camera-role">${displayRole}</div>
                    <hr>
                    <img src="../html/images/item-bg.svg" class="item-bg" alt="">
                    <div class="camera-actions">
                        <button class="watch-btn">${type === 'Recording' ? 'PLAY' : 'VIEW'}</button>
                    </div>
                    <div class="camera-id">${displayId}</div>
                </div>
            `);
            camerasGrid.append(videoCard);
        });
    } else {
        camerasGrid.append(`<div class="no-cameras">No ${type.toLowerCase()}s found</div>`);
    }
}



$(document).on('keydown', function(event) {
    if (event.key === 'Escape') {
        $.post(`https://${GetParentResourceName()}/closeUI`, JSON.stringify({}));
    }
});

$(document).on('click', '.list-item', function () {
    $('.list-item').removeClass('active');   
    $(this).addClass('active');
    
    const videoUrl = $(this).attr('data-video-url');
    
    if (videoUrl) {
        playVideo(videoUrl);
    } else {
        showDefaultImage();
    }
});

$(document).on('click', '#start-bodycam', function () {
    const button = $(this);
    const currentText = button.text();
    
    if (currentText === 'START BODYCAM') {
        button.text('STOP BODYCAM');
        $('.record-bg').css('display', 'block');
        $('.record-bg .body-name').text(playerData.name);
        $('.record-bg .street').text(playerData.street + ", " + playerData.zone);
        $('.record-bg .general-box').text(playerData.rank);
        
        $.post(`https://${GetParentResourceName()}/streetNames`, JSON.stringify({}), function(data) {
            $('.record-bg .street').text(data.street + ", " + data.zone);
        }, 'json').fail(function(error) {
            console.error('Error fetching street names:', error);
        });
        
        const intervalId = setInterval(() => {
            $.post(`https://${GetParentResourceName()}/streetNames`, JSON.stringify({}), function(data) {
                $('.record-bg .street').text(data.street + ", " + data.zone);
            }, 'json').fail(function(error) {
                console.error('Error fetching street names:', error);
            });
        }, 1000);
        
        window.bodycamIntervalId = intervalId;
        $.post(`https://${GetParentResourceName()}/setBodycamStateOn`, JSON.stringify({}));
    } else {
        button.text('START BODYCAM');
        $('.record-bg').css('display', 'none');
        
        if (window.bodycamIntervalId) {
            clearInterval(window.bodycamIntervalId);
            window.bodycamIntervalId = null;
        }
        
        $.post(`https://${GetParentResourceName()}/setBodycamStateOff`, JSON.stringify({}));
    }
});

$(document).on('click', '#start-recording', function () {
    const button = $(this);
    const currentText = button.text();
    
    if (currentText === 'START RECORDING') {
        button.text('STOP RECORDING');
        $('.record-bg').css('display', 'block');
        $('.record-bg .body-name').text(playerData.name);
        $('.record-bg .street').text(playerData.street + ", " + playerData.zone);
        $('.record-bg .general-box').text(playerData.rank);

        $.post(`https://${GetParentResourceName()}/startCapture`, JSON.stringify({}));
        
        $.post(`https://${GetParentResourceName()}/streetNames`, JSON.stringify({}), function(data) {
            $('.record-bg .street').text(data.street + ", " + data.zone);
        }, 'json').fail(function(error) {
            console.error('Error fetching street names:', error);
        });
        
        const intervalId = setInterval(() => {
            $.post(`https://${GetParentResourceName()}/streetNames`, JSON.stringify({}), function(data) {
                $('.record-bg .street').text(data.street + ", " + data.zone);
            }, 'json').fail(function(error) {
                console.error('Error fetching street names:', error);
            });
        }, 1000);
        
        window.bodycamIntervalId = intervalId;
        
    } else {
        button.text('START RECORDING');
        $('.record-bg').css('display', 'none');
        
        if (window.bodycamIntervalId) {
            clearInterval(window.bodycamIntervalId);
            window.bodycamIntervalId = null;
        }
        
        $.post(`https://${GetParentResourceName()}/stopCapture`, JSON.stringify({}));
    }
});

$(document).on('click', '#close-body-screen', function() {
    $('.body-screen').css('display', 'none');
    $.post(`https://${GetParentResourceName()}/closeBodyScreen`, JSON.stringify({}));
});

$(document).on('click', '#saved-recordings-btn', function() {
    showSavedRecordings();
});

$(document).on('click', '.body-cameras', function() {
    showBodyCameras();
});

$(document).on('click', '.dash-cameras', function() {
    showDashCameras();
});

function openVideoModal(videoUrl, title, date) {
    const modal = $('#video-modal');
    const modalVideo = $('#modal-video');
    const modalTitle = $('#video-modal-title');
    
    modalTitle.text(`${title} - ${date}`);
    modalVideo.attr('src', videoUrl);
    modal.show();
    
    modalVideo[0].load();
    modalVideo[0].play().catch(error => {
        console.error('Error playing video:', error);
    });
}

$(document).on('click', '#video-modal-close', function() {
    const modal = $('#video-modal');
    const modalVideo = $('#modal-video');
    
    modalVideo[0].pause();
    modalVideo[0].currentTime = 0;
    modal.hide();
});

$(document).on('click', '.video-modal', function(e) {
    if (e.target === this) {
        const modal = $('#video-modal');
        const modalVideo = $('#modal-video');
        
        modalVideo[0].pause();
        modalVideo[0].currentTime = 0;
        modal.hide();
    }
});

$(document).on('click', '.camera-card .watch-btn', function() {
    const videoUrl = $(this).closest('.camera-card').attr('data-video-url');
    const recordingId = $(this).closest('.camera-card').attr('data-recording-id');
    const recordingName = $(this).closest('.camera-card').find('.camera-name').text();
    const recordingDate = $(this).closest('.camera-card').find('.camera-id').text();
    
    if (currentView === 'saved' && videoUrl && videoUrl !== '') {
        openVideoModal(videoUrl, recordingName, recordingDate);
    } else {
        const cameraData = currentView === 'dash' ? dashboardData.dashCameras : dashboardData.bodyCameras;
        const camera = cameraData.find(cam => cam.playerSrc == recordingId);
        
        if (camera) {
            const cameraInfo = {
                playerSrc: camera.playerSrc,
                name: camera.name,
                rank: camera.rank,
                callsign: camera.callsign,
                isInVehicle: camera.isInVehicle
            };
            if (camera.isInVehicle === 1) {
                $.post(`https://${GetParentResourceName()}/showDashCam`, JSON.stringify(cameraInfo));
            } else {
                $.post(`https://${GetParentResourceName()}/showBodyCam`, JSON.stringify(cameraInfo));
            }
        } else {
            console.error('Camera not found for recordingId:', recordingId);
        }
    }
});

$(document).on('click', '.close-btn', function() {
    $.post(`https://${GetParentResourceName()}/closeUI`, JSON.stringify({}));
});

