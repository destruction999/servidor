-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Core = nil
CoreName = nil
CoreReady = false

CreateThread(function()
    for k, v in pairs(Cores) do
        if GetResourceState(v.ResourceName) == "starting" or GetResourceState(v.ResourceName) == "started" then
            CoreName = v.ResourceName
            Core = v.GetFramework()
            CoreReady = true
        end
    end
end)

RegisterNetEvent("frkn-bodycam:server:triggerCallback", function(name, ...)
    local src = source
    if FRKN.ServerCallbacks and FRKN.ServerCallbacks[name] then
        FRKN.ServerCallbacks[name](src, function(...)
            TriggerClientEvent("frkn-bodycam:client:triggerCallback", src, name, ...)
        end, ...)
    end
end)

function GetPlayerData(src)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(src)
        return player
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(src)
        return player
    end
    return nil
end

function GetPlayerJob(src)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = GetPlayerData(src)
        if player and player.PlayerData and player.PlayerData.job then
            return player.PlayerData.job.name, player.PlayerData.job.grade.level, player.PlayerData.job.grade.name
        end
    elseif CoreName == "es_extended" then
        local player = GetPlayerData(src)
        if player and player.job then
            return player.job.name, player.job.grade, player.job.grade_label
        end
    end
    return nil, nil, nil
end

function GetPlayerName(src)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = GetPlayerData(src)
        if player and player.PlayerData and player.PlayerData.charinfo then
            return player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
        end
    elseif CoreName == "es_extended" then
        local player = GetPlayerData(src)
        if player then
            return player.getName()
        end
    end
    return "Unknown"
end

function GetPlayerIdentifier(src)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = GetPlayerData(src)
        if player and player.PlayerData then
            return player.PlayerData.citizenid
        end
    elseif CoreName == "es_extended" then
        local player = GetPlayerData(src)
        if player then
            return player.identifier
        end
    end
    return nil
end

function Notify(src, text, type, length)
    TriggerClientEvent("frkn-bodycam:client:notify", src, text, type, length or 5000)
end

