-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

local bodycamStates = {}
local vehicleData = {}
local watchingPlayers = {}

FRKN.ServerCallbacks = FRKN.ServerCallbacks or {}

FRKN.ServerCallbacks["frkn-bodycam:server:validatePlayer"] = function(src, cb, targetSrc)
    local targetId = tonumber(targetSrc)
    if not targetId then
        cb({ success = false, error = Lang:t("error.validate_invalid_id") })
        return
    end
    local targetPed = GetPlayerPed(targetId)
    if not targetPed or targetPed == 0 then
        cb({ success = false, error = Lang:t("error.validate_not_online") })
        return
    end
    local jobName, gradeLevel, gradeName = GetPlayerJob(targetId)
    if not jobName then
        cb({ success = false, error = Lang:t("error.validate_no_data") })
        return
    end
    if jobName ~= FRKN.policeJobName then
        cb({ success = false, error = Lang:t("error.validate_not_police") })
        return
    end
    if not bodycamStates[targetId] then
        cb({ success = false, error = Lang:t("error.validate_bodycam_off") })
        return
    end
    local playerName = GetPlayerName(targetId)
    cb({
        success = true,
        data = {
            playerSrc = targetId,
            name = playerName,
            rank = gradeName,
            callsign = ""
        }
    })
end

FRKN.ServerCallbacks["frkn-bodycam:server:validatePlayerInVehicle"] = function(src, cb, targetSrc)
    local targetId = tonumber(targetSrc)
    if not targetId then
        cb({ success = false, error = Lang:t("error.validate_invalid_id") })
        return
    end
    local targetPed = GetPlayerPed(targetId)
    if not targetPed or targetPed == 0 then
        cb({ success = false, error = Lang:t("error.validate_not_online") })
        return
    end
    local jobName, gradeLevel, gradeName = GetPlayerJob(targetId)
    if not jobName then
        cb({ success = false, error = Lang:t("error.validate_no_data") })
        return
    end
    if jobName ~= FRKN.policeJobName then
        cb({ success = false, error = Lang:t("error.validate_not_police") })
        return
    end
    if not vehicleData[targetId] then
        cb({ success = false, error = Lang:t("error.not_vehicle") })
        return
    end
    local playerName = GetPlayerName(targetId)
    cb({
        success = true,
        data = {
            playerSrc = targetId,
            name = playerName,
            rank = gradeName,
            callsign = ""
        }
    })
end

FRKN.ServerCallbacks["frkn-bodycam:server:getPedCoords"] = function(src, cb, targetSrc)
    local targetId = tonumber(targetSrc)
    if not targetId then
        cb(nil)
        return
    end
    local targetPed = GetPlayerPed(targetId)
    if not targetPed or targetPed == 0 then
        cb(nil)
        return
    end
    local coords = GetEntityCoords(targetPed)
    cb({ x = coords.x, y = coords.y, z = coords.z })
end

FRKN.ServerCallbacks["frkn-bodycam:server:getCarCoords"] = function(src, cb, targetSrc)
    local targetId = tonumber(targetSrc)
    if not targetId then
        cb(nil)
        return
    end
    local targetPed = GetPlayerPed(targetId)
    if not targetPed or targetPed == 0 then
        cb(nil)
        return
    end
    local coords = GetEntityCoords(targetPed)
    cb({ x = coords.x, y = coords.y, z = coords.z })
end

FRKN.ServerCallbacks["frkn-bodycam:server:getOfficers"] = function(src, cb)
    local officers = {}
    local players = GetPlayers()
    for _, playerId in ipairs(players) do
        local id = tonumber(playerId)
        local jobName, gradeLevel, gradeName = GetPlayerJob(id)
        if jobName == FRKN.policeJobName then
            local playerName = GetPlayerName(id)
            table.insert(officers, {
                id = id,
                name = playerName,
                rank = gradeName,
                bodycamOn = bodycamStates[id] or false,
                inVehicle = vehicleData[id] ~= nil
            })
        end
    end
    cb(officers)
end

RegisterNetEvent("frkn-bodycam:server:setBodycamState", function(state)
    local src = source
    bodycamStates[src] = state
    TriggerClientEvent("frkn-bodycam:client:setBodycamState", src)
    for watcherId, targetId in pairs(watchingPlayers) do
        if targetId == src then
            TriggerClientEvent("frkn-bodycam:client:refreshDashCamData", watcherId)
        end
    end
end)

RegisterNetEvent("frkn-bodycam:server:startWatching", function(targetSrc)
    local src = source
    watchingPlayers[src] = tonumber(targetSrc)
end)

RegisterNetEvent("frkn-bodycam:server:stopWatching", function()
    local src = source
    watchingPlayers[src] = nil
end)

RegisterNetEvent("frkn-bodycam:server:playerEnteredVehicle", function(data)
    local src = source
    vehicleData[src] = data
    TriggerClientEvent("frkn-bodycam:client:refreshDashCamData", -1)
end)

RegisterNetEvent("frkn-bodycam:server:playerExitedVehicle", function()
    local src = source
    if vehicleData[src] then
        vehicleData[src] = nil
        for watcherId, targetId in pairs(watchingPlayers) do
            if targetId == src then
                TriggerClientEvent("frkn-bodycam:client:closeDashcamView", watcherId)
            end
        end
    end
end)

RegisterNetEvent("frkn-bodycam:server:refreshDashCamData", function()
    TriggerClientEvent("frkn-bodycam:client:refreshDashCamData", -1)
end)

AddEventHandler("playerDropped", function(reason)
    local src = source
    bodycamStates[src] = nil
    vehicleData[src] = nil
    for watcherId, targetId in pairs(watchingPlayers) do
        if targetId == src then
            TriggerClientEvent("frkn-bodycam:client:closeBodyScreen", watcherId)
            watchingPlayers[watcherId] = nil
        end
    end
    watchingPlayers[src] = nil
end)

