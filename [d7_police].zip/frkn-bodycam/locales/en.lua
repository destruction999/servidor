

local Translations = {
    error = {
        not_officer = "You are not an officer!",
        invalid_id = "Invalid player ID provided!",
        cannot_yourself = "You cannot watch yourself!",
        target_not_online = "Target player not found or too far away!",
        target_not_found = "Target player entity not found after teleporting!",
        cannot_own_vehicle = "You cannot watch your own vehicle dashcam!",
        vehicle_not_found = "No vehicle found for the target player!",
        not_vehicle = "Target player is not in a vehicle!",
        not_police_vehicle = "Target vehicle is not a police vehicle!",

        validate_invalid_id = "Invalid player ID",
        validate_not_online = "Target player not found or has disconnected",
        validate_no_data = "Target player data not found",
        validate_bodycam_off = "Target player's bodycam is not active",
        validate_not_police = "Target player is not an active police officer",
        
        validate_invalid_id = "Invalid player ID",
        validate_not_online = "Target player not found or has disconnected",
        validate_no_data = "Target player data not found",
        validate_bodycam_off = "Target player's bodycam is not active",
        validate_not_police = "Target player is not an active police officer",
        player_not_found = "Player not found",
    },

    success = {
        validate_ok = "Player validation successful",
        validate_ok = "Player validation successful",

    },

    general = {
        closed_dashcam = "The officer has exited their vehicle. Dashcam view closed.",
        disconnected = "Target player has disconnected. View closed.",
        entity_not_found = "Target player entity not found. View closed.",
    }
}

Lang = Lang or Locale:new({
    phrases = Translations,
    warnOnMissing = true
})

